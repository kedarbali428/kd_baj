package com.bajaj.bfsd.loanaccount.dao.impl;

import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.FETCH_APLLICANT_DETAILS;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.loanaccount.bean.ApplicantDeatilsForNotification;
import com.bajaj.bfsd.loanaccount.dao.ProductDao;
import com.bajaj.bfsd.loanaccount.entity.Applicant;
import com.bajaj.bfsd.loanaccount.entity.Application;
import com.bajaj.bfsd.loanaccount.entity.ApplicationApplicant;
import com.bajaj.bfsd.loanaccount.model.LoanProduct;
import com.bajaj.bfsd.loanaccount.model.LoanProductType;
import com.bajaj.bfsd.loanaccount.util.LoanAccountConstants;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RefreshScope
@Component
public class ProductDaoImpl extends BFLComponent implements ProductDao {
	
	private static final String CLASS_NAME = ProductDaoImpl.class.getCanonicalName(); 
	
	@Autowired
	EntityManager entityManager;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private BFLLoggerUtilExt logger;

	@Override
	@Transactional
	public LoanProductType getLoanTypeDesc(String loanType) {
		LoanProductType loanProductType = null;
		Query query = entityManager
				.createQuery("from  LoanProductType lp where lp.loantype =:loanType");
		query.setParameter("loanType", loanType);

		@SuppressWarnings("unchecked")
		List<LoanProductType> loanProductTypes = query.getResultList();

		if(!loanProductTypes.isEmpty()){
			loanProductType = loanProductTypes.get(0);
		}
		return loanProductType;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ApplicantDeatilsForNotification getApplicantdetails(Long applicantid){
		List<Object[]> applicatdetails;
		ApplicantDeatilsForNotification details = null;
		StringBuilder strBuilder = new StringBuilder(FETCH_APLLICANT_DETAILS);
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("applicantKey", applicantid);
		applicatdetails = query.getResultList();
		if(null != applicatdetails && !applicatdetails.isEmpty())
			for (Object[] object : applicatdetails) {
				details = new ApplicantDeatilsForNotification();
				if (object[0] != null) {
					details.setApplicantName(object[0].toString());
				}
				if (object[1] != null) {
					details.setEmailId(object[1].toString());
				}
				if (object[2] != null) {
					details.setMobileNumber(object[2].toString());
				}
			}
		return details;
	}



	@SuppressWarnings("unchecked")
	@Override
	public String getproductDesc(String code) {
		String productDesc = null;
		StringBuilder strBuilder = new StringBuilder(LoanAccountConstants.FETCH_VAS_DETAILS);
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("VPPRODUCTCODE", code);
		List<Object[]> vasproductdetails = query.getResultList();
		if(vasproductdetails!=null&&!vasproductdetails.isEmpty()){
			for (Object[] object : vasproductdetails) {
				if (object[1] != null) {
					productDesc=object[1].toString();
				}
			}
		}
		return productDesc;
	}

	@Override
	public String getInsproductDesc(String code) {

		String productDesc = null;
		StringBuilder strBuilder = new StringBuilder(LoanAccountConstants.FETCH_INS_DETAILS);
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("INSPLANCODE", code);
		@SuppressWarnings("unchecked")
		List<Object[]> insProductdetails = query.getResultList();
		if(insProductdetails!=null&&!insProductdetails.isEmpty()){
			for (Object[] object : insProductdetails) {
				if (object[1] != null) {
					productDesc=object[1].toString();
				}
			}
		}
		return productDesc;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getpolicyNo(String policyno) {
		String polNo = null;
		int applicationKey=getApplicationKey(policyno);
		if(applicationKey!=0){
			StringBuilder strBuilder = new StringBuilder(LoanAccountConstants.FETCH_POLICYNO);
			Query query = entityManager.createNativeQuery(strBuilder.toString());
			query.setParameter("APPLICATIONKEY", applicationKey);
			List<Object[]> policyDetails = query.getResultList();
			if(policyDetails!=null&&!policyDetails.isEmpty()){
				polNo = getPolicyNumber(policyDetails);
			}
		}
		return polNo;
	}

	private String getPolicyNumber(List<Object[]> policyDetails) {
		String polNo = null;
		for (Object[] object : policyDetails) {
			if (object[0] != null) {
				polNo=object[0].toString();
			}
		}
		return polNo;
	}

	@SuppressWarnings("unchecked")
	public int getApplicationKey(String policyno) {
		int applicationKey = 0;
		StringBuilder strBuilder = new StringBuilder(LoanAccountConstants.FETCH_APPLICATIONDETAILS);
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("LOANNUMBER", policyno);
		List<Object[]> applicationDetails = query.getResultList();
		if(applicationDetails!=null&&!applicationDetails.isEmpty()){
			for (Object[] object : applicationDetails) {
				if (object[0] != null) {
					applicationKey=Integer.valueOf(object[0].toString());
				}
			}
		}
		return applicationKey;
	}

	@Override
	public Applicant getApplicantDetailsByApplicantId(Long applicantID) {
		Applicant applicant = null;
		Query query = entityManager
				.createQuery(LoanAccountConstants.FETCH_APPLICANTDETAILS);
		query.setParameter("applicantkey", applicantID);
		query.setParameter("apltisactive", LoanAccountConstants.ISACTIVE);

		@SuppressWarnings("unchecked")
		List<Applicant> applicants = query.getResultList();

		if(!applicants.isEmpty()){
			applicant = applicants.get(0);
		}
		return applicant;
	}



	@Override
	public Application getApplicationByLAN(String lanNo) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO, "Inside getApplicationByLAN method - started with LAN no-->"+lanNo);
		Application applicaton = null;
		Query query = entityManager
				.createQuery(LoanAccountConstants.FETCH_APPLICATIONBYLAN);
		query.setParameter("lanNo", lanNo);

		@SuppressWarnings("unchecked")
		List<Application> applications = query.getResultList();

		if(!applications.isEmpty()){
			applicaton = applications.get(0);
		}
		if(null != applicaton) {
			logger.info(CLASS_NAME, BFLLoggerComponent.DAO, "Inside getApplicationByLAN method - completed with LAN no-->"+lanNo);
			return applicaton;
		}
		else {
			throw new BFLTechnicalException("LOAN_002",env.getProperty("LOAN_002"));
		}
	}


	@Override
	public ApplicationApplicant getAppApplicantByApplicantId(String applicantId) {
		ApplicationApplicant appApplicant = null;
		try {
		Query query = entityManager
				.createQuery(LoanAccountConstants.FETCH_APPAPPLICANTBYAPPLICANTID);
		query.setParameter("applicantId", Long.parseLong(applicantId));

		@SuppressWarnings("unchecked")
		List<ApplicationApplicant> appApplicants = query.getResultList();

		if(!appApplicants.isEmpty()){
			appApplicant = appApplicants.get(0);
		}
		}catch(Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "AppAppicant not found",e);
			throw new BFLBusinessException("LOAN_005", env.getProperty("LOAN_005"));
		}
		return appApplicant;
	}
	
	@Override
	public LoanProduct getLoanProduct(String loantype) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO, "Inside getLoanProduct method - started with loanTypeId-->"+loantype);
		LoanProductType loanProductType = null;
		Query query = entityManager
				.createQuery(LoanAccountConstants.FETCH_LOANPRODUCTTYPE);
		query.setParameter("loantype", loantype);

		@SuppressWarnings("unchecked")
		List<LoanProductType> loanProductTypes = query.getResultList();

		if(!loanProductTypes.isEmpty()){
			loanProductType = loanProductTypes.get(0);
		}
		if(null != loanProductType) {
			logger.info(CLASS_NAME, BFLLoggerComponent.DAO, "Inside getLoanProduct method - completed with loanType-->"+loantype);
			return loanProductType.getLoanProduct();
		}
		else {
			throw new BFLTechnicalException("LOAN_004",env.getProperty("LOAN_004"));
		}
	}

}
