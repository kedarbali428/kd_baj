/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.bean;

import java.io.Serializable;
import java.math.BigDecimal;


public class VasDetailBean implements Serializable{

   
    /**
     * Constant for serialVersionUID.
     */
    private static final long serialVersionUID = 330487960426782097L;
    private String productName;
    private String productDate;
    private BigDecimal feespaid ;
    private String expiryDate;

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}


	public BigDecimal getFeespaid() {
		return feespaid;
	}

	public void setFeespaid(BigDecimal feespaid) {
		this.feespaid = feespaid;
	}

	public String getProductDate() {
		return productDate;
	}

	public void setProductDate(String productDate) {
		this.productDate = productDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	
    
    
}
