package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the INS_PROVIDERS database table.
 * 
 */
@Entity
@Table(name="INS_PROVIDERS")
@NamedQuery(name="InsProvider.findAll", query="SELECT i FROM InsProvider i")
public class InsProvider implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long insproviderkey;

	@Temporal(TemporalType.DATE)
	private Date ipestablishmentdt;

	private BigDecimal ipisactive;

	private String iplstupdateby;

	private Timestamp iplstupdatedt;

	private String ipprovidername;

	private String ipprovidertype;

	//bi-directional many-to-one association to InsuranceApplication
	@OneToMany(mappedBy="insProvider")
	private List<InsuranceApplication> insuranceApplications;

	//bi-directional many-to-one association to InsProductPlan
	@OneToMany(mappedBy="insProvider")
	private List<InsProductPlan> insProductPlans;

	public InsProvider() {
	}

	public long getInsproviderkey() {
		return this.insproviderkey;
	}

	public void setInsproviderkey(long insproviderkey) {
		this.insproviderkey = insproviderkey;
	}

	public Date getIpestablishmentdt() {
		return this.ipestablishmentdt;
	}

	public void setIpestablishmentdt(Date ipestablishmentdt) {
		this.ipestablishmentdt = ipestablishmentdt;
	}

	public BigDecimal getIpisactive() {
		return this.ipisactive;
	}

	public void setIpisactive(BigDecimal ipisactive) {
		this.ipisactive = ipisactive;
	}

	public String getIplstupdateby() {
		return this.iplstupdateby;
	}

	public void setIplstupdateby(String iplstupdateby) {
		this.iplstupdateby = iplstupdateby;
	}

	public Timestamp getIplstupdatedt() {
		return this.iplstupdatedt;
	}

	public void setIplstupdatedt(Timestamp iplstupdatedt) {
		this.iplstupdatedt = iplstupdatedt;
	}

	public String getIpprovidername() {
		return this.ipprovidername;
	}

	public void setIpprovidername(String ipprovidername) {
		this.ipprovidername = ipprovidername;
	}

	public String getIpprovidertype() {
		return this.ipprovidertype;
	}

	public void setIpprovidertype(String ipprovidertype) {
		this.ipprovidertype = ipprovidertype;
	}

	public List<InsuranceApplication> getInsuranceApplications() {
		return this.insuranceApplications;
	}

	public void setInsuranceApplications(List<InsuranceApplication> insuranceApplications) {
		this.insuranceApplications = insuranceApplications;
	}

	public InsuranceApplication addInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().add(insuranceApplication);
		insuranceApplication.setInsProvider(this);

		return insuranceApplication;
	}

	public InsuranceApplication removeInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().remove(insuranceApplication);
		insuranceApplication.setInsProvider(null);

		return insuranceApplication;
	}

	public List<InsProductPlan> getInsProductPlans() {
		return this.insProductPlans;
	}

	public void setInsProductPlans(List<InsProductPlan> insProductPlans) {
		this.insProductPlans = insProductPlans;
	}

	public InsProductPlan addInsProductPlan(InsProductPlan insProductPlan) {
		getInsProductPlans().add(insProductPlan);
		insProductPlan.setInsProvider(this);

		return insProductPlan;
	}

	public InsProductPlan removeInsProductPlan(InsProductPlan insProductPlan) {
		getInsProductPlans().remove(insProductPlan);
		insProductPlan.setInsProvider(null);

		return insProductPlan;
	}

}