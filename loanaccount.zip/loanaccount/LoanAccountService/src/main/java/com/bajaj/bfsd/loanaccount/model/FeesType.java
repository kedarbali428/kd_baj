package com.bajaj.bfsd.loanaccount.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the FEES_TYPES database table.
 * 
 */
@Entity
@Table(name="FEES_TYPES")
@NamedQuery(name="FeesType.findAll", query="SELECT f FROM FeesType f")
public class FeesType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long feetypekey;

	private String feecode;

	private String feedesc;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;
	
	public long getFeetypekey() {
		return this.feetypekey;
	}

	public void setFeetypekey(long feetypekey) {
		this.feetypekey = feetypekey;
	}

	public String getFeecode() {
		return this.feecode;
	}

	public void setFeecode(String feecode) {
		this.feecode = feecode;
	}

	public String getFeedesc() {
		return this.feedesc;
	}

	public void setFeedesc(String feedesc) {
		this.feedesc = feedesc;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}