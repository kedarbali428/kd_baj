package com.bajaj.bfsd.loanaccount.service;

import com.bajaj.bfsd.loanaccount.bean.InsurancesDetailResponse;

@FunctionalInterface
public interface VasInsuranceService {

	public InsurancesDetailResponse getVasAndInsuranceDetails(String loanNumber,String productCode);

}
