package com.bajaj.bfsd.loanaccount.model;

public class VasDetail {

	private String product;
	
	private String postingAgainst;
	
	private String primaryLinkRef;
	
	private String vasReference;
	
	private Number fee;
	
	private String feePaymentMode;
	
	private String valueDate;
	
	private String accrualTillDate;
	
	private String recurringDate;
	
	private Number renewalFee;
	
	private String vasStatus;
	private String waivedAmt;
	

	public String getWaivedAmt() {
		return waivedAmt;
	}

	public void setWaivedAmt(String waivedAmt) {
		this.waivedAmt = waivedAmt;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getPostingAgainst() {
		return postingAgainst;
	}

	public void setPostingAgainst(String postingAgainst) {
		this.postingAgainst = postingAgainst;
	}

	public String getPrimaryLinkRef() {
		return primaryLinkRef;
	}

	public void setPrimaryLinkRef(String primaryLinkRef) {
		this.primaryLinkRef = primaryLinkRef;
	}

	public String getVasReference() {
		return vasReference;
	}

	public void setVasReference(String vasReference) {
		this.vasReference = vasReference;
	}

	public Number getFee() {
		return fee;
	}

	public void setFee(Number fee) {
		this.fee = fee;
	}

	public String getFeePaymentMode() {
		return feePaymentMode;
	}

	public void setFeePaymentMode(String feePaymentMode) {
		this.feePaymentMode = feePaymentMode;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getAccrualTillDate() {
		return accrualTillDate;
	}

	public void setAccrualTillDate(String accrualTillDate) {
		this.accrualTillDate = accrualTillDate;
	}

	public String getRecurringDate() {
		return recurringDate;
	}

	public void setRecurringDate(String recurringDate) {
		this.recurringDate = recurringDate;
	}

	

	public Number getRenewalFee() {
		return renewalFee;
	}

	public void setRenewalFee(Number renewalFee) {
		this.renewalFee = renewalFee;
	}

	public String getVasStatus() {
		return vasStatus;
	}

	public void setVasStatus(String vasStatus) {
		this.vasStatus = vasStatus;
	}

	

	@Override
	public String toString() {
		return "VasDetail [product=" + product + ", postingAgainst=" + postingAgainst + ", primaryLinkRef="
				+ primaryLinkRef + ", vasReference=" + vasReference + ", fee=" + fee + ", feePaymentMode="
				+ feePaymentMode + ", valueDate=" + valueDate + ", accrualTillDate=" + accrualTillDate
				+ ", recurringDate=" + recurringDate +",renewalFee=" + renewalFee + ", vasStatus="
				+ vasStatus + "]";
	}

}
