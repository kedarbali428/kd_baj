package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the VAS_PROVIDERS database table.
 * 
 */
@Entity
@Table(name="VAS_PROVIDERS")
@NamedQuery(name="VasProvider.findAll", query="SELECT v FROM VasProvider v")
public class VasProvider implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long vasproviderkey;

	@Temporal(TemporalType.DATE)
	private Date vpestablishmentdate;

	private BigDecimal vpisactive;

	private String vplstupdateby;

	private Timestamp vplstupdatedt;

	private String vpprovidername;

	//bi-directional many-to-one association to VasProductPlan
	@OneToMany(mappedBy="vasProvider")
	private List<VasProductPlan> vasProductPlans;

	public VasProvider() {
	}

	public long getVasproviderkey() {
		return this.vasproviderkey;
	}

	public void setVasproviderkey(long vasproviderkey) {
		this.vasproviderkey = vasproviderkey;
	}

	public Date getVpestablishmentdate() {
		return this.vpestablishmentdate;
	}

	public void setVpestablishmentdate(Date vpestablishmentdate) {
		this.vpestablishmentdate = vpestablishmentdate;
	}

	public BigDecimal getVpisactive() {
		return this.vpisactive;
	}

	public void setVpisactive(BigDecimal vpisactive) {
		this.vpisactive = vpisactive;
	}

	public String getVplstupdateby() {
		return this.vplstupdateby;
	}

	public void setVplstupdateby(String vplstupdateby) {
		this.vplstupdateby = vplstupdateby;
	}

	public Timestamp getVplstupdatedt() {
		return this.vplstupdatedt;
	}

	public void setVplstupdatedt(Timestamp vplstupdatedt) {
		this.vplstupdatedt = vplstupdatedt;
	}

	public String getVpprovidername() {
		return this.vpprovidername;
	}

	public void setVpprovidername(String vpprovidername) {
		this.vpprovidername = vpprovidername;
	}

	public List<VasProductPlan> getVasProductPlans() {
		return this.vasProductPlans;
	}

	public void setVasProductPlans(List<VasProductPlan> vasProductPlans) {
		this.vasProductPlans = vasProductPlans;
	}

	public VasProductPlan addVasProductPlan(VasProductPlan vasProductPlan) {
		getVasProductPlans().add(vasProductPlan);
		vasProductPlan.setVasProvider(this);

		return vasProductPlan;
	}

	public VasProductPlan removeVasProductPlan(VasProductPlan vasProductPlan) {
		getVasProductPlans().remove(vasProductPlan);
		vasProductPlan.setVasProvider(null);

		return vasProductPlan;
	}

}