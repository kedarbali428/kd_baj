package com.bajaj.bfsd.loanaccount.bean;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import com.bajaj.bfsd.loanaccount.model.ApplicantSysCode;
import com.fasterxml.jackson.annotation.JsonFormat;

public class ApplicantBean {

	private Long applicantKey;
	@NotNull(message = "First Name can not be null")
	private String firstName;
	private String middleName;
	private String lastName;
	private String panNumber;
	private Integer loanApplicationId;
	private String aadhaarNumber;
	private String passportNumber;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date passportExpDate;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private Date dateOfBirth;
	private BigDecimal netSalary;
	private BigDecimal monthlyObligation;
	private String apltcorecusid;
	private String apltcustcif;
	
	// bi-directional many-to-one association to BankMasterSysCode
	@OneToMany(mappedBy = "applicant")
	private List<ApplicantSysCode> applicantSysCodes;
		
	public List<ApplicantSysCode> getApplicantSysCodes() {
		return applicantSysCodes;
	}

	public void setApplicantSysCodes(List<ApplicantSysCode> applicantSysCodes) {
		this.applicantSysCodes = applicantSysCodes;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getAadhaarNumber() {
	    return aadhaarNumber;
	}

	public void setAadhaarNumber(String aadhaarNumber) {
	    this.aadhaarNumber = aadhaarNumber;
	}

	public String getPassportNumber() {
	    return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
	    this.passportNumber = passportNumber;
	}

	public Date getPassportExpDate() {
	    return passportExpDate;
	}

	public void setPassportExpDate(Date passportExpDate) {
	    this.passportExpDate = passportExpDate;
	}

	public Integer getLoanApplicationId() {
		return loanApplicationId;
	}

	public void setLoanApplicationId(Integer loanApplicationId) {
		this.loanApplicationId = loanApplicationId;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public BigDecimal getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(BigDecimal netSalary) {
		this.netSalary = netSalary;
	}
	public BigDecimal getMonthlyObligation() {
		return monthlyObligation;
	}

	public void setMonthlyObligation(BigDecimal monthlyObligation) {
		this.monthlyObligation = monthlyObligation;
	}

	public String getApltcorecusid() {
		return apltcorecusid;
	}

	public void setApltcorecusid(String apltcorecusid) {
		this.apltcorecusid = apltcorecusid;
	}

	public String getApltcustcif() {
		return apltcustcif;
	}

	public void setApltcustcif(String apltcustcif) {
		this.apltcustcif = apltcustcif;
	}
}