package com.bajaj.bfsd.loanaccount.model;

public class CustomerLoanRequest {

	private String cif;

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	@Override
	public String toString() {
		return "LoanPennantRequest [cif=" + cif + "]";
	}
	
}