/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.loanaccount.bean.ApplicantDeatilsForNotification;
import com.bajaj.bfsd.loanaccount.bean.CifDetailsBean;
import com.bajaj.bfsd.loanaccount.bean.DisbursementBean;
import com.bajaj.bfsd.loanaccount.bean.FeeBean;
import com.bajaj.bfsd.loanaccount.bean.LoanAccountResponseBean;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailBean;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailResponseBean;
import com.bajaj.bfsd.loanaccount.bean.MissedEMI;
import com.bajaj.bfsd.loanaccount.dao.ProductDao;
import com.bajaj.bfsd.loanaccount.entity.Applicant;
import com.bajaj.bfsd.loanaccount.helper.LoanDetailHelper;
import com.bajaj.bfsd.loanaccount.helper.LoanHelper;
import com.bajaj.bfsd.loanaccount.model.ApplicantSysCode;
import com.bajaj.bfsd.loanaccount.service.LoanAccountService;
import com.bajaj.bfsd.loanaccount.util.LoanAccountUtil;
import com.google.gson.Gson;

/**
 * This is a service class for Loan Account.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	20/02/2017      Initial Version
 */
@Service
public class LoanAccountServiceImpl  extends BFLComponent implements LoanAccountService {

    private static final String THIS_CLASS = LoanAccountServiceImpl.class.getSimpleName();

    @Value("${loanAccountMocked}")
    private String isMocked;
    
    @Autowired 
    private LoanHelper loanHelper;
    
    @Autowired 
    private LoanDetailHelper loandetailHelper;
    
    @Autowired 
    private ProductDao productDao;
    
    @Autowired
    private BFLLoggerUtilExt logger;
    
    @Autowired
    LoanAccountUtil loanAccountUtil;
    
    @Value("${PENNANT.PROVIDER}")
    private String pennantProvider;
    
    @Override
    public LoanAccountResponseBean getLoanAccountDetails(String applicantId,String type) {
    	logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE,"Inside getLoanAccountDetails() with applicantId--> "+applicantId+ " and type--> "+type);
        return getLoanDetailsByCustomerId(applicantId,type);
    }
    
	private LoanAccountResponseBean getLoanDetailsByCustomerId(String applicantId, String type) {
		Gson gson = new Gson();
		LoanAccountResponseBean newRes = new LoanAccountResponseBean();
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE,"Inside getLoanDetailsByCustomerId() with applicantId--> "+applicantId+ " and type--> "+type);
		List<CifDetailsBean> cifAndTargetBeanList = getCustomerIdByApplicantid(applicantId);
		LoanAccountResponseBean response = loandetailHelper.getAllActiveLoansForCustomer(cifAndTargetBeanList,type);
		response = loandetailHelper.prepareLMSResponse(response, type);
		if(null!=response)
		{
			ApplicantDeatilsForNotification details = productDao.getApplicantdetails(Long.parseLong(applicantId));
			if(null!=details)
			{
				response.setEmailID(details.getEmailId());
				response.setMobileNumber(details.getMobileNumber());
			}
			newRes=convertCurrency(response);
		}
		String responseJson = gson.toJson(response,LoanAccountResponseBean.class);
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE,"successfully  getLoanDetailsByCustomerId() old response--> "+responseJson);
		String responseJsonNew = gson.toJson(newRes,LoanAccountResponseBean.class);
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE,"successfully  getLoanDetailsByCustomerId() Converted response--> "+responseJsonNew);
		return newRes;
	}
	
	private LoanAccountResponseBean convertCurrency(LoanAccountResponseBean res) {
		if (null != res.getTotalEmiAmount()) {
			res.setTotalEmiAmount(loanAccountUtil.convertRstoPaisa(res.getTotalEmiAmount()));
		}
		if (null != res.getTotalOutstandingAmount()) {
			res.setTotalOutstandingAmount(loanAccountUtil.convertRstoPaisa(res.getTotalOutstandingAmount()));
		}
		if (null != res.getTotalLoanAmount()) {
			res.setTotalLoanAmount(loanAccountUtil.convertRstoPaisa(res.getTotalLoanAmount()));
		}
		convertLoanDetailBeanValues(res);
		return res;
	}

	private void convertLoanDetailBeanValues(LoanAccountResponseBean res) {
		if (null != res.getLoanDetails()) {
		for (LoanDetailBean newLoanDtl : res.getLoanDetails()) {
				convertLoanDetailBean(newLoanDtl);
				convertFeeAmount(newLoanDtl.getFees());
				convertDisbDetails(newLoanDtl.getDisbursement());
				convertMissedEMIDtl(newLoanDtl);
				convertMissedEmi(newLoanDtl);
				if(null!=newLoanDtl.getLinkedLanNo()){
				for (LoanDetailBean loanDtlBn : newLoanDtl.getLinkedLanNo()) {
					logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "inside getLinkedLanNo--> ");
					convertLoanDetailBean(loanDtlBn);
				}
				}
			}
		}
		 
	}

	private void convertLoanDetailBean(LoanDetailBean newLoanDtl) {
		if(null!=newLoanDtl){
			 if(null!=newLoanDtl.getLoanAmount()){
		newLoanDtl.setLoanAmount(loanAccountUtil.convertRstoPaisa(newLoanDtl.getLoanAmount()));
			 }
			 if(null!=newLoanDtl.getLoanISAmount()){
		 newLoanDtl.setLoanISAmount(loanAccountUtil.convertRstoPaisa(newLoanDtl.getLoanISAmount()));
			 }
			 if(null!=newLoanDtl.getOutstandingLoanISAmount()){
		 newLoanDtl.setOutstandingLoanISAmount(loanAccountUtil.convertRstoPaisa(newLoanDtl.getOutstandingLoanISAmount()));
			 }
			 if(null!=newLoanDtl.getOutstandingLoanAmount()){
		 newLoanDtl.setOutstandingLoanAmount(loanAccountUtil.convertRstoPaisa(newLoanDtl.getOutstandingLoanAmount()));
			 }
			 if(null!=newLoanDtl.getEmiAmount()){
		 newLoanDtl.setEmiAmount(loanAccountUtil.convertRstoPaisa(newLoanDtl.getEmiAmount()));
			 }
			 if(null!=newLoanDtl.getEmiPaid()){
		 newLoanDtl.setEmiPaid((newLoanDtl.getEmiPaid()));
			 }
			 if(null!=newLoanDtl.getOverdueEMIAmount()){
		 newLoanDtl.setOverdueEMIAmount(loanAccountUtil.convertRstoPaisa(newLoanDtl.getOverdueEMIAmount()));
			 }
			 if(null!=newLoanDtl.getTotalEmi()){
		 newLoanDtl.setTotalEmi((newLoanDtl.getTotalEmi()));
			 }
			 if(null!=newLoanDtl.getTotalEMIReceived()){
		 newLoanDtl.setTotalEMIReceived(loanAccountUtil.convertRstoPaisa(newLoanDtl.getTotalEMIReceived()));
			 }
			 if(null!=newLoanDtl.getTotalLimit()){
		 newLoanDtl.setTotalLimit(newLoanDtl.getTotalLimit()*100);
			 }
			 if(null!=newLoanDtl.getAvailableAmount()){
		 newLoanDtl.setAvailableAmount(newLoanDtl.getAvailableAmount()*100);
			 }
			 if(null!=newLoanDtl.getTotalDisburseAmount()){
		 newLoanDtl.setTotalDisburseAmount(newLoanDtl.getTotalDisburseAmount()*100);
			 }
			 if(null!=newLoanDtl.getAmountAvailableDisbursement()){
		 newLoanDtl.setAmountAvailableDisbursement(newLoanDtl.getAmountAvailableDisbursement()*100);
			 }
			 if(null!=newLoanDtl.getLoanPaidAmount()){
		 newLoanDtl.setLoanPaidAmount(newLoanDtl.getLoanPaidAmount()*100);
			 }
			 if(null!=newLoanDtl.getMinimumAmountToPay()){
		 newLoanDtl.setMinimumAmountToPay(loanAccountUtil.convertRstoPaisa(newLoanDtl.getMinimumAmountToPay()));
			 }
			 if(null!=newLoanDtl.getCurrentDroplineLimit()){
		 newLoanDtl.setCurrentDroplineLimit(loanAccountUtil.convertRstoPaisa(newLoanDtl.getCurrentDroplineLimit()));
			 }
			 if(null!=newLoanDtl.getAvailableLimit()){
		 newLoanDtl.setAvailableLimit(loanAccountUtil.convertRstoPaisa(newLoanDtl.getAvailableLimit()));
			 }
			 if(null!=newLoanDtl.getDisbursementBean() && null!=newLoanDtl.getDisbursementBean().getDisbursementAmount()){
		 newLoanDtl.getDisbursementBean().setDisbursementAmount(newLoanDtl.getDisbursementBean().getDisbursementAmount()*100);
			 }
			 if(null!=newLoanDtl.getUtilisation()){
				 newLoanDtl.setUtilisation(newLoanDtl.getUtilisation().doubleValue()*100);
					 }
		}
		}

	private void convertMissedEMIDtl(LoanDetailBean newLoanDtl) {
		if (null != newLoanDtl.getMissedEMIDetails()) {
			if (null != newLoanDtl.getMissedEMIDetails().getAmountToBePaid()) {
				newLoanDtl.getMissedEMIDetails()
						.setAmountToBePaid(newLoanDtl.getMissedEMIDetails().getAmountToBePaid() * 100);
			}
			if (null != newLoanDtl.getMissedEMIDetails().getTotalBounceCharge()) {
				newLoanDtl.getMissedEMIDetails()
						.setTotalBounceCharge(newLoanDtl.getMissedEMIDetails().getTotalBounceCharge() * 100);
			}
			if (null != newLoanDtl.getMissedEMIDetails().getTotalFee()) {
				newLoanDtl.getMissedEMIDetails().setTotalFee(newLoanDtl.getMissedEMIDetails().getTotalFee() * 100);
			}
		}
	}

	private void convertMissedEmi(LoanDetailBean newLoanDtl) {
		if (null != newLoanDtl.getMissedEMIDetails() && null != newLoanDtl.getMissedEMIDetails().getMissedEMI()) {
			for (MissedEMI emi : newLoanDtl.getMissedEMIDetails().getMissedEMI()) {
				if (null != emi.getBounceCharges()) {
					emi.setBounceCharges(emi.getBounceCharges() * 100);
				}
				if (null != emi.getEmiAmount()) {
					emi.setEmiAmount(emi.getEmiAmount() * 100);
				}
				if (null != emi.getLateFeeAmount()) {
					emi.setLateFeeAmount(emi.getLateFeeAmount() * 100);
				}
				if (null != emi.getTotalEmiAmount()) {
					emi.setTotalEmiAmount(emi.getTotalEmiAmount() * 100);
				}
			}
		}
	}

	private void convertDisbDetails(List<DisbursementBean> disblst) {
		if (null != disblst) {
			for (DisbursementBean disb : disblst) {
				if (null != disb.getDisbursementAmount()) {
					disb.setDisbursementAmount(disb.getDisbursementAmount() * 100);
				}
			}
		}

	}

	private void convertFeeAmount(List<FeeBean> fees) {
		if (null != fees) {
			for (FeeBean newFees : fees) {
				if (null != newFees.getFeeAmount()) {
					newFees.setFeeAmount(loanAccountUtil.convertRstoPaisa(newFees.getFeeAmount()));
				}
				if (null != newFees.getFeeBalanceAmount()) {
					newFees.setFeeBalanceAmount(loanAccountUtil.convertRstoPaisa(newFees.getFeeBalanceAmount()));
				}
				if (null != newFees.getOverDueAmount()) {
					newFees.setOverDueAmount(loanAccountUtil.convertRstoPaisa(newFees.getOverDueAmount()));
				}
				if (null != newFees.getPaidAmount()) {
					newFees.setPaidAmount(loanAccountUtil.convertRstoPaisa(newFees.getPaidAmount()));
				}
			}
		}

	}

	@Override
   	public LoanDetailResponseBean getLoanDetailsByLanNo(String lanNo,String loanProduct) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Before  getLoanDetailsByLanNo() in ServiceImpl with LAN Number--> "+lanNo);
   		return loanHelper.getLoanDetailByLanNo(lanNo,loanProduct);
   	}
    

	public List<CifDetailsBean> getCustomerIdByApplicantid(String applicantId)
	{
		List<CifDetailsBean> cifAndTargetBeans = new ArrayList<>();
		CifDetailsBean cifAndTargetBean = new CifDetailsBean();
		if(null!=applicantId){
			Applicant applicant =  productDao.getApplicantDetailsByApplicantId(Long.parseLong(applicantId));
			
			if(null!=applicant.getApplicantSysCodes() && !applicant.getApplicantSysCodes().isEmpty()){
				cifAndTargetBeans = getCustomerCIFDetails(applicant.getApplicantSysCodes());
			} else if(null!=applicant.getApltcustcif()){
				boolean plfFound = false;
				for(CifDetailsBean cifDetailsBean : cifAndTargetBeans) {
					if("PLF".equals(cifDetailsBean.getTarget())) {
						plfFound = true;
						break;
					}
				}
				if(!plfFound) {
					cifAndTargetBean.setApltCustCif(applicant.getApltcustcif());
					cifAndTargetBean.setTarget("PLF");
					cifAndTargetBeans.add(cifAndTargetBean);
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "apltCustCIF from applicant value "+cifAndTargetBean.getApltCustCif());
				}
			}
			
			
			
			
			else if(null!=applicant.getApltcustcif()) {
				cifAndTargetBean.setApltCustCif(applicant.getApltcustcif());
				cifAndTargetBean.setTarget("PLF");
				cifAndTargetBeans.add(cifAndTargetBean);
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "apltCustCIF from applicant value "+cifAndTargetBean.getApltCustCif());
			}
		}
		return cifAndTargetBeans;
	}
	
	private List<CifDetailsBean> getCustomerCIFDetails(List<ApplicantSysCode> applicantSysCodes) {
		List<CifDetailsBean> cifAndTargetBeans = new ArrayList<>();
		CifDetailsBean cifAndTargetBean;
		for (ApplicantSysCode applicantSysCode : applicantSysCodes) {
			if(null!=applicantSysCode && null!= applicantSysCode.getInterfaceSystem() && fetchPennantProviderFlag(applicantSysCode)){
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "apltCustCIF value from child "+applicantSysCode.getRefcode());
				cifAndTargetBean = new CifDetailsBean();
				cifAndTargetBean.setApltCustCif(applicantSysCode.getRefcode());
				cifAndTargetBean.setTarget(applicantSysCode.getInterfaceSystem().getSystemcode());
				cifAndTargetBeans.add(cifAndTargetBean);
			}
			
		}
		return cifAndTargetBeans;
	}
	
	public boolean fetchPennantProviderFlag(ApplicantSysCode applicantSysCode) {
		boolean pennantProviderFlag = false;
		List<String> pennantProviderList =  Arrays.asList(pennantProvider.split(",")); 
	    boolean pennantProviderMatchFound = pennantProviderList.stream().anyMatch(applicantSysCode.getInterfaceSystem().getSystemcode()::equals);
		if (pennantProviderMatchFound){
			pennantProviderFlag = true;
		}
		return pennantProviderFlag;
	}
}
