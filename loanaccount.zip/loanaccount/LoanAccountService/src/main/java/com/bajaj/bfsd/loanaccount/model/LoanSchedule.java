package com.bajaj.bfsd.loanaccount.model;

import java.util.List;

import com.bajaj.bfsd.loanaccount.bean.EMIHoliday;

public class LoanSchedule {

	private LoanDetail financeDetail;
	
	private List<Schedule> schedule;
	
	private ScheduleSummary summary;
	
	private List<Fee> fees;

	private List<EMIHoliday> planEMIHmonths;

	public List<EMIHoliday> getPlanEMIHmonths() {
		return planEMIHmonths;
	}

	public void setPlanEMIHmonths(List<EMIHoliday> planEMIHmonths) {
		this.planEMIHmonths = planEMIHmonths;
	}

	public LoanDetail getFinanceDetail() {
		return financeDetail;
	}

	public void setFinanceDetail(LoanDetail financeDetail) {
		this.financeDetail = financeDetail;
	}

	public List<Schedule> getSchedule() {
		return schedule;
	}

	public void setSchedule(List<Schedule> schedule) {
		this.schedule = schedule;
	}

	public ScheduleSummary getSummary() {
		return summary;
	}

	public void setSummary(ScheduleSummary summary) {
		this.summary = summary;
	}

	public List<Fee> getFees() {
		return fees;
	}

	public void setFees(List<Fee> fees) {
		this.fees = fees;
	}

	//insurance and step are not supported by pennant yet so not added here.
	
}
