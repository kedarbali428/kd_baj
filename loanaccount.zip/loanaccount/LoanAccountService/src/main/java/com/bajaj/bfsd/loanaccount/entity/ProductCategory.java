package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the PRODUCT_CATEGORIES database table.
 * 
 */
@Entity
@Table(name="PRODUCT_CATEGORIES")
@NamedQuery(name="ProductCategory.findAll", query="SELECT p FROM ProductCategory p")
public class ProductCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long prodcatkey;

	private String prodcatcode;

	private String prodcatdesc;

	private BigDecimal prodcatisactive;

	private String prodcatlstupdateby;

	private Timestamp prodcatlstupdatedt;


	public ProductCategory() {
	}

	public long getProdcatkey() {
		return this.prodcatkey;
	}

	public void setProdcatkey(long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public String getProdcatcode() {
		return this.prodcatcode;
	}

	public void setProdcatcode(String prodcatcode) {
		this.prodcatcode = prodcatcode;
	}

	public String getProdcatdesc() {
		return this.prodcatdesc;
	}

	public void setProdcatdesc(String prodcatdesc) {
		this.prodcatdesc = prodcatdesc;
	}

	public BigDecimal getProdcatisactive() {
		return this.prodcatisactive;
	}

	public void setProdcatisactive(BigDecimal prodcatisactive) {
		this.prodcatisactive = prodcatisactive;
	}

	public String getProdcatlstupdateby() {
		return this.prodcatlstupdateby;
	}

	public void setProdcatlstupdateby(String prodcatlstupdateby) {
		this.prodcatlstupdateby = prodcatlstupdateby;
	}

	public Timestamp getProdcatlstupdatedt() {
		return this.prodcatlstupdatedt;
	}

	public void setProdcatlstupdatedt(Timestamp prodcatlstupdatedt) {
		this.prodcatlstupdatedt = prodcatlstupdatedt;
	}

}