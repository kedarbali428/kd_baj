package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the APPLICANT_LIMITS database table.
 * 
 */
@Entity
@Table(name="APPLICANT_LIMITS")
@NamedQuery(name="ApplicantLimit.findAll", query="SELECT a FROM ApplicantLimit a")
public class ApplicantLimit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long apltlimitkey;

	@Temporal(TemporalType.DATE)
	private Date aleffenddt;

	@Temporal(TemporalType.DATE)
	private Date aleffstartdt;

	private BigDecimal alisactive;

	@Temporal(TemporalType.DATE)
	private Date allastcalcdt;

	private BigDecimal allimittype;

	private BigDecimal allineassignflg;

	private String allstupdateby;

	private Timestamp allstupdatedt;

	private BigDecimal altoteligibilityamt;

	//bi-directional many-to-one association to Applicant
	@ManyToOne
	@JoinColumn(name="APPLICANTKEY")
	private Applicant applicant;

	//bi-directional many-to-one association to ApplicantLimitProduct
	@OneToMany(mappedBy="applicantLimit")
	private List<ApplicantLimitProduct> applicantLimitProducts;

	public ApplicantLimit() {
	}

	public long getApltlimitkey() {
		return this.apltlimitkey;
	}

	public void setApltlimitkey(long apltlimitkey) {
		this.apltlimitkey = apltlimitkey;
	}

	public Date getAleffenddt() {
		return this.aleffenddt;
	}

	public void setAleffenddt(Date aleffenddt) {
		this.aleffenddt = aleffenddt;
	}

	public Date getAleffstartdt() {
		return this.aleffstartdt;
	}

	public void setAleffstartdt(Date aleffstartdt) {
		this.aleffstartdt = aleffstartdt;
	}

	public BigDecimal getAlisactive() {
		return this.alisactive;
	}

	public void setAlisactive(BigDecimal alisactive) {
		this.alisactive = alisactive;
	}

	public Date getAllastcalcdt() {
		return this.allastcalcdt;
	}

	public void setAllastcalcdt(Date allastcalcdt) {
		this.allastcalcdt = allastcalcdt;
	}

	public BigDecimal getAllimittype() {
		return this.allimittype;
	}

	public void setAllimittype(BigDecimal allimittype) {
		this.allimittype = allimittype;
	}

	public BigDecimal getAllineassignflg() {
		return this.allineassignflg;
	}

	public void setAllineassignflg(BigDecimal allineassignflg) {
		this.allineassignflg = allineassignflg;
	}

	public String getAllstupdateby() {
		return this.allstupdateby;
	}

	public void setAllstupdateby(String allstupdateby) {
		this.allstupdateby = allstupdateby;
	}

	public Timestamp getAllstupdatedt() {
		return this.allstupdatedt;
	}

	public void setAllstupdatedt(Timestamp allstupdatedt) {
		this.allstupdatedt = allstupdatedt;
	}

	public BigDecimal getAltoteligibilityamt() {
		return this.altoteligibilityamt;
	}

	public void setAltoteligibilityamt(BigDecimal altoteligibilityamt) {
		this.altoteligibilityamt = altoteligibilityamt;
	}

	public Applicant getApplicant() {
		return this.applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}

	public List<ApplicantLimitProduct> getApplicantLimitProducts() {
		return this.applicantLimitProducts;
	}

	public void setApplicantLimitProducts(List<ApplicantLimitProduct> applicantLimitProducts) {
		this.applicantLimitProducts = applicantLimitProducts;
	}

	public ApplicantLimitProduct addApplicantLimitProduct(ApplicantLimitProduct applicantLimitProduct) {
		getApplicantLimitProducts().add(applicantLimitProduct);
		applicantLimitProduct.setApplicantLimit(this);

		return applicantLimitProduct;
	}

	public ApplicantLimitProduct removeApplicantLimitProduct(ApplicantLimitProduct applicantLimitProduct) {
		getApplicantLimitProducts().remove(applicantLimitProduct);
		applicantLimitProduct.setApplicantLimit(null);

		return applicantLimitProduct;
	}

}