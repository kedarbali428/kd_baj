package com.bajaj.bfsd.common.business.baseclasses;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@RefreshScope
@Component
public abstract class BFLBusinessProcessor { //NOSONAR
}
