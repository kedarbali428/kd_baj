package com.bajaj.bfsd.loanaccount.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.InsuranceDetail;
import com.bajaj.bfsd.loanaccount.bean.InsurancesDetailResponse;
import com.bajaj.bfsd.loanaccount.bean.LmsRequestBean;
import com.bajaj.bfsd.loanaccount.bean.VasDetailBean;
import com.bajaj.bfsd.loanaccount.config.MapperFactory;
import com.bajaj.bfsd.loanaccount.dao.ProductDao;
import com.bajaj.bfsd.loanaccount.model.ExtendedFields;
import com.bajaj.bfsd.loanaccount.model.LoanProduct;
import com.bajaj.bfsd.loanaccount.model.LoanRequest;
import com.bajaj.bfsd.loanaccount.model.VasDetail;
import com.bajaj.bfsd.loanaccount.model.VasInsRequest;
import com.bajaj.bfsd.loanaccount.model.VasInsuranceDetailsLMSResponse;
import com.bajaj.bfsd.loanaccount.model.VasInsuranceLMSResponse;
import com.bajaj.bfsd.loanaccount.util.LoanAccountConstants;
import com.bajaj.bfsd.loanaccount.util.LoanAccountUtil;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Component
public class VasInsuranceHelper extends BFLComponent {

	private static final String THIS_CLASS = VasInsuranceHelper.class.getSimpleName();

	@Autowired
	private BFLLoggerUtilExt logger;

	@Value("${resource-path-pennant-get-vas}")
	private String  resourcePathValueGetInsuranceAndVAS;

	@Value("${resource-path-pennant-get-vasins-details}")
	private String  resourcePathValueGetInsuranceAndVASDetails;

	@Value("${pennant-authorization}")
	private String authorizationKey;
	
	@Autowired
	private ProductDao productDao;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private LoanAccountUtil loanAccountUtil;
	
	

	public InsurancesDetailResponse getVasAndInsurance(String loanNumber,String productCode)
	{
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "inside getVasAndInsurance with loanNumber --> "+loanNumber);
		InsurancesDetailResponse detailResponse ;
		VasInsuranceLMSResponse insuranceVASDetails;
		String policyNo=productDao.getpolicyNo(loanNumber);
		LoanProduct loanProduct = productDao.getLoanProduct(productCode);
		//insuranceVASDetails =  callPennantForGetDetails(loanNumber);
		insuranceVASDetails =  callPennantForGetDetailsLMS(loanNumber,loanProduct);
		if(null!=insuranceVASDetails && null!=insuranceVASDetails.getReturnStatus() && "0000".equals(insuranceVASDetails.getReturnStatus().getReturnCode()))
		{
			detailResponse = prepareLMSResponse(insuranceVASDetails,policyNo,productCode);
		}else if(null!=insuranceVASDetails && null!=insuranceVASDetails.getReturnStatus())
		{
			detailResponse = new InsurancesDetailResponse();
			detailResponse.setReturnCode(insuranceVASDetails.getReturnStatus().getReturnCode());
			detailResponse.setReturnText(insuranceVASDetails.getReturnStatus().getReturnText());
		}else{
			detailResponse = new InsurancesDetailResponse();
			detailResponse.setReturnText("Pennant not return data");
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "returned from getVasAndInsurance with loanNumber --> "+loanNumber);
		return detailResponse;
	}

	private VasInsuranceLMSResponse callPennantForGetDetailsLMS(String loanNumber,LoanProduct loanProduct) {
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside  callPennantForGetDetailsLMS() in VasInsurance with loanNumber--> "+loanNumber);
		VasInsuranceLMSResponse vasInsuranceLMSResponse = null;
		if(null != loanNumber)
		{
			ObjectMapper mapper = MapperFactory.getInstance();
			String responseFromLMS;
			String vasInsuranceLMSRequestString = null;
			String lmsIntegrationRequestBeanString = null;
			LmsRequestBean lmsRequestBean = new LmsRequestBean();
			lmsRequestBean.setHttpMethod("POST");
			lmsRequestBean.setProductCode(loanProduct.getLnprodcode());
			
			LoanRequest loanrequest = new LoanRequest();
			loanrequest.setFinReference(loanNumber);
			//Prepare Request for LMSIntegrationService
		
			try {
				vasInsuranceLMSRequestString = mapper.writeValueAsString(loanrequest);
				logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "PartialSettlement request in JSON--> "+vasInsuranceLMSRequestString);
			} catch (JsonProcessingException e) {
				throw new BFLTechnicalException("JSNMAPEXC_002", env.getProperty("JSNMAPEXC_002"));
			}
			
			lmsRequestBean.setRequestPayload(vasInsuranceLMSRequestString);
			lmsRequestBean.setSource("GETVAS"); //source present in centralconfiguration properties file
			
			try {
				lmsIntegrationRequestBeanString = mapper.writeValueAsString(lmsRequestBean);
			} catch (JsonProcessingException e) {
				throw new BFLTechnicalException("JSNMAPEXC_002", env.getProperty("JSNMAPEXC_002"));
			}
			String lmsURL = env.getProperty("api.lms.gateway.POST.url");
			// calling LMSIntegrationService
			responseFromLMS = loanAccountUtil.hitLMSIntegrationService(lmsIntegrationRequestBeanString, lmsURL);
			logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "Response from LMS--> "+responseFromLMS);
			vasInsuranceLMSResponse =loanAccountUtil.mapFromJson(responseFromLMS, VasInsuranceLMSResponse.class);
		}
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "return from callLoanPaymentForeclosurePennatLMS() in loanHelper with Pennant response--> "+vasInsuranceLMSResponse);
		return vasInsuranceLMSResponse;
	
	
		}

	private InsurancesDetailResponse prepareLMSResponse(VasInsuranceLMSResponse insuranceVASDetails,String policyNo,String productCode) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "inside prepareLMSResponse method -->started");
		InsurancesDetailResponse insurancesDetailResponse = new InsurancesDetailResponse();
		if(null!=insuranceVASDetails.getVasDetails() && !insuranceVASDetails.getVasDetails().isEmpty())
		{
			List<InsuranceDetail> insuranceDetailsList=new ArrayList<>();
			List<VasDetailBean> vasList=new ArrayList<>();
			List<VasDetail> vasDetails = insuranceVASDetails.getVasDetails();
			VasDetailBean vasDetailBean;
			InsuranceDetail detail;
			for (VasDetail vasDetail : vasDetails) {
				if("VAS".equals(vasDetail.getProduct().subSequence(0,3)))
				{
					vasDetailBean=new VasDetailBean();
					String vasrefno=vasDetail.getVasReference();
					LoanProduct loanProduct = productDao.getLoanProduct(productCode);
					//VasInsuranceDetailsLMSResponse insuranceVASDetailsResponse =  callPennantForGetInsvasDetails(vasrefno);
					VasInsuranceDetailsLMSResponse insuranceVASDetailsResponse =  callPennantForGetInsvasDetailsLMS(vasrefno,loanProduct);
					if(insuranceVASDetailsResponse!=null){
						String productcode=insuranceVASDetailsResponse.getProduct();
						String productDesc=productDao.getproductDesc(productcode);
						vasDetailBean.setProductName(productDesc);
					}
					if(insuranceVASDetailsResponse!=null){
						BigDecimal fee=insuranceVASDetailsResponse.getFee();
						vasDetailBean.setFeespaid(fee);
					}
					if(insuranceVASDetailsResponse!=null){
						List<ExtendedFields> extendedFields=insuranceVASDetailsResponse.getExtendedDetails().get(0).getExtendedFields();
						for(ExtendedFields fields:extendedFields){
							if(fields.getFieldName().startsWith("PRDATE")){
								if(null!=fields.getFieldValue() && !"null".endsWith(fields.getFieldValue()))
								{
									String preDate=fields.getFieldValue();
									String pdate=LoanAccountUtil.getPredate(preDate);
									vasDetailBean.setProductDate(pdate);
									String expDate=LoanAccountUtil.getExpdate(pdate);
									vasDetailBean.setExpiryDate(expDate);
								}
							}
						}
						vasList.add(vasDetailBean);
					}
				}else if(policyNo!=null && StringUtils.isNotBlank(policyNo) && "N".equals(vasDetail.getVasStatus())){
					detail = new InsuranceDetail();
					detail.setPolicyNumber(policyNo);
					String insrefno=vasDetail.getVasReference();
					LoanProduct loanProduct = productDao.getLoanProduct(productCode);
					//VasInsuranceDetailsLMSResponse insuranceVASDetailsResponse =  callPennantForGetInsvasDetails(insrefno);
					VasInsuranceDetailsLMSResponse insuranceVASDetailsResponse =  callPennantForGetInsvasDetailsLMS(insrefno,loanProduct);
					if(insuranceVASDetailsResponse!=null){
						String productcode=insuranceVASDetailsResponse.getProduct();
						String productDesc=productDao.getInsproductDesc(productcode);
						detail.setInsuranceType(productDesc);
					}
					if(insuranceVASDetailsResponse!=null){
						List<ExtendedFields> extendedFields=insuranceVASDetailsResponse.getExtendedDetails().get(0).getExtendedFields();
						for(ExtendedFields fields:extendedFields){
							if(fields.getFieldName().startsWith("SA") && null != fields.getFieldValue() && !"null".equals(fields.getFieldValue())){
								detail.setSumAssured(new BigDecimal(fields.getFieldValue()));
							}
							if(fields.getFieldName().startsWith("PREMIUM") && null!=fields.getFieldValue() && !"null".equals(fields.getFieldValue())){
								detail.setPremium(new BigDecimal(fields.getFieldValue()));
							}
						}
						insuranceDetailsList.add(detail);
					}
				}
			}
			if(null!=vasList && !vasList.isEmpty())
			{
				insurancesDetailResponse.setVasDetails(vasList);
			}
			if(null!=insuranceDetailsList && !insuranceDetailsList.isEmpty())
			{
				insurancesDetailResponse.setInsuranceDetails(insuranceDetailsList);
			}
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "inside prepareLMSResponse method -->completed");

		return insurancesDetailResponse;
	}

	private VasInsuranceDetailsLMSResponse callPennantForGetInsvasDetailsLMS(String vasInsno,LoanProduct loanProduct) {
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside  callPennantForGetInsvasDetailsLMS() in VasInsurance with vasInsNumber--> "+vasInsno);
		//VasInsuranceLMSResponse vasInsuranceLMSResponse = null;
		VasInsuranceDetailsLMSResponse vasInsuranceDetailsLMSResponse = null;
		String responseFromLMS = null;
		if(null != vasInsno)
		{
			ObjectMapper mapper = MapperFactory.getInstance();
			String vasInsuranceLMSRequestString = null;
			String lmsIntegrationRequestBeanString = null;
			VasInsRequest vasInsrequest = new VasInsRequest();
			vasInsrequest.setVasReference(vasInsno);
			//Prepare Request for LMSIntegrationService
			LmsRequestBean lmsRequestBean = new LmsRequestBean();
			lmsRequestBean.setHttpMethod("POST");
			lmsRequestBean.setProductCode(loanProduct.getLnprodcode());
			try {
				vasInsuranceLMSRequestString = mapper.writeValueAsString(vasInsrequest);
				logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "vasInsuranceLMSRequestString request in JSON--> "+vasInsuranceLMSRequestString);
			} catch (JsonProcessingException e) {
				throw new BFLTechnicalException("JSNMAPEXC_002", env.getProperty("JSNMAPEXC_002"));
			}
		
			lmsRequestBean.setRequestPayload(vasInsuranceLMSRequestString);
			lmsRequestBean.setSource("GETVASINSDETAILS"); //source present in centralconfiguration properties file
			
			try {
				lmsIntegrationRequestBeanString = mapper.writeValueAsString(lmsRequestBean);
				logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "vasInsuranceLMSRequestString request in JSON--> "+vasInsuranceLMSRequestString);
			} catch (JsonProcessingException e) {
				
				throw new BFLTechnicalException("JSNMAPEXC_002", env.getProperty("JSNMAPEXC_002"));
			}
		
	
			String lmsURL = env.getProperty("api.lms.gateway.POST.url");
			// calling LMSIntegrationService
			responseFromLMS = loanAccountUtil.hitLMSIntegrationService(lmsIntegrationRequestBeanString, lmsURL);
			logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "Response from LMS--> "+responseFromLMS);
			vasInsuranceDetailsLMSResponse =loanAccountUtil.mapFromJson(responseFromLMS, VasInsuranceDetailsLMSResponse.class);
		}
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "return from callPennantForGetInsvasDetailsLMS Pennant response--> "+responseFromLMS);
		return vasInsuranceDetailsLMSResponse;
	
	}

	private VasInsuranceDetailsLMSResponse callPennantForGetInsvasDetails(String vasInsno) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "inside callPennantForGetInsvasDetails() url ::"+resourcePathValueGetInsuranceAndVASDetails);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "vasInsno value"+vasInsno);
		if(StringUtils.isNotBlank(vasInsno) && StringUtils.isNotBlank(resourcePathValueGetInsuranceAndVASDetails))
		{
			HttpHeaders headers = new HttpHeaders();
			//using existing request object to pass to lms
			VasInsRequest request = new VasInsRequest();
			request.setVasReference(vasInsno);
			headers.add(LoanAccountConstants.AUTHORIZATION, authorizationKey);
			headers.setContentType(MediaType.APPLICATION_JSON);
			@SuppressWarnings("unchecked")
			ResponseEntity<VasInsuranceDetailsLMSResponse> lmsResponse = (ResponseEntity<VasInsuranceDetailsLMSResponse>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST,resourcePathValueGetInsuranceAndVASDetails,request, VasInsuranceDetailsLMSResponse.class, null, null, headers);
			if(null != lmsResponse && HttpStatus.OK.equals(lmsResponse.getStatusCode())) {
				return lmsResponse.getBody();
			}
		}
		return null;
	}
	private VasInsuranceLMSResponse callPennantForGetDetails(String loanNumber) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "inside callPennantForGetDetails() url ::"+resourcePathValueGetInsuranceAndVAS);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "loanNumber value"+loanNumber);
		if(StringUtils.isNotBlank(loanNumber) && StringUtils.isNotBlank(resourcePathValueGetInsuranceAndVAS))
		{
			HttpHeaders headers = new HttpHeaders();
			//using existing request object to pass to lms
			LoanRequest request = new LoanRequest();
			request.setFinReference(loanNumber);
			headers.add(LoanAccountConstants.AUTHORIZATION, authorizationKey);
			headers.setContentType(MediaType.APPLICATION_JSON);
			@SuppressWarnings("unchecked")
			ResponseEntity<VasInsuranceLMSResponse> lmsResponse = (ResponseEntity<VasInsuranceLMSResponse>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST,resourcePathValueGetInsuranceAndVAS,request, VasInsuranceLMSResponse.class, null, null, headers);
			if(null != lmsResponse && HttpStatus.OK.equals(lmsResponse.getStatusCode())) {
				return lmsResponse.getBody();
			}
		}
		return null;
	}
}
