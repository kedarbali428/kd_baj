package com.bajaj.bfsd.loanaccount.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.ApplicantBean;
import com.bajaj.bfsd.loanaccount.model.ApplicantSysCode;
import com.bfl.common.exceptions.BFLBusinessException;
import com.google.gson.Gson;

@RefreshScope
@Component
public class ApplicantHelper extends BFLComponent  {

	private static final String CLASS_NAME = ApplicantHelper.class.getName();
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Value("${api.applicant.getDetails.GET.url}")
	private String applicantURL;
	
	@Value("${APLT_001}")
	private String errorCodeAPLTOne;
	
	@Value("${APLT_002}")
	private String errorCodeAPLTTwo;
	
	@Autowired
    private BFLLoggerUtilExt logger;
	
	public String getCustomerIdByApplicantid(String applicantId)
	{
		String apltCustCIF = null;
		ApplicantBean applicantBean =  getApplicantData(applicantId);
		if(null!=applicantBean.getApplicantSysCodes() && !applicantBean.getApplicantSysCodes().isEmpty()){
			List<ApplicantSysCode> applicantSysCodes =applicantBean.getApplicantSysCodes();
			for (ApplicantSysCode applicantSysCode : applicantSysCodes) {
				if(null!=applicantSysCode && null!= applicantSysCode.getInterfaceSystem() && "PLF".equals(applicantSysCode.getInterfaceSystem().getSystemcode()))
				{
					apltCustCIF=applicantSysCode.getRefcode();
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "apltCustCIF value from child "+apltCustCIF);
				}
			}
		}else if(null!=applicantBean.getApltcustcif())
		{
			apltCustCIF= applicantBean.getApltcustcif();
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "apltCustCIF from applicant value "+apltCustCIF);
		}
		return apltCustCIF;
	}
	
	private ApplicantBean getApplicantData(String applicantID)
	{
		ApplicantBean applicantBean;
		if(null!=applicantURL && StringUtils.isNotBlank(applicantURL) && StringUtils.isNotBlank(applicantID))
		{
			Map<String, String> params = new HashMap<>();
			params.put("applicantKey", applicantID);
			ResponseEntity<?> applicantResponseBean = BFLCommonRestClient.invokeRestEndpoint(HttpMethod.GET,applicantURL, null, String.class, params, null, null);
			if(null != applicantResponseBean && HttpStatus.OK.equals(applicantResponseBean.getStatusCode()) && null!=applicantResponseBean.getBody()) {
				String payloadString = new JSONObject(applicantResponseBean.getBody().toString()).get("payload").toString();
				Gson gson = new Gson();
				applicantBean = gson.fromJson(payloadString,ApplicantBean.class);
			}else{
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Invalid data for Applicant from Service");
				throw new BFLBusinessException("APLT_001", errorCodeAPLTOne);
			}
			if(null==applicantBean)
			{
				throw new BFLBusinessException("APLT_001", errorCodeAPLTOne);
			}
		}
		else{
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Wrong with Applicant URL");
			throw new BFLBusinessException("APLT_002", errorCodeAPLTTwo);
		}
		return applicantBean;
	}
}
