package com.bajaj.bfsd.loanaccount.model;

import java.math.BigDecimal;
import java.util.List;

public class VasInsuranceDetailsLMSResponse {

    private String product;
	private String postingAgainst;
	private String primaryLinkRef;
	private String vasReference;
	private BigDecimal fee;
	private String feePaymentMode;
	private String valueDate;
	private String accrualTillDate;
	private String recurringDate;
	private Number renewalFee;
	private String vasStatus;
	private String waivedAmt;
	private List<ExtendedDetails> extendedDetails;
	private ReturnStatus returnStatus;
	private List<Documents> documents;

	public List<Documents> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Documents> documents) {
		this.documents = documents;
	}

	public List<ExtendedDetails> getExtendedDetails() {
		return extendedDetails;
	}

	public void setExtendedDetails(List<ExtendedDetails> extendedDetails) {
		this.extendedDetails = extendedDetails;
	}



	public ReturnStatus getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(ReturnStatus returnStatus) {
		this.returnStatus = returnStatus;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getPostingAgainst() {
		return postingAgainst;
	}

	public void setPostingAgainst(String postingAgainst) {
		this.postingAgainst = postingAgainst;
	}

	public String getPrimaryLinkRef() {
		return primaryLinkRef;
	}

	public void setPrimaryLinkRef(String primaryLinkRef) {
		this.primaryLinkRef = primaryLinkRef;
	}

	public String getVasReference() {
		return vasReference;
	}

	public void setVasReference(String vasReference) {
		this.vasReference = vasReference;
	}

	

	public BigDecimal getFee() {
		return fee;
	}

	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}

	public String getFeePaymentMode() {
		return feePaymentMode;
	}

	public void setFeePaymentMode(String feePaymentMode) {
		this.feePaymentMode = feePaymentMode;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getAccrualTillDate() {
		return accrualTillDate;
	}

	public void setAccrualTillDate(String accrualTillDate) {
		this.accrualTillDate = accrualTillDate;
	}

	public String getRecurringDate() {
		return recurringDate;
	}

	public void setRecurringDate(String recurringDate) {
		this.recurringDate = recurringDate;
	}

	public Number getRenewalFee() {
		return renewalFee;
	}

	public void setRenewalFee(Number renewalFee) {
		this.renewalFee = renewalFee;
	}

	public String getVasStatus() {
		return vasStatus;
	}

	public void setVasStatus(String vasStatus) {
		this.vasStatus = vasStatus;
	}

	public String getWaivedAmt() {
		return waivedAmt;
	}

	public void setWaivedAmt(String waivedAmt) {
		this.waivedAmt = waivedAmt;
	}

	

	
	
}
