package com.bajaj.bfsd.loanaccount.model;

import java.util.Date;

public class Schedule {

	private Date schDate;
	
	private String event;
	
	private Number pftAmount;
	
	private Number schdPft;
	
	private Number schdPftPaid;
	
	private Number schdPri;
	
	private Number schdPriPaid;
	
	private Number feeSchd;
	
	private Number totalAmount;
	
	private Number endBal;

	public Date getSchDate() {
		return schDate;
	}

	public void setSchDate(Date schDate) {
		this.schDate = schDate;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public Number getPftAmount() {
		return pftAmount;
	}

	public void setPftAmount(Number pftAmount) {
		this.pftAmount = pftAmount;
	}

	public Number getSchdPft() {
		return schdPft;
	}

	public void setSchdPft(Number schdPft) {
		this.schdPft = schdPft;
	}

	public Number getSchdPftPaid() {
		return schdPftPaid;
	}

	public void setSchdPftPaid(Number schdPftPaid) {
		this.schdPftPaid = schdPftPaid;
	}

	public Number getSchdPri() {
		return schdPri;
	}

	public void setSchdPri(Number schdPri) {
		this.schdPri = schdPri;
	}

	public Number getSchdPriPaid() {
		return schdPriPaid;
	}

	public void setSchdPriPaid(Number schdPriPaid) {
		this.schdPriPaid = schdPriPaid;
	}

	public Number getFeeSchd() {
		return feeSchd;
	}

	public void setFeeSchd(Number feeSchd) {
		this.feeSchd = feeSchd;
	}

	public Number getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Number totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Number getEndBal() {
		return endBal;
	}

	public void setEndBal(Number endBal) {
		this.endBal = endBal;
	}

	@Override
	public String toString() {
		return "Schedule [schDate=" + schDate + ", event=" + event + ", pftAmount=" + pftAmount + ", schdPft=" + schdPft
				+ ", schdPftPaid=" + schdPftPaid + ", schdPri=" + schdPri + ", schdPriPaid=" + schdPriPaid
				+ ", feeSchd=" + feeSchd + ", totalAmount=" + totalAmount + ", endBal=" + endBal + "]";
	}
	
}
