package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the INSURANCE_APPLICATIONS database table.
 * 
 */
@Entity
@Table(name="INSURANCE_APPLICATIONS")
@NamedQuery(name="InsuranceApplication.findAll", query="SELECT i FROM InsuranceApplication i")
public class InsuranceApplication implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long insapplicationkey;

	private BigDecimal iaagreementacceptflg;

	private BigDecimal iabundlepurpremiumdisc;

	@Temporal(TemporalType.DATE)
	private Date iainsenddt;

	@Temporal(TemporalType.DATE)
	private Date iainsstartdt;

	private BigDecimal iaisactive;

	private String ialstupdateby;

	private Timestamp ialstupdatedt;

	@Temporal(TemporalType.DATE)
	private Date iamaturitydt;

	private BigDecimal ianetpremiumamt;

	private BigDecimal iatcacceptedflg;

	private BigDecimal iatotpremiumamt;

	private BigDecimal iatotsumassured;

	//bi-directional many-to-one association to Application
	@ManyToOne
	@JoinColumn(name="APPLICATIONKEY")
	private Application application;

	//bi-directional many-to-one association to InsPremiumPayMethod
	@ManyToOne
	@JoinColumn(name="INSPREMIUMPAYMETHODKEY")
	private InsPremiumPayMethod insPremiumPayMethod;

	//bi-directional many-to-one association to InsProductCategory
	@ManyToOne
	@JoinColumn(name="INSPRODCATKEY")
	private InsProductCategory insProductCategory;

	//bi-directional many-to-one association to InsProductPlan
	@ManyToOne
	@JoinColumn(name="INSPRODPLANKEY")
	private InsProductPlan insProductPlan;

	//bi-directional many-to-one association to InsProductType
	@ManyToOne
	@JoinColumn(name="INSPRODTYPEKEY")
	private InsProductType insProductType;

	//bi-directional many-to-one association to InsProvider
	@ManyToOne
	@JoinColumn(name="INSPROVIDERKEY")
	private InsProvider insProvider;

	public InsuranceApplication() {
	}

	public long getInsapplicationkey() {
		return this.insapplicationkey;
	}

	public void setInsapplicationkey(long insapplicationkey) {
		this.insapplicationkey = insapplicationkey;
	}

	public BigDecimal getIaagreementacceptflg() {
		return this.iaagreementacceptflg;
	}

	public void setIaagreementacceptflg(BigDecimal iaagreementacceptflg) {
		this.iaagreementacceptflg = iaagreementacceptflg;
	}

	public BigDecimal getIabundlepurpremiumdisc() {
		return this.iabundlepurpremiumdisc;
	}

	public void setIabundlepurpremiumdisc(BigDecimal iabundlepurpremiumdisc) {
		this.iabundlepurpremiumdisc = iabundlepurpremiumdisc;
	}

	public Date getIainsenddt() {
		return this.iainsenddt;
	}

	public void setIainsenddt(Date iainsenddt) {
		this.iainsenddt = iainsenddt;
	}

	public Date getIainsstartdt() {
		return this.iainsstartdt;
	}

	public void setIainsstartdt(Date iainsstartdt) {
		this.iainsstartdt = iainsstartdt;
	}

	public BigDecimal getIaisactive() {
		return this.iaisactive;
	}

	public void setIaisactive(BigDecimal iaisactive) {
		this.iaisactive = iaisactive;
	}

	public String getIalstupdateby() {
		return this.ialstupdateby;
	}

	public void setIalstupdateby(String ialstupdateby) {
		this.ialstupdateby = ialstupdateby;
	}

	public Timestamp getIalstupdatedt() {
		return this.ialstupdatedt;
	}

	public void setIalstupdatedt(Timestamp ialstupdatedt) {
		this.ialstupdatedt = ialstupdatedt;
	}

	public Date getIamaturitydt() {
		return this.iamaturitydt;
	}

	public void setIamaturitydt(Date iamaturitydt) {
		this.iamaturitydt = iamaturitydt;
	}

	public BigDecimal getIanetpremiumamt() {
		return this.ianetpremiumamt;
	}

	public void setIanetpremiumamt(BigDecimal ianetpremiumamt) {
		this.ianetpremiumamt = ianetpremiumamt;
	}

	public BigDecimal getIatcacceptedflg() {
		return this.iatcacceptedflg;
	}

	public void setIatcacceptedflg(BigDecimal iatcacceptedflg) {
		this.iatcacceptedflg = iatcacceptedflg;
	}

	public BigDecimal getIatotpremiumamt() {
		return this.iatotpremiumamt;
	}

	public void setIatotpremiumamt(BigDecimal iatotpremiumamt) {
		this.iatotpremiumamt = iatotpremiumamt;
	}

	public BigDecimal getIatotsumassured() {
		return this.iatotsumassured;
	}

	public void setIatotsumassured(BigDecimal iatotsumassured) {
		this.iatotsumassured = iatotsumassured;
	}

	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public InsPremiumPayMethod getInsPremiumPayMethod() {
		return this.insPremiumPayMethod;
	}

	public void setInsPremiumPayMethod(InsPremiumPayMethod insPremiumPayMethod) {
		this.insPremiumPayMethod = insPremiumPayMethod;
	}

	public InsProductCategory getInsProductCategory() {
		return this.insProductCategory;
	}

	public void setInsProductCategory(InsProductCategory insProductCategory) {
		this.insProductCategory = insProductCategory;
	}

	public InsProductPlan getInsProductPlan() {
		return this.insProductPlan;
	}

	public void setInsProductPlan(InsProductPlan insProductPlan) {
		this.insProductPlan = insProductPlan;
	}

	public InsProductType getInsProductType() {
		return this.insProductType;
	}

	public void setInsProductType(InsProductType insProductType) {
		this.insProductType = insProductType;
	}

	public InsProvider getInsProvider() {
		return this.insProvider;
	}

	public void setInsProvider(InsProvider insProvider) {
		this.insProvider = insProvider;
	}

}