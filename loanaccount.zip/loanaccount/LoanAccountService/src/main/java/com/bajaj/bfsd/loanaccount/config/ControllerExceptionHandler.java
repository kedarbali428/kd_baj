/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.config;

import javax.enterprise.context.RequestScoped;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.bfl.common.util.BFLExceptionUtil;

/**
 * This is exception handler class for exceptions thrown.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	09/12/2016      Initial Version
 */
@ControllerAdvice
public class ControllerExceptionHandler extends ResponseEntityExceptionHandler {
    
    private static final String THIS_CLASS = ControllerExceptionHandler.class.getSimpleName();
    
    /**
     * Variable to hold value for env.
     */
    @Autowired
    private Environment env;
    
    @RequestScoped
    @Autowired
    private BFLLoggerUtil logUtil;
    /**
     * Handle conflict.
     *
     * @param ex the ex
     * @param request the request
     * @return the response entity
     */
    @ExceptionHandler(value = { BFLTechnicalException.class, BFLBusinessException.class, Exception.class })
    protected ResponseEntity<Object> handleConflict(Exception ex, WebRequest request) {
        logUtil.setCorrelationID(request.getHeader(BFLLoggerHeader.ID.getValue()));
        ResponseBean responseBean = BFLExceptionUtil.handle(ex, env);
        if (ex instanceof BFLBusinessException) {

            return new ResponseEntity<>(responseBean, HttpStatus.OK);
        } else if (ex instanceof BFLTechnicalException) {

            return new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
        } else {

            logUtil.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "handleConflict - ",ex);

            return new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}