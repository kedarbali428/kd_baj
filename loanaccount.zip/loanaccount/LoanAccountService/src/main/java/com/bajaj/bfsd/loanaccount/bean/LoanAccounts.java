/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.bean;

import java.util.List;

/**
 * This class holds list of loan account numbers.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	20/02/2017      Initial Version
 */
public class LoanAccounts {

    /**
     * Variable to hold value for loan acct numbers.
     */
    private List<Long> loanAcctNumbers;

    /**
     * Getter method for loan acct numbers.
     *
     * @return loan acct numbers
     */
    public List<Long> getLoanAcctNumbers() {
        return loanAcctNumbers;
    }

    /**
     * Sets the value of loan acct numbers.
     *
     * @param loanAcctNumbers the new loan acct numbers
     */
    public void setLoanAcctNumbers(List<Long> loanAcctNumbers) {
        this.loanAcctNumbers = loanAcctNumbers;
    }
}
