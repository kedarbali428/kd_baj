package com.bajaj.bfsd.loanaccount.bean;

import java.util.List;

public class LoanDetailResponseBean {

	private String loanAcctNumber;
	
	private String returnCode;
	
	private String returnText;
	
	//incomplete details for loans few will be added one by one
	private LoanCollatoralResponseBean collatoralResponseBean;
	
	private LoanScheduleBean financeDetail;
	
	private List<DisbursementBean> disbursementBean;
	
	
	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnText() {
		return returnText;
	}

	public void setReturnText(String returnText) {
		this.returnText = returnText;
	}

	public List<DisbursementBean> getDisbursementBean() {
		return disbursementBean;
	}

	public void setDisbursementBean(List<DisbursementBean> disbursementBean) {
		this.disbursementBean = disbursementBean;
	}

	public String getLoanAcctNumber() {
		return loanAcctNumber;
	}

	public void setLoanAcctNumber(String loanAcctNumber) {
		this.loanAcctNumber = loanAcctNumber;
	}

	public LoanCollatoralResponseBean getCollatoralResponseBean() {
		return collatoralResponseBean;
	}

	public void setCollatoralResponseBean(LoanCollatoralResponseBean collatoralResponseBean) {
		this.collatoralResponseBean = collatoralResponseBean;
	}

	public LoanScheduleBean getFinanceDetail() {
		return financeDetail;
	}

	public void setFinanceDetail(LoanScheduleBean financeDetail) {
		this.financeDetail = financeDetail;
	}
	
	
}
