package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the INS_PRODUCT_CATEGORIES database table.
 * 
 */
@Entity
@Table(name="INS_PRODUCT_CATEGORIES")
@NamedQuery(name="InsProductCategory.findAll", query="SELECT i FROM InsProductCategory i")
public class InsProductCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long insprodcatkey;

	private String ipccode;

	private String ipcdesc;

	private BigDecimal ipcisactive;

	private String ipclstupdateby;

	private Timestamp ipclstupdatedt;

	private BigDecimal ipcprodbundlingflg;

	//bi-directional many-to-one association to InsuranceApplication
	@OneToMany(mappedBy="insProductCategory")
	private List<InsuranceApplication> insuranceApplications;

	//bi-directional many-to-one association to InsPremiumPayMethod
	@OneToMany(mappedBy="insProductCategory")
	private List<InsPremiumPayMethod> insPremiumPayMethods;

	//bi-directional many-to-one association to ProductCategory
	@ManyToOne
	@JoinColumn(name="PRODCATKEY")
	private ProductCategory productCategory;

	//bi-directional many-to-one association to InsProductType
	@OneToMany(mappedBy="insProductCategory")
	private List<InsProductType> insProductTypes;

	public InsProductCategory() {
	}

	public long getInsprodcatkey() {
		return this.insprodcatkey;
	}

	public void setInsprodcatkey(long insprodcatkey) {
		this.insprodcatkey = insprodcatkey;
	}

	public String getIpccode() {
		return this.ipccode;
	}

	public void setIpccode(String ipccode) {
		this.ipccode = ipccode;
	}

	public String getIpcdesc() {
		return this.ipcdesc;
	}

	public void setIpcdesc(String ipcdesc) {
		this.ipcdesc = ipcdesc;
	}

	public BigDecimal getIpcisactive() {
		return this.ipcisactive;
	}

	public void setIpcisactive(BigDecimal ipcisactive) {
		this.ipcisactive = ipcisactive;
	}

	public String getIpclstupdateby() {
		return this.ipclstupdateby;
	}

	public void setIpclstupdateby(String ipclstupdateby) {
		this.ipclstupdateby = ipclstupdateby;
	}

	public Timestamp getIpclstupdatedt() {
		return this.ipclstupdatedt;
	}

	public void setIpclstupdatedt(Timestamp ipclstupdatedt) {
		this.ipclstupdatedt = ipclstupdatedt;
	}

	public BigDecimal getIpcprodbundlingflg() {
		return this.ipcprodbundlingflg;
	}

	public void setIpcprodbundlingflg(BigDecimal ipcprodbundlingflg) {
		this.ipcprodbundlingflg = ipcprodbundlingflg;
	}

	public List<InsuranceApplication> getInsuranceApplications() {
		return this.insuranceApplications;
	}

	public void setInsuranceApplications(List<InsuranceApplication> insuranceApplications) {
		this.insuranceApplications = insuranceApplications;
	}

	public InsuranceApplication addInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().add(insuranceApplication);
		insuranceApplication.setInsProductCategory(this);

		return insuranceApplication;
	}

	public InsuranceApplication removeInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().remove(insuranceApplication);
		insuranceApplication.setInsProductCategory(null);

		return insuranceApplication;
	}

	public List<InsPremiumPayMethod> getInsPremiumPayMethods() {
		return this.insPremiumPayMethods;
	}

	public void setInsPremiumPayMethods(List<InsPremiumPayMethod> insPremiumPayMethods) {
		this.insPremiumPayMethods = insPremiumPayMethods;
	}

	public InsPremiumPayMethod addInsPremiumPayMethod(InsPremiumPayMethod insPremiumPayMethod) {
		getInsPremiumPayMethods().add(insPremiumPayMethod);
		insPremiumPayMethod.setInsProductCategory(this);

		return insPremiumPayMethod;
	}

	public InsPremiumPayMethod removeInsPremiumPayMethod(InsPremiumPayMethod insPremiumPayMethod) {
		getInsPremiumPayMethods().remove(insPremiumPayMethod);
		insPremiumPayMethod.setInsProductCategory(null);

		return insPremiumPayMethod;
	}

	public ProductCategory getProductCategory() {
		return this.productCategory;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}

	public List<InsProductType> getInsProductTypes() {
		return this.insProductTypes;
	}

	public void setInsProductTypes(List<InsProductType> insProductTypes) {
		this.insProductTypes = insProductTypes;
	}

	public InsProductType addInsProductType(InsProductType insProductType) {
		getInsProductTypes().add(insProductType);
		insProductType.setInsProductCategory(this);

		return insProductType;
	}

	public InsProductType removeInsProductType(InsProductType insProductType) {
		getInsProductTypes().remove(insProductType);
		insProductType.setInsProductCategory(null);

		return insProductType;
	}

}