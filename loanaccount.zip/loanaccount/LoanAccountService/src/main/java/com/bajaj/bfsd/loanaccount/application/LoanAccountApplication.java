/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.scheduling.annotation.EnableAsync;

import com.bajaj.bfsd.common.business.baseclasses.BFLAsyncBusinessApplication;

/**
 * This is a main class for LoanAccount Service.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	16/02/2017      Initial Version
 */
@PropertySources(value = {@PropertySource("classpath:loanaccount.properties"),
                          @PropertySource("classpath:error.properties"),
                          @PropertySource("classpath:common.properties")})
@EntityScan("com")
@EnableAsync
public class LoanAccountApplication extends BFLAsyncBusinessApplication {

    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {        
        SpringApplication.run(LoanAccountApplication.class, args);
    }

}
