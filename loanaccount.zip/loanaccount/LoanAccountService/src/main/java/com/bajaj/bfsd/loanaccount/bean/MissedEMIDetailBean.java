package com.bajaj.bfsd.loanaccount.bean;

import java.util.List;

public class MissedEMIDetailBean {

	private Double amountToBePaid;
	
	private List<MissedEMI> missedEMI;

	private Double totalFee;
	
	private Double totalBounceCharge;

	public Double getTotalBounceCharge() {
		return totalBounceCharge;
	}

	public void setTotalBounceCharge(Double totalBounceCharge) {
		this.totalBounceCharge = totalBounceCharge;
	}

	public Double getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(Double totalFee) {
		this.totalFee = totalFee;
	}

	public Double getAmountToBePaid() {
		return amountToBePaid;
	}

	public void setAmountToBePaid(Double amountToBePaid) {
		this.amountToBePaid = amountToBePaid;
	}

	public List<MissedEMI> getMissedEMI() {
		return missedEMI;
	}

	public void setMissedEMI(List<MissedEMI> missedEMI) {
		this.missedEMI = missedEMI;
	}
	
	
}
