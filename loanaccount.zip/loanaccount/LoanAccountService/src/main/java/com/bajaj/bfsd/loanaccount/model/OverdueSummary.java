package com.bajaj.bfsd.loanaccount.model;

public class OverdueSummary {

	private String odDate;
	
	private Number odAmount;
	
	private Number odCharge;
	
	private Number odChargePaid;

	private Number odPft;
	
	private Number odPftPaid;

	public String getOdDate() {
		return odDate;
	}

	public void setOdDate(String odDate) {
		this.odDate = odDate;
	}

	public Number getOdAmount() {
		return odAmount;
	}

	public void setOdAmount(Number odAmount) {
		this.odAmount = odAmount;
	}

	public Number getOdCharge() {
		return odCharge;
	}

	public void setOdCharge(Number odCharge) {
		this.odCharge = odCharge;
	}

	public Number getOdChargePaid() {
		return odChargePaid;
	}

	public void setOdChargePaid(Number odChargePaid) {
		this.odChargePaid = odChargePaid;
	}

	public Number getOdPft() {
		return odPft;
	}

	public void setOdPft(Number odPft) {
		this.odPft = odPft;
	}

	public Number getOdPftPaid() {
		return odPftPaid;
	}

	public void setOdPftPaid(Number odPftPaid) {
		this.odPftPaid = odPftPaid;
	}
	
}	
