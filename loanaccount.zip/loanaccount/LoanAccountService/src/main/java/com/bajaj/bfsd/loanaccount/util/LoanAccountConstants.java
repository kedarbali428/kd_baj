/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.util;

import java.math.BigDecimal;

/**
 * This is constant class for constants.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602          20/02/2017      Initial Version
 */
public class LoanAccountConstants {
    
	
	/**
     * Constant for VALUE_Y.
     */
    public static final String VALUE_Y = "Y";
    
    /**
     * Constant for VALUE_N.
     */
    public static final String VALUE_N = "N";

    public static final String AUTHORIZATION="Authorization";
    
    public static final String PPEVENT = "PP";
    public static final String FCEVENT = "FC";
    public static final String WDEVENT = "WD";
    public static final String MEEVENT = "ME";
    public static final String DIEVENT = "DI";
    public static final String TDEVENT = "TD";
    public static final String MTLOAN = "MT";
	public static final String ADVEMILOAN = "ADVEMI";
    public static final String NEFT = "NEFT";
    public static final String IMPS = "IMPS";
    public static final String CIF = "cif";
    public static final String FINREFERENCE = "finreference";
    public static final String COLLATERALREF = "collateralRef";
    public static final String SOFL = "SOFL";
    public static final String SOLTL = "SOLTL";
    public static final String DDLHF = "DDLHF";
    public static final String DCAHF = "DCAHF";
    public static final String DBLH = "DBLH";
    public static final String DHPL = "DHPL";
    public static final String REDUCETENOR = "reduceTENOR";
    public static final String REDUCEPRINCIPAL = "reducePRINCIPAL";

    public static final String FETCH_APLLICANT_DETAILS="SELECT DISTINCT AP.APLTFIRSTNAME, AE.APLTEMAILADDRESS, AN.APLTPHNUMNUMBER FROM "
			+ "APPLICANTS AP,APPLICANT_EMAILS AE,APPLICANT_PHONE_NUMBERS AN,EMAIL_TYPES ET,PHONE_NUMBER_TYPES PH"
			+ " WHERE AP.APPLICANTKEY = :applicantKey AND AP.APLTISACTIVE = 1 AND AE.APLTEMAILISACTIVE = 1 AND AN.APLTPHNUMISACTIVE=1 AND AP.APPLICANTKEY = AE.APPLICANTKEY"
			+ " AND AP.APPLICANTKEY = AN.APPLICANTKEY AND AE.EMAILTYPEKEY = ET.EMAILTYPEKEY AND ET.EMAILTYPECODE = 'PERSON1' "
			+ " AND AN.PHONETYPEKEY = PH.PHONETYPEKEY AND PH.PHONETYPECODE = 'MOBILE'";
    public static final String FETCH_INS_DETAILS="SELECT INSPRODTYPECODE,INSPRODTYPEDESC FROM INS_PRODUCT_TYPES WHERE INSPRODTYPEKEY IN(SELECT INSPRODTYPEKEY FROM "
			+ " INS_PRODUCT_PLANS WHERE INS_PRODUCT_PLANS.INSPLANCODE=:INSPLANCODE)";
    public static final String FETCH_VAS_DETAILS="SELECT VPPRODUCTCODE,VPPRODUCTDESC FROM VAS_PRODUCT_PLANS WHERE VPPRODUCTCODE=:VPPRODUCTCODE";
    public static final String FETCH_APPLICATIONDETAILS="SELECT APPLICATIONKEY,PRODCATKEY,APPCOREACCNUM FROM APPLICATIONS WHERE APPCOREACCNUM = :LOANNUMBER";
    public static final String FETCH_POLICYNO="SELECT APPCOREACCNUM,PRODCATKEY FROM APPLICATIONS WHERE PARENTAPPLICATIONKEY=:APPLICATIONKEY AND PRODCATKEY IN(28,29,6)";
    public static final String FETCH_APPLICANTDETAILS="from  Applicant ap where ap.applicantkey =:applicantkey and ap.apltisactive=:apltisactive";
    public static final String FETCH_APPLICATIONBYLAN="from Application a where a.appcoreaccnum =:lanNo and a.appisactive=1";
    public static final String FETCH_APPAPPLICANTBYAPPLICANTID="from ApplicationApplicant aa where aa.applicant.applicantkey = :applicantId and aa.appapltisactive=1";
    public static final BigDecimal ISACTIVE = new BigDecimal(1);
    public static final String FETCH_LOANPRODUCTTYPE = "from LoanProductType where loantype = :loantype and lntypisactive = 1";

    public static final String AMC_Charge="AMCCHG";
    private LoanAccountConstants()
	{
		//private contructor
	}
}
