package com.bajaj.bfsd.loanaccount.model;

public class Disbursement {

	private String disbParty;
	
	private String disbType;
	
	private String disbDate;
	
	private Double disbAmount;
	
	private String bankCode;
	
	private String bankName;
	
	private String ifsc;

	private String branchCode;
	
	private String accountNo;
	
	private String acHolderName;
	
	private String phoneCountryCode;
	
	private String phoneAreaCode;
	
	private String phoneNumber;

	public String getDisbParty() {
		return disbParty;
	}

	public void setDisbParty(String disbParty) {
		this.disbParty = disbParty;
	}

	public String getDisbType() {
		return disbType;
	}

	public void setDisbType(String disbType) {
		this.disbType = disbType;
	}

	public String getDisbDate() {
		return disbDate;
	}

	public void setDisbDate(String disbDate) {
		this.disbDate = disbDate;
	}

	public Double getDisbAmount() {
		return disbAmount;
	}

	public void setDisbAmount(Double disbAmount) {
		this.disbAmount = disbAmount;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAcHolderName() {
		return acHolderName;
	}

	public void setAcHolderName(String acHolderName) {
		this.acHolderName = acHolderName;
	}

	public String getPhoneCountryCode() {
		return phoneCountryCode;
	}

	public void setPhoneCountryCode(String phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}

	public String getPhoneAreaCode() {
		return phoneAreaCode;
	}

	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
}
