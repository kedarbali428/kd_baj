/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.loanaccount.bean.LoanAccountResponseBean;
import com.bajaj.bfsd.loanaccount.service.LoanAccountService;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLBusinessException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * This is a controller class for LoanAccount.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	16/02/2017      Initial Version
 */
@RestController
public class LoanAccountController extends BFLController {

    private static final String THIS_CLASS = LoanAccountController.class.getSimpleName();
    
    @Autowired
    private LoanAccountService loanAccountService;
    
    @Autowired
    private BFLLoggerUtilExt logger;
    
    @Autowired
	private CustomDefaultHeaders customheaders;
    
    @Value("${APLT_003}")
	private String errorCodeAPLTOne;
    
    @Value("${custThreeSixty}")
	private String custThreeSixty;
    
    

    @ApiOperation(value = "Provides loan details for loan account number", 
                notes = "Provides loan details for loan account number", httpMethod = "GET")
    @ApiImplicitParam(name = "cmptcorrid", required = true,
                    dataType = "string", paramType = "header") 
    @RequestMapping(value = "${api.loanaccount.loandetails.GET.uri}",
                  method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    public ResponseEntity<ResponseBean> getLoanDetails(
    		@PathVariable String loanAcctNumber, 
          @RequestHeader HttpHeaders headers){
      
          logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getLoanDetails - started with LAN number--> "+loanAcctNumber);
       	  return new ResponseEntity<>(new ResponseBean(loanAccountService.getLoanDetailsByLanNo(null,loanAcctNumber)),headers, HttpStatus.OK);
    }
    
    @ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header") 
	@ApiOperation(value = "loan Details", notes = "list of loan accounts for customer id", httpMethod = "GET")
	@RequestMapping(value = "${api.loanaccount.customerloans.GET.uri}",method = RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getLoanAccountDetails(@RequestParam (required=false)String customerId,
			@RequestParam(required=false) String type, @RequestHeader HttpHeaders headers) {
    	
    	logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"Inside getLoanAccountDetails() with customerId--> "+customerId+ " and type--> "+type);
    	LoanAccountResponseBean loanAccountResponseBean;
      	if("Y".equals(custThreeSixty))
      	{
      		loanAccountResponseBean = callCustomerThreeSixtyFlow(type);
      	}else{
      		loanAccountResponseBean = loanAccountService.getLoanAccountDetails(customerId,type);
      	}
    	logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER," completed getLoanAccountDetails() with customerId--> "+customerId+ " and type--> "+type);
		return new ResponseEntity<>(new ResponseBean(loanAccountResponseBean), HttpStatus.OK);
    }

	private LoanAccountResponseBean callCustomerThreeSixtyFlow(String type) {
		if(null!=customheaders && 0!=customheaders.getApplntId()){
			Long applicantkey = customheaders.getApplntId();
			String applicantKey=applicantkey.toString();
	    logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "getLoanAccountDetails - started");
		return loanAccountService.getLoanAccountDetails(applicantKey,type);
      	}
		else{
			throw new BFLBusinessException("APLT_003", errorCodeAPLTOne);
		}
	}
}




