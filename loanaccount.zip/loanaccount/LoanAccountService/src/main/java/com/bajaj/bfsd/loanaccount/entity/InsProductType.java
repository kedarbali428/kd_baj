package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the INS_PRODUCT_TYPES database table.
 * 
 */
@Entity
@Table(name="INS_PRODUCT_TYPES")
@NamedQuery(name="InsProductType.findAll", query="SELECT i FROM InsProductType i")
public class InsProductType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long insprodtypekey;

	private String iptcode;

	private String iptdesc;

	private BigDecimal iptisactive;

	private String iptlstupdateby;

	private Timestamp iptlstupdatedt;

	//bi-directional many-to-one association to InsuranceApplication
	@OneToMany(mappedBy="insProductType")
	private List<InsuranceApplication> insuranceApplications;

	//bi-directional many-to-one association to InsProductPlan
	@OneToMany(mappedBy="insProductType")
	private List<InsProductPlan> insProductPlans;

	//bi-directional many-to-one association to InsProductCategory
	@ManyToOne
	@JoinColumn(name="INSPRODCATKEY")
	private InsProductCategory insProductCategory;

	public InsProductType() {
	}

	public long getInsprodtypekey() {
		return this.insprodtypekey;
	}

	public void setInsprodtypekey(long insprodtypekey) {
		this.insprodtypekey = insprodtypekey;
	}

	public String getIptcode() {
		return this.iptcode;
	}

	public void setIptcode(String iptcode) {
		this.iptcode = iptcode;
	}

	public String getIptdesc() {
		return this.iptdesc;
	}

	public void setIptdesc(String iptdesc) {
		this.iptdesc = iptdesc;
	}

	public BigDecimal getIptisactive() {
		return this.iptisactive;
	}

	public void setIptisactive(BigDecimal iptisactive) {
		this.iptisactive = iptisactive;
	}

	public String getIptlstupdateby() {
		return this.iptlstupdateby;
	}

	public void setIptlstupdateby(String iptlstupdateby) {
		this.iptlstupdateby = iptlstupdateby;
	}

	public Timestamp getIptlstupdatedt() {
		return this.iptlstupdatedt;
	}

	public void setIptlstupdatedt(Timestamp iptlstupdatedt) {
		this.iptlstupdatedt = iptlstupdatedt;
	}

	public List<InsuranceApplication> getInsuranceApplications() {
		return this.insuranceApplications;
	}

	public void setInsuranceApplications(List<InsuranceApplication> insuranceApplications) {
		this.insuranceApplications = insuranceApplications;
	}

	public InsuranceApplication addInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().add(insuranceApplication);
		insuranceApplication.setInsProductType(this);

		return insuranceApplication;
	}

	public InsuranceApplication removeInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().remove(insuranceApplication);
		insuranceApplication.setInsProductType(null);

		return insuranceApplication;
	}

	public List<InsProductPlan> getInsProductPlans() {
		return this.insProductPlans;
	}

	public void setInsProductPlans(List<InsProductPlan> insProductPlans) {
		this.insProductPlans = insProductPlans;
	}

	public InsProductPlan addInsProductPlan(InsProductPlan insProductPlan) {
		getInsProductPlans().add(insProductPlan);
		insProductPlan.setInsProductType(this);

		return insProductPlan;
	}

	public InsProductPlan removeInsProductPlan(InsProductPlan insProductPlan) {
		getInsProductPlans().remove(insProductPlan);
		insProductPlan.setInsProductType(null);

		return insProductPlan;
	}

	public InsProductCategory getInsProductCategory() {
		return this.insProductCategory;
	}

	public void setInsProductCategory(InsProductCategory insProductCategory) {
		this.insProductCategory = insProductCategory;
	}

}