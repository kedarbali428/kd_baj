package com.bajaj.bfsd.loanaccount.model;

import java.util.Date;
import java.util.List;

public class LoanDetail {

	private String finReference;

	private String cif;
	
	private String finType;
	
	private String finCcy;
	
	private String finBranch;

	private String profitDaysBasis;
	
	private Number finAmount;
	
	private Number finAssetValue;
	
    private String finRepayMethod;
	
    private String finStartDate;
	
	private Number numberOfTerms;
	
	private String maturityDate;
	
	private String repayFrq;
	
	private Boolean allowGrcPeriod;
	
	private Boolean tdsApplicable;
	
	private Boolean manualSchedule;
	
	private String grcPeriodEndDate;
	
	private String grcBaseRate;
	
	private String nextRepayDate;
	
   private Date firstDisbDate;
  
   private Date lastDisbDate;

   private Number repayPftRate;
   
   private String repayBaseRate;
   
   private Number repayMargin;
   
   private Number repaySpecialRate;
   
   private Number nextRepayAmount;

   private Number paidTotal;
   
   private Number paidPri;
   
   private Number paidPft;
   
   private Number outstandingTotal;
   
   private Number outstandingPri;
   
   private Number outstandingPft;
   
   private Number futureInst;
   
   private String finStatus;
   
   private String disbStatus;
   
   private String product;
   
   private String applicationNo;
   
   private List<CoApplicant> coApplicants;
   
public String getApplicationNo() {
	return applicationNo;
}

public void setApplicationNo(String applicationNo) {
	this.applicationNo = applicationNo;
}

public String getProduct() {
	return product;
}

public void setProduct(String product) {
	this.product = product;
}

public String getDisbStatus() {
	return disbStatus;
}

public void setDisbStatus(String disbStatus) {
	this.disbStatus = disbStatus;
}

public String getCif() {
	return cif;
}

public void setCif(String cif) {
	this.cif = cif;
}

public String getFinType() {
	return finType;
}

public void setFinType(String finType) {
	this.finType = finType;
}

public String getFinCcy() {
	return finCcy;
}

public void setFinCcy(String finCcy) {
	this.finCcy = finCcy;
}

public String getFinBranch() {
	return finBranch;
}

public void setFinBranch(String finBranch) {
	this.finBranch = finBranch;
}

public String getProfitDaysBasis() {
	return profitDaysBasis;
}

public void setProfitDaysBasis(String profitDaysBasis) {
	this.profitDaysBasis = profitDaysBasis;
}

public Number getFinAmount() {
	return finAmount;
}

public void setFinAmount(Number finAmount) {
	this.finAmount = finAmount;
}

public Number getFinAssetValue() {
	return finAssetValue;
}

public void setFinAssetValue(Number finAssetValue) {
	this.finAssetValue = finAssetValue;
}

public String getFinRepayMethod() {
	return finRepayMethod;
}

public void setFinRepayMethod(String finRepayMethod) {
	this.finRepayMethod = finRepayMethod;
}

public String getFinStartDate() {
	return finStartDate;
}

public void setFinStartDate(String finStartDate) {
	this.finStartDate = finStartDate;
}

public Number getNumberOfTerms() {
	return numberOfTerms;
}

public void setNumberOfTerms(Number numberOfTerms) {
	this.numberOfTerms = numberOfTerms;
}

public String getMaturityDate() {
	return maturityDate;
}

public void setMaturityDate(String maturityDate) {
	this.maturityDate = maturityDate;
}

public String getRepayFrq() {
	return repayFrq;
}

public void setRepayFrq(String repayFrq) {
	this.repayFrq = repayFrq;
}

public Boolean getAllowGrcPeriod() {
	return allowGrcPeriod;
}

public void setAllowGrcPeriod(Boolean allowGrcPeriod) {
	this.allowGrcPeriod = allowGrcPeriod;
}

public Boolean getTdsApplicable() {
	return tdsApplicable;
}

public void setTdsApplicable(Boolean tdsApplicable) {
	this.tdsApplicable = tdsApplicable;
}

public Boolean getManualSchedule() {
	return manualSchedule;
}

public void setManualSchedule(Boolean manualSchedule) {
	this.manualSchedule = manualSchedule;
}

public String getGrcPeriodEndDate() {
	return grcPeriodEndDate;
}

public void setGrcPeriodEndDate(String grcPeriodEndDate) {
	this.grcPeriodEndDate = grcPeriodEndDate;
}

public String getGrcBaseRate() {
	return grcBaseRate;
}

public void setGrcBaseRate(String grcBaseRate) {
	this.grcBaseRate = grcBaseRate;
}

public String getNextRepayDate() {
	return nextRepayDate;
}

public void setNextRepayDate(String nextRepayDate) {
	this.nextRepayDate = nextRepayDate;
}

public Date getFirstDisbDate() {
	return firstDisbDate;
}

public void setFirstDisbDate(Date firstDisbDate) {
	this.firstDisbDate = firstDisbDate;
}

public Date getLastDisbDate() {
	return lastDisbDate;
}

public void setLastDisbDate(Date lastDisbDate) {
	this.lastDisbDate = lastDisbDate;
}

public Number getRepayPftRate() {
	return repayPftRate;
}

public void setRepayPftRate(Number repayPftRate) {
	this.repayPftRate = repayPftRate;
}

public String getRepayBaseRate() {
	return repayBaseRate;
}

public void setRepayBaseRate(String repayBaseRate) {
	this.repayBaseRate = repayBaseRate;
}

public Number getRepayMargin() {
	return repayMargin;
}

public void setRepayMargin(Number repayMargin) {
	this.repayMargin = repayMargin;
}

public Number getRepaySpecialRate() {
	return repaySpecialRate;
}

public void setRepaySpecialRate(Number repaySpecialRate) {
	this.repaySpecialRate = repaySpecialRate;
}

public String getFinReference() {
	return finReference;
}

public void setFinReference(String finReference) {
	this.finReference = finReference;
}

public Number getNextRepayAmount() {
	return nextRepayAmount;
}

public void setNextRepayAmount(Number nextRepayAmount) {
	this.nextRepayAmount = nextRepayAmount;
}

public Number getPaidTotal() {
	return paidTotal;
}

public void setPaidTotal(Number paidTotal) {
	this.paidTotal = paidTotal;
}

public Number getPaidPri() {
	return paidPri;
}

public void setPaidPri(Number paidPri) {
	this.paidPri = paidPri;
}

public Number getPaidPft() {
	return paidPft;
}

public void setPaidPft(Number paidPft) {
	this.paidPft = paidPft;
}

public Number getOutstandingTotal() {
	return outstandingTotal;
}

public void setOutstandingTotal(Number outstandingTotal) {
	this.outstandingTotal = outstandingTotal;
}

public Number getOutstandingPri() {
	return outstandingPri;
}

public void setOutstandingPri(Number outstandingPri) {
	this.outstandingPri = outstandingPri;
}

public Number getOutstandingPft() {
	return outstandingPft;
}

public void setOutstandingPft(Number outstandingPft) {
	this.outstandingPft = outstandingPft;
}

public Number getFutureInst() {
	return futureInst;
}

public void setFutureInst(Number futureInst) {
	this.futureInst = futureInst;
}

public String getFinStatus() {
	return finStatus;
}

public void setFinStatus(String finStatus) {
	this.finStatus = finStatus;
}

public List<CoApplicant> getCoApplicants() {
	return coApplicants;
}

public void setCoApplicants(List<CoApplicant> coApplicants) {
	this.coApplicants = coApplicants;
}	
	
}
