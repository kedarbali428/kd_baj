package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the SER_STMT_REPORT_TYPES database table.
 * 
 */
@Entity
@Table(name="SER_STMT_REPORT_TYPES")
@NamedQuery(name="SerStmtReportType.findAll", query="SELECT s FROM SerStmtReportType s")
public class SerStmtReportType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long serstmttypekey;

	private String description;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodcatkey;

	private String statementcode;

	//bi-directional many-to-one association to SerAppStmtRptDocument
	@OneToMany(mappedBy="serStmtReportType")
	private List<SerAppStmtRptDocument> serAppStmtRptDocuments;

	public SerStmtReportType() {
	}

	public long getSerstmttypekey() {
		return this.serstmttypekey;
	}

	public void setSerstmttypekey(long serstmttypekey) {
		this.serstmttypekey = serstmttypekey;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdcatkey() {
		return this.prodcatkey;
	}

	public void setProdcatkey(BigDecimal prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public String getStatementcode() {
		return this.statementcode;
	}

	public void setStatementcode(String statementcode) {
		this.statementcode = statementcode;
	}

	public List<SerAppStmtRptDocument> getSerAppStmtRptDocuments() {
		return this.serAppStmtRptDocuments;
	}

	public void setSerAppStmtRptDocuments(List<SerAppStmtRptDocument> serAppStmtRptDocuments) {
		this.serAppStmtRptDocuments = serAppStmtRptDocuments;
	}

	public SerAppStmtRptDocument addSerAppStmtRptDocument(SerAppStmtRptDocument serAppStmtRptDocument) {
		getSerAppStmtRptDocuments().add(serAppStmtRptDocument);
		serAppStmtRptDocument.setSerStmtReportType(this);

		return serAppStmtRptDocument;
	}

	public SerAppStmtRptDocument removeSerAppStmtRptDocument(SerAppStmtRptDocument serAppStmtRptDocument) {
		getSerAppStmtRptDocuments().remove(serAppStmtRptDocument);
		serAppStmtRptDocument.setSerStmtReportType(null);

		return serAppStmtRptDocument;
	}

}