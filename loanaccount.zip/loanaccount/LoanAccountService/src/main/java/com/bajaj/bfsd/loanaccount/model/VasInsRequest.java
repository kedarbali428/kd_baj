package com.bajaj.bfsd.loanaccount.model;

public class VasInsRequest {

	private String vasReference;

	public String getVasReference() {
		return vasReference;
	}

	public void setVasReference(String vasReference) {
		this.vasReference = vasReference;
	}

	

}