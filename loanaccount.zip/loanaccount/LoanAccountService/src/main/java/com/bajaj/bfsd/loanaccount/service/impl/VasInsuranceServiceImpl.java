package com.bajaj.bfsd.loanaccount.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.loanaccount.bean.InsurancesDetailResponse;
import com.bajaj.bfsd.loanaccount.helper.VasInsuranceHelper;
import com.bajaj.bfsd.loanaccount.service.VasInsuranceService;
import com.bfl.common.exceptions.BFLBusinessException;

@Service
public class VasInsuranceServiceImpl extends BFLComponent implements VasInsuranceService {

    private static final String THIS_CLASS = VasInsuranceServiceImpl.class.getSimpleName();

    @Autowired
    private BFLLoggerUtilExt logger;
    
    @Autowired
    private VasInsuranceHelper vasInsuranceHelper;
    
    @Value("${VASINS001}")
    private String errorLAN01;
    
	@Override
	public InsurancesDetailResponse getVasAndInsuranceDetails(String loanNumber,String productCode) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "inside getVasAndInsuranceDetails");
		if(null!=loanNumber && StringUtils.isNotBlank(loanNumber))
		{
			return vasInsuranceHelper.getVasAndInsurance(loanNumber,productCode);
		}else{
			throw new BFLBusinessException("VASINS001", errorLAN01);
		}
	}

}
