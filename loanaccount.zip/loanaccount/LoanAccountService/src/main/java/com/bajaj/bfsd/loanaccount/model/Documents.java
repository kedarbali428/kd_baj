package com.bajaj.bfsd.loanaccount.model;

public class Documents {

	

}
