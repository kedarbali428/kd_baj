/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.service;

import com.bajaj.bfsd.loanaccount.bean.LoanAccountResponseBean;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailResponseBean;

/**
 * This is an interface for Loan account details view operations.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602          20/02/2012      Initial Version
 */
public interface LoanAccountService {
    
    public LoanAccountResponseBean getLoanAccountDetails(String customerId,String type);
    
    public LoanDetailResponseBean getLoanDetailsByLanNo(String lanNo,String productCode);
}
