package com.bajaj.bfsd.loanaccount.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.bajaj.bfsd.loanaccount.entity.Applicant;

/**
 * The persistent class for the BANK_MASTER_SYS_CODES database table.
 * 
 */
@Entity
@Table(name = "APPLICANT_SYS_CODES")
@NamedQuery(name = "ApplicantSysCode.findAll", query = "SELECT a FROM ApplicantSysCode a")
public class ApplicantSysCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long apltsyscdkey;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String refcode;

	// bi-directional many-to-one association to Applicant
	@ManyToOne
	@JoinColumn(name = "APPLICANTKEY")
	private Applicant applicant;

	// bi-directional many-to-one association to InterfaceSystem
	@ManyToOne
	@JoinColumn(name = "SYSTEMKEY")
	private InterfaceSystem interfaceSystem;

	public long getApltsyscdkey() {
		return apltsyscdkey;
	}

	public void setApltsyscdkey(long apltsyscdkey) {
		this.apltsyscdkey = apltsyscdkey;
	}

	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getRefcode() {
		return refcode;
	}

	public void setRefcode(String refcode) {
		this.refcode = refcode;
	}

	public Applicant getApplicant() {
		return applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}

	public InterfaceSystem getInterfaceSystem() {
		return interfaceSystem;
	}

	public void setInterfaceSystem(InterfaceSystem interfaceSystem) {
		this.interfaceSystem = interfaceSystem;
	}

}