package com.bajaj.bfsd.loanaccount.dao;

import com.bajaj.bfsd.loanaccount.model.FeesType;

@FunctionalInterface
public interface FeeDetailDao {

	public FeesType getFeeDetailsByFeeCode(String feeCode);
}
