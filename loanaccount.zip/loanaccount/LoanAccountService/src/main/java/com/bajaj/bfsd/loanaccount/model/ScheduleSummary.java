package com.bajaj.bfsd.loanaccount.model;

import java.util.List;

import com.bajaj.bfsd.loanaccount.bean.AdvanceEMIBean;

public class ScheduleSummary {
	
	private Number effectiveRateOfReturn;
	
	private String nextSchDate;
	
	private String firstInstDate;
	
	private String firstDisbDate;
	
	private String lastDisbDate;
	
	private Number firstEmiAmount;
	
	private Number futureInst;
	
	private Number futureTenor;
	
	private Number loanTenor;
	
	private Number paidTotal;
	
	private Number paidPri;
	
	private Number paidPft;
	
	private Number outstandingTotal;
	
	private Number outstandingPri;
	
	private Number outstandingPft;
	
	private Number overdueTotal;
	
	private Number overduePri;
	
	private Number overduePft;
	
	private Number overdueInst;
	
	private String lastRepayDate;
	
	private Number totalGracePft;
	
	private Number totalProfit;
	
	private Number totalGrossGrcPft;
	
	private Number feeChargeAmt;
	
	private Number numberOfTerms;
	
	private String maturityDate;
	
	private Number advPaymentAmount;

	private List<OverdueSummary> overdueCharges;
	
	private String finActiveStatus;
	
	private Boolean fullyDisb;

	private Number nextRepayAmount;
	
	private Number currentDroplineLimit;
	
	private Number utilisation;
	
	private Number availableLimit;
	
	private Number graceInst;
	
	private Number futureGraceInst;
	
	private List<AdvanceEMIBean> advEmi;
	
	private Number noPaidInst;
	
	public List<OverdueSummary> getOverdueCharges() {
		return overdueCharges;
	}

	public void setOverdueCharges(List<OverdueSummary> overdueCharges) {
		this.overdueCharges = overdueCharges;
	}

	public String getFirstDisbDate() {
		return firstDisbDate;
	}

	public void setFirstDisbDate(String firstDisbDate) {
		this.firstDisbDate = firstDisbDate;
	}

	public String getLastDisbDate() {
		return lastDisbDate;
	}

	public void setLastDisbDate(String lastDisbDate) {
		this.lastDisbDate = lastDisbDate;
	}

	public Number getLoanTenor() {
		return loanTenor;
	}

	public void setLoanTenor(Number loanTenor) {
		this.loanTenor = loanTenor;
	}

	public Number getNextRepayAmount() {
		return nextRepayAmount;
	}

	public void setNextRepayAmount(Number nextRepayAmount) {
		this.nextRepayAmount = nextRepayAmount;
	}

	public Number getEffectiveRateOfReturn() {
		return effectiveRateOfReturn;
	}

	public void setEffectiveRateOfReturn(Number effectiveRateOfReturn) {
		this.effectiveRateOfReturn = effectiveRateOfReturn;
	}

	public String getNextSchDate() {
		return nextSchDate;
	}

	public void setNextSchDate(String nextSchDate) {
		this.nextSchDate = nextSchDate;
	}

	public String getFirstInstDate() {
		return firstInstDate;
	}

	public void setFirstInstDate(String firstInstDate) {
		this.firstInstDate = firstInstDate;
	}

	public Number getFirstEmiAmount() {
		return firstEmiAmount;
	}

	public void setFirstEmiAmount(Number firstEmiAmount) {
		this.firstEmiAmount = firstEmiAmount;
	}

	public Number getFutureInst() {
		return futureInst;
	}

	public void setFutureInst(Number futureInst) {
		this.futureInst = futureInst;
	}

	public Number getFutureTenor() {
		return futureTenor;
	}

	public void setFutureTenor(Number futureTenor) {
		this.futureTenor = futureTenor;
	}

	public Number getPaidTotal() {
		return paidTotal;
	}

	public void setPaidTotal(Number paidTotal) {
		this.paidTotal = paidTotal;
	}

	public Number getPaidPri() {
		return paidPri;
	}

	public void setPaidPri(Number paidPri) {
		this.paidPri = paidPri;
	}

	public Number getPaidPft() {
		return paidPft;
	}

	public void setPaidPft(Number paidPft) {
		this.paidPft = paidPft;
	}

	public Number getOutstandingTotal() {
		return outstandingTotal;
	}

	public void setOutstandingTotal(Number outstandingTotal) {
		this.outstandingTotal = outstandingTotal;
	}

	public Number getOutstandingPri() {
		return outstandingPri;
	}

	public void setOutstandingPri(Number outstandingPri) {
		this.outstandingPri = outstandingPri;
	}

	public Number getOutstandingPft() {
		return outstandingPft;
	}

	public void setOutstandingPft(Number outstandingPft) {
		this.outstandingPft = outstandingPft;
	}

	public Number getOverdueTotal() {
		return overdueTotal;
	}

	public void setOverdueTotal(Number overdueTotal) {
		this.overdueTotal = overdueTotal;
	}

	public Number getOverduePri() {
		return overduePri;
	}

	public void setOverduePri(Number overduePri) {
		this.overduePri = overduePri;
	}

	public Number getOverduePft() {
		return overduePft;
	}

	public void setOverduePft(Number overduePft) {
		this.overduePft = overduePft;
	}

	public Number getOverdueInst() {
		return overdueInst;
	}

	public void setOverdueInst(Number overdueInst) {
		this.overdueInst = overdueInst;
	}

	public String getLastRepayDate() {
		return lastRepayDate;
	}

	public void setLastRepayDate(String lastRepayDate) {
		this.lastRepayDate = lastRepayDate;
	}

	public Number getTotalGracePft() {
		return totalGracePft;
	}

	public void setTotalGracePft(Number totalGracePft) {
		this.totalGracePft = totalGracePft;
	}

	public Number getTotalProfit() {
		return totalProfit;
	}

	public void setTotalProfit(Number totalProfit) {
		this.totalProfit = totalProfit;
	}

	public Number getTotalGrossGrcPft() {
		return totalGrossGrcPft;
	}

	public void setTotalGrossGrcPft(Number totalGrossGrcPft) {
		this.totalGrossGrcPft = totalGrossGrcPft;
	}

	public Number getFeeChargeAmt() {
		return feeChargeAmt;
	}

	public void setFeeChargeAmt(Number feeChargeAmt) {
		this.feeChargeAmt = feeChargeAmt;
	}

	public Number getNumberOfTerms() {
		return numberOfTerms;
	}

	public void setNumberOfTerms(Number numberOfTerms) {
		this.numberOfTerms = numberOfTerms;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public Number getAdvPaymentAmount() {
		return advPaymentAmount;
	}

	public void setAdvPaymentAmount(Number advPaymentAmount) {
		this.advPaymentAmount = advPaymentAmount;
	}

	public String getFinActiveStatus() {
		return finActiveStatus;
	}

	public void setFinActiveStatus(String finActiveStatus) {
		this.finActiveStatus = finActiveStatus;
	}

	public Boolean getFullyDisb() {
		return fullyDisb;
	}

	public void setFullyDisb(Boolean fullyDisb) {
		this.fullyDisb = fullyDisb;
	}

	public Number getCurrentDroplineLimit() {
		return currentDroplineLimit;
	}

	public void setCurrentDroplineLimit(Number currentDroplineLimit) {
		this.currentDroplineLimit = currentDroplineLimit;
	}

	public Number getUtilisation() {
		return utilisation;
	}

	public void setUtilisation(Number utilisation) {
		this.utilisation = utilisation;
	}

	public Number getAvailableLimit() {
		return availableLimit;
	}

	public void setAvailableLimit(Number availableLimit) {
		this.availableLimit = availableLimit;
	}

	/**
	 * @return the graceInst
	 */
	public Number getGraceInst() {
		return graceInst;
	}

	/**
	 * @param graceInst the graceInst to set
	 */
	public void setGraceInst(Number graceInst) {
		this.graceInst = graceInst;
	}

	/**
	 * @return the futureGraceInst
	 */
	public Number getFutureGraceInst() {
		return futureGraceInst;
	}

	/**
	 * @param futureGraceInst the futureGraceInst to set
	 */
	public void setFutureGraceInst(Number futureGraceInst) {
		this.futureGraceInst = futureGraceInst;
	}

	public List<AdvanceEMIBean> getAdvEmi() {
		return advEmi;
	}

	public void setAdvEmi(List<AdvanceEMIBean> advEmi) {
		this.advEmi = advEmi;
	}

	public Number getNoPaidInst() {
		return noPaidInst;
	}

	public void setNoPaidInst(Number noPaidInst) {
		this.noPaidInst = noPaidInst;
	}
	
}
