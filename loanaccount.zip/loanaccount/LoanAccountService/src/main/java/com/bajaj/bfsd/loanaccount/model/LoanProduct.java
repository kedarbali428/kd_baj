package com.bajaj.bfsd.loanaccount.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the LOAN_PRODUCTS database table.
 * 
 */
@Entity
@Table(name="LOAN_PRODUCTS")
@NamedQuery(name="LoanProduct.findAll", query="SELECT l FROM LoanProduct l")
public class LoanProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long lnprodkey;

	private String lnprodcode;

	private String lnproddesc;

	private BigDecimal lnprodisactive;

	private String lnprodlstupdateby;

	private Timestamp lnprodlstupdatedt;

	//bi-directional many-to-one association to LoanProductType
	@OneToMany(mappedBy="loanProduct")
	private List<LoanProductType> loanProductTypes;

	public LoanProduct() {
	}

	public long getLnprodkey() {
		return this.lnprodkey;
	}

	public void setLnprodkey(long lnprodkey) {
		this.lnprodkey = lnprodkey;
	}

	public String getLnprodcode() {
		return this.lnprodcode;
	}

	public void setLnprodcode(String lnprodcode) {
		this.lnprodcode = lnprodcode;
	}

	public String getLnproddesc() {
		return this.lnproddesc;
	}

	public void setLnproddesc(String lnproddesc) {
		this.lnproddesc = lnproddesc;
	}

	public BigDecimal getLnprodisactive() {
		return this.lnprodisactive;
	}

	public void setLnprodisactive(BigDecimal lnprodisactive) {
		this.lnprodisactive = lnprodisactive;
	}

	public String getLnprodlstupdateby() {
		return this.lnprodlstupdateby;
	}

	public void setLnprodlstupdateby(String lnprodlstupdateby) {
		this.lnprodlstupdateby = lnprodlstupdateby;
	}

	public Timestamp getLnprodlstupdatedt() {
		return this.lnprodlstupdatedt;
	}

	public void setLnprodlstupdatedt(Timestamp lnprodlstupdatedt) {
		this.lnprodlstupdatedt = lnprodlstupdatedt;
	}

	public List<LoanProductType> getLoanProductTypes() {
		return this.loanProductTypes;
	}

	public void setLoanProductTypes(List<LoanProductType> loanProductTypes) {
		this.loanProductTypes = loanProductTypes;
	}
}