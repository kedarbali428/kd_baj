package com.bajaj.bfsd.loanaccount.bean;

public class CollateralRequestBean {
	
	private String collateralRef;

	public String getCollateralRef() {
		return collateralRef;
	}

	public void setCollateralRef(String collateralRef) {
		this.collateralRef = collateralRef;
	}
	

}
