package com.bajaj.bfsd.loanaccount.model;

public class Collateral {

	private String collateralRef;
	
	private Number assignPerc;
	
	public String getCollateralRef() {
		return collateralRef;
	}

	public void setCollateralRef(String collateralRef) {
		this.collateralRef = collateralRef;
	}

	public Number getAssignPerc() {
		return assignPerc;
	}

	public void setAssignPerc(Number assignPerc) {
		this.assignPerc = assignPerc;
	}

	@Override
	public String toString() {
		return "Collateral [collateralRef=" + collateralRef + ", assignPerc=" + assignPerc + "]";
	}
	
}
