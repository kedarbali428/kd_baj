package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the VAS_APPLICATIONS database table.
 * 
 */
@Entity
@Table(name="VAS_APPLICATIONS")
@NamedQuery(name="VasApplication.findAll", query="SELECT v FROM VasApplication v")
public class VasApplication implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long vasappkey;

	private BigDecimal vaagreementacceptedflg;

	private BigDecimal vaamcfees;

	@Temporal(TemporalType.DATE)
	private Date vaenddate;

	private BigDecimal vaisactive;

	private String valstupdateby;

	private Timestamp valstupdatedt;

	private BigDecimal vanetfees;

	@Temporal(TemporalType.DATE)
	private Date vastartdate;

	private BigDecimal vatcacceptedflg;

	//bi-directional many-to-one association to Application
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="APPLICATIONKEY")
	private Application application;

	//bi-directional many-to-one association to VasProductPlan
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="VASPRODPLANKEY")
	private VasProductPlan vasProductPlan;

	public VasApplication() {
	}

	public long getVasappkey() {
		return this.vasappkey;
	}

	public void setVasappkey(long vasappkey) {
		this.vasappkey = vasappkey;
	}

	public BigDecimal getVaagreementacceptedflg() {
		return this.vaagreementacceptedflg;
	}

	public void setVaagreementacceptedflg(BigDecimal vaagreementacceptedflg) {
		this.vaagreementacceptedflg = vaagreementacceptedflg;
	}

	public BigDecimal getVaamcfees() {
		return this.vaamcfees;
	}

	public void setVaamcfees(BigDecimal vaamcfees) {
		this.vaamcfees = vaamcfees;
	}

	public Date getVaenddate() {
		return this.vaenddate;
	}

	public void setVaenddate(Date vaenddate) {
		this.vaenddate = vaenddate;
	}

	public BigDecimal getVaisactive() {
		return this.vaisactive;
	}

	public void setVaisactive(BigDecimal vaisactive) {
		this.vaisactive = vaisactive;
	}

	public String getValstupdateby() {
		return this.valstupdateby;
	}

	public void setValstupdateby(String valstupdateby) {
		this.valstupdateby = valstupdateby;
	}

	public Timestamp getValstupdatedt() {
		return this.valstupdatedt;
	}

	public void setValstupdatedt(Timestamp valstupdatedt) {
		this.valstupdatedt = valstupdatedt;
	}

	public BigDecimal getVanetfees() {
		return this.vanetfees;
	}

	public void setVanetfees(BigDecimal vanetfees) {
		this.vanetfees = vanetfees;
	}

	public Date getVastartdate() {
		return this.vastartdate;
	}

	public void setVastartdate(Date vastartdate) {
		this.vastartdate = vastartdate;
	}

	public BigDecimal getVatcacceptedflg() {
		return this.vatcacceptedflg;
	}

	public void setVatcacceptedflg(BigDecimal vatcacceptedflg) {
		this.vatcacceptedflg = vatcacceptedflg;
	}

	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public VasProductPlan getVasProductPlan() {
		return this.vasProductPlan;
	}

	public void setVasProductPlan(VasProductPlan vasProductPlan) {
		this.vasProductPlan = vasProductPlan;
	}

}