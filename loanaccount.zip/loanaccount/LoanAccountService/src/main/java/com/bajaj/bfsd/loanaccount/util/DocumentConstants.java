package com.bajaj.bfsd.loanaccount.util;

/**
 * This is constant class for constants.
 *
 * @author 412398
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          412398          01/03/2017      Initial Version
 */
public class DocumentConstants {
	
	
    /**
     * Constant for MENU_BANK_STATEMENT.
     */
    public static final String MENU_BANK_STATEMENT = "BANK STATEMENT";
    
    /**
     * Constant for MENU_LOAN_AGREEMENT.
     */
    public static final String MENU_LOAN_AGREEMENT = "LOAN AGREEMENT";
    
    /**
     * Constant for MENU_ESIGNED_DOCUMENT.
     */
    public static final String MENU_ESIGNED_DOCUMENT = "ESIGNED DOCUMENT";
    
    /**
     * Constant for MENU_KYC_DOCUMENTS.
     */
    public static final String MENU_KYC_DOCUMENTS = "KYC DOCUMENTS(POI,POA)";
	public static final String IS_ACTIVE = "isActive";

    private DocumentConstants()
	{
		//private constructor 
	}
   
}
