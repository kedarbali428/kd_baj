package com.bajaj.bfsd.loanaccount.helper;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLExceptionHandler;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.CifDetailsBean;
import com.bajaj.bfsd.loanaccount.bean.LoanAccountResponseBean;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailBean;
import com.bajaj.bfsd.loanaccount.bean.MissedEMI;
import com.bajaj.bfsd.loanaccount.bean.MissedEMIDetailBean;
import com.bajaj.bfsd.loanaccount.config.MapperFactory;
import com.bajaj.bfsd.loanaccount.model.CustomerLoanResponse;
import com.bajaj.bfsd.loanaccount.util.LoanAccountUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:common.properties" })
@SpringBootTest(classes = { BFLCommonRestClient.class })
public class LoanDetailHelperTest {

	@InjectMocks
	private LoanDetailHelper loanDetailHelper;

	@Mock
	LoanAccountUtil loanAccountUtil;
	@Mock
	BFLLoggerUtilExt logger;
	@Autowired
	Environment env;

	@Value("${partpayment_loans}")
	private String ppLoans;

	@Value("${foreclosure_loans}")
	private String fcLoans;

	@Value("${deposit_is_loans}")
	private String diLoans;

	@Value("${withdrawals_loans}")
	private String wdLoans;

	@Value("${hybrid_flexi_loans}")
	private String hfLoans;

	@Value("${tranche_loans}")
	private String tdLoans;

	@Value("${missedemi_loans}")
	private String meLoans;

	@Value("${matured_loan_status}")
	private String maturedLoanStatus;

	@Value("${ppLoansDefaultRecalType}")
	private String ppLoansDefaultRecalType;

	@Value("${depositHFLoansDefaultRecalType}")
	private String depositHFLoansDefaultRecalType;
	
	@Value("${FreezePeriod}")
	private Integer freezeperiod;
	    
	@Value("${LimitMonth}")
	private Integer underlimit;
	    
	@Value("${minimumPaidEMI}")
	private Integer minimumPaidEMI;

	BFLExceptionHandler exceptionHandler;
	ObjectMapper mapper;

	@Before
	public void setUp() throws IOException {
		mapper = MapperFactory.getInstance();
		exceptionHandler = new BFLExceptionHandler();
		ReflectionTestUtils.setField(loanDetailHelper, "logger", logger);
		ReflectionTestUtils.setField(loanDetailHelper, "tdLoans", tdLoans);
		ReflectionTestUtils.setField(loanDetailHelper, "meLoans", meLoans);
		ReflectionTestUtils.setField(loanDetailHelper, "hfLoans", hfLoans);
		ReflectionTestUtils.setField(loanDetailHelper, "wdLoans", wdLoans);
		ReflectionTestUtils.setField(loanDetailHelper, "ppLoans", ppLoans);
		ReflectionTestUtils.setField(loanDetailHelper, "fcLoans", fcLoans);
		ReflectionTestUtils.setField(loanDetailHelper, "diLoans", diLoans);
		ReflectionTestUtils.setField(loanDetailHelper, "maturedLoanStatus", maturedLoanStatus);
		ReflectionTestUtils.setField(loanDetailHelper, "ppLoansDefaultRecalType", ppLoansDefaultRecalType);
		ReflectionTestUtils.setField(loanDetailHelper, "depositHFLoansDefaultRecalType",
				depositHFLoansDefaultRecalType);
		ReflectionTestUtils.setField(loanDetailHelper, "env", env);
		ReflectionTestUtils.setField(loanDetailHelper, "freezeperiod", freezeperiod);
		ReflectionTestUtils.setField(loanDetailHelper, "underlimit", underlimit);
		ReflectionTestUtils.setField(loanDetailHelper, "minimumPaidEMI", minimumPaidEMI);
		ReflectionTestUtils.setField(exceptionHandler, "bfllogger", logger);
	}

	@Ignore
	@Test
	public void testGetAllActiveLoansForCustomer() throws Exception {
		CifDetailsBean cifDetailsBean = new CifDetailsBean();
		cifDetailsBean.setApltCustCif("4152");
		cifDetailsBean.setTarget("Target");
		List<CifDetailsBean> cifDetailsBeanList = new ArrayList<>();
		cifDetailsBeanList.add(cifDetailsBean);
		String responseFromLMS = "{\"finances\":[{\"finReference\":\"P405SOL0026518\",\"finType\":\"SOLTL\",\"product\":\"SOL\",\"finCcy\":\"INR\",\"finAmount\":29000000,\"finAssetValue\":29000000,\"numberOfTerms\":60,\"loanTenor\":61,\"maturityDate\":\"2022-12-05T00:00:00\",\"firstEmiAmount\":692800,\"nextRepayAmount\":692800,\"paidTotal\":6928000,\"paidPri\":3406400,\"paidPft\":3521600,\"outstandingTotal\":34639900,\"outstandingPri\":25593600,\"outstandingPft\":9046300,\"futureInst\":48,\"finStatus\":\"A\",\"disbStatus\":\"Fully Disbursed\",\"coApplicants\":[]}],\"returnStatus\":{\"returnCode\":\"0001\",\"returnText\":\"Success\"}} ";
		CustomerLoanResponse lmsResponse = mapper.readValue(responseFromLMS, CustomerLoanResponse.class);
		Mockito.when(loanAccountUtil.hitLMSIntegrationService(Mockito.any(), Mockito.any()))
				.thenReturn(responseFromLMS);
		Mockito.when(loanAccountUtil.mapFromJson(Mockito.any(), Mockito.any())).thenReturn(lmsResponse);
		LoanAccountResponseBean expectedResult = loanDetailHelper.getAllActiveLoansForCustomer(cifDetailsBeanList,"ME");
		assertNotNull(expectedResult);
	}

	@Test
	public void testPrepareLMSResponse_PPEVENT() {
		MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();
		missedEMIDetailBean.setAmountToBePaid(10002D);
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setIsblock(false);
		loanDetailBean.setLoanStatus("A");
		loanDetailBean.setUnderLimitMonth(true);
		loanDetailBean.setLoanTypeId("DDLTL");
		loanDetailBean.setMissedEMIDetails(missedEMIDetailBean);
		loanDetailBean.setEmiAmount(1452);
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		loanDetailBeans.add(loanDetailBean);
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);
		LoanAccountResponseBean expectedResult = loanDetailHelper.prepareLMSResponse(loanAccountResponseBean, "PP");
		assertNotNull(expectedResult);
	}

	@Test
	public void testPrepareLMSResponse_FCEVENT() {
		MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();
		missedEMIDetailBean.setAmountToBePaid(10002D);
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setIsblock(false);
		loanDetailBean.setLoanStatus("A");
		loanDetailBean.setUnderLimitMonth(true);
		loanDetailBean.setLoanTypeId("DSPTL");
		loanDetailBean.setMissedEMIDetails(missedEMIDetailBean);
		loanDetailBean.setEmiAmount(1452);
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		loanDetailBeans.add(loanDetailBean);
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);
		LoanAccountResponseBean expectedResult = loanDetailHelper.prepareLMSResponse(loanAccountResponseBean, "FC");
		assertNotNull(expectedResult);
	}

	@Test
	public void testPrepareLMSResponse_DIEVENT() {
		MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();
		missedEMIDetailBean.setAmountToBePaid(10002D);
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setIsblock(false);
		loanDetailBean.setLoanStatus("A");
		loanDetailBean.setUnderLimitMonth(true);
		loanDetailBean.setLoanTypeId("SOFL");
		loanDetailBean.setMissedEMIDetails(missedEMIDetailBean);
		loanDetailBean.setEmiAmount(1452);
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		loanDetailBeans.add(loanDetailBean);
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);
		LoanAccountResponseBean expectedResult = loanDetailHelper.prepareLMSResponse(loanAccountResponseBean, "DI");
		assertNotNull(expectedResult);
	}

	@Test
	public void testPrepareLMSResponse_WDEVENT() {
		MissedEMI missedEMI = new MissedEMI();
		missedEMI.setEmiAmount(1400D);
		List<MissedEMI> missedEMIs = new ArrayList<>();
		missedEMIs.add(missedEMI);
		MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();
		missedEMIDetailBean.setAmountToBePaid(10002D);
		missedEMIDetailBean.setMissedEMI(missedEMIs);
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setIsblock(false);
		loanDetailBean.setEmiBounceIS(true);
		loanDetailBean.setFreeze(true);
		loanDetailBean.setLoanStatus("A");
		loanDetailBean.setUnderLimitMonth(true);
		loanDetailBean.setLoanTypeId("DHPL");
		loanDetailBean.setMissedEMIDetails(missedEMIDetailBean);
		loanDetailBean.setEmiAmount(1452);
		loanDetailBean.setAvailableLimit(1452);
		loanDetailBean.setCurrentDroplineLimit(5632);
		loanDetailBean.setUtilisation(4563);
		loanDetailBean.setOverdueEMIAmount(11);
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		loanDetailBeans.add(loanDetailBean);
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);
		LoanAccountResponseBean expectedResult = loanDetailHelper.prepareLMSResponse(loanAccountResponseBean, "WD");
		assertNotNull(expectedResult);
	}

	@Test
	public void testPrepareLMSResponse_TDEVENT() {
		MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();
		missedEMIDetailBean.setAmountToBePaid(10002D);
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setIsblock(false);
		loanDetailBean.setLoanStatus("A");
		loanDetailBean.setUnderLimitMonth(true);
		loanDetailBean.setLoanTypeId("DHLT");
		loanDetailBean.setMissedEMIDetails(missedEMIDetailBean);
		loanDetailBean.setEmiAmount(1452);
		loanDetailBean.setLoanDisburseStatus("Partially Disbursed");
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		loanDetailBeans.add(loanDetailBean);
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);
		LoanAccountResponseBean expectedResult = loanDetailHelper.prepareLMSResponse(loanAccountResponseBean, "TD");
		assertNotNull(expectedResult);
	}

	@Test
	public void testPrepareLMSResponse_MEEVENT() {
		MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();
		missedEMIDetailBean.setAmountToBePaid(10002D);
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setIsblock(false);
		loanDetailBean.setLoanStatus("A");
		loanDetailBean.setUnderLimitMonth(true);
		loanDetailBean.setLoanTypeId("DSPTL");
		loanDetailBean.setMissedEMIDetails(missedEMIDetailBean);
		loanDetailBean.setEmiAmount(1452);
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		loanDetailBeans.add(loanDetailBean);
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);
		LoanAccountResponseBean expectedResult = loanDetailHelper.prepareLMSResponse(loanAccountResponseBean, "ME");
		assertNotNull(expectedResult);
	}

	@Test
	public void testPrepareLMSResponse_MTEVENT() {
		MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();
		missedEMIDetailBean.setAmountToBePaid(10002D);
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setIsblock(false);
		loanDetailBean.setUnderLimitMonth(true);
		loanDetailBean.setLoanStatus("M");
		loanDetailBean.setMissedEMIDetails(missedEMIDetailBean);
		loanDetailBean.setEmiAmount(1452);
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		loanDetailBeans.add(loanDetailBean);
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);
		LoanAccountResponseBean expectedResult = loanDetailHelper.prepareLMSResponse(loanAccountResponseBean, "MT");
		assertNotNull(expectedResult);
	}
	
	@Ignore
	@Test
	public void testPrepareLMSResponse_ADVEMIEVENT() {
		MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();
		missedEMIDetailBean.setAmountToBePaid(10002D);
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setIsblock(false);
		loanDetailBean.setUnderLimitMonth(true);
		loanDetailBean.setLoanStatus("A");
		loanDetailBean.setMissedEMIDetails(missedEMIDetailBean);
		loanDetailBean.setEmiAmount(1452);
		loanDetailBean.setLoanAmount(1);
		loanDetailBean.setOutstandingLoanAmount(1);
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		loanDetailBeans.add(loanDetailBean);
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);
		LoanAccountResponseBean expectedResult = loanDetailHelper.prepareLMSResponse(loanAccountResponseBean, "ADVEMI");
		assertNotNull(expectedResult);
	}

	@Test
	public void testPrepareLMSResponse_NULLEVENT() {
		MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();
		missedEMIDetailBean.setAmountToBePaid(10002D);
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setIsblock(false);
		loanDetailBean.setUnderLimitMonth(true);
		loanDetailBean.setLoanStatus("A");
		loanDetailBean.setMissedEMIDetails(missedEMIDetailBean);
		loanDetailBean.setEmiAmount(1452);
		loanDetailBean.setLoanAmount(1);
		loanDetailBean.setOutstandingLoanAmount(1);
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		loanDetailBeans.add(loanDetailBean);
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);
		LoanAccountResponseBean expectedResult = loanDetailHelper.prepareLMSResponse(loanAccountResponseBean, null);
		assertNotNull(expectedResult);
	}
	
}
