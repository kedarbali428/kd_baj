package com.bajaj.bfsd.loanaccount.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.InsurancesDetailResponse;
import com.bajaj.bfsd.loanaccount.helper.VasInsuranceHelper;
import com.bajaj.bfsd.loanaccount.service.impl.VasInsuranceServiceImpl;
import com.bfl.common.exceptions.BFLBusinessException;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:error.properties" })
@SpringBootTest(classes = { BFLCommonRestClient.class })
public class VasInsuranceServiceImplTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;

	@InjectMocks
	private VasInsuranceServiceImpl vasInsuranceServiceImpl;

	@Mock
	VasInsuranceHelper vasInsuranceHelper;

	@Test
	public void testGetVasAndInsuranceDetails() throws Exception {
		InsurancesDetailResponse insurancesDetailResponse = new InsurancesDetailResponse();
		Mockito.when(vasInsuranceHelper.getVasAndInsurance(Mockito.any(), Mockito.any()))
				.thenReturn(insurancesDetailResponse);
		InsurancesDetailResponse result = vasInsuranceServiceImpl.getVasAndInsuranceDetails("1451", "DHT");
		assertNotNull(result);
	}

	@Test(expected = BFLBusinessException.class)
	public void testGetVasAndInsuranceDetails_Failure() {
		vasInsuranceServiceImpl.getVasAndInsuranceDetails(null, "1452");
	}
}