package com.bajaj.bfsd.loanaccount.util;

import java.util.Map;
import java.util.stream.Collectors;

public class CheckNew {
	
	public static void main(String[] args) {
		CheckNew chk = new CheckNew();
		chk.check();
		System.out.println("chk = "+chk);
	}
	
	public void check() {
		String s = "aabcdefcc";
		Map<Character, Long> map = s.chars().mapToObj(c -> (char)c).collect(Collectors.groupingBy(Character::charValue,Collectors.counting()));
		
		map.entrySet().forEach(e -> System.out.println("key : "+e.getKey()+" value : "+e.getValue()));
	
	}
	

}
