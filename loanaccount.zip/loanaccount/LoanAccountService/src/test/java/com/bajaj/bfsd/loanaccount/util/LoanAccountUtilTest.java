package com.bajaj.bfsd.loanaccount.util;

import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:common.properties" })
@SpringBootTest(classes = { BFLCommonRestClient.class })
public class LoanAccountUtilTest {
	
	@InjectMocks
	private LoanAccountUtil loanAccountUtil;

	@Mock
	BFLLoggerUtilExt logger;
	
	@Autowired
	Environment env;
	
	@Test
	public void getCurrentTimestampTest(){
		Timestamp t=loanAccountUtil.getCurrentTimestamp();
		assertNotNull(t);
	}
	
	@Test
	public void getSRNumberTest(){
		String t=loanAccountUtil.getSRNumber();
		assertNotNull(t);
	}
	
	@Test
	public void getDaysDifferenceForDateWithoutTimeStampTest(){
		int t=loanAccountUtil.getDaysDifferenceForDateWithoutTimeStamp("2019-10-10");
		assertNotNull(t);
	}
	
	@Test
	public void getDaysDifferenceForDateWithoutTimeTest(){
		int t=loanAccountUtil.getDaysDifferenceForDateWithoutTime("2019-10-10");
		assertNotNull(t);
	}
	
	@Test
	public void calculatePercentTest(){
		Double t=loanAccountUtil.calculatePercent(new Double(1),new Double(1));
		assertNotNull(t);
	}
	
}
