package com.bajaj.bfsd.loanaccount.helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailResponseBean;
import com.bajaj.bfsd.loanaccount.config.MapperFactory;
import com.bajaj.bfsd.loanaccount.dao.FeeDetailDao;
import com.bajaj.bfsd.loanaccount.dao.ProductDao;
import com.bajaj.bfsd.loanaccount.model.Disbursement;
import com.bajaj.bfsd.loanaccount.model.Fee;
import com.bajaj.bfsd.loanaccount.model.LoanDetail;
import com.bajaj.bfsd.loanaccount.model.LoanResponse;
import com.bajaj.bfsd.loanaccount.model.LoanSchedule;
import com.bajaj.bfsd.loanaccount.model.ReturnStatus;
import com.bajaj.bfsd.loanaccount.model.ScheduleSummary;
import com.bajaj.bfsd.loanaccount.util.LoanAccountUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:common.properties" })
@SpringBootTest(classes = { BFLCommonRestClient.class })
public class LoanHelperTest {

	@InjectMocks
	private LoanHelper loanHelper;

	@Mock
	FeeDetailDao feeDetailDao;
	
	@Mock
	ProductDao productDao;
	
	@Mock
	LoanAccountUtil loanAccountUtil;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	Environment env;
	
	@Value("${resource-path-pennant-loan-lanno}")
	private String  resourcePathValueGetLoanByLanNo;	
	
	@Value("${resource-path-pennant-loan-collateral}")
	private String  resourcePathValueGetLoanCollateral;	
	
	@Value("${pennant-authorization}")
	private String authorizationKey;
  
	@Value("${LimitMonth}")
    private Integer underlimit;
	
	@Value("${FreezePeriod}")
    private Integer freezeperiod;
	
	@Value("${LOAN_001}")
    private String errorCodeLOAN;
	
	@Value("${advEmiNum}")
	private int advEmiNum;
	
	@Value("${hfc.pennant.productcodes}")
	private String hfcProductCodes;
	
	ObjectMapper mapper;
	
	@Before
	public void setUp() throws IOException {
		mapper = MapperFactory.getInstance();
		ReflectionTestUtils.setField(loanHelper, "logger", logger);
		ReflectionTestUtils.setField(loanHelper, "resourcePathValueGetLoanByLanNo", resourcePathValueGetLoanByLanNo);
		ReflectionTestUtils.setField(loanHelper, "resourcePathValueGetLoanCollateral", resourcePathValueGetLoanCollateral);
		ReflectionTestUtils.setField(loanHelper, "authorizationKey", authorizationKey);
		ReflectionTestUtils.setField(loanHelper, "underlimit", underlimit);
		ReflectionTestUtils.setField(loanHelper, "freezeperiod", freezeperiod);
		ReflectionTestUtils.setField(loanHelper, "errorCodeLOAN", errorCodeLOAN);
		ReflectionTestUtils.setField(loanHelper, "advEmiNum", advEmiNum);
		ReflectionTestUtils.setField(loanHelper, "env", env);
		ReflectionTestUtils.setField(loanHelper, "hfcProductCodes", hfcProductCodes);
	}

	@Ignore
	@Test
	public void getLoanDetailByLanNoTest1(){
		
		//getLoanDetailsByLanNOFromPennantLMS starts
		LoanResponse loanResponse = new LoanResponse();
		ReturnStatus returnStatus=new ReturnStatus();
		returnStatus.setReturnCode("0000");
		loanResponse.setReturnStatus(returnStatus);
		loanResponse.setFinReference("P405SOL0026518");
		
		LoanDetail financeDetail =new LoanDetail();
		financeDetail.setFinType("ab");
		financeDetail.setFinAssetValue(1);
		financeDetail.setRepayPftRate(1);
		financeDetail.setFinStartDate("ab");
		financeDetail.setRepayFrq("3445111");
		financeDetail.setFinRepayMethod("NEFT");
		financeDetail.setNextRepayDate("ab");
		financeDetail.setApplicationNo("1");
		financeDetail.setFinRepayMethod("NEFT");
		LoanSchedule financeSchedule=new LoanSchedule();
		
		financeSchedule.setFinanceDetail(financeDetail);
		ScheduleSummary summary=new ScheduleSummary();
		summary.setOutstandingPri(1);
		summary.setNextRepayAmount(1);
		summary.setFutureInst(1);
		summary.setNumberOfTerms(1);
		summary.setFirstDisbDate("1");
		summary.setOverdueTotal(1);
		summary.setMaturityDate("1");
		summary.setPaidTotal(1);
		summary.setPaidPri(1);
		summary.setAdvPaymentAmount(1);
		summary.setEffectiveRateOfReturn(1);
		summary.setFeeChargeAmt(1);
		summary.setFinActiveStatus("");
		summary.setFirstEmiAmount(1);
		summary.setFirstInstDate("");
		summary.setFullyDisb(true);
		summary.setFutureTenor(1);
		summary.setLastRepayDate("");
		summary.setNextSchDate("");
		summary.setOutstandingPft(1);
		summary.setOutstandingTotal(1);
		summary.setOverdueInst(1);
		summary.setOverduePft(1);
		summary.setOverduePri(1);
		summary.setPaidPft(1);
		summary.setTotalGracePft(1);
		summary.setTotalGrossGrcPft(1);
		summary.setLoanTenor(1);
		summary.setGraceInst(1);
		summary.setFutureGraceInst(1);
		summary.setTotalGracePft(1);
		summary.setCurrentDroplineLimit(1);
		summary.setUtilisation(1);
		summary.setAvailableLimit(1);
		financeSchedule.setSummary(summary);
		//setFeesDetails starts
		List<Fee> fees = new ArrayList<>();
		Fee fee=new Fee();
		fee.setFeeCategory("FeeCategory");
		fee.setFeeAmount(1);
		fee.setFeeCode("FeeCode");
		fee.setFeeMethod("FeeMethod");
		fee.setScheduleTerms(1);
		fee.setPaidAmount(1);
		fee.setSchdDate(new Date());
		fees.add(fee);
		//setFeesDetails ends
		
		//setDisbursementBeanData starts
		List<Disbursement> disbursement=new ArrayList<>();
		Disbursement disbursementDetail=new Disbursement();
		disbursementDetail.setAcHolderName("");
		disbursementDetail.setAccountNo("");
		disbursementDetail.setBankCode("");
		disbursementDetail.setBranchCode("");
		disbursementDetail.setDisbAmount(new Double(11));
		disbursementDetail.setDisbDate("");
		disbursementDetail.setDisbType("");
		disbursementDetail.setDisbParty("");
		disbursementDetail.setIfsc("VIJB0001551");
		disbursementDetail.setPhoneNumber("");
		disbursement.add(disbursementDetail);
		//setDisbursementBeanData ends
		
		loanResponse.setFees(fees);
		loanResponse.setFinanceSchedule(financeSchedule);
		
		Mockito.when(loanAccountUtil.hitLMSIntegrationService(Mockito.any(), Mockito.any()))
		.thenReturn("");
		Mockito.when(loanAccountUtil.mapFromJson(Mockito.any(), Mockito.any())).thenReturn(loanResponse);
		//getLoanDetailsByLanNOFromPennantLMS ends
		
		LoanDetailResponseBean response=loanHelper.getLoanDetailByLanNo("P405SOL0026518","SPFL");
	}
	
	public void getLoanDetailByLanNoTest2(){
		
		//getLoanDetailsByLanNOFromPennantLMS starts
		LoanResponse loanResponse = new LoanResponse();
		loanResponse.setReturnCode("1");
		loanResponse.setReturnText("Exception");
		Mockito.when(loanAccountUtil.hitLMSIntegrationService(Mockito.any(), Mockito.any()))
		.thenReturn("");
		Mockito.when(loanAccountUtil.mapFromJson(Mockito.any(), Mockito.any())).thenReturn(loanResponse);
		//getLoanDetailsByLanNOFromPennantLMS ends
		
		LoanDetailResponseBean response=loanHelper.getLoanDetailByLanNo("P405SOL0026518","SPFL");
	}
}
