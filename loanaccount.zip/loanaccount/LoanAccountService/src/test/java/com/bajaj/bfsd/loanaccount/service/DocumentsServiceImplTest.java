package com.bajaj.bfsd.loanaccount.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.DocumentsResponse;
import com.bajaj.bfsd.loanaccount.service.impl.DocumentsServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:error.properties" })
@SpringBootTest(classes = { BFLCommonRestClient.class })
public class DocumentsServiceImplTest {

	@InjectMocks
	DocumentsServiceImpl documentsServiceImpl;

	@Value("Y")
	private String isMocked;

	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(documentsServiceImpl, "isMocked", isMocked);
	}

	@Test
	public void testGetDocuments() throws Exception {
		Long customerId = 14523L;
		DocumentsResponse result = documentsServiceImpl.getDocuments(customerId);
		assertNotNull(result);
	}
}