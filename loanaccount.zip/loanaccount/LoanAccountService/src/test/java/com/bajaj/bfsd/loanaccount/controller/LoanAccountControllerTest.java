package com.bajaj.bfsd.loanaccount.controller;

import org.junit.Test;

public class LoanAccountControllerTest {


	@Test
	public void testGetPartpaymentSuccess()
	{
		
	}
}