package com.bajaj.bfsd.loanaccount.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLExceptionHandler;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.ApplicantDeatilsForNotification;
import com.bajaj.bfsd.loanaccount.bean.CifDetailsBean;
import com.bajaj.bfsd.loanaccount.bean.LoanAccountResponseBean;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailResponseBean;
import com.bajaj.bfsd.loanaccount.config.MapperFactory;
import com.bajaj.bfsd.loanaccount.dao.ProductDao;
import com.bajaj.bfsd.loanaccount.entity.Applicant;
import com.bajaj.bfsd.loanaccount.helper.LoanDetailHelper;
import com.bajaj.bfsd.loanaccount.helper.LoanHelper;
import com.bajaj.bfsd.loanaccount.service.impl.LoanAccountServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:error.properties" })
@SpringBootTest(classes = { BFLCommonRestClient.class })
public class LoanAccountServiceImplTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;
	@InjectMocks
	private LoanAccountServiceImpl loanAccountServiceImpl;

	@Mock
	LoanDetailHelper loandetailHelper;

	@Mock
	LoanHelper loanHelper;

	@Mock
	ProductDao productDao;

	@Value("${PENNANT.PROVIDER}")
	private String pennantProvider;

	ObjectMapper mapper;
	BFLExceptionHandler exceptionHandler;

	@Before
	public void setUp() throws Exception {
		mapper = MapperFactory.getInstance();
		exceptionHandler = new BFLExceptionHandler();
		ReflectionTestUtils.setField(loanAccountServiceImpl, "logger", logger);
		ReflectionTestUtils.setField(exceptionHandler, "bfllogger", logger);
		ReflectionTestUtils.setField(loanAccountServiceImpl, "pennantProvider", pennantProvider);
		ReflectionTestUtils.setField(exceptionHandler, "env", env);
	}

	@Ignore
	@Test
	public void testGetLoanAccountDetails() throws Exception {
		String applicantId = "14523";
		String stringRequest = "{\"apltcustcif\": \"12345\",\"applicantSysCodes\": [{\"interfaceSystem\": {\"systemcode\": \"PLF\"},\"refcode\": \"TestReg\"}]}";
		Applicant applicant = mapper.readValue(stringRequest, Applicant.class);
		LoanAccountResponseBean response = new LoanAccountResponseBean();
		ApplicantDeatilsForNotification details = new ApplicantDeatilsForNotification();
		details.setEmailId("abc@gmail.com");
		details.setMobileNumber("9874561230");
		Mockito.when(productDao.getApplicantdetails(Mockito.any())).thenReturn(details);
		Mockito.when(productDao.getApplicantDetailsByApplicantId(Mockito.any())).thenReturn(applicant);
		//Mockito.when(loandetailHelper.getAllActiveLoansForCustomer(Mockito.any(),Mockito.any())).thenReturn(response);
		Mockito.when(loandetailHelper.prepareLMSResponse(Mockito.any(), Mockito.any())).thenReturn(response);
		LoanAccountResponseBean result = loanAccountServiceImpl.getLoanAccountDetails(applicantId, "PER");
		assertNotNull(result);
	}

	@Test
	public void testGetCustomerIdByApplicantid() throws Exception {
		String applicantId = "14523";
		String stringRequest = "{\"apltcustcif\": \"12345\"}";
		Applicant applicant = mapper.readValue(stringRequest, Applicant.class);
		Mockito.when(productDao.getApplicantDetailsByApplicantId(Mockito.any())).thenReturn(applicant);
		List<CifDetailsBean> result = loanAccountServiceImpl.getCustomerIdByApplicantid(applicantId);
		assertEquals("PLF", result.get(0).getTarget());
	}

	@Test
	public void testGetLoanDetailsByLanNo() throws Exception {
		LoanDetailResponseBean loanDetailResponseBean = new LoanDetailResponseBean();
		Mockito.when(loanHelper.getLoanDetailByLanNo(Mockito.any(), Mockito.any())).thenReturn(loanDetailResponseBean);
		LoanDetailResponseBean result = loanAccountServiceImpl.getLoanDetailsByLanNo("1451", "52639");
		assertNotNull(result);
	}
}