package com.bajaj.bfsd.loanaccount.controller;

import org.junit.Test;

public class DocumentControllerTest {

	@Test
	public void testGetPartpaymentSuccess()
	{
		
	}
}
