package com.bajaj.bfsd.loanaccount.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.bflawsutil.helper.BFLAwsS3Helper;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.ApplicantDeatilsForNotification;
import com.bajaj.bfsd.loanaccount.dao.impl.ProductDaoImpl;
import com.bajaj.bfsd.loanaccount.entity.Applicant;
import com.bajaj.bfsd.loanaccount.entity.Application;
import com.bajaj.bfsd.loanaccount.entity.ApplicationApplicant;
import com.bajaj.bfsd.loanaccount.model.LoanProduct;
import com.bajaj.bfsd.loanaccount.model.LoanProductType;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:error.properties" })
@SpringBootTest(classes = { BFLCommonRestClient.class })
public class ProductDaoImplTest {

	@InjectMocks
	private ProductDaoImpl productDaoImpl;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	EntityManager entityManager;

	@Autowired
	Environment env;

	@Mock
	BFLAwsS3Helper helper;

	@Mock
	private Query query;

	@Mock
	private Query query1;

	ObjectMapper mapper;

	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(productDaoImpl, "entityManager", entityManager);
		ReflectionTestUtils.setField(productDaoImpl, "logger", logger);
	}

	@Test
	public void testGetLoanTypeDesc() {
		LoanProductType loanProductType = new LoanProductType();
		List<LoanProductType> loanProductTypes = new ArrayList<>();
		loanProductTypes.add(loanProductType);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(loanProductTypes);
		LoanProductType result = productDaoImpl.getLoanTypeDesc("Personal");
		assertNotNull(result);
	}

	@Test
	public void testGetApplicantdetails() {
		Object applicatdetail[] = { "Ram", "abc@gmail.com", "9874102563" };
		List<Object[]> applicatdetails = new ArrayList<>();
		applicatdetails.add(applicatdetail);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(applicatdetails);
		ApplicantDeatilsForNotification result = productDaoImpl.getApplicantdetails(1452L);
		assertNotNull(result);
	}

	@Test
	public void testGetproductDesc() {
		Object vasproductdetail[] = { "LAP", "Home" };
		List<Object[]> vasproductdetails = new ArrayList<>();
		vasproductdetails.add(vasproductdetail);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(vasproductdetails);
		String expectedResult = productDaoImpl.getproductDesc("VASCODE");
		assertEquals("Home", expectedResult);
	}

	@Test
	public void testGetInsproductDesc() {
		Object insProductdetail[] = { "INSPLAN1", "INSPLAN2" };
		List<Object[]> insProductdetails = new ArrayList<>();
		insProductdetails.add(insProductdetail);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(insProductdetails);
		String expectedResult = productDaoImpl.getInsproductDesc("INSPLANCODE");
		assertEquals("INSPLAN2", expectedResult);
	}

	@Test
	public void testGetpolicyNo() {
		Object applicationDetail[] = { "13625" };
		List<Object[]> applicationDetails = new ArrayList<>();
		applicationDetails.add(applicationDetail);
		Object policyDetail[] = { "1111" };
		List<Object[]> policyDetails = new ArrayList<>();
		policyDetails.add(policyDetail);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(applicationDetails);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query1);
		Mockito.when(query1.getResultList()).thenReturn(policyDetails);
		String expectedResult = productDaoImpl.getpolicyNo("1452");
		assertEquals("1111", expectedResult);
	}
	
	@Test
	public void testGetApplicantDetailsByApplicantId() {
		Applicant applicant = new Applicant();
		List<Applicant> applicants= new ArrayList<>();
		applicants.add(applicant);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(applicants);
		Applicant result = productDaoImpl.getApplicantDetailsByApplicantId(2563L);
		assertNotNull(result);
	}
	
	@Test
	public void testGetApplicationByLAN() {
		Application application = new Application();
		List<Application> applications= new ArrayList<>();
		applications.add(application);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(applications);
		Application result = productDaoImpl.getApplicationByLAN("1452");
		assertNotNull(result);
	}
	
	@Test
	public void testGetAppApplicantByApplicantId() {
		ApplicationApplicant applicationApplicant = new ApplicationApplicant();
		List<ApplicationApplicant> applicationApplicants= new ArrayList<>();
		applicationApplicants.add(applicationApplicant);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(applicationApplicants);
		ApplicationApplicant result = productDaoImpl.getAppApplicantByApplicantId("1452");
		assertNotNull(result);
	}
	
	@Test
	public void testGetLoanProduct() {
		LoanProduct loanProduct=new LoanProduct();
		LoanProductType loanProductType = new LoanProductType();
		loanProductType.setLoanProduct(loanProduct);
		List<LoanProductType> loanProductTypes= new ArrayList<>();
		loanProductTypes.add(loanProductType);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(loanProductTypes);
		LoanProduct result = productDaoImpl.getLoanProduct("Personal");
		assertNotNull(result);
	}
}
