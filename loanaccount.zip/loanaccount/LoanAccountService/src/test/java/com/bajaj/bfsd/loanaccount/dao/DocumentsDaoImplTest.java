package com.bajaj.bfsd.loanaccount.dao;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.bflawsutil.helper.BFLAwsS3Helper;
import com.bajaj.bfsd.common.business.baseclasses.BFLExceptionHandler;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.DocumentsResponse;
import com.bajaj.bfsd.loanaccount.config.MapperFactory;
import com.bajaj.bfsd.loanaccount.dao.impl.DocumentsDaoImpl;
import com.bajaj.bfsd.loanaccount.entity.SerAppStmtRptDocument;
import com.bajaj.bfsd.loanaccount.entity.SerStmtReportType;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:error.properties" })
@SpringBootTest(classes = { BFLCommonRestClient.class })
public class DocumentsDaoImplTest {

	@InjectMocks
	private DocumentsDaoImpl documentsDaoImpl;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	EntityManager entityManager;

	@Autowired
	Environment env;

	@Mock
	BFLAwsS3Helper helper;

	@Mock
	BFLExceptionHandler exceptionHandler;

	@Mock
	private Query query;

	@Mock
	private Query query1;

	ObjectMapper mapper;

	@Before
	public void setUp() throws Exception {
		exceptionHandler = new BFLExceptionHandler();
		mapper = MapperFactory.getInstance();
		ReflectionTestUtils.setField(documentsDaoImpl, "helper", helper);
		ReflectionTestUtils.setField(documentsDaoImpl, "entityManager", entityManager);
		ReflectionTestUtils.setField(documentsDaoImpl, "logger", logger);
		ReflectionTestUtils.setField(exceptionHandler, "env", env);
	}

	@Test
	public void testGetDocuments() {
		List<Object[]> queryData = new ArrayList<>();
		SerStmtReportType serStmtReportType = new SerStmtReportType();
		serStmtReportType.setStatementcode("140");
		serStmtReportType.setDescription("desc");
		SerAppStmtRptDocument stmtRptDocument = new SerAppStmtRptDocument();
		stmtRptDocument.setApplicantkey(1452L);
		stmtRptDocument.setGenerationdt(null);
		stmtRptDocument.setStoragelink("https");
		stmtRptDocument.setSerStmtReportType(serStmtReportType);
		List<SerAppStmtRptDocument> stmntTypeList = new ArrayList<>();
		stmntTypeList.add(stmtRptDocument);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query1);
		Mockito.when(query1.getResultList()).thenReturn(stmntTypeList);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(queryData);
		DocumentsResponse result = documentsDaoImpl.getDocuments(14523L);
		assertNotNull(result);
	}
}
