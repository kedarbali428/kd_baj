package com.bajaj.bfsd.loanaccount.dao;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.config.MapperFactory;
import com.bajaj.bfsd.loanaccount.dao.impl.FeeDetailDaoImpl;
import com.bajaj.bfsd.loanaccount.model.FeesType;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:error.properties" })
@SpringBootTest(classes = { BFLCommonRestClient.class })
public class FeeDetailDaoImplTest {

	@InjectMocks
	private FeeDetailDaoImpl feeDetailDaoImpl;

	@Mock
	EntityManager entityManager;

	@Mock
	private Query query;

	ObjectMapper mapper;

	@Before
	public void setUp() throws Exception {
		mapper = MapperFactory.getInstance();
		ReflectionTestUtils.setField(feeDetailDaoImpl, "entityManager", entityManager);
	}

	@Test
	public void testGetFeeDetailsByFeeCode() {
		FeesType feesType = new FeesType();
		List<FeesType> feeTypeList = new ArrayList<>();
		feeTypeList.add(feesType);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(feeTypeList);
		FeesType result = feeDetailDaoImpl.getFeeDetailsByFeeCode("1111");
		assertNotNull(result);
	}
}
