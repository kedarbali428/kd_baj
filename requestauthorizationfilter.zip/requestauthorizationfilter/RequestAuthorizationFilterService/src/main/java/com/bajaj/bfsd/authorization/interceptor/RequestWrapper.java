package com.bajaj.bfsd.authorization.interceptor;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.stream.Collectors;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ReadListener;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RequestWrapper implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		MultiReadRequest wrapper = new MultiReadRequest((HttpServletRequest) request);
		chain.doFilter(wrapper, response);
	}

	@Override
	public void destroy() {
	}

	class MultiReadRequest extends HttpServletRequestWrapper {

		private String requestBody;

		public MultiReadRequest(HttpServletRequest request) {
			super(request);
			try {
					if ((request.getContentType() != null) && 
						   ! (request.getContentType().toLowerCase().indexOf("multipart/form-data") > -1 ))
				    {
				       requestBody = request.getReader().lines().collect(Collectors.joining(""));
				    }
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		@Override
		public ServletInputStream getInputStream() throws IOException {
			final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(requestBody.getBytes());
			return new ServletInputStream() {
				@Override
				public boolean isFinished() {
					return byteArrayInputStream.available() == 0;
				}

				@Override
				public boolean isReady() {
					return true;
				}

				@Override
				public void setReadListener(ReadListener readListener) {

				}

				@Override
				public int read() throws IOException {
					return byteArrayInputStream.read();
				}
			};
		}

		@Override
		public BufferedReader getReader() throws IOException {
			return new BufferedReader(new InputStreamReader(this.getInputStream(), Charset.forName("UTF-8")));
		}
	}
}
