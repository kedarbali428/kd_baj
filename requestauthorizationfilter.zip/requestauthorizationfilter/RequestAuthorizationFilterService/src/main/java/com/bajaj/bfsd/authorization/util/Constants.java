package com.bajaj.bfsd.authorization.util;

public class Constants {

	public static final String ERR_STRING = "Issue during performing authentication, try logging in again.";
	public static final String ROLE_CUSTOMER = "customer";
	public static final String USER_PROFILE_ENTITY = "userProfileEntity";

	private Constants() {

	}
}
