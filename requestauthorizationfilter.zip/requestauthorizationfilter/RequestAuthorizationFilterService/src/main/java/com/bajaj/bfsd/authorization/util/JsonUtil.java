package com.bajaj.bfsd.authorization.util;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.http.HttpStatus;

import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {

	private static final String JSNMAPEXC001 = "JSNMAPEXC_001";

	private JsonUtil() {
		// private Constructor
	}

	public static String mapToJson(Object obj) {
		if (null == obj) {
			return null;
		}
		String jsonString = null;
		try {
			ObjectMapper mapper = MapperFactory.getInstance();
			jsonString = mapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new BFLTechnicalException(JSNMAPEXC001, "Error in parsing json-" + e.getMessage());
		}
		return jsonString;
	}

	public static Map<String, Set<Object>> getFlatMapKeyObjectList(Object object) {
		if (null == object) {
			return null;
		}
		Map<String, Set<Object>> finalFlatMapList = new HashMap<>();
		try {
			org.json.JSONObject jsonObject = new org.json.JSONObject(object.toString());
			Set<String> jsonKeys = jsonObject.keySet();
			if (null != jsonKeys && !jsonKeys.isEmpty()) {
				finalFlatMapList = processJsonToListMap(jsonObject, jsonKeys);
			}
		} catch (Exception e) {
			throw new BFLTechnicalException(JSNMAPEXC001, "Error in parsing json-" + e.getMessage());
		}

		return finalFlatMapList;
	}

	private static Map<String, Set<Object>> processJsonToListMap(org.json.JSONObject jsonObject, Set<String> jsonKeys) {
		Map<String, Set<Object>> finalFlatMapList = new HashMap<>();
		for (String key : jsonKeys) {
			Object val = jsonObject.get(key);
			if (val instanceof JSONArray) {
				JSONArray array = (JSONArray) val;
				jsonArrayForList(array, key, finalFlatMapList);

			} else if (val instanceof org.json.JSONObject) {
				org.json.JSONObject jsonOb = (org.json.JSONObject) val;
				jsonObjForList(jsonOb, key, finalFlatMapList);
			} else {
				putToListMap(key, val.toString(), finalFlatMapList);
			}
		}
		return finalFlatMapList;
	}

	public static Map<String, String> getAllFlatMapKeyValue(Object object) {
		Map<String, String> finalFlatMap = new HashMap<>();
		try {
			String jsonString = mapToJson(object);
			org.json.JSONObject jsonObject = new org.json.JSONObject(jsonString);
			Set<String> jsonKeys = jsonObject.keySet();
			if (null != jsonKeys && !jsonKeys.isEmpty()) {
				finalFlatMap = processJsonToMap(jsonObject, jsonKeys);
			}
		} catch (Exception e) {
			throw new BFLTechnicalException(JSNMAPEXC001, "Error in parsing json-" + e.getMessage());
		}

		return finalFlatMap;
	}

	private static Map<String, String> processJsonToMap(org.json.JSONObject jsonObject, Set<String> jsonKeys) {
		Map<String, String> finalFlatMap = new HashMap<>();
		for (String key : jsonKeys) {
			Object val = jsonObject.get(key);
			if (val instanceof JSONArray) {
				JSONArray array = (JSONArray) val;
				jsonArray(array, key, finalFlatMap);

			} else if (val instanceof org.json.JSONObject) {
				org.json.JSONObject jsonOb = (org.json.JSONObject) val;
				jsonObj(jsonOb, key, finalFlatMap);
			} else {
				finalFlatMap.put(key, val.toString());
			}
		}
		return finalFlatMap;
	}

	private static void jsonObj(org.json.JSONObject object, String key2, Map<String, String> finalFlatMap) {
		Set<String> innerKeys = object.keySet();
		for (String key : innerKeys) {
			Object val = object.get(key);
			if (val instanceof JSONArray) {
				JSONArray array = (JSONArray) val;
				jsonArray(array, key, finalFlatMap);
			} else if (val instanceof org.json.JSONObject) {
				org.json.JSONObject jsonOb = (org.json.JSONObject) val;
				jsonObj(jsonOb, key2 + "->" + key, finalFlatMap);
			} else {

				finalFlatMap.put(key, val.toString());
			}
		}
	}

	private static void jsonArray(JSONArray array, String key, Map<String, String> finalFlatMap) {
		if (array.length() == 0) {
			finalFlatMap.put(key, "");
		} else {
			for (int i = 0; i < array.length(); i++) {
				Object jObject = array.get(i);
				if (jObject instanceof org.json.JSONObject) {
					org.json.JSONObject job = (org.json.JSONObject) jObject;
					jsonObj(job, key, finalFlatMap);
				}
			}
		}
	}

	private static void jsonObjForList(org.json.JSONObject object, String key2, Map<String, Set<Object>> finalFlatMapList) {
		Set<String> innerKeys = object.keySet();
		for (String key : innerKeys) {
			Object val = object.get(key);
			if (val instanceof JSONArray) {
				JSONArray array = (JSONArray) val;
				jsonArrayForList(array, key, finalFlatMapList);
			} else if (val instanceof org.json.JSONObject) {
				org.json.JSONObject jsonOb = (org.json.JSONObject) val;
				jsonObjForList(jsonOb, key2 + "->" + key, finalFlatMapList);
			} else {

				putToListMap(key, val.toString(), finalFlatMapList);
			}
		}
	}

	private static void jsonArrayForList(JSONArray array, String key, Map<String, Set<Object>> finalFlatMapList) {
		if (array.length() == 0) {
			putToListMap(key, "", finalFlatMapList);
			return;
		}
		for (int i = 0; i < array.length(); i++) {
			Object jObject = array.get(i);
			if (jObject instanceof org.json.JSONObject) {
				org.json.JSONObject job = (org.json.JSONObject) jObject;
				jsonObjForList(job, key, finalFlatMapList);
			} else {
				putToListMap(key, jObject.toString(), finalFlatMapList);
			}
		}

	}

	private static Map<String, Set<Object>> putToListMap(String key, Object value, Map<String, Set<Object>> finalFlatMapList) {
		if (finalFlatMapList.containsKey(key)) {
			finalFlatMapList.get(key).add(value);
		} else {
			Set<Object> paramValueList = new HashSet<>();
			paramValueList.add(value);
			finalFlatMapList.put(key, paramValueList);
		}
		return finalFlatMapList;
	}

	public static Map<String, List<Object>> getFirstLevelParamMapForInstance(Object obj) {
		Map<String, List<Object>> mapAttributeObj = null;
		try {
			Class<?> objClass = obj.getClass();
			Field[] fields = objClass.getDeclaredFields();
			mapAttributeObj = new HashMap<>();
			for (Field field : fields) {
				field.setAccessible(true);
				if (mapAttributeObj.containsKey(field.getName())) {
					mapAttributeObj.get(field.getName()).add(field.get(obj));
				} else {
					List<Object> paramValueList = new ArrayList<>();
					paramValueList.add(field.get(obj));
					mapAttributeObj.put(field.getName(), paramValueList);
				}
			}
		} catch (Exception e) {
			throw new BFLTechnicalException(JSNMAPEXC001, "Error in parsing json-" + e.getMessage());
		}
		return mapAttributeObj;
	}

	/**
	 * Converts a list of Object to Long ignoring 0L
	 * 
	 * @param objects
	 * @return
	 */
	public static List<Long> getListofLong(Set<Object> objects) {
		if (null == objects || objects.isEmpty()) {
			return Collections.emptyList();
		}
		List<Long> longList = new ArrayList<>();
		for (Object obj : objects) {
			try {
				if (null != obj && !String.valueOf(obj).isEmpty() && !"null".equals(String.valueOf(obj))
						&& Long.valueOf(String.valueOf(obj).trim()) > 0) {
					longList.add(Long.valueOf(String.valueOf(obj)));
				}
			} catch (Exception e) {
				throw new BFLTechnicalException(JSNMAPEXC001, "Error in parsing json-" + e.getMessage());
			}
		}
		if (!longList.isEmpty()) {
			return longList;
		}
		return Collections.emptyList();
	}

	public static List<String> getListofString(Set<Object> objects) {

		if (null == objects || objects.isEmpty()) {
			return Collections.emptyList();
		}

		List<String> stringList = new ArrayList<>();
		for (Object obj : objects) {
			try {
				if (null != obj) {
					String strParamvalue = String.valueOf(obj);
					if (strParamvalue != null && !strParamvalue.isEmpty() && !"null".equals(String.valueOf(obj))) {
						stringList.add(strParamvalue);
					}
				}

			} catch (Exception e) {
				throw new BFLTechnicalException(JSNMAPEXC001, "Error in parsing json-" + e.getMessage());
			}
		}

		if (!stringList.isEmpty()) {
			return stringList;
		}
		return Collections.emptyList();
	}

	public static void validateProcessIdForTampering(String action, String nextTaskKey, List<String> allowedKeys) {
		if ("resume".equals(action) && !allowedKeys.contains(nextTaskKey)) {
			throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "FA-401", "Process id has been tampered");
		}
	}

	public static void validateTamperingForSysTemUser(String userRole, String cuurentTaskKey,
			List<String> allowedKeys) {
		if ("system".equalsIgnoreCase(userRole) && !allowedKeys.contains(cuurentTaskKey)) {
			throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "FA-401", "Process id has been tampered");
		}
	}

	public static JSONObject getJsonObject(Object object) {
		JSONObject jsonObject = new JSONObject();
		try {
			JSONParser parser = new JSONParser();
			if (object instanceof JSONObject) {
				jsonObject = (JSONObject) object;
			} else {
				Object obj = parser.parse(object.toString());
				jsonObject = (JSONObject) obj;
			}

		} catch (Exception e) {
			throw new BFLTechnicalException(JSNMAPEXC001, "Error in parsing json-" + e.getMessage());
		}
		return jsonObject;
	}

	public static <T> T mapFromJson(String jsonString, Class<T> clazz) {
		ObjectMapper mapper = MapperFactory.getInstance();
		try {
			return mapper.readValue(jsonString, clazz);
		} catch (IOException e) {
			throw new BFLTechnicalException(JSNMAPEXC001, "Error in parsing json-" + e.getMessage());
		}
	}
}