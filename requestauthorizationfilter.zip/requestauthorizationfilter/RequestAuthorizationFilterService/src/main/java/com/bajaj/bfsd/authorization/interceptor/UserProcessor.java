package com.bajaj.bfsd.authorization.interceptor;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.authorization.util.Constants;
import com.bajaj.bfsd.authorization.util.JsonUtil;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.service.UserProfileCacheService;
import com.bajaj.bfsd.common.cache.service.entity.UserProfileEntity;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

@Component
public class UserProcessor {

	private static final String CLASSNAME = UserProcessor.class.getName();

	@Autowired
	CustomDefaultHeaders customHdrs;

	@Autowired
	UserProfileCacheService userProfileCacheService;

	@Autowired
	UserProfileCacheService userProfileServiceImpl;

	@Autowired
	BFLLoggerUtilExt logger;

	@Value("${api.usermanagement.baseprofile.GET.url}")
	private String userProfileBaseUrl;

	public UserProfileEntity fetchUserProfile(boolean reloadAccessMapInCache) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Fetching user profile with user id  -- "
				+ customHdrs.getUserKey() + " and Load from cache flag-" + reloadAccessMapInCache);

		if (!Constants.ROLE_CUSTOMER.equalsIgnoreCase(customHdrs.getDefaultRole())) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "User role is not customer");
			return null;
		}

		UserProfileEntity userProfileEntity = null;
		Long userId = customHdrs.getUserKey();

		try {
			if (!reloadAccessMapInCache) {
				userProfileEntity = userProfileCacheService.get(userId);
			}
		}catch(Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Error while fetching User profile from cache-", e);
		}
		
		try {
		
			if (Objects.nonNull(userProfileEntity) && !CollectionUtils.isEmpty(userProfileEntity.getApplicationIds())) {

				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"User profile from cache-" + userProfileEntity.toString());
				return userProfileEntity;
			}

			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
					"UserProfileEntity not found against userId in cache -- " + userId);

			userProfileEntity = getBaseUserProfile(userId);

			if (Objects.nonNull(userProfileEntity)) {

				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"userProfileCacheService save for user profile -- " + userProfileEntity.toString());
				userProfileCacheService.save(userId, userProfileEntity);
			} else {

				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"userProfileEntity is null so unable to save in cache");
			}

			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Exit from fetchUserProfile method");
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Error occured while Fetching user profile for user id -- " + userId);
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Exit from fetchUserProfile method with userProfileEntity");
		return userProfileEntity;
	}

	@SuppressWarnings("unchecked")
	private UserProfileEntity getBaseUserProfile(Long userId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"get getBaseUserProfile from rest call with db for userid -- " + userId);
		UserProfileEntity baseUserProfileEntity = null;
		String responsePayload;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		JSONObject reqJsonObj = new JSONObject();
		reqJsonObj.put("userKey", userId);
		Map<String, String> params = new HashMap<>();
		params.put("userKey", String.valueOf(userId));
		ResponseEntity<?> response = BFLCommonRestClient.invokeRestEndpoint(HttpMethod.GET, userProfileBaseUrl, null,
				String.class, params, null, headers);
		if (null != response && HttpStatus.OK.equals(response.getStatusCode())) {
			Object responseObject = response.getBody();
			JSONObject responseJson = JsonUtil.getJsonObject(responseObject);
			if (null != responseJson.get("payload")) {
				responsePayload = responseJson.get("payload").toString();
				baseUserProfileEntity = JsonUtil.mapFromJson(responsePayload, UserProfileEntity.class);
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "response from getBaseUserProfile -- " + response);
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"payload for getBaseUserProfile is null -- " + userId);
			}
		} else {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "invalid response from getBaseUserProfile");
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "returning baseUserProfileEntity for userId -- " + userId);
		return baseUserProfileEntity;
	}

}
