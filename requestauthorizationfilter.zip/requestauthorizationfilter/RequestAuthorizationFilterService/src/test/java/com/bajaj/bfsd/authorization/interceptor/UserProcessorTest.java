package com.bajaj.bfsd.authorization.interceptor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.authorization.util.MapperFactory;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.service.UserProfileCacheService;
import com.bajaj.bfsd.common.cache.service.entity.UserProfileEntity;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

@RunWith(PowerMockRunner.class)
@PrepareForTest({BFLCommonRestClient.class,MapperFactory.class})
public class UserProcessorTest {

	@InjectMocks
	UserProcessor userProcessor;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	CustomDefaultHeaders customHdrs;
	
	@Mock
	UserProfileCacheService userProfileCacheService;

	@Mock
	UserProfileCacheService userProfileServiceImpl;
	
	@Value("${api.usermanagement.baseprofile.GET.url}")
	private String userProfileBaseUrl;
	
	@Before
	public void setUp() {
		userProcessor = new UserProcessor();
		customHdrs = new CustomDefaultHeaders();
		customHdrs.setUserkey(12345);
		customHdrs.setDefaultRole("customer");
		ReflectionTestUtils.setField(userProcessor, "logger", logger);
		ReflectionTestUtils.setField(userProcessor, "customHdrs", customHdrs);
		ReflectionTestUtils.setField(userProcessor, "userProfileCacheService", userProfileCacheService);
		ReflectionTestUtils.setField(userProcessor, "userProfileServiceImpl", userProfileServiceImpl);
	}
	
	
	@Test
	public void fetchUserProfileTestSuccess1()
	{
		UserProfileEntity userProfileEntity = new UserProfileEntity();
		List<Long> applicationIds = new ArrayList<>();
		applicationIds.add(Long.valueOf(111111));applicationIds.add(Long.valueOf(111222));
		userProfileEntity.setApplicationIds(applicationIds);
		Mockito.when(userProfileCacheService.get(Mockito.anyLong())).thenReturn(userProfileEntity);
		userProcessor.fetchUserProfile(false);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void fetchUserProfileTestSuccess2()
	{
		UserProfileEntity userProfileEntity = new UserProfileEntity();
		Mockito.when(userProfileCacheService.get(Mockito.anyLong())).thenReturn(userProfileEntity);
		
		UserProfileEntity userProfileEntity1 = new UserProfileEntity();
		List<Long> applicationIds = new ArrayList<>();
		applicationIds.add(Long.valueOf(111111));applicationIds.add(Long.valueOf(111222));
		userProfileEntity1.setApplicationIds(applicationIds);
		List<Long> applicationApplicantIds = new ArrayList<>();
		applicationApplicantIds.add(Long.valueOf(32654234));applicationApplicantIds.add(Long.valueOf(556234));
		userProfileEntity1.setApplicationApplicantIds(applicationApplicantIds);
		userProfileEntity1.setApplicantId(Long.valueOf(222222));
		List<String> appProcessIds = new ArrayList<>();
		appProcessIds.add("345345");appProcessIds.add("1232352");
		userProfileEntity1.setAppProcessIds(appProcessIds);
		userProfileEntity1.setMobileNumber("9876789999");
		userProfileEntity1.setDateOfBirth("1991-10-10");
		
		//ResponseBean responseBean = new ResponseBean();
		Object payload = "{\"status\":\"SUCCESS\",\"errorBean\":[],\"payload\":{\"dateOfBirth\":\"1991-10-10\",\"mobileNumber\":\"9876789999\",\"applicantId\":\"222222\",\"applicationIds\":[\"111111\",\"111222\"],\"applicationApplicantIds\":[\"32654234\",\"556234\"],\"appProcessIds\":[\"345345\",\"1232352\"]}}";
		//responseBean.setPayload(payload);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		JSONObject reqJsonObj = new JSONObject();
		reqJsonObj.put("userKey", Long.valueOf(12345));
		Map<String, String> params = new HashMap<>();
		params.put("userKey", String.valueOf(Long.valueOf(12345)));
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(new ResponseEntity(payload, HttpStatus.OK));
		userProcessor.fetchUserProfile(false);
	}
}