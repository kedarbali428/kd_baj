package com.bajaj.bfsd.authorization.interceptor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

@RunWith(PowerMockRunner.class)
public class RequestAuthorizationInterceptorTest {

	@InjectMocks
	RequestAuthorizationInterceptor requestAuthorizationInterceptor;
	
	@Mock
	RequestAuthorizationHandler requestAuthorizationHandler;
	
	@Before
	public void setUp() {
		requestAuthorizationInterceptor = new RequestAuthorizationInterceptor();
		ReflectionTestUtils.setField(requestAuthorizationInterceptor, "requestAuthorizationHandler", requestAuthorizationHandler);
	}
	
	@Test
	public void addInterceptorsTest()
	{
		InterceptorRegistry registry = new InterceptorRegistry();
		requestAuthorizationInterceptor.addInterceptors(registry);
	}
}
