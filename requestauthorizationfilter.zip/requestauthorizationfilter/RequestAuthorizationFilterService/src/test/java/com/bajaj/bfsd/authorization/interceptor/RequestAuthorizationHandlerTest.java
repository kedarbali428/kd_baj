/*package com.bajaj.bfsd.authorization.interceptor;

import java.lang.reflect.Method;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.method.HandlerMethod;

import com.bajaj.bfsd.authorization.bean.AuthorizationPolicyMap;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@RunWith(PowerMockRunner.class)
public class RequestAuthorizationHandlerTest {

	@InjectMocks
	RequestAuthorizationHandler requestAuthorizationHandler;
	
	@Mock
	ForcedAuthenticationProcessor forcedAuthenticationProcessor;
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	Environment env;

	@Mock
	AuthorizationPolicyMap authMap;
	
	@Before
	public void setUp() {
		forcedAuthenticationProcessor = new ForcedAuthenticationProcessor();
		ReflectionTestUtils.setField(requestAuthorizationHandler, "env", env);
		ReflectionTestUtils.setField(requestAuthorizationHandler, "logger", logger);
		ReflectionTestUtils.setField(requestAuthorizationHandler, "authMap", authMap);
		ReflectionTestUtils.setField(requestAuthorizationHandler, "forcedAuthenticationProcessor", forcedAuthenticationProcessor);
	}

	@Test
	public void preHandleTest() throws Exception 
	{
		String key = "api.generate.url?action=resume";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(key);
		request.setMethod("GET");
		String requestBody = "{\"mobdobChanged\":\"Y\",\"action\":\"resume\",\"applicationId\":\"111111\",\"applicantId\":\"222222\",\"mobileNumber\":\"9876789999\",\"dateOfBirth\":\"1991-10-10\",\"appProcessId\":\"1232352\",\"applicationApplicantId\":\"32654234\"}";
		request.setContent(requestBody.getBytes());
		
		MockHttpServletResponse response = new MockHttpServletResponse();

		Method method = RequestAuthorizationHandlerTest.class.getMethod("preHandleTest");
		RequestAuthorizationHandlerTest controller = new RequestAuthorizationHandlerTest();
        HandlerMethod handlerMethod = new HandlerMethod(controller, method);
		
		requestAuthorizationHandler.preHandle(request, response, handlerMethod);
	}
	
}*/