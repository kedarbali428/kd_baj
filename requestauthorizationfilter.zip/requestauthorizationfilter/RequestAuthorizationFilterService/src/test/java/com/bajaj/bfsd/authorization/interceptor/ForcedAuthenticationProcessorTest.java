package com.bajaj.bfsd.authorization.interceptor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.authorization.bean.AuthorizationPolicy;
import com.bajaj.bfsd.authorization.bean.AuthorizationPolicyMap;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.service.entity.UserProfileEntity;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLHttpException;

@RunWith(PowerMockRunner.class)
public class ForcedAuthenticationProcessorTest {

	@InjectMocks
	ForcedAuthenticationProcessor forcedAuthenticationProcessor;
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	Environment env;

	@Mock
	AuthorizationPolicyMap authMap;
	
	@Mock
	CustomDefaultHeaders customHdrs;

	@Mock
	UserProcessor userProcessor;
	
	@Value("#{'${applicationId.params}'.split(',')}")
	private List<String> applicationIdParams;

	@Value("#{'${applicantId.params}'.split(',')}")
	private List<String> applicantIdParams;

	@Value("#{'${mobileNumber.params}'.split(',')}")
	private List<String> mobileNumberParams;

	@Value("#{'${dateOfBirth.params}'.split(',')}")
	private List<String> dateOfBirthParams;

	@Value("#{'${appProcessId.params}'.split(',')}")
	private List<String> appProcessIdParams;

	@Value("#{'${applicationApplicantId.params}'.split(',')}")
	private List<String> applicationApplicantIdParams;

	@Value("${api.applicationstages.thresholdcheck.GET.url}")
	private String validateStageUrl;

	@Value("${spring.application.name}")
	private String serviceName;
	
	@Mock
	HttpServletRequest request;
	
	@Before
	public void setUp() {
		forcedAuthenticationProcessor = new ForcedAuthenticationProcessor();
		applicationIdParams = new ArrayList<>();
		applicationIdParams.add("applicationId");
		applicantIdParams = new ArrayList<>();
		applicantIdParams.add("applicantId");
		mobileNumberParams = new ArrayList<>();
		mobileNumberParams.add("mobileNumber");
		dateOfBirthParams = new ArrayList<>();
		dateOfBirthParams.add("dateOfBirth");
		appProcessIdParams = new ArrayList<>();
		appProcessIdParams.add("appProcessId");
		applicationApplicantIdParams = new ArrayList<>();
		applicationApplicantIdParams.add("applicationApplicantId");
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "env", env);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "logger", logger);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "authMap", authMap);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "customHdrs", customHdrs);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "userProcessor", userProcessor);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "applicationIdParams", applicationIdParams);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "applicantIdParams", applicantIdParams);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "mobileNumberParams", mobileNumberParams);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "dateOfBirthParams", dateOfBirthParams);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "appProcessIdParams", appProcessIdParams);
		ReflectionTestUtils.setField(forcedAuthenticationProcessor, "applicationApplicantIdParams", applicationApplicantIdParams);
	}
	
	/**
	 * Negative Test - RequestURI null
	 */
	@Test
	public void finegrainCheckRequestTestFailure1() throws IOException
	{
		String uri = "https://www.example.com";	
		forcedAuthenticationProcessor.finegrainCheckRequest(request, uri);
	}
	
	/**
	 * Negative Test - AuthorizationPolicy object null
	 */
	@Test
	public void finegrainCheckRequestTestFailure2() throws IOException
	{
		String uri = "https://www.example.com";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(uri);
		AuthorizationPolicy policy = null;
		Mockito.when(authMap.getPolicy(uri)).thenReturn(policy);
		forcedAuthenticationProcessor.finegrainCheckRequest(request, uri);
	}
	
	/**
	 * Negative Test - UserProfileEntity object null
	 */
	@Test
	public void finegrainCheckRequestTestFailure3() throws IOException
	{
		String key = "api.generate.url";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(key);
		request.setMethod("GET");
		boolean reloadAccessMapInCache = false;
		Mockito.when(env.getProperty(key)).thenReturn(key);
		AuthorizationPolicy policy = new AuthorizationPolicy();
		policy.setRequestAuthorizationRequired("Y");
		Mockito.when(authMap.getPolicy(Mockito.any())).thenReturn(policy);
		UserProfileEntity userProfileEntity = null;
		Mockito.when(userProcessor.fetchUserProfile(reloadAccessMapInCache)).thenReturn(userProfileEntity);
		forcedAuthenticationProcessor.finegrainCheckRequest(request, key);
	}
	
	/**
	 * Negative Test - RequestBody object null
	 */
	@Test
	public void finegrainCheckRequestTestFailure4() throws IOException
	{
		String key = "api.generate.url";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(key);
		request.setMethod("GET");
		/*String requestBody = "{\"mobdobChanged\":\"Y\",\"action\":\"complete\",\"applicationId\":\"111111\",\"applicantId\":\"222222\",\"mobileNumber\":\"9876789999\",\"dateOfBirth\":\"1991-10-10\",\"appProcessId\":\"1232352\",\"applicationApplicantId\":\"32654234\"}";
		request.setContent(requestBody.getBytes());*/
		boolean reloadAccessMapInCache = false;
		Mockito.when(env.getProperty(key)).thenReturn(key);
		AuthorizationPolicy policy = new AuthorizationPolicy();
		policy.setRequestAuthorizationRequired("Y");
		policy.setRequestBodyParams("action,applicationId,applicantId,mobileNumber,dateOfBirth,appProcessId,applicationApplicantId,mobdobChanged");
		policy.setPathParams("test");
		Mockito.when(authMap.getPolicy(Mockito.any())).thenReturn(policy);
		UserProfileEntity userProfileEntity = new UserProfileEntity();
		Mockito.when(userProcessor.fetchUserProfile(reloadAccessMapInCache)).thenReturn(userProfileEntity);
		forcedAuthenticationProcessor.finegrainCheckRequest(request, key);
	}
	
	/**
	 * Positive Test - Authorization Failed
	 */
	//@Test (expected = BFLHttpException.class)
	public void finegrainCheckRequestTestFailure5() throws IOException
	{
		String key = "api.generate.url";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(key);
		request.setMethod("GET");
		String requestBody = "{\"mobdobChanged\":\"Y\",\"action\":\"complete\",\"applicationId\":\"111111\",\"applicantId\":\"222222\",\"mobileNumber\":\"9876789999\",\"dateOfBirth\":\"1991-10-10\",\"appProcessId\":\"1232352\",\"applicationApplicantId\":\"32654234\"}";
		request.setContent(requestBody.getBytes());
		Mockito.when(env.getProperty(key)).thenReturn(key);
		AuthorizationPolicy policy = new AuthorizationPolicy();
		policy.setRequestAuthorizationRequired("Y");
		policy.setRequestBodyParams("action,applicationId,applicantId,mobileNumber,dateOfBirth,appProcessId,applicationApplicantId,mobdobChanged");
		policy.setPathParams("complete");
		Mockito.when(authMap.getPolicy(Mockito.any())).thenReturn(policy);
		UserProfileEntity userProfileEntity = new UserProfileEntity();
		List<Long> applicationIds = new ArrayList<>();
		applicationIds.add(Long.valueOf(111222));
		userProfileEntity.setApplicationIds(applicationIds);
		List<Long> applicationApplicantIds = new ArrayList<>();
		applicationApplicantIds.add(Long.valueOf(556234));
		userProfileEntity.setApplicationApplicantIds(applicationApplicantIds);
		userProfileEntity.setApplicantId(Long.valueOf(222222));
		List<String> appProcessIds = new ArrayList<>();
		appProcessIds.add("345345");
		userProfileEntity.setAppProcessIds(appProcessIds);
		userProfileEntity.setMobileNumber("9876782343");
		userProfileEntity.setDateOfBirth("1991-03-09");
		Mockito.when(userProcessor.fetchUserProfile(true)).thenReturn(userProfileEntity);
		Mockito.when(userProcessor.fetchUserProfile(false)).thenReturn(userProfileEntity);
		forcedAuthenticationProcessor.finegrainCheckRequest(request, key);
	}
	
	/**
	 * Positive Test - HttpServletRequest object
	 */
	@Test
	public void finegrainCheckRequestTestSuccess() throws IOException
	{
		String key = "api.generate.url";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(key);
		request.setMethod("GET");
		String requestBody = "{\"mobdobChanged\":\"Y\",\"action\":\"resume\",\"applicationId\":\"111111\",\"applicantId\":\"222222\",\"mobileNumber\":\"9876789999\",\"dateOfBirth\":\"1991-10-10\",\"appProcessId\":\"1232352\",\"applicationApplicantId\":\"32654234\"}";
		request.setContent(requestBody.getBytes());
		Mockito.when(env.getProperty(key)).thenReturn(key);
		AuthorizationPolicy policy = new AuthorizationPolicy();
		policy.setRequestAuthorizationRequired("Y");
		policy.setRequestBodyParams("action,applicationId,applicantId,mobileNumber,dateOfBirth,appProcessId,applicationApplicantId,mobdobChanged");
		policy.setPathParams("resume");
		Mockito.when(authMap.getPolicy(Mockito.any())).thenReturn(policy);
		UserProfileEntity userProfileEntity = new UserProfileEntity();
		List<Long> applicationIds = new ArrayList<>();
		applicationIds.add(Long.valueOf(111111));applicationIds.add(Long.valueOf(111222));
		userProfileEntity.setApplicationIds(applicationIds);
		List<Long> applicationApplicantIds = new ArrayList<>();
		applicationApplicantIds.add(Long.valueOf(32654234));applicationApplicantIds.add(Long.valueOf(556234));
		userProfileEntity.setApplicationApplicantIds(applicationApplicantIds);
		userProfileEntity.setApplicantId(Long.valueOf(222222));
		List<String> appProcessIds = new ArrayList<>();
		appProcessIds.add("345345");appProcessIds.add("1232352");
		userProfileEntity.setAppProcessIds(appProcessIds);
		userProfileEntity.setMobileNumber("9876789999");
		userProfileEntity.setDateOfBirth("1991-10-10");
		Mockito.when(userProcessor.fetchUserProfile(true)).thenReturn(userProfileEntity);
		Mockito.when(userProcessor.fetchUserProfile(false)).thenReturn(userProfileEntity);
		forcedAuthenticationProcessor.finegrainCheckRequest(request, key);
	}
	
	
	
}