package com.bajaj.bfsd.authorization.util;

import java.util.HashSet;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MapperFactory.class })
public class JsonUtilTest {

	@InjectMocks
	JsonUtil jsonUtil;
	
	
	@SuppressWarnings("static-access")
	@Test
	public void mapToJsonTestFailure1()
	{
		Object payload = null;
		jsonUtil.mapToJson(payload);
	}
	
	@SuppressWarnings("static-access")
	@Test
	public void mapToJsonTest()
	{
		Object payload = "{\"status\":\"SUCCESS\",\"errorBean\":[],\"payload\":{\"dateOfBirth\":\"1991-10-10\",\"mobileNumber\":\"9876789999\",\"applicantId\":\"222222\",\"applicationIds\":[\"111111\",\"111222\"],\"applicationApplicantIds\":[\"32654234\",\"556234\"],\"appProcessIds\":[\"345345\",\"1232352\"]}}";
		jsonUtil.mapToJson(payload);
	}

	@SuppressWarnings("static-access")
	@Test
	public void getFlatMapKeyObjectListFailure1()
	{
		Object payload = null;
		jsonUtil.getFlatMapKeyObjectList(payload);
	}
	
	@SuppressWarnings("static-access")
	@Test
	public void getFlatMapKeyObjectListTest()
	{
		Object payload = "{\"status\":\"SUCCESS\",\"errorBean\":[],\"payload\":{\"dateOfBirth\":\"1991-10-10\",\"mobileNumber\":\"9876789999\",\"applicantId\":\"222222\",\"applicationIds\":[\"111111\",\"111222\"],\"applicationApplicantIds\":[\"32654234\",\"556234\"],\"appProcessIds\":[\"345345\",\"1232352\"]}}";
		jsonUtil.getFlatMapKeyObjectList(payload);
	}
	
	@SuppressWarnings("static-access")
	@Test (expected = BFLTechnicalException.class)
	public void getAllFlatMapKeyValueFailure1()
	{
		Object payload = null;
		jsonUtil.getAllFlatMapKeyValue(payload);
	}
	
	@Test
	public void processJsonToMap1() throws Exception
	{
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		jsonArray.put("true");jsonArray.put("false");
		jsonObject.put("status", jsonArray);
		Set<String> jsonKeys = new HashSet<>();
		jsonKeys.add("status");
		Whitebox.invokeMethod(jsonUtil, "processJsonToMap", jsonObject,jsonKeys);
	}
	
	@Test
	public void processJsonToMap2() throws Exception
	{
		JSONObject jsonObject = new JSONObject();
		JSONObject jsonObject1 = new JSONObject();
		jsonObject1.put("key1", "value1");
		jsonObject.put("status", jsonObject1);
		Set<String> jsonKeys = new HashSet<>();
		jsonKeys.add("status");
		Whitebox.invokeMethod(jsonUtil, "processJsonToMap", jsonObject,jsonKeys);
	}
	
	@Test
	public void processJsonToMap3() throws Exception
	{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("key1", "value1");
		Set<String> jsonKeys = new HashSet<>();
		jsonKeys.add("key1");
		Whitebox.invokeMethod(jsonUtil, "processJsonToMap", jsonObject,jsonKeys);
	}
}
