package com.bajaj.bfsd.authorization.interceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Component
@Order(3)
public class RequestAuthorizationInterceptor extends WebMvcConfigurerAdapter {

	@Autowired
	RequestAuthorizationHandler requestAuthorizationHandler;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(requestAuthorizationHandler);
	}

}
