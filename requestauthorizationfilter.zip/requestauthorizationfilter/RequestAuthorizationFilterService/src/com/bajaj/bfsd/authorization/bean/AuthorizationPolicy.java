package com.bajaj.bfsd.authorization.bean;

public class AuthorizationPolicy {
	private String uri;
	private String requestMethod;
	private boolean requestAuthorizationRequired;
	private String requestBodyParams;
	private String pathParams;

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getRequestMethod() {
		return requestMethod;
	}

	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public boolean getRequestAuthorizationRequired() {
		return requestAuthorizationRequired;
	}

	public void setRequestAuthorizationRequired(String requestAuthorizationRequired) {
		this.requestAuthorizationRequired = false;

		if (null != requestAuthorizationRequired) {
			this.requestAuthorizationRequired = "Y".equalsIgnoreCase(requestAuthorizationRequired.trim());
		}
	}

	public String getRequestBodyParams() {
		return requestBodyParams;
	}

	public void setRequestBodyParams(String requestBodyParams) {
		this.requestBodyParams = requestBodyParams;
	}

	public String getPathParams() {
		return pathParams;
	}

	public void setPathParams(String pathParams) {
		this.pathParams = pathParams;
	}

}
