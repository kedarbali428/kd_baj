package com.bajaj.bfsd.authorization.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerMapping;

public class ParamReaderUtil {

	public static Map<String, Set<Object>> getQueryParameters(HttpServletRequest request) {
		Map<String, Set<Object>> queryParameters = new HashMap<>();
		String queryString = request.getQueryString();

		if (StringUtils.isEmpty(queryString)) {
			return queryParameters;
		}

		String[] parameters = queryString.split("&");

		for (String parameter : parameters) {
			String[] keyValuePair = parameter.split("=");
			Set<Object> values = queryParameters.get(keyValuePair[0]);
			if (keyValuePair.length == 1) {
				values.add("");
			} else {
				values.add(keyValuePair[1]);
			}
			queryParameters.put(keyValuePair[0], values);
		}
		return queryParameters;
	}

	public static Map<String, Set<Object>> getRequestBody(Map<String, Set<Object>> mapAttributeObj,
			List<String> requestBodyParam) {
		Map<String, Set<Object>> requestBodyParams = new HashMap<>();
		for (String param : requestBodyParam) {
			requestBodyParams.put(param, mapAttributeObj.get(param));
		}
		return requestBodyParams;
	}

	public static Map<String, Set<Object>> getPathParams(HttpServletRequest request, String pathParam) {
		Map<String, Set<Object>> pathParameters = new HashMap<>();
		Set<Object> pathParamSet = new HashSet<>();
		Object pathParamValue = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
		pathParamSet.add(pathParamValue);
		pathParameters.put(pathParam, pathParamSet);
		return pathParameters;
	}

}
