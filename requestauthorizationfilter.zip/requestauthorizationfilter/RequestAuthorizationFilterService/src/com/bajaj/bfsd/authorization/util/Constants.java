package com.bajaj.bfsd.authorization.util;

public class Constants {

	public static final String ERR_STRING = "Issue during performing authentication, try logging in again.";
	public static final String ROLE_CUSTOMER = "customer";

	private Constants() {

	}
}
