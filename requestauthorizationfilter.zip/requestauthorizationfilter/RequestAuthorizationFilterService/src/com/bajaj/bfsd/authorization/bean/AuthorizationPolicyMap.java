package com.bajaj.bfsd.authorization.bean;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class AuthorizationPolicyMap {

	private Map<String, AuthorizationPolicy> authMap;
	
	public AuthorizationPolicyMap(){
		authMap = new HashMap<>();
	}
	public void setPolicyMap(Map<String, AuthorizationPolicy> authMap){
		this.authMap = authMap;
	}
	
	public Map<String, AuthorizationPolicy> getAuthMap(){
		return authMap;
	}
	
	public AuthorizationPolicy getPolicy(String uri){
		AuthorizationPolicy policy;
		policy = authMap.get(uri);
		return policy;
	}
	
	public void putPolicy(String uri, AuthorizationPolicy policy){
		authMap.put(uri, policy);
	}
}

