package com.bajaj.bfsd.authorization.interceptor;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.bajaj.bfsd.authorization.bean.AuthorizationPolicy;
import com.bajaj.bfsd.authorization.bean.AuthorizationPolicyMap;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bfl.common.exceptions.BFLBusinessException;

@Component
public class RequestAuthorizationHandler implements HandlerInterceptor {
	private static final String CLASS_NAME = RequestAuthorizationHandler.class.getName();
	@Autowired
	private ForcedAuthenticationProcessor forcedAuthenticationProcessor;

	@Autowired
	Environment env;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	AuthorizationPolicyMap authMap;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "RequestAuthorizationHandler-preHandle started");
		if (handler instanceof HandlerMethod) {
			HandlerMethod method = (HandlerMethod) handler;

			RequestMapping mapping = method.getMethodAnnotation(RequestMapping.class);
			String uriPath = Arrays.toString(mapping.value());
			String uri = uriPath.substring(uriPath.indexOf('{') + 1, uriPath.indexOf('}'));
			getAuthMapProperty(request, uri);
			forcedAuthenticationProcessor.finegrainCheckRequest(request, uri);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "RequestAuthorizationHandler-preHandle done");
		return true;
	}

	private void getAuthMapProperty(HttpServletRequest request, String uri) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"getAuthMapProperty-Getting auth map property for URI" + uri);
		try {
			String key = env.getProperty(uri) + "-" + request.getMethod();
			String property = env.getProperty(key);
			String[] prop = property.split(";");
			uri = prop[0];
			String method = prop[1];
			String isRequestAuthorizationRequired = prop[2];
			String bodyParams = prop[3];
			String pathParam = prop[4];
			AuthorizationPolicy authorizationPolicy = new AuthorizationPolicy();
			authorizationPolicy.setUri(uri);
			authorizationPolicy.setRequestMethod(method);
			authorizationPolicy.setPathParams(pathParam);
			authorizationPolicy.setRequestAuthorizationRequired(isRequestAuthorizationRequired);
			authorizationPolicy.setRequestBodyParams(bodyParams);
			authMap.putPolicy(key, authorizationPolicy);
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Property undefined or not in correct format for URI-" + uri);
			throw new BFLBusinessException("RVF",
					"Property undefined or not in correct format for URI-" + uri);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"getAuthMapProperty-Done getting auth map property for URI-" + uri);
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub

	}

}
