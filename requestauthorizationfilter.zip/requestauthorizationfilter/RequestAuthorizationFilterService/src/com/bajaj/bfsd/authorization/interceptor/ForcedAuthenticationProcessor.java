package com.bajaj.bfsd.authorization.interceptor;

import static com.bajaj.bfsd.authorization.util.BFLForcedAuthContants.ACTION_CONTINUE_NEW;
import static com.bajaj.bfsd.authorization.util.BFLForcedAuthContants.ACTION_RESUME;
import static com.bajaj.bfsd.authorization.util.BFLForcedAuthContants.ACTION_TERMINATE;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.authorization.bean.AuthorizationPolicy;
import com.bajaj.bfsd.authorization.bean.AuthorizationPolicyMap;
import com.bajaj.bfsd.authorization.util.JsonUtil;
import com.bajaj.bfsd.authorization.util.ParamReaderUtil;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.service.entity.UserProfileEntity;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLHttpException;

@Component
public class ForcedAuthenticationProcessor {

	private static final String CLASSNAME = ForcedAuthenticationProcessor.class.getName();

	public static final String PARAM_MOBDOB_CHANGED = "mobdobChanged";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	protected Environment env;

	@Autowired
	AuthorizationPolicyMap authMap;

	@Value("#{'${applicationId.params}'.split(',')}")
	private List<String> applicationIdParams;

	@Value("#{'${applicantId.params}'.split(',')}")
	private List<String> applicantIdParams;

	@Value("#{'${mobileNumber.params}'.split(',')}")
	private List<String> mobileNumberParams;

	@Value("#{'${dateOfBirth.params}'.split(',')}")
	private List<String> dateOfBirthParams;

	@Value("#{'${appProcessId.params}'.split(',')}")
	private List<String> appProcessIdParams;

	@Value("#{'${applicationApplicantId.params}'.split(',')}")
	private List<String> applicationApplicantIdParams;

	@Value("${api.applicationstages.thresholdcheck.GET.url}")
	private String validateStageUrl;

	@Value("${spring.application.name}")
	private String serviceName;

	@Autowired
	CustomDefaultHeaders customHdrs;

	@Autowired
	UserProcessor userProcessor;

	public boolean finegrainCheckRequest(HttpServletRequest request, String uri) throws IOException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside validateRequest for request-" + request);

		if (!isFineGrainAuthorizationRequired(request, uri)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside validateRequest:Request authorization not required -" + request);
			return true;
		}

		UserProfileEntity userProfileEntity = userProcessor.fetchUserProfile(false);

		boolean flag = true;
		if (null != userProfileEntity) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside validateRequest userProfileEntity not null");
			flag = finegrainAuthCheck(request, userProfileEntity, uri);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "after validateVaptRequest flag -- " + flag);
		}

		if (!flag) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "not found userProfileEntity else set as -- " + flag);
			throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "FA-401",
					"Forced Authencation is failed, Unable to perform this action!!");
		}
		return flag;
	}

	private boolean finegrainAuthCheck(HttpServletRequest request, UserProfileEntity userProfileEntity, String uri)
			throws IOException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside finegrainAuthCheck");

		Map<String, Set<Object>> paramToValidate = getParams(request, uri);

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Params to validate-" + paramToValidate);

		if (CollectionUtils.isEmpty(paramToValidate)) {
          	logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Empty paramToValidate");
			return true;
		}

		boolean fineGrainAuthSuccess = doFineGrainAuthCheck(userProfileEntity, paramToValidate);

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "exit validateVaptRequest all check passed");
		return fineGrainAuthSuccess;
	}

	private boolean doFineGrainAuthCheck(UserProfileEntity userProfileEntity,
			Map<String, Set<Object>> paramToValidate) {

		Set<String> keySet = paramToValidate.keySet();

		boolean resOrTerOrContAction = isResOrTerOrContAction(paramToValidate);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,"resOrTerOrContAction - "+resOrTerOrContAction);
      
		boolean mobdobChanged = isMobDobChanged(paramToValidate);
		if (mobdobChanged) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
					"MOB or DOB changed in this request & yet to be persisted. So in Authcheck will be ignored -- ");
		}

		boolean fineGrainAuthSuccess = true;
		for (String keyName : keySet) {
			if (keyName == null) {
				continue;
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,"Key Name : "+keyName);
			if (!fineGrainAuthSuccess) {
				return fineGrainAuthSuccess;
			}
			if (applicationIdParams.contains(keyName)) {
				fineGrainAuthSuccess = forceAuthenticateApplication(userProfileEntity, paramToValidate, keyName);
			} else if (applicantIdParams.contains(keyName)) {
				fineGrainAuthSuccess = forceAuthenticateApplicant(userProfileEntity, paramToValidate, keyName);
			} else if (appProcessIdParams.contains(keyName)) {
				fineGrainAuthSuccess = forceAuthenticateProcessId(userProfileEntity, paramToValidate,
						resOrTerOrContAction, keyName);
			} else if (applicationApplicantIdParams.contains(keyName)) {
				fineGrainAuthSuccess = forceAuthenticateApplicationApplicantId(userProfileEntity, paramToValidate,
						keyName);
			} else if (!mobdobChanged && dateOfBirthParams.contains(keyName)) {
				fineGrainAuthSuccess = forceAuthenticateDOB(userProfileEntity, paramToValidate, keyName);
			} else if (!mobdobChanged && mobileNumberParams.contains(keyName)) {
				fineGrainAuthSuccess = forceAuthenticateMobNo(userProfileEntity, paramToValidate, keyName);
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "No criteria Matched for check values");
			}
		}
		return fineGrainAuthSuccess;
	}

	private Map<String, Set<Object>> getParams(HttpServletRequest request, String uri) throws IOException {
		Map<String, Set<Object>> paramToValidate = null;
		try {
			String key = env.getProperty(uri) + "-" + request.getMethod();
          	logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "KEY : " + key);
			AuthorizationPolicy policy = authMap.getPolicy(key);
			String requestBodyParams = policy.getRequestBodyParams();
			String[] split = requestBodyParams.split(",");
			List<String> requestBodyParam = Arrays.asList(split);

			String pathParams = policy.getPathParams();
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "pathParams String value : " + pathParams);

			Object requestBody = request.getReader().lines().collect(Collectors.joining(""));

			if (Objects.isNull(requestBody)) {
				return null;
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "request body to validate - " + requestBody);

			Map<String, Set<Object>> mapAttributeObj = JsonUtil.getFlatMapKeyObjectList(requestBody);

			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "request body to validate map - " + mapAttributeObj);

			paramToValidate = ParamReaderUtil.getRequestBody(mapAttributeObj, requestBodyParam);

			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "request body to validate prepared map -" + paramToValidate);

			Map<String, Set<Object>> queryParameters = ParamReaderUtil.getQueryParameters(request);
          	logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "queryParameters : " + queryParameters);
			paramToValidate.putAll(queryParameters);

			Map<String, Set<Object>> pathParam = ParamReaderUtil.getPathParams(request, pathParams);
          	logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "pathParam : " + pathParam);
			paramToValidate.putAll(pathParam);
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Exception in getting params to validate-" + e.getStackTrace());
		}
		return paramToValidate;
	}

	private boolean isMobDobChanged(Map<String, Set<Object>> mapAttributeObj) {
		Set<String> keySet = mapAttributeObj.keySet();
		if (keySet.contains(PARAM_MOBDOB_CHANGED)) {
			List<String> mobdobChanged = JsonUtil.getListofString(mapAttributeObj.get(PARAM_MOBDOB_CHANGED));
			if (mobdobChanged != null && (mobdobChanged.contains("true"))) {
				return true;
			}
		}
		return false;
	}

	private boolean isFineGrainAuthorizationRequired(HttpServletRequest request, String uri) {

		if (StringUtils.isEmpty(request.getRequestURI())) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "URI is null.");
			return false;
		}

		String key = env.getProperty(uri) + "-" + request.getMethod();
		AuthorizationPolicy policy = authMap.getPolicy(key);
		if (Objects.isNull(policy)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Policy is null.");
			return false;
		}

		return policy.getRequestAuthorizationRequired();

	}

	private boolean forceAuthenticateMobNo(UserProfileEntity userProfileEntity,
			Map<String, Set<Object>> mapAttributeObj, String keyName) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"inside mobileNumberParams.contains(keyName) -- " + keyName);

		List<String> payloadMobileNumber = JsonUtil.getListofString(mapAttributeObj.get(keyName));
		String cacheMobileNumber = userProfileEntity.getMobileNumber();

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Force Authenticating mobile number  with payload- " + payloadMobileNumber);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Cached mmobile number - " + cacheMobileNumber);

		if (CollectionUtils.isEmpty(payloadMobileNumber)) {
			return false;
		}
		if (payloadMobileNumber.contains(cacheMobileNumber)) {
			return true;
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "exit mobileNumberParams.contains(keyName)");
		return false;
	}

	private boolean forceAuthenticateDOB(UserProfileEntity userProfileEntity, Map<String, Set<Object>> mapAttributeObj,
			String keyName) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside dateOfBirthParams.contains(keyName) -- " + keyName);

		List<String> payloadDateOfBirth = JsonUtil.getListofString(mapAttributeObj.get(keyName));
		String cacheDateOfBirth = userProfileEntity.getDateOfBirth();
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Force Authenticating dob  with payload- " + payloadDateOfBirth);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Cached dob - " + cacheDateOfBirth);

		if (CollectionUtils.isEmpty(payloadDateOfBirth)) {
			return false;
		}
		if (payloadDateOfBirth.contains(cacheDateOfBirth)) {
			return true;
		}

		return false;
	}

	private boolean forceAuthenticateApplicationApplicantId(UserProfileEntity userProfileEntity,
			Map<String, Set<Object>> mapAttributeObj, String keyName) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"inside applicationApplicantIdParams.contains(keyName) -- " + keyName);

		List<Long> payloadApplicationApplicantIds = JsonUtil.getListofLong(mapAttributeObj.get(keyName));
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Force Authenticating application applicant id  with payload- " + payloadApplicationApplicantIds);

		if (CollectionUtils.isEmpty(payloadApplicationApplicantIds)) {
			return false;
		}
		for (Long payloadApplicationApplicantId : payloadApplicationApplicantIds) {
			if (!userProfileEntity.getApplicationApplicantIds().contains(payloadApplicationApplicantId)) {
				// reload the cache
				UserProfileEntity updatedUserProfileEntity = userProcessor.fetchUserProfile(true);
				if (!updatedUserProfileEntity.getApplicationApplicantIds().contains(payloadApplicationApplicantId)) {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
							"ApplicationApplicantId missing in userProfile -- " + payloadApplicationApplicantId);
					return false;
				}
			}
		}

		return true;
	}

	private boolean forceAuthenticateProcessId(UserProfileEntity userProfileEntity,
			Map<String, Set<Object>> mapAttributeObj, boolean resOrTerOrContAction, String keyName) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"inside appProcessIdParams.contains(keyName) -- " + keyName);

		if (resOrTerOrContAction) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Payload is from Resume or Terminate Action so skipping ProcessId check");
			return resOrTerOrContAction;
		}

		List<String> payloadAppProcessIds = JsonUtil.getListofString(mapAttributeObj.get(keyName));
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Force Authenticating process id  with payload- " + payloadAppProcessIds);

		if (CollectionUtils.isEmpty(payloadAppProcessIds)) {
			return true;
		}
		for (String payloadAppProcessId : payloadAppProcessIds) {
			if (!userProfileEntity.getAppProcessIds().contains(payloadAppProcessId)) {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"ProcessId missing in userProfile and hence fetching from db -- " + payloadAppProcessId);
				UserProfileEntity updatedUserProfileEntity = userProcessor.fetchUserProfile(true);
				if (!updatedUserProfileEntity.getAppProcessIds().contains(payloadAppProcessId)) {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
							"ProcessId missing in userProfile and db also -- " + payloadAppProcessId);
					return false;
				}
			}
		}

		return true;

	}

	private boolean forceAuthenticateApplicant(UserProfileEntity userProfileEntity,
			Map<String, Set<Object>> mapAttributeObj, String keyName) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside applicantIdParams.contains(keyName) -- " + keyName);

		List<Long> applnIds = JsonUtil.getListofLong(mapAttributeObj.get(keyName));
		Long cacheApplicantId = userProfileEntity.getApplicantId();
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Force Authenticating applicant id  with payload- " + applnIds);
		if (CollectionUtils.isEmpty(applnIds)) {
			return false;
		}

		if (!applnIds.contains(cacheApplicantId)) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "payloadApplicantId and cacheApplicantId mismatch");
			return false;
		}

		return true;
	}

	private boolean forceAuthenticateApplication(UserProfileEntity userProfileEntity,
			Map<String, Set<Object>> mapAttributeObj, String keyName) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Force Authenticating- " + keyName);

		List<Long> payloadAppKeys = JsonUtil.getListofLong(mapAttributeObj.get(keyName));
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Force Authenticating application id with payload- " + payloadAppKeys);

		if (CollectionUtils.isEmpty(payloadAppKeys)) {
			return false;
		}

		for (Long payloadAppKey : payloadAppKeys) {
			if (!userProfileEntity.getApplicationIds().contains(payloadAppKey)) {
				// reload the cache
				UserProfileEntity updatedUserProfileEntity = userProcessor.fetchUserProfile(true);
				if (!updatedUserProfileEntity.getApplicationIds().contains(payloadAppKey)) {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
							"ApplicationKey missing in userProfile -- " + payloadAppKey);
					return false;
				}
			}
		}

		return true;
	}

	private boolean isResOrTerOrContAction(Map<String, Set<Object>> mapAttributeObj) {
		logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside isResOrTerOrContAction -- " + mapAttributeObj);

		Set<String> keySet = mapAttributeObj.keySet();
		if (!keySet.contains("action")) {
          	logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "keySet not cantains action return false");
			return false;
		}
		List<String> actions = JsonUtil.getListofString(mapAttributeObj.get("action"));
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Force Authenticating action with payload- " + actions);

		if (!CollectionUtils.isEmpty(actions) && (actions.contains(ACTION_RESUME) || actions.contains(ACTION_TERMINATE)
				|| actions.contains(ACTION_CONTINUE_NEW))) {
          	logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "keySet return true");
			return true;
		}
		logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exit from isResOrTerOrContAction -- ");
      	logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "keySet return false");
		return false;
	}

}
