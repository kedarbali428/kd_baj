package com.bajaj.bfsd.tms.model;

import java.io.Serializable;

public class ExpireTokenUserId implements Serializable {

	private static final long serialVersionUID = 7978134504681080093L;
	
	private boolean isExpired;
	private Long userId;
	public boolean isExpired() {
		return isExpired;
	}
	public void setExpired(boolean isExpired) {
		this.isExpired = isExpired;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (isExpired ? 1231 : 1237);
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		ExpireTokenUserId other = (ExpireTokenUserId) object;
		if (isExpired != other.isExpired)
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ExpireTokenUserId [isExpired=" + isExpired + ", userId=" + userId + "]";
	}
	
}
