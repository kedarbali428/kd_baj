package com.bajaj.bfsd.tms.util;

public enum TokenType {

	AUTHENTICATION("authToken"), 
	REFRESH("refreshToken");

	private final String value;

	TokenType(String input) {
		this.value = input;
	}

	public String getValue() {
		return this.value;
	}

	@Override
	public String toString() {
		return this.value;
	}
}
