package com.bajaj.bfsd.tms.repository;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;

@Component
public abstract class RefreshTokenStore extends BFLComponent implements TokenStoreService<String, RefreshTokenEntity>{
	
	public RefreshTokenStore()
	{
	}	
}