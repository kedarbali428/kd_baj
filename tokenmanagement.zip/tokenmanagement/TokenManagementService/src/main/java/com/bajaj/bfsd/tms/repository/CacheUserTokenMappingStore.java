package com.bajaj.bfsd.tms.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.constants.CacheDataType;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;
import com.bajaj.bfsd.tms.entity.TokenEntity;
import com.bajaj.bfsd.tms.util.TMSConstants;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
public class CacheUserTokenMappingStore extends BaseUserTokenMappingStore{

	// List need to be changed to hashmap to improve performance - Functionally this might not help as tokenstring
	// key will change so it will defeate the purpose of hashmap
	//private HashMap<Long, List<TokenEntity>> userTokenStore
	private SingleObjectCacheRepositoryImpl<String, List<TokenEntity>> cacheRepository; 
	
	@Autowired
	CacheAuthTokenStore cacheAuthTokenStore;
	
	@Autowired
	CacheRefreshTokenStore cacheRefreshTokenStore;
	
	@Autowired
	protected Environment env;
		
	@Autowired
	protected RedisConfig redisConfig;
	
	@Autowired
    private BFLLoggerUtil logger;	
	
	private static final String THIS_CLASS = CacheUserTokenMappingStore.class.getCanonicalName();

	@Override
	public List<TokenEntity> fetchToken(String userId) throws BFLTechnicalException {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.REPOSITORY, "fetching tokens with userid: " + userId);
			return getCacheRepository().find(userId);
		} catch (Exception exception) {
			throw new BFLTechnicalException("TMS-006", exception);
		}		
	}

	@Override
	public void saveToken(String userId, List<TokenEntity> entity) throws BFLTechnicalException {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.REPOSITORY, "saving tokens with userid: " + userId);
			getCacheRepository().save(userId, entity);
		} catch (Exception exception) {
			throw new BFLTechnicalException("TMS-007", exception);
		}
	}

	@Override
	public void deleteToken(String userId) throws BFLTechnicalException {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.REPOSITORY, "deleting tokens with userid: " + userId);
			getCacheRepository().delete(userId);
		} catch (Exception exception) {
			throw new BFLTechnicalException("TMS-008", exception);
		}
	}		
	
	@Override
	void deleteAssociatedEntities(TokenEntity entity){
		if(null != entity){
			short entityType = entity.getType(); 
			if(entityType == TMSConstants.TOKENTYPE_AUTH){
				cacheAuthTokenStore.deleteToken(entity.getToken());
			} else if(entityType == TMSConstants.TOKENTYPE_REFRESH){
				cacheRefreshTokenStore.deleteToken(entity.getToken());
			} 	
		}
	}
	
	@Override
	void addAssociatedEntity(TokenEntity entity){
		if(null != entity){
			short entityType = entity.getType(); 
			logger.error(THIS_CLASS, BFLLoggerComponent.REPOSITORY, "Token entity save start :: "+  entity.getToken());
			if(entityType == TMSConstants.TOKENTYPE_AUTH){
				cacheAuthTokenStore.saveToken(entity.getToken(), (AuthTokenEntity)entity);
			} else if(entityType == TMSConstants.TOKENTYPE_REFRESH){
				cacheRefreshTokenStore.saveToken(entity.getToken(), (RefreshTokenEntity)entity);
			} 
			logger.error(THIS_CLASS, BFLLoggerComponent.REPOSITORY, "Token entity save end :: " + entity.getToken());
		}
		
	}
	
	private SingleObjectCacheRepositoryImpl<String, List<TokenEntity>> getCacheRepository()
	{
		if(null == this.cacheRepository){
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(TokenEntity.class, CacheDataType.LISTOBJECT, env, redisConfig);
		}
		
		return cacheRepository;
	}	
}
