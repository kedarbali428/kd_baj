package com.bajaj.bfsd.tms.model;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;

public class TokenEncryptionRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8036910740081862273L;

	@NotEmpty(message = "AUTH_635")
	private String authToken;
	
	@NotEmpty(message = "AUTH_635")
	private String  guardKey;
	public String getAuthToken() {
		return authToken;
	}
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
	public String getGuardKey() {
		return guardKey;
	}
	public void setGuardKey(String guardKey) {
		this.guardKey = guardKey;
	}
	

}
