package com.bajaj.bfsd.tms.util;

public class TMSConstants {
	
	public static final String PLATFORM_DESKTOP = "desk";
	public static final String PLATFORM_MOBILE = "mob";
	public static final String PLATFORM_MOBILE_APP = "moba";
	public static final String HEADER_DOMAIN = "domain";
	public static final String HEADER_PLATFORM = "platform";
	public static final String HEADER_SOURCE = "source";
	public static final String VALID_TOKEN = "VALID";
	public static final String EXPIRED_TOKEN = "EXPIRED";
	public static final String INVALID_TOKEN = "INVALID";
	public static final String TOKEN = "token";
	public static final String SUCCESS = "SUCCESS"; 
	public static final String FAILURE = "FAILURE"; 
	public static final String AUTH_TOKEN = "authtoken";
	public static final String GUARD_TOKEN = "guardtoken";
	public static final String PIPE = "|";
	public static final String SPILT_PIPE = "\\|";
	public static final String REF_TOKEN = "refreshtoken";
	
	public static final short TOKENTYPE_AUTH = 0;
	public static final short TOKENTYPE_REFRESH = 1;
	public static final short TOKENTYPE_GAURD = 2;
	
	public static final String JWT_FIELD_LOGIN = "login";
	public static final String JWT_FIELD_USERTYPE = "userType";
	
	public static final short USERTYPE_SYSTEM = 0;
	public static final short USERTYPE_CUSTOMER = 1;
	public static final short USERTYPE_EMPLOYEE = 2;
	public static final short USERTYPE_VENDOR_PARTNER = 3;
	public static final short USERTYPE_B2B_PARTNER = 4;
	public static final short USERTYPE_SYSTEM_PARTNER = 5;
    public static final short USERTYPE_PRINCIPAL = 6;
	public static final short USERTYPE_PSEUDO_CUSTOMER = 10;
	public static final short USERTYPE_PSEUDO_VERIFIED_CUSTOMER = 11;
    public static final short USERTYPE_INTERNAL = 99;
	
	public static final String DEFAULTROLE_SYSTEM = "system";
	public static final String DEFAULTROLE_CUSTOMER = "customer";
	public static final String DEFAULTROLE_EMPLOYEE = "employee";
	public static final String DEFAULTROLE_B2B_PARTNER = "b2bpartner";
	public static final String DEFAULTROLE_VENDOR_PARTNER = "vendorpartner";
	public static final String DEFAULTROLE_SYSTEM_PARTNER = "systempartner";
	public static final String DEFAULTROLE_PSEUDO_CUSTOMER = "pcustomer";
	public static final String DEFAULTROLE_PSEUDO_VERIFIED_CUSTOMER = "pvcustomer";
    public static final String DEFAULTROLE_INTERNAL = "internal";
	
	private TMSConstants(){
		
	}
}
