package com.bajaj.bfsd.tms.repository;

import java.util.HashMap;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.tms.entity.AuthTokenEntity;

@Component
public class LocalAuthTokenStore extends AuthTokenStore{

	private HashMap<String, AuthTokenEntity> authTokenStore;
	
	public LocalAuthTokenStore()
	{
		authTokenStore = new HashMap<>();
	}
	@Override
	public void deleteAllTokensForUser(long userId) {
		// 
	}

	@Override
	public AuthTokenEntity fetchToken(String token) {
		
		return token==null? null: authTokenStore.get(token);
	}

	@Override
	public void saveToken(String token, AuthTokenEntity entity) {
		authTokenStore.put(token, entity);	
	}

	@Override
	public void deleteToken(String token) {
		authTokenStore.remove(token);		
	}
}
