package com.bajaj.bfsd.tms.repository;

import java.util.List;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.tms.entity.TokenEntity;

public abstract class UserTokenMappingStore extends BFLComponent implements TokenStoreService<String, List<TokenEntity>>{

	public UserTokenMappingStore(){
		//
	}
	
	public abstract void addToken(Long userId, TokenEntity entity);
	public abstract void updateToken(Long userId, TokenEntity entity);
	public abstract void removeParticularToken(Long userId, TokenEntity entity);
}
