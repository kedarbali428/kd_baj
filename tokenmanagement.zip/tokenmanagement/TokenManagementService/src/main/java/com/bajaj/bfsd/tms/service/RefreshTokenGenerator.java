package com.bajaj.bfsd.tms.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.tms.entity.TokenEntity;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
@RefreshScope
public class RefreshTokenGenerator extends TokenGeneratorImpl {

	private static final String THIS_CLASS = RefreshTokenGenerator.class.getCanonicalName();

	@Value("${tms.token.subjectRef}")
	private String subjectRefresh;

	@Value("${tms.reftoken.expirationperiod}")
	private String expirationPeriod;

	@Override
	public void generateToken(TokenEntity tokenEntity) {

		try {			
			super.generateToken(tokenEntity, subjectRefresh, expirationPeriod);
			logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "RefreshTokenGenerator: generateToken(): Refresh Tokens generated successfully");

		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "RefreshTokenGenerator :  generateToken(): Error occurred during Refresh Tokens generation", e);
			throw new BFLTechnicalException("TMS-002", env.getProperty("TMS-002"));
		}
	}

}
