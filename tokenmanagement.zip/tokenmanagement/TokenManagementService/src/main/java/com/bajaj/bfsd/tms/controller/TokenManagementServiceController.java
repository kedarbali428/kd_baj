/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.tms.controller;

import java.io.UnsupportedEncodingException;

import javax.enterprise.context.RequestScoped;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.tms.model.ExpireTokenResponse;
import com.bajaj.bfsd.tms.model.GenerateTokenRequest;
import com.bajaj.bfsd.tms.model.TokenEncryptionRequest;
import com.bajaj.bfsd.tms.model.TokenEncryptionResponse;
import com.bajaj.bfsd.tms.model.TokenResponse;
import com.bajaj.bfsd.tms.model.UserIdResponse;
import com.bajaj.bfsd.tms.model.ValidateRefreshTokenResponse;
import com.bajaj.bfsd.tms.model.ValidateTokenResponse;
import com.bajaj.bfsd.tms.service.TokenManagementService;
import com.bajaj.bfsd.tms.util.TMSConstants;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author 419488
 *
 */
@RestController
@RefreshScope
public class TokenManagementServiceController extends BFLController {

	@Autowired
	TokenManagementService tokenManagement;

	@RequestScoped
	@Autowired
	private BFLLoggerUtil logger;

	private static final String THIS_CLASS = TokenManagementServiceController.class.getCanonicalName();

	@ApiOperation(value = "Generates token based on platform", notes = "POST Generates toekn based on platform", httpMethod = "POST")
	@RequestMapping(value = "${api.tokenmanagement.generatetoken.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> generateTokens(@RequestBody GenerateTokenRequest generateTokenReq,
			@RequestHeader HttpHeaders headers) throws UnsupportedEncodingException {

		try {
			logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
			long startTime = System.currentTimeMillis();
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: generateTokens - start -" + startTime);
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"Started generateTokens with request - " + generateTokenReq);
			ResponseBean response;
			String platform = headers.getFirst(TMSConstants.HEADER_PLATFORM);
			String deviceId = "";
			TokenResponse tokenResponse = tokenManagement.generateToken(generateTokenReq, platform, deviceId);
			response = new ResponseBean(tokenResponse);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"method: generateTokens - end - " + (System.currentTimeMillis() - startTime));
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception exception) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Exception occurred while generating tokens ",
					exception);
			throw new BFLTechnicalException("TMS-009", exception);
		}
	}

	@ApiOperation(value = "validates token", notes = "GET validates token", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@RequestMapping(value = "${api.tokenmanagement.validatetoken.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> validateToken(@RequestHeader HttpHeaders headers) {

		try {
			logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
			long start = System.currentTimeMillis();
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: validateToken - start - " + start);

			ResponseBean response;
			HttpStatus httpStatus = HttpStatus.OK;
			String authToken = headers.getFirst(TMSConstants.AUTH_TOKEN);
			String guardToken = headers.getFirst(TMSConstants.GUARD_TOKEN);
			ValidateTokenResponse validateTokenresponse;

			if (null != authToken) {
				validateTokenresponse = tokenManagement.validateAuthToken(authToken, guardToken);
			} else {
				validateTokenresponse = new ValidateTokenResponse();
				httpStatus = HttpStatus.BAD_REQUEST;
			}

			response = new ResponseBean(validateTokenresponse);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"method: validateToken - end - response time " + (System.currentTimeMillis() - start));
			return new ResponseEntity<>(response, httpStatus);
		} catch (Exception exception) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Exception occurred while validating tokens ",
					exception);
			throw new BFLTechnicalException("TMS-010", exception);
		}
	}

	@ApiOperation(value = "expires token", notes = "DELETE expire token", httpMethod = "DELETE")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@RequestMapping(value = "${api.tokenmanagement.expiretoken.DELETE.uri}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> expireToken(@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: expireToken - start");
		ResponseBean response;
		String authToken = headers.getFirst(TMSConstants.AUTH_TOKEN);
		String guardToken = headers.getFirst(TMSConstants.GUARD_TOKEN);
		String refreshToken = headers.getFirst(TMSConstants.REF_TOKEN);
		short tokenType = -1;
		String token = "";
		if (authToken != null) {
			tokenType = TMSConstants.TOKENTYPE_AUTH;
			token = authToken;
		} else if (refreshToken != null) {
			tokenType = TMSConstants.TOKENTYPE_REFRESH;
			token = refreshToken;
		}
		ExpireTokenResponse expireTokenResponse;
		if (tokenType != -1) {
			expireTokenResponse = tokenManagement.expireToken(token, guardToken, tokenType);
		} else {
			expireTokenResponse = new ExpireTokenResponse();
			expireTokenResponse.setExpireTokenStatus(TMSConstants.FAILURE);
		}
		response = new ResponseBean(expireTokenResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: expireToken - end");
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@ApiOperation(value = "returns User Id based on Tokens", notes = "GET validates token", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@RequestMapping(value = "${api.tokenmanagement.getuser.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserIdFromToken(@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: returnUserId - start");
		ResponseBean response;
		String token = headers.getFirst(TMSConstants.TOKEN);
		UserIdResponse userIdResponse = tokenManagement.returnUserId(token);
		response = new ResponseBean(userIdResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: returnUserId - end");
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@ApiOperation(value = "expires token based on userId", notes = "DELETE expire token", httpMethod = "DELETE")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@RequestMapping(value = "${api.tokenmanagement.expireuser.DELETE.uri}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> expireTokenForUser(@PathVariable long userId,
			@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: expireUserToken - start");
		ResponseBean response;
		response = new ResponseBean(tokenManagement.expireUserToken(userId));
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: expireUserToken - end");
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@ApiOperation(value = "validates refresh token", notes = "GET validates token", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@RequestMapping(value = "${api.tokenmanagement.accesstoken.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> generateAuthTokenForRefreshToken(@RequestHeader HttpHeaders headers)
			throws UnsupportedEncodingException {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: validateRefreshToken - start");
		ResponseBean response;
		String token = headers.getFirst(TMSConstants.REF_TOKEN);
		String guardToken = headers.getFirst(TMSConstants.GUARD_TOKEN);
		ValidateRefreshTokenResponse validateRefreshTokenResponse = tokenManagement.getAuthTokenForRefreshToken(token,
				guardToken);
		response = new ResponseBean(validateRefreshTokenResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: validateRefreshToken - end");
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	/**
	 * ChatBot-209 changes start This end point is added to generate encrypted
	 * guardToken using guard key and both authtoken,guardtoken generated through
	 * this endpoint will be used by systempartner to make any subsequent calls to
	 * our api's/.
	 * 
	 * @param headers
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@ApiOperation(value = "encrypts the guard key", notes = "post  generates encryption for  guard key", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@RequestMapping(value = "${api.tokenmanagement.encrypttoken.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> generateEncryptedToken(@RequestHeader HttpHeaders headers,
			@Valid @RequestBody TokenEncryptionRequest request, BindingResult result)
			throws UnsupportedEncodingException {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: generateEncryptedToken - start");
		validateInput(result);
		ResponseBean response;
		String guardKey = request.getGuardKey();
		String authToken = request.getAuthToken();
		TokenEncryptionResponse tokenEncryptionResponse = tokenManagement.encryptGuardKey(guardKey, authToken);
		response = new ResponseBean(tokenEncryptionResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "method: generateEncryptedToken - end");
		return new ResponseEntity<>(response, HttpStatus.OK);

	}
	// ChatBot 209 changes end.

	private void validateInput(BindingResult result) {
		if (result.hasErrors()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"validateInput - Invalid request input - " + result);
			throw new BFLBusinessException(result.getFieldErrors());
		}
	}

	@ApiOperation(value = "validates authentication token", notes = "Validate Authentication Token", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Returns token validity with user info (User Id, Role, Login Id)", response = ValidateTokenResponse.class), })
	@PostMapping(value = "${api.tokenmanagement.authenticate.token.POST.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> validateAuthToken(@RequestHeader HttpHeaders headers) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER, "Inside validateAuthToken - start");
		String authToken = headers.getFirst(TMSConstants.AUTH_TOKEN);

		HttpStatus httpStatus = HttpStatus.OK;
		ValidateTokenResponse validateTokenresponse;

		if (null != authToken) {
			validateTokenresponse = tokenManagement.validateAuthToken(authToken);
		} else {
			validateTokenresponse = new ValidateTokenResponse();
			httpStatus = HttpStatus.BAD_REQUEST;
		}

		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER, "Inside validateAuthToken - end");
		return new ResponseEntity<>(validateTokenresponse, httpStatus);
	}

}
