package com.bajaj.bfsd.tms.repository;

public interface TokenStoreService<R, T> {
	
	public T fetchToken(R token);
	public void saveToken(R token, T entity);
	public void deleteToken(R token);
	public void deleteAllTokensForUser(long userId); // Remove tokens from both the hashmaps
}
