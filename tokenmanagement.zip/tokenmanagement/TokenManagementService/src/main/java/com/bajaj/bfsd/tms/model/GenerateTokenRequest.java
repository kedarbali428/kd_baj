package com.bajaj.bfsd.tms.model;

public class GenerateTokenRequest {
	
	private long userId;
	private String loginId;
	private short userType;
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public short getUserType() {
		return userType;
	}
	public void setUserType(short userType) {
		this.userType = userType;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GenerateTokenRequest [userId=" + userId + ", loginId=" + loginId + ", userType=" + userType + "]";
	}
	
	
	
	
}
