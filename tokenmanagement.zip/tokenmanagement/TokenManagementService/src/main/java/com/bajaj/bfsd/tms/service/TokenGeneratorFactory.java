package com.bajaj.bfsd.tms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.tms.util.TokenType;

@Component
public class TokenGeneratorFactory extends BFLComponent{

	@Autowired
	AuthTokenGenerator authTokenGenerator;
	
	@Autowired
	RefreshTokenGenerator refreshTokenGenerator;
	
	public TokenGeneratorImpl getTokenGenerator(TokenType tokenType){
		TokenGeneratorImpl tokenGenerator = authTokenGenerator;
		if(TokenType.REFRESH.equals(tokenType)){
			tokenGenerator = refreshTokenGenerator;
		}
		else if (TokenType.AUTHENTICATION.equals(tokenType)){	
			tokenGenerator = authTokenGenerator;
		}
		return tokenGenerator;
	}
}
