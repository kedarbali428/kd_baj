package com.bajaj.bfsd.tms.model;

public class ExpireTokenResponse {
	
	private String expireTokenStatus;
	
	public String getExpireTokenStatus() {
		return expireTokenStatus;
	}

	public void setExpireTokenStatus(String expireTokenStatus) {
		this.expireTokenStatus = expireTokenStatus;
	}
	
	@Override
	public String toString() {
		return "ExpireTokenResponse [expireTokenStatus=" + expireTokenStatus + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((expireTokenStatus == null) ? 0 : expireTokenStatus.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExpireTokenResponse other = (ExpireTokenResponse) obj;
		if (expireTokenStatus == null) {
			if (other.expireTokenStatus != null)
				return false;
		} else if (!expireTokenStatus.equals(other.expireTokenStatus))
			return false;
		return true;
	}


}
