package com.bajaj.bfsd.tms.repository;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;

@Component
public class LocalRefreshTokenStore extends RefreshTokenStore{

	private HashMap<String, RefreshTokenEntity> refreshTokenStore;
	
	@Autowired
	LocalAuthTokenStore authTokenStore;
	
	public LocalRefreshTokenStore()
	{
		refreshTokenStore = new HashMap<>();
	}
	@Override
	public void deleteAllTokensForUser(long userId) {
		// 	
	}

	@Override
	public RefreshTokenEntity fetchToken(String token) {
		
		return token==null? null: refreshTokenStore.get(token);
	}

	@Override
	public void saveToken(String token, RefreshTokenEntity entity) {
		refreshTokenStore.put(token, entity);	
	}

	@Override
	public void deleteToken(String token) {
		RefreshTokenEntity entity = fetchToken(token);
		if(null != entity){
			String authToken = entity.getAuthToken();
			authTokenStore.deleteToken(authToken);
			refreshTokenStore.remove(token);
		}
	}
}