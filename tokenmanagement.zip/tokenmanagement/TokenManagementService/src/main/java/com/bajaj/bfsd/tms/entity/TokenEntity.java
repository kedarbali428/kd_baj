package com.bajaj.bfsd.tms.entity;

import java.io.Serializable;

import com.bajaj.bfsd.tms.model.GenerateTokenRequest;

public abstract class TokenEntity implements Serializable {

	private static final long serialVersionUID = 301524936684932742L;
	
	protected long userId;
	protected String loginId;
	protected String token;
	protected short type;
	protected long createdOn;
	protected long toBeExpiredOn;
	protected long accessedOn;
	protected String salt;
	protected String guardKey;
	protected String platform;
	protected short userType;

	public TokenEntity(GenerateTokenRequest generateTokenReq, String platform, String salt) {

		userId = generateTokenReq.getUserId();
		loginId = generateTokenReq.getLoginId();
		this.salt = salt;
		userType = generateTokenReq.getUserType();
		this.platform = platform == null?"":platform;
	}

	/**
	 * @return the userId
	 */
	public long getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(long userId) {
		this.userId = userId;
	}

	/**
	 * @return the loginId
	 */
	public String getLoginId() {
		return loginId;
	}

	/**
	 * @param loginId the loginId to set
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * @return the type
	 */
	public short getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(short type) {
		this.type = type;
	}

	/**
	 * @return the createdOn
	 */
	public long getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(long createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the toBeExpiredOn
	 */
	public long getToBeExpiredOn() {
		return toBeExpiredOn;
	}

	/**
	 * @param toBeExpiredOn the toBeExpiredOn to set
	 */
	public void setToBeExpiredOn(long toBeExpiredOn) {
		this.toBeExpiredOn = toBeExpiredOn;
	}

	/**
	 * @return the accessedOn
	 */
	public long getAccessedOn() {
		return accessedOn;
	}

	/**
	 * @param accessedOn the accessedOn to set
	 */
	public void setAccessedOn(long accessedOn) {
		this.accessedOn = accessedOn;
	}

	/**
	 * @return the expired
	 */
	public boolean isExpired() {
		return System.currentTimeMillis() >= this.toBeExpiredOn;		
	}	

	/**
	 * @return the salt
	 */
	public String getSalt() {
		return salt;
	}

	/**
	 * @param salt the salt to set
	 */
	public void setSalt(String salt) {
		this.salt = salt;
	}

	/**
	 * @return the guardKey
	 */
	public String getGuardKey() {
		return guardKey;
	}

	/**
	 * @param guardKey the guardKey to set
	 */
	public void setGuardKey(String guardKey) {
		this.guardKey = guardKey;
	}

	/**
	 * @return the platform
	 */
	public String getPlatform() {
		return platform;
	}

	/**
	 * @param platform the platform to set
	 */
	public void setPlatform(String platform) {
		this.platform = platform;
	}

	/**
	 * @return the userType
	 */
	public short getUserType() {
		return userType;
	}

	/**
	 * @param userType the userType to set
	 */
	public void setUserType(short userType) {
		this.userType = userType;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((loginId == null) ? 0 : loginId.hashCode());
		result = prime * result + (int) (userId ^ (userId >>> 32));
		result = prime * result + userType;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TokenEntity other = (TokenEntity) obj;
		if (loginId == null) {
			if (other.loginId != null)
				return false;
		} else if (!loginId.equals(other.loginId))
			return false;
		if (userId != other.userId)
			return false;
		if (userType != other.userType)
			return false;
		if(type != other.getType())
			return false;
		if (platform == null && other.platform != null)
			return false;
		else if (platform == null || !platform.equalsIgnoreCase(other.getPlatform()))
			return false;
		
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TokenEntity [userId=" + userId + ", loginId=" + loginId + ", token=" + token + ", type=" + type
				+ ", createdOn=" + createdOn + ", toBeExpiredOn=" + toBeExpiredOn + ", accessedOn=" + accessedOn
				+ ", salt=" + salt + ", guardKey=" + guardKey + ", platform=" + platform
				+ ", userType=" + userType + "]";
	}	
	
	public void setExpirationWindow(long authTokenExpirationPeriod){
		this.setAccessedOn(System.currentTimeMillis());
		long expMillis = this.getAccessedOn() + authTokenExpirationPeriod;
		this.setToBeExpiredOn(expMillis);
	}
	
	public abstract boolean isAuthToken();
	
	public abstract boolean isRefreshToken();
	
	public abstract boolean isGaurdToken();
}
