package com.bajaj.bfsd.tms.entity;

import java.io.Serializable;

import com.bajaj.bfsd.tms.model.GenerateTokenRequest;
import com.bajaj.bfsd.tms.util.TMSConstants;

public class AuthTokenEntity extends TokenEntity implements Serializable {//NOSONAR

	private static final long serialVersionUID = -3102714996647035916L;
	private String browserId;

	public AuthTokenEntity(GenerateTokenRequest generateTokenReq,String platform, String browserid, String salt) {
		super(generateTokenReq, platform, salt);
		type = TMSConstants.TOKENTYPE_AUTH;
		//Ideally this should be part of the request even though coming in header.
		//this.platform = platform
		browserId = browserid;
	}

	public String getBrowserId() {
		return browserId;
	}

	public void setBrowserId(String browserId) {
		this.browserId = browserId;
	}

	@Override
	public boolean isAuthToken() {
		return true;
	}

	@Override
	public boolean isRefreshToken() {		 
		return false;
	}

	@Override
	public boolean isGaurdToken() {
		return false;
	}

	@Override
	public String toString() {
		return "AuthTokenEntity [browserId=" + browserId + ", userId=" + userId + ", loginId=" + loginId + ", token="
				+ token + ", type=" + type + ", createdOn=" + createdOn + ", toBeExpiredOn=" + toBeExpiredOn
				+ ", accessedOn=" + accessedOn + ", salt=" + salt + ", guardKey=" + guardKey + ", platform=" + platform
				+ ", userType=" + userType + "]";
	}
	
}
