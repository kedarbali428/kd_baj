package com.bajaj.bfsd.tms.service;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.tms.entity.TokenEntity;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
@RefreshScope
public class AuthTokenGenerator extends TokenGeneratorImpl {

	private static final String THIS_CLASS = AuthTokenGenerator.class.getCanonicalName();
	
	@Value("${tms.token.subjectAuth}")
	private String subjectAuth;

	@Value("${tms.authtoken.expirationperiod}")
	private String expirationPeriod;

	@Override
	public void generateToken(TokenEntity tokenEntity) {

		try {

			logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "AuthToken: generateToken(): Auth Tokens and Guard Tokens generated successfully");
			super.generateToken(tokenEntity, subjectAuth, expirationPeriod);

		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "AuthToken :  generateAuthToken(): Error occurred during Auth Tokens generation", e);
			throw new BFLTechnicalException("TMS-001", env.getProperty("TMS-001"));
		}
	}

}
