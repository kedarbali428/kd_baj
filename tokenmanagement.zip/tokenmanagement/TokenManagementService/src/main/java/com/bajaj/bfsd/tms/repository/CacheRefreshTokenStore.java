package com.bajaj.bfsd.tms.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;

@Component
public class CacheRefreshTokenStore extends RefreshTokenStore{

	private SingleObjectCacheRepositoryImpl<String, RefreshTokenEntity> cacheRepository;
	
	@Autowired
	CacheAuthTokenStore authTokenStore;
	
	@Autowired
	protected Environment env;
		
	@Autowired
	protected RedisConfig redisConfig;
	
	public CacheRefreshTokenStore()
	{
		//
	}
	@Override
	public void deleteAllTokensForUser(long userId) {
		//
	}

	@Override
	public RefreshTokenEntity fetchToken(String token) {
		
		return token==null? null: getCacheRepository().find(token);
	}

	@Override
	public void saveToken(String token, RefreshTokenEntity entity) {
		getCacheRepository().save(token, entity);	
	}

	@Override
	public void deleteToken(String token) {
		RefreshTokenEntity entity = fetchToken(token);
		if(null != entity){
			String authToken = entity.getAuthToken();
			authTokenStore.deleteToken(authToken);
			getCacheRepository().delete(token);
		}
	}
	
	private SingleObjectCacheRepositoryImpl<String, RefreshTokenEntity> getCacheRepository()
	{
		if(null == this.cacheRepository){
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(RefreshTokenEntity.class, env, redisConfig);
		}
		
		return cacheRepository;
	}
}