package com.bajaj.bfsd.tms.model;

import java.io.Serializable;

public class ValidateTokenResponse implements Serializable {

	private static final long serialVersionUID = 5100042237267783818L;
	
	private String tokenStatus;
	private Long userId;
	private String defaultRole;
	private String loginId;

	


	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getTokenStatus() {
		return tokenStatus;
	}

	public void setTokenStatus(String tokenStatus) {
		this.tokenStatus = tokenStatus;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((tokenStatus == null) ? 0 : tokenStatus.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((defaultRole == null) ? 0 : defaultRole.hashCode());
		result = prime * result + ((loginId == null) ? 0 : loginId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ValidateTokenResponse other = (ValidateTokenResponse) obj;
	
		if (tokenStatus == null) {
			if (other.tokenStatus != null)
				return false;
		} else if (!tokenStatus.equals(other.tokenStatus))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		if (defaultRole == null) {
			if (other.defaultRole != null)
				return false;
		} else if (!defaultRole.equals(other.defaultRole))
			return false;
		if (loginId == null) {
			if (other.loginId != null)
				return false;
		} else if (!loginId.equals(other.loginId))
			return false;
		return true;
	} 
	
	public String getDefaultRole() {
		return defaultRole;
	}

	public void setDefaultRole(String defaultRole) {
		this.defaultRole = defaultRole;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

}
