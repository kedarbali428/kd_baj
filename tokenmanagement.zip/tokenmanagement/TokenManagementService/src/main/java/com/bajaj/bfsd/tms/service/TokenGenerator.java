package com.bajaj.bfsd.tms.service;

import com.bajaj.bfsd.tms.entity.TokenEntity;

public interface TokenGenerator {

	public void generateToken(TokenEntity tokenEntity, String subject, String expirationPeriod);
	public void generateToken(TokenEntity tokenEntity);

}
