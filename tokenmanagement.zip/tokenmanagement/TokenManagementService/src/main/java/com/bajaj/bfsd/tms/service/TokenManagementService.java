package com.bajaj.bfsd.tms.service;

import java.io.UnsupportedEncodingException;

import com.bajaj.bfsd.tms.entity.TokenEntity;
import com.bajaj.bfsd.tms.model.ExpireTokenResponse;
import com.bajaj.bfsd.tms.model.GenerateTokenRequest;
import com.bajaj.bfsd.tms.model.TokenEncryptionResponse;
import com.bajaj.bfsd.tms.model.TokenResponse;
import com.bajaj.bfsd.tms.model.UserIdResponse;
import com.bajaj.bfsd.tms.model.ValidateRefreshTokenResponse;
import com.bajaj.bfsd.tms.model.ValidateTokenResponse;

public interface TokenManagementService {

	public TokenResponse generateToken(GenerateTokenRequest generateTokenReq, String platform, String deviceId)
			throws UnsupportedEncodingException;

	public ValidateTokenResponse validateAuthToken(String authToken, String guardToken);

	public UserIdResponse returnUserId(String token);

	public ExpireTokenResponse expireUserToken(long userId);

	public ValidateRefreshTokenResponse getAuthTokenForRefreshToken(String refreshToken, String guardToken)
			throws UnsupportedEncodingException;

	public void saveToken(TokenEntity tokenEntity);

	public ExpireTokenResponse expireToken(String token, String guardToken, short tokenType);

	public TokenEncryptionResponse encryptGuardKey(String guardKey, String authToken);

	public ValidateTokenResponse validateAuthToken(String authToken);
}
