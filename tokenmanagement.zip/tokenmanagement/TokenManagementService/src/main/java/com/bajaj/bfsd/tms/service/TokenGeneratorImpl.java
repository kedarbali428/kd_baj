package com.bajaj.bfsd.tms.service;

import java.security.Key;
import java.util.Date;

import javax.crypto.spec.SecretKeySpec;
import javax.enterprise.context.RequestScoped;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLService;
import com.bajaj.bfsd.tms.entity.TokenEntity;
import com.bajaj.bfsd.tms.util.TMSConstants;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
@RefreshScope
public abstract class TokenGeneratorImpl extends BFLService implements TokenGenerator{
	
	private static final String THIS_CLASS = TokenGeneratorImpl.class.getCanonicalName();

	@Value("${tms.token.secret}")
	private String secret;

	@Value("${tms.token.issuer}")
	private String issuer;

	@Value("${tms.token.type}")
	private String type;
	
	@RequestScoped
	@Autowired
	protected BFLLoggerUtil logger;
	
	@Autowired
    protected Environment env;
	
	@Override
	public void generateToken(TokenEntity tokenEntity, String subject, String expirationPeriod) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "generateToken - for token entity" + tokenEntity.toString());
		SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

		long currentMillis = System.currentTimeMillis();
		Date currentDate = new Date(currentMillis);

		// We will sign our JWT with our ApiKey secret
		byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secret);
		Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

		Long expMillis = currentMillis + Long.valueOf(expirationPeriod.trim());
		Date exp = new Date(expMillis);
		
		//TODO Check if date can be set as long instead of date object
		// Let's set the JWT Claims
		JwtBuilder builder = Jwts.builder().setIssuer(issuer).setExpiration(exp).setIssuedAt(currentDate)
				.setSubject(subject).claim(TMSConstants.JWT_FIELD_LOGIN,tokenEntity.getLoginId()).claim(TMSConstants.JWT_FIELD_USERTYPE, tokenEntity.getUserType())
				.signWith(signatureAlgorithm, signingKey);

		tokenEntity.setToken(builder.compact());
		
		//TODO check why salt has not been used here?
		tokenEntity.setGuardKey(RandomStringUtils.randomAlphanumeric(12));
		tokenEntity.setCreatedOn(currentMillis);
		tokenEntity.setToBeExpiredOn(expMillis);
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "generateToken - Tokens generated" + tokenEntity.getToken());
	}
}
