package com.bajaj.bfsd.tms.model;

import java.io.Serializable;

public class UserIdResponse implements Serializable{
	
	private static final long serialVersionUID = 6430607407100605013L;
	
	private Long userid;

	public Long getUserid() {
		return userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}

}
