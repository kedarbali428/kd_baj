/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.tms;

import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

import com.bajaj.bfsd.common.business.baseclasses.BFLBusinessApplication;


/**
 * This is the main class for Tokens Management Service
 * 
 * @author 419488
* Version      BugId           UsrId           Date            Description
 * 1.0                         419488       	21/02/2017      Initial Version
 */
@PropertySources(value = {@PropertySource("classpath:tokenManagement.properties"),
        @PropertySource("classpath:error.properties"),
        @PropertySource("classpath:application.properties")})
public class TokenManagementServiceApplication extends BFLBusinessApplication{

	public static void main(String[] args) {
		   SpringApplication.run(TokenManagementServiceApplication.class, args);
	}

}
