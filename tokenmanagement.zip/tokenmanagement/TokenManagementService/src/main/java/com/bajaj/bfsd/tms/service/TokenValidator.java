package com.bajaj.bfsd.tms.service;

import static com.bajaj.bfsd.tms.util.TMSConstants.USERTYPE_B2B_PARTNER;
import static com.bajaj.bfsd.tms.util.TMSConstants.USERTYPE_SYSTEM_PARTNER;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

import javax.enterprise.context.RequestScoped;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;
import com.bajaj.bfsd.tms.model.ValidateTokenResponse;
import com.bajaj.bfsd.tms.repository.AuthTokenStore;
import com.bajaj.bfsd.tms.repository.EntityStoreFactory;
import com.bajaj.bfsd.tms.repository.RefreshTokenStore;
import com.bajaj.bfsd.tms.repository.UserTokenMappingStore;
import com.bajaj.bfsd.tms.util.TMSConstants;

@Component
@RefreshScope
public class TokenValidator extends BFLComponent {

	private static final String THIS_CLASS = TokenValidator.class.getCanonicalName();

	@RequestScoped
	@Autowired
	protected BFLLoggerUtil logger;

	@Autowired
	private EntityStoreFactory entityStoreFactory;

	@Value("${tms.authtoken.expirationperiod}")
	private long authTokenExpirationPeriod;

	@Value("${tms.reftoken.expirationperiod}")
	private long refTokenExpirationPeriod;

	@Value("${tms.guardtoken.generation.threshold}")
	private long guardTokenThreshold;

	public ValidateTokenResponse validateAuthToken(String authTokenValue, String guardToken) {
		long start = System.currentTimeMillis();
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateAuthToken - before fetch token start - " + start);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateAuthToken - authTokenValue - " + authTokenValue);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateAuthToken - guardTokenValue - " + guardToken);
		
		ValidateTokenResponse tokenResponse = new ValidateTokenResponse();

		AuthTokenStore authTokenStore = entityStoreFactory.getAuthTokenStore();
		UserTokenMappingStore userTokenMappingStore = entityStoreFactory.getUserTokenMappingStore();

		AuthTokenEntity entity = authTokenStore.fetchToken(authTokenValue);

		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateAuthToken - after fetch token end - response time - " 
				+ (System.currentTimeMillis() - start));
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateAuthToken - entity after fetch token call - " + entity);

		if (null == entity) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateAuthToken - Tokens is not present: " + authTokenValue);
			tokenResponse.setTokenStatus(TMSConstants.EXPIRED_TOKEN);
		} else if (entity.isExpired()){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateAuthToken - Tokens is expired: " + authTokenValue);
			tokenResponse.setTokenStatus(TMSConstants.EXPIRED_TOKEN);
			userTokenMappingStore.removeParticularToken(entity.getUserId(), entity);
		} else {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateAuthToken - Tokens is present & valid. - " + authTokenValue);

			tokenResponse.setTokenStatus(TMSConstants.VALID_TOKEN);
			tokenResponse.setUserId(entity.getUserId());
			tokenResponse.setDefaultRole(getDefaultRole(entity.getUserType()));
			tokenResponse.setLoginId(entity.getLoginId());
			
			if (entity.getUserType() == USERTYPE_B2B_PARTNER || entity.getUserType() == USERTYPE_SYSTEM_PARTNER) {
				return tokenResponse;
			} else if (TMSConstants.USERTYPE_SYSTEM == entity.getUserType()) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"skipping guard token validation for system token" + entity.getToken());
				entity.setExpirationWindow(authTokenExpirationPeriod);
				userTokenMappingStore.updateToken(entity.getUserId(), entity);
				return tokenResponse;
			} else {
				entity.setExpirationWindow(authTokenExpirationPeriod);
				authTokenStore.saveToken(authTokenValue, entity);
				
				return tokenResponse;
			}

//			String guardKey = entity.getGuardKey();
//			if (validateGuardToken(guardToken, guardKey, entity.getSalt())) {// validateTokenAgainstAuthEntity(entity,
//																				// authTokenValue) &&
//				// if both are valid reset the token into entity.
//				entity.setExpirationWindow(authTokenExpirationPeriod);
//				userTokenMappingStore.updateToken(entity.getUserId(), entity);
//				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateGuardToken - validation success.");
//			} else {
//				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateGuardToken - validation failure.");
//				tokenResponse.setTokenStatus(TMSConstants.INVALID_TOKEN);
//				tokenResponse.setUserId((long) 0);
//				tokenResponse.setDefaultRole(null);
//				userTokenMappingStore.removeParticularToken(entity.getUserId(), entity);
//			}
		}
		return tokenResponse;
	}

	// private boolean validateTokenAgainstAuthEntity(TokenEntity entity, String
	// authTokenValue)
	// boolean retVal = true
	// Will this really add any value?? Hacker might simply reuse the same token,
	// even decoding generate the same output
	// return true
	//

	private boolean validateGuardToken(String guardToken, String guardKey, String salt) {

		String decodedGuardToken = null;
		boolean retVal = false;
		if (null == guardToken || guardToken.isEmpty())
			return retVal;

		try {
			decodedGuardToken = new String(Base64.getDecoder().decode(guardToken), "utf-8");
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateGuardToken - Decoded guard token. - " + decodedGuardToken);
		} catch (UnsupportedEncodingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateGuardToken - Unable to decode guardtoken" + guardToken + "	- ex" + e);
		}

		if (null != decodedGuardToken && decodedGuardToken.contains(TMSConstants.PIPE)) {
			// B!&1j|1492852180461|SVlrA1yOkECi
			String[] guardTokenContents = decodedGuardToken.split(TMSConstants.SPILT_PIPE);
			if (guardTokenContents.length == 3) {
				long guardTokenGenerationTime = 0L;
				try {
					guardTokenGenerationTime = Long.parseLong(guardTokenContents[1]);
				} catch (Exception ex) {
					// time is not valid
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
							"validateGuardToken - Guard token genetaion time is not valid. - " + guardTokenContents[1]
									+ "	- exception " + ex);
				}
				if (salt.equalsIgnoreCase(guardTokenContents[0])
						&& ((guardTokenGenerationTime + guardTokenThreshold) > System.currentTimeMillis())
						&& guardKey.equalsIgnoreCase(guardTokenContents[2])) {
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateGuardToken - guard token is valid.");
					retVal = true;
				}
			} else {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "decrypted token lenght not 3!!");
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "decoded guard token is null or corrupted token");
		}
		if (!retVal)
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateGuardToken - Invalid guard token. - " + guardToken);

		return retVal;
	}

	private boolean validateRefreshGuardToken(String guardToken, String guardKey, String salt) {

		String decodedGuardToken = null;
		boolean retVal = false;
		try {
			decodedGuardToken = new String(Base64.getDecoder().decode(guardToken), "utf-8");
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateRefreshGuardToken - Decoded guard token. - " + decodedGuardToken);
		} catch (UnsupportedEncodingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateRefreshGuardToken - Unable to decode refreshguardtoken" + guardToken + "	- exception "
							+ e);
		}

		if (null != decodedGuardToken && decodedGuardToken.contains(TMSConstants.PIPE)) {
			// B!&1j|1492852180461|SVlrA1yOkECi

			String[] guardTokenContents = decodedGuardToken.split(TMSConstants.SPILT_PIPE);
			if (guardTokenContents.length == 3 && salt.equalsIgnoreCase(guardTokenContents[0])
					&& guardKey.equalsIgnoreCase(guardTokenContents[2])) {

				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"validateRefreshGuardToken - guard token is valid.");
				retVal = true;

			}

		}
		if (!retVal)
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateRefreshGuardToken - Invalid guard token. - " + guardToken);

		return retVal;
	}

	public ValidateTokenResponse validateRefreshToken(String refTokenValue, String guardToken) {
		ValidateTokenResponse tokenResponse = new ValidateTokenResponse();

		RefreshTokenStore refreshTokenStore = entityStoreFactory.getRefreshTokenStore();
		UserTokenMappingStore userTokenMappingStore = entityStoreFactory.getUserTokenMappingStore();

		RefreshTokenEntity entity = refreshTokenStore.fetchToken(refTokenValue);
		if (null == entity || entity.isExpired()) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateRefreshToken - Tokens is expired or not present. - " + refTokenValue);
			// Expire Tokens
			tokenResponse.setTokenStatus(TMSConstants.EXPIRED_TOKEN);
			if (null != entity)
				userTokenMappingStore.removeParticularToken(entity.getUserId(), entity);
		} else {
			// Validate guard token
			String guardKey = entity.getGuardKey();
			if (validateRefreshGuardToken(guardToken, guardKey, entity.getSalt())) {// validateTokenAgainstAuthEntity(entity,
																					// refTokenValue) &&
				// if both are valid reset the token into entity.
				entity.setAccessedOn(System.currentTimeMillis());
				long expMillis = entity.getAccessedOn() + refTokenExpirationPeriod;
				entity.setToBeExpiredOn(expMillis);
				userTokenMappingStore.updateToken(entity.getUserId(), entity);

				tokenResponse.setTokenStatus(TMSConstants.VALID_TOKEN);
				tokenResponse.setUserId(entity.getUserId());
				tokenResponse.setDefaultRole(getDefaultRole(entity.getUserType()));
			} else {
				tokenResponse.setTokenStatus(TMSConstants.INVALID_TOKEN);
				userTokenMappingStore.removeParticularToken(entity.getUserId(), entity);
			}
		}
		return tokenResponse;

	}

	String getDefaultRole(short userType) {
		String defaultRole;
		switch (userType) {
		case TMSConstants.USERTYPE_EMPLOYEE:
			defaultRole = TMSConstants.DEFAULTROLE_EMPLOYEE;
			break;
		case TMSConstants.USERTYPE_CUSTOMER:
			defaultRole = TMSConstants.DEFAULTROLE_CUSTOMER;
			break;
		case TMSConstants.USERTYPE_B2B_PARTNER:
			defaultRole = TMSConstants.DEFAULTROLE_B2B_PARTNER;
			break;
		case TMSConstants.USERTYPE_VENDOR_PARTNER:
			defaultRole = TMSConstants.DEFAULTROLE_EMPLOYEE; // This is done because employee and vendor is same as
																// bajaj wants to do that.
			break;
		case TMSConstants.USERTYPE_SYSTEM:
			defaultRole = TMSConstants.DEFAULTROLE_SYSTEM;
			break;
		case TMSConstants.USERTYPE_SYSTEM_PARTNER:
			defaultRole = TMSConstants.DEFAULTROLE_SYSTEM_PARTNER;
			break;
		case TMSConstants.USERTYPE_PSEUDO_CUSTOMER:
			defaultRole = TMSConstants.DEFAULTROLE_PSEUDO_CUSTOMER;
			break;
		case TMSConstants.USERTYPE_PSEUDO_VERIFIED_CUSTOMER:
			defaultRole = TMSConstants.DEFAULTROLE_PSEUDO_VERIFIED_CUSTOMER;
			break;
        case TMSConstants.USERTYPE_PRINCIPAL:
			defaultRole = TMSConstants.DEFAULTROLE_EMPLOYEE;
			break;
        case TMSConstants.USERTYPE_INTERNAL:
			defaultRole = TMSConstants.DEFAULTROLE_INTERNAL;
			break;
		default:
			defaultRole = TMSConstants.DEFAULTROLE_CUSTOMER;
		}
		return defaultRole;
	}

	public ValidateTokenResponse validateAuthToken(String authToken) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
				"Inside validateAuthToken - start: authtoken: " + authToken);
		ValidateTokenResponse tokenResponse = new ValidateTokenResponse();

		AuthTokenStore authTokenStore = entityStoreFactory.getAuthTokenStore();
		UserTokenMappingStore userTokenMappingStore = entityStoreFactory.getUserTokenMappingStore();

		AuthTokenEntity entity = authTokenStore.fetchToken(authToken);

		if (null == entity || entity.isExpired()) {

			tokenResponse.setTokenStatus(TMSConstants.EXPIRED_TOKEN);
			if (null != entity) {
				userTokenMappingStore.removeParticularToken(entity.getUserId(), entity);
			}

		} else {

			entity.setExpirationWindow(authTokenExpirationPeriod);
			authTokenStore.saveToken(authToken, entity);

			tokenResponse.setTokenStatus(TMSConstants.VALID_TOKEN);
			tokenResponse.setUserId(entity.getUserId());
			tokenResponse.setDefaultRole(getDefaultRole(entity.getUserType()));
			tokenResponse.setLoginId(entity.getLoginId());

		}

		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE, "Inside validateAuthToken - end");
		return tokenResponse;
	}
}
