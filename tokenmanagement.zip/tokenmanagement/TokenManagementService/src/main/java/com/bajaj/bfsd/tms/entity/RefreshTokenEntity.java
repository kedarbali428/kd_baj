package com.bajaj.bfsd.tms.entity;

import java.io.Serializable;

import com.bajaj.bfsd.tms.model.GenerateTokenRequest;
import com.bajaj.bfsd.tms.util.TMSConstants;

public class RefreshTokenEntity extends TokenEntity implements Serializable{////NOSONAR

	private static final long serialVersionUID = 6982528239010636956L;

	protected String deviceId;
	protected String authToken;

	public RefreshTokenEntity(GenerateTokenRequest generateTokenReq, String deviceid,String salt) {
		super(generateTokenReq, TMSConstants.PLATFORM_MOBILE, salt);
		type = TMSConstants.TOKENTYPE_REFRESH;
		deviceId = deviceid;
	}

	public String getAuthToken(){
		return authToken;
	}
	
	public void setAuthToken(String authToken){
		this.authToken = authToken;
	}
	
	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	@Override
	public String toString() {
		return "RefreshTokenEntity [deviceId=" + deviceId + "]";
	}

	@Override
	public boolean isAuthToken() {
		return false;
	}

	@Override
	public boolean isRefreshToken() {
		return true;
	}

	@Override
	public boolean isGaurdToken() {		
		return false;
	}

}
