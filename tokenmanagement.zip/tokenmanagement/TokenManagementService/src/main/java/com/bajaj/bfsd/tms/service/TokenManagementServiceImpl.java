/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.tms.service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.List;

import javax.enterprise.context.RequestScoped;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;
import com.bajaj.bfsd.tms.entity.TokenEntity;
import com.bajaj.bfsd.tms.model.ExpireTokenResponse;
import com.bajaj.bfsd.tms.model.GenerateTokenRequest;
import com.bajaj.bfsd.tms.model.TokenEncryptionResponse;
import com.bajaj.bfsd.tms.model.TokenResponse;
import com.bajaj.bfsd.tms.model.Tokens;
import com.bajaj.bfsd.tms.model.UserIdResponse;
import com.bajaj.bfsd.tms.model.ValidateRefreshTokenResponse;
import com.bajaj.bfsd.tms.model.ValidateTokenResponse;
import com.bajaj.bfsd.tms.repository.AuthTokenStore;
import com.bajaj.bfsd.tms.repository.EntityStoreFactory;
import com.bajaj.bfsd.tms.repository.RefreshTokenStore;
import com.bajaj.bfsd.tms.repository.UserTokenMappingStore;
import com.bajaj.bfsd.tms.util.TMSConstants;
import com.bajaj.bfsd.tms.util.TokenType;

@Component
public class TokenManagementServiceImpl extends BFLComponent implements TokenManagementService {

	private static final String THIS_CLASS = TokenManagementServiceImpl.class.getName();

	@Autowired
	private TokenGeneratorFactory tokenFactory;
	
	@Autowired
	private EntityStoreFactory entityStoreFactory;
	
	@Value("${tms.token.salt}")
	private String salt;
	
	@Value("${tms.authtoken.expirationperiod}")
	private long authTokenExpirationPeriod;
	
	@Value("${tms.reftoken.expirationperiod}")
	private long refTokenExpirationPeriod;

	@RequestScoped
	@Autowired
	private BFLLoggerUtil logger;
	
	@Autowired
	TokenValidator tokenValidator;
	
	@Autowired
	UserCacheService cacheService;
	
//	@Value("${save.token.retry}")
//	private int savetokenretry;

	private AuthTokenEntity generateAuthToken(GenerateTokenRequest generateTokenReq, String platform, String deviceId) throws UnsupportedEncodingException{
		String loginId = generateTokenReq.getUserType() == 99 ? null :URLDecoder.decode(generateTokenReq.getLoginId(), "utf-8");
		generateTokenReq.setLoginId(loginId);
		
		AuthTokenEntity authTokenEntity = new AuthTokenEntity(generateTokenReq, platform, deviceId, salt);
		long startTime = System.currentTimeMillis();
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateAuthToken - before fetchExistingToken start - "+startTime);
		//AuthTokenEntity existingAuthTokenEntity = generateTokenReq.getUserType() == 99 ?null : (AuthTokenEntity) this.fetchExistingToken(authTokenEntity);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateAuthToken - after fetchExistingToken end response time - "+(System.currentTimeMillis()-startTime));
		
//		if(existingAuthTokenEntity != null){
//			authTokenEntity = existingAuthTokenEntity;
//			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "generateAuthToken - authTokenEntity - "+authTokenEntity);
//			updateToken(authTokenEntity);			
//		}
//		else{
			TokenGeneratorImpl authTokenGenerator = tokenFactory.getTokenGenerator(TokenType.AUTHENTICATION);
			authTokenGenerator.generateToken(authTokenEntity);
			startTime = System.currentTimeMillis();
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateAuthToken - before save token start - "+startTime);
			saveToken(authTokenEntity);	
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateAuthToken - after save token end response time - "+(System.currentTimeMillis()-startTime));
//		}		
		
		return authTokenEntity;
	}
	
	@Override
	public TokenResponse generateToken(GenerateTokenRequest generateTokenReq, String platform, String deviceId) throws UnsupportedEncodingException {
		long start = System.currentTimeMillis();
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateToken - start - "+start);
		
		List<Tokens> tokens = new ArrayList<>();
		TokenResponse tokenResponse = new TokenResponse();
		long startTime = System.currentTimeMillis();
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateToken - before generate token start - "+startTime);
		AuthTokenEntity authTokenEntity =generateAuthToken(generateTokenReq, platform, deviceId);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateToken - after generate token end response time - "+(System.currentTimeMillis()-startTime));
		
		Tokens token = new Tokens();
		token.setToken(authTokenEntity.getToken());
		token.setGuardKey(authTokenEntity.getGuardKey());
		token.setType(TMSConstants.AUTH_TOKEN);
				
		tokens.add(token);
		
		if (null!= platform && platform.equalsIgnoreCase(TMSConstants.PLATFORM_MOBILE)) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateToken - generating refresh token");
			RefreshTokenEntity refreshTokenEntity = generateRereshToken(generateTokenReq, deviceId, authTokenEntity);	
						
			token = new Tokens();
			token.setToken(refreshTokenEntity.getToken());
			token.setGuardKey(refreshTokenEntity.getGuardKey());
			token.setType(TMSConstants.REF_TOKEN);
			
			tokens.add(token);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateToken - refresh token generated");
		}
		tokenResponse.setTokens(tokens);
		tokenResponse.setUserKey(generateTokenReq.getUserId());
		tokenResponse.setDefaultRole(tokenValidator.getDefaultRole(generateTokenReq.getUserType()));
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateToken - end - "+(System.currentTimeMillis()-start));
		return tokenResponse;
	}
	
	private RefreshTokenEntity generateRereshToken(GenerateTokenRequest generateTokenReq, String deviceId, AuthTokenEntity authTokenEntity) throws UnsupportedEncodingException{
		String loginId = URLDecoder.decode(generateTokenReq.getLoginId(), "utf-8"); 
		generateTokenReq.setLoginId(loginId);
		
		RefreshTokenEntity refreshTokenEntity = new RefreshTokenEntity(generateTokenReq, deviceId, salt);
		refreshTokenEntity.setAuthToken(authTokenEntity.getToken());
		long startTime = System.currentTimeMillis();
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateRereshToken - before fetchExistingToken start - "+startTime);
		//RefreshTokenEntity existingRefereshTokenEntity = (RefreshTokenEntity) this.fetchExistingToken(refreshTokenEntity);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateRereshToken - after fetchExistingToken end response time - "+(System.currentTimeMillis()-startTime));
		
//		if(existingRefereshTokenEntity != null){
//			refreshTokenEntity = existingRefereshTokenEntity;
//			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "generateRereshToken - refreshTokenEntity - "+refreshTokenEntity);
//			updateToken(refreshTokenEntity);			
//		}
//		else{
			TokenGeneratorImpl refreshTokenGenerator = tokenFactory.getTokenGenerator(TokenType.REFRESH);
			refreshTokenGenerator.generateToken(refreshTokenEntity);
			startTime = System.currentTimeMillis();
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateRereshToken - before save token start - "+startTime);
			saveToken(refreshTokenEntity);	
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: generateRereshToken - after save token end response time - "+(System.currentTimeMillis()-startTime));
//		}		
		
		return refreshTokenEntity;
	}
	
	@Override
	public ValidateTokenResponse validateAuthToken(String authToken, String guardToken) {

		return tokenValidator.validateAuthToken(authToken, guardToken);
	}

	@Override
	public ValidateRefreshTokenResponse getAuthTokenForRefreshToken(String refreshToken, String guardToken) throws UnsupportedEncodingException {

		ValidateTokenResponse tokenResponse = tokenValidator.validateRefreshToken(refreshToken, guardToken);
		ValidateRefreshTokenResponse refreshTokenResponse = new ValidateRefreshTokenResponse();
		
		if (TMSConstants.VALID_TOKEN.equalsIgnoreCase(tokenResponse.getTokenStatus())) {
			// Validate Auth Tokens
			RefreshTokenStore refTokenStore = entityStoreFactory.getRefreshTokenStore();
			AuthTokenStore authTokenStore = entityStoreFactory.getAuthTokenStore();
			UserTokenMappingStore userTokenMappingStore = entityStoreFactory.getUserTokenMappingStore();
			
			RefreshTokenEntity refEntity = refTokenStore.fetchToken(refreshToken);
			if(null != refEntity){
				AuthTokenEntity authEntity = authTokenStore.fetchToken(refEntity.getAuthToken());
				if(null != authEntity)
					userTokenMappingStore.removeParticularToken(authEntity.getUserId(), authEntity);
				
				/*
				 * BFSDMOB-1084 : Always generate new token and return that. Previously in the first attempt, we were returning old authtoken 
				 * after removing it from authEntity instead of generating a new token.
				 */
				GenerateTokenRequest request = new GenerateTokenRequest();
				request.setUserId(refEntity.getUserId());
				request.setLoginId(refEntity.getLoginId());
				request.setUserType(refEntity.getUserType());
					
				authEntity = generateAuthToken(request, refEntity.getPlatform(), refEntity.getDeviceId());
		
				refreshTokenResponse.setToken(authEntity.getToken());
				refreshTokenResponse.setGuardToken(authEntity.getGuardKey());
				refreshTokenResponse.setStatus(TMSConstants.VALID_TOKEN);
			}
			else
			{
				refreshTokenResponse.setStatus(TMSConstants.EXPIRED_TOKEN);
			}
		}
		return refreshTokenResponse;
	}

	@Override
	public ExpireTokenResponse expireToken(String token, String guardToken, short tokenType) {

		ExpireTokenResponse expireTokenResponse = new ExpireTokenResponse();
		UserTokenMappingStore userTokenMappingStore = entityStoreFactory.getUserTokenMappingStore();
		TokenEntity entity = null;
		Long userId;
		if(tokenType == TMSConstants.TOKENTYPE_AUTH){
			AuthTokenStore tokenStore = entityStoreFactory.getAuthTokenStore();
			entity = tokenStore.fetchToken(token);			
		}
		else if(tokenType == TMSConstants.TOKENTYPE_REFRESH)
		{
			RefreshTokenStore tokenStore = entityStoreFactory.getRefreshTokenStore();
			entity = tokenStore.fetchToken(token);
		}
		if(null != entity){
			userId = entity.getUserId();
			userTokenMappingStore.removeParticularToken(userId, entity);
			cacheService.delete(userId);

			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: expireToken - for -"+userId);
		}
		expireTokenResponse.setExpireTokenStatus(TMSConstants.SUCCESS);
		return expireTokenResponse;
	}	

	@Override
	public UserIdResponse returnUserId(String token) {
		UserIdResponse userResponse = new UserIdResponse();
		TokenEntity entity;
		if(null != token){
			AuthTokenStore authTokenStore = entityStoreFactory.getAuthTokenStore();
			entity = authTokenStore.fetchToken(token);
			if(null == entity){
				RefreshTokenStore refreshTokenStore = entityStoreFactory.getRefreshTokenStore();
				entity = refreshTokenStore.fetchToken(token);
			}
			
			if(null != entity){
				userResponse.setUserid(entity.getUserId());
			}
		}
		return userResponse;
	}

	@Override
	public ExpireTokenResponse expireUserToken(long userId) {

		UserTokenMappingStore userTokenMappingStore = entityStoreFactory.getUserTokenMappingStore();
		userTokenMappingStore.deleteAllTokensForUser(userId);
		
		ExpireTokenResponse expireTokenResponse = new ExpireTokenResponse();
		
		expireTokenResponse.setExpireTokenStatus(TMSConstants.SUCCESS);
		
		return expireTokenResponse;
	}	

	@Override
	public void saveToken(TokenEntity tokenEntity) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveToken - adding tokenEntity into redis - " + tokenEntity.getUserId());
		int maxRetryCount = 3;
		while(maxRetryCount != 0) {
			try {
				UserTokenMappingStore userTokenMappingStore = entityStoreFactory.getUserTokenMappingStore();
				userTokenMappingStore.addToken(tokenEntity.getUserId(), tokenEntity);
				break;
			} catch (Exception exception) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveToken - error occurred while saving token: ", exception);
				maxRetryCount--;
				try {
					Thread.sleep((long) 10);
				} catch (InterruptedException e) {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveToken - error occurred while interuptting the thread: ", exception);
					Thread.currentThread().interrupt();
				}
			}
		}
	}	
	
	private void updateToken(TokenEntity tokenEntity) {
		if(null != tokenEntity){
			UserTokenMappingStore userTokenMappingStore = entityStoreFactory.getUserTokenMappingStore();
			//BFSDMOB-1488 : Setting correct time on auth token and refresh token entities
			if(tokenEntity.isAuthToken()) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "updateToken - updating expiration window for existing token - " + tokenEntity);
				tokenEntity.setExpirationWindow(authTokenExpirationPeriod);
			}
			else if (tokenEntity.isRefreshToken())
				tokenEntity.setExpirationWindow(refTokenExpirationPeriod);
			
			userTokenMappingStore.updateToken(tokenEntity.getUserId(), tokenEntity);
		}		
	}
	
	private TokenEntity fetchExistingToken(TokenEntity tokenEntity) {

		String userId = String.valueOf(tokenEntity.getUserId());
		UserTokenMappingStore userTokenMappingStore = entityStoreFactory.getUserTokenMappingStore();
		List<TokenEntity> existingTokenList = userTokenMappingStore.fetchToken(userId);

		if (existingTokenList!=null && !existingTokenList.isEmpty()){
			TokenEntity existingToken = null;
			for(TokenEntity t : existingTokenList){
				if(t.equals(tokenEntity)){
					existingToken = t;
					break;
				}
			}
			
			if(existingToken !=null){
				long currentMillis = System.currentTimeMillis();
				if(currentMillis < existingToken.getToBeExpiredOn()){
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "fetchExistingToken - currentMillis < existingToken");
					return existingToken;
				}
				else {
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "fetchExistingToken - removing timed out existing token - " + existingToken);
					userTokenMappingStore.removeParticularToken(Long.valueOf(userId), existingToken);
				}
			}
		}
		return null;

	}
	/**
	 * Chatbot-209 changes start
	 */
	@Override
	public TokenEncryptionResponse encryptGuardKey(String guardKey, String authToken) {
		TokenEncryptionResponse tokenEncryptionResponse = new TokenEncryptionResponse();
		String encrypGuardToken = "";
		long start = System.currentTimeMillis();
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: encryptGuardKey - start - " + start);
			long curTime = Calendar.getInstance().getTimeInMillis();
			String guardToken = salt + "|" + curTime + "|" + guardKey;
			encrypGuardToken = Base64.getEncoder().encodeToString(guardToken.getBytes());
			tokenEncryptionResponse.setGuardToken(encrypGuardToken);
			tokenEncryptionResponse.setAuthToken(authToken);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "method: encryptGuardKey - end - " + start);	
		return tokenEncryptionResponse;
	}

	@Override
	public ValidateTokenResponse validateAuthToken(String authToken) {
		return tokenValidator.validateAuthToken(authToken);
	}


}
