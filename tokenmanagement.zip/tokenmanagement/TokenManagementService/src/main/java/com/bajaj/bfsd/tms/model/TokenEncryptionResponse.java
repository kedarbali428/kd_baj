package com.bajaj.bfsd.tms.model;

public class TokenEncryptionResponse {
	
	private String authToken;
	private String guardToken;
	public String getAuthToken() {
		return authToken;
	}
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
	public String getGuardToken() {
		return guardToken;
	}
	public void setGuardToken(String guardToken) {
		this.guardToken = guardToken;
	}
	
	

}
