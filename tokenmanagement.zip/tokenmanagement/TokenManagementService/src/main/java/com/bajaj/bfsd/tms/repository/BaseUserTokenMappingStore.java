package com.bajaj.bfsd.tms.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.tms.entity.TokenEntity;

@Component
public abstract class BaseUserTokenMappingStore extends UserTokenMappingStore{

	// List need to be changed to hashmap to improve performance - Functionally this might not help as tokenstring
	// key will change so it will defeate the purpose of hashmap
	private HashMap<String, List<TokenEntity>> userTokenStore;
	
	public BaseUserTokenMappingStore()
	{
		userTokenStore = new HashMap<>();
	}
	
	@Override
	public void deleteAllTokensForUser(long userId) {
		String userIdStr = String.valueOf(userId);
		List<TokenEntity> localEntities = fetchToken(userIdStr);
		if(null != localEntities){
			
			for(TokenEntity entity : localEntities){
				//BFSDMOB-1084 : No need to delete refreshToken which is used to fetch authToken for Mobile platform
				if(null != entity && !entity.isRefreshToken()){
					deleteAssociatedEntities(entity);			
				}
			}			
			deleteToken(userIdStr);
		}		
	}

	@Override
	public List<TokenEntity> fetchToken(String userId) {
		
		return userTokenStore.get(userId);
	}

	@Override
	public void saveToken(String userId, List<TokenEntity> entity) {
		userTokenStore.put(userId, entity);	
	}

	@Override
	public void deleteToken(String userId) {
		userTokenStore.remove(userId);		
	}
	
	@Override
	public void addToken(Long userId, TokenEntity entity){
		//String userIdStr =userId.toString();
		//List<TokenEntity> localEntities = fetchToken(userIdStr);		
		//if(null == localEntities){
		//	localEntities = new ArrayList<>();
		//}
		//localEntities.add(entity);
		// This could have put inside if loop but purposly kept here so that when cache logic is implemented it would be consistent
		//saveToken(userIdStr, localEntities);
		addAssociatedEntity(entity);	
	}
	
	@Override
	public void removeParticularToken(Long userId, TokenEntity entity){
		String userIdStr =userId.toString();
//		List<TokenEntity> localEntities = fetchToken(userIdStr);
//		if(null != localEntities){
//			boolean entityRemoved = false;
//			for(int i=0; i < localEntities.size(); i++){
//				if(localEntities.get(i).getToken().equalsIgnoreCase(entity.getToken())){
//					localEntities.remove(i);
//					entityRemoved = true;
//					break;
//				}	
//			}
			//if(entityRemoved){
				deleteAssociatedEntities(entity);
			//if(localEntities.isEmpty())
				deleteToken(userIdStr);
//			else
//				saveToken(userIdStr, localEntities);
//			}
		//}
	}
	
	@Override
	public void updateToken(Long userId, TokenEntity entity) {
//		String userIdStr =userId.toString();
//		List<TokenEntity> localEntities = fetchToken(userIdStr);
//		
//		if(null == localEntities){
//			localEntities = new ArrayList<>();
//			localEntities.add(entity);
//		}
//		else {
//			for(int i=0; i<localEntities.size();i++){
//				if(localEntities.get(i).equals(entity)){
//					localEntities.set(i,entity);
//					break;
//				}
//			}
//		}
//		saveToken(userIdStr, localEntities);
		addAssociatedEntity(entity);
	}
	
	abstract void deleteAssociatedEntities(TokenEntity entity);
	
	abstract void addAssociatedEntity(TokenEntity entity);
}
