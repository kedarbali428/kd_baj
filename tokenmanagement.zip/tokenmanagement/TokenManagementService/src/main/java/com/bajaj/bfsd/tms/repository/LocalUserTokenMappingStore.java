package com.bajaj.bfsd.tms.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;
import com.bajaj.bfsd.tms.entity.TokenEntity;
import com.bajaj.bfsd.tms.util.TMSConstants;

@Component
public class LocalUserTokenMappingStore extends BaseUserTokenMappingStore{

	@Autowired
	LocalAuthTokenStore localAuthTokenStore;
	
	@Autowired
	LocalRefreshTokenStore localRefreshTokenStore;
	
		
	@Override
	void deleteAssociatedEntities(TokenEntity entity){
		if(null != entity){
			short entityType = entity.getType(); 
			if(entityType == TMSConstants.TOKENTYPE_AUTH){
				localAuthTokenStore.deleteToken(entity.getToken());
			} else if(entityType == TMSConstants.TOKENTYPE_REFRESH){
				localRefreshTokenStore.deleteToken(entity.getToken());
			} 	
		}
	}
	
	@Override
	void addAssociatedEntity(TokenEntity entity){
		if(null != entity){
			short entityType = entity.getType(); 
			if(entityType == TMSConstants.TOKENTYPE_AUTH){
				localAuthTokenStore.saveToken(entity.getToken(), (AuthTokenEntity)entity);
			} else if(entityType == TMSConstants.TOKENTYPE_REFRESH){
				localRefreshTokenStore.saveToken(entity.getToken(), (RefreshTokenEntity)entity);
			} 	
		}
		
	}
}