package com.bajaj.bfsd.tms.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
public class CacheAuthTokenStore extends AuthTokenStore {

	SingleObjectCacheRepositoryImpl<String, AuthTokenEntity> cacheRepository;
	
	@Autowired
	protected Environment env;
		
	@Autowired
	protected RedisConfig redisConfig;
	
	@Autowired
    private BFLLoggerUtil logger;
	
	private static final String THIS_CLASS = CacheAuthTokenStore.class.getCanonicalName();
	
	public CacheAuthTokenStore(){
		//
	}
	@Override
	public AuthTokenEntity fetchToken(String token) throws BFLTechnicalException {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.REPOSITORY, "fetching tokens with token key: " + token);
			return token==null? null: getCacheRepository().find(token);
		} catch (Exception exception) {
			throw new BFLTechnicalException("TMS-006", exception);
		}
	}

	@Override
	public void saveToken(String token, AuthTokenEntity entity) throws BFLTechnicalException {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.REPOSITORY, "saving tokens with token key: " + token);
			getCacheRepository().save(token,  entity);
		} catch (Exception exception) {
			throw new BFLTechnicalException("TMS-007", exception);
		}
	}

	@Override
	public void deleteToken(String token) throws BFLTechnicalException {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.REPOSITORY, "deleting tokens with token key: " + token);
			getCacheRepository().delete(token);
		} catch (Exception exception) {
			throw new BFLTechnicalException("TMS-008", exception);
		}
	}

	@Override
	public void deleteAllTokensForUser(long userId) {
		//
	}	

	private SingleObjectCacheRepositoryImpl<String, AuthTokenEntity> getCacheRepository()
	{
		if(null == this.cacheRepository){
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(AuthTokenEntity.class, env, redisConfig);			
		}
		
		return cacheRepository;
	}
}
