package com.bajaj.bfsd.tms.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.cache.config.RedisConfig;

@Component
public class EntityStoreFactory extends BFLComponent{

	@Value("${tms.tokenstore.local}")
	private boolean localTokenStore;
	
	@Autowired
	Environment env;
	
	@Autowired
	RedisConfig redisConfig;
	
	@Autowired
	RedisTemplate<String, Object> redisTemplate;
			
	@Autowired
	LocalRefreshTokenStore localRefTokenStore;
	
	@Autowired
	LocalAuthTokenStore localAuthTokenStore;
	
	@Autowired
	LocalUserTokenMappingStore localUserTokenMappingStore;
	
	@Autowired
	CacheUserTokenMappingStore cacheUserTokenMappingStore;
	
	@Autowired
	CacheAuthTokenStore cacheAuthTokenStore;
	
	@Autowired
	CacheRefreshTokenStore cacheRefreshTokenStore;
	
	public RefreshTokenStore getRefreshTokenStore(){
		RefreshTokenStore refreshTokenStore;
			if(localTokenStore){
				refreshTokenStore = localRefTokenStore; 
			}
			else{
				// Initialize with cache token store here
				refreshTokenStore = cacheRefreshTokenStore;
			}				
		
		return refreshTokenStore;
	}
	
	public AuthTokenStore getAuthTokenStore(){
		AuthTokenStore authTokenStore;
			if(localTokenStore){
				authTokenStore = localAuthTokenStore; 
			}
			else{
				// Initialize with cache token store here
				authTokenStore = cacheAuthTokenStore;
			}
		return authTokenStore;
	}
	
	public UserTokenMappingStore getUserTokenMappingStore(){
		UserTokenMappingStore userTokenMappingStore;
		if(localTokenStore){
			userTokenMappingStore = localUserTokenMappingStore; 
		}
		else{
			// Initialize with cache token store here
			userTokenMappingStore = cacheUserTokenMappingStore;
		}
		return userTokenMappingStore;		
	}
}
