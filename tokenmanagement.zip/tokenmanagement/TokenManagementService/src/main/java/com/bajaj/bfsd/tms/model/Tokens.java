package com.bajaj.bfsd.tms.model;

import java.io.Serializable;

public class Tokens implements Serializable {

	private static final long serialVersionUID = 5214151939252231697L;
	
	private String token; 
	private String guardKey;
	private String type;
	

	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getGuardKey() {
		return guardKey;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((guardKey == null) ? 0 : guardKey.hashCode());
		result = prime * result + ((token == null) ? 0 : token.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object ob) {
		if (this == ob)
			return true;
		if (ob == null)
			return false;
		if (getClass() != ob.getClass())
			return false;
		Tokens other = (Tokens) ob;
		if (guardKey == null) {
			if (other.guardKey != null)
				return false;
		} else if (!guardKey.equals(other.guardKey))
			return false;
		if (token == null) {
			if (other.token != null)
				return false;
		} else if (!token.equals(other.token))
			return false;
		return true;
	}
	public void setGuardKey(String guardKey) {
		this.guardKey = guardKey;
	}
	
	@Override
	public String toString() {
		return "Tokens [token=" + token + ", guardKey=" + guardKey + "]";
	}
	
	
}
