package com.bajaj.bfsd.tms.repository;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;

@Component
public abstract class AuthTokenStore extends BFLComponent implements TokenStoreService<String, AuthTokenEntity> {

	public AuthTokenStore() {
	}
}