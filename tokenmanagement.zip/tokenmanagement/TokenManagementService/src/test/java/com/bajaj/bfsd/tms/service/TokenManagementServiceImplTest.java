package com.bajaj.bfsd.tms.service;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;
import com.bajaj.bfsd.tms.entity.TokenEntity;
import com.bajaj.bfsd.tms.model.GenerateTokenRequest;
import com.bajaj.bfsd.tms.model.TokenEncryptionResponse;
import com.bajaj.bfsd.tms.model.UserIdResponse;
import com.bajaj.bfsd.tms.model.ValidateRefreshTokenResponse;
import com.bajaj.bfsd.tms.model.ValidateTokenResponse;
import com.bajaj.bfsd.tms.repository.AuthTokenStore;
import com.bajaj.bfsd.tms.repository.EntityStoreFactory;
import com.bajaj.bfsd.tms.repository.RefreshTokenStore;
import com.bajaj.bfsd.tms.repository.UserTokenMappingStore;
import com.bajaj.bfsd.tms.util.TMSConstants;

@SpringBootTest(classes = { BFLCommonRestClient.class })
@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:error.properties" })
public class TokenManagementServiceImplTest {

	@InjectMocks
	private TokenManagementServiceImpl tokenManagementServiceImpl;

	@Mock
	TokenManagementService tokenmanagementService;

	private TokenGeneratorFactory tokenFactory;

	@Mock
	EntityStoreFactory entityStoreFactory;

	@Mock
	BFLLoggerUtil logger;

	@Mock
	TokenValidator tokenValidator;

	@Mock
	UserCacheService cacheService;
	
	@Mock
	Environment env;

	GenerateTokenRequest generateTokenReq;

	AuthTokenGenerator authTokenGenerator;

	RefreshTokenGenerator refreshTokenGenerator;
	
	@Value("${tms.token.secret}")
	private String secret;

	@Value("${tms.token.issuer}")
	private String issuer;

	@Value("${tms.token.type}")
	private String type;
	
	@Value("${tms.token.subjectAuth}")
	private String subjectAuth;

	@Value("${tms.authtoken.expirationperiod}")
	private String expirationPeriod;
	
	@Value("${tms.token.subjectRef}")
	private String subjectRefresh;

	@Value("${tms.reftoken.expirationperiod}")
	private String expirationPeriodRefreshToken;

	//private int savetokenretry = 2;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		tokenManagementServiceImpl = new TokenManagementServiceImpl();
		generateTokenReq = new GenerateTokenRequest();
		tokenFactory = new TokenGeneratorFactory();
		authTokenGenerator = new AuthTokenGenerator();
		refreshTokenGenerator = new RefreshTokenGenerator();
		
		ReflectionTestUtils.setField(authTokenGenerator, "logger", logger);
		ReflectionTestUtils.setField(authTokenGenerator, "env", env);
		ReflectionTestUtils.setField(authTokenGenerator, "secret", secret);
		ReflectionTestUtils.setField(authTokenGenerator, "issuer", issuer);
		ReflectionTestUtils.setField(authTokenGenerator, "type", type);
		ReflectionTestUtils.setField(authTokenGenerator, "subjectAuth", subjectAuth);
		ReflectionTestUtils.setField(authTokenGenerator, "expirationPeriod", expirationPeriod);		
		
		ReflectionTestUtils.setField(refreshTokenGenerator, "logger", logger);
		ReflectionTestUtils.setField(refreshTokenGenerator, "env", env);
		ReflectionTestUtils.setField(refreshTokenGenerator, "secret", secret);
		ReflectionTestUtils.setField(refreshTokenGenerator, "issuer", issuer);
		ReflectionTestUtils.setField(refreshTokenGenerator, "type", type);
		ReflectionTestUtils.setField(refreshTokenGenerator, "subjectRefresh", subjectRefresh);
		ReflectionTestUtils.setField(refreshTokenGenerator, "expirationPeriod", expirationPeriodRefreshToken);
		
		ReflectionTestUtils.setField(tokenManagementServiceImpl, "logger", logger);
		ReflectionTestUtils.setField(tokenManagementServiceImpl, "tokenValidator", tokenValidator);
		ReflectionTestUtils.setField(tokenManagementServiceImpl, "cacheService", cacheService);
		ReflectionTestUtils.setField(tokenFactory, "authTokenGenerator", authTokenGenerator);
		ReflectionTestUtils.setField(tokenFactory, "refreshTokenGenerator", refreshTokenGenerator);
		ReflectionTestUtils.setField(tokenManagementServiceImpl, "tokenFactory", tokenFactory);
		ReflectionTestUtils.setField(tokenManagementServiceImpl, "entityStoreFactory", entityStoreFactory);
		//ReflectionTestUtils.setField(tokenManagementServiceImpl, "savetokenretry", savetokenretry);
		ReflectionTestUtils.setField(authTokenGenerator, "subjectAuth", "dsd");
		ReflectionTestUtils.setField(authTokenGenerator, "expirationPeriod", "32434");

	}

	@Test
	public void testGenerateToken() throws UnsupportedEncodingException {
		String platform = "abc";
		String deviceId = "xyz";
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		generateTokenReq.setLoginId("123");
		generateTokenReq.setUserId(1L);
		generateTokenReq.setUserType((short) 0);
		TokenEntity tokenEntity = Mockito.mock(TokenEntity.class);
		tokenEntity.setUserId(1L);
		tokenEntity.setUserType((short) 0);
		tokenEntity.setLoginId("123");
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		List<TokenEntity> existingTokenList = new ArrayList<>();
		existingTokenList.add(tokenEntity);
		tokenEntity.setUserId(1L);
		Mockito.when(userTokenMappingStore.fetchToken(Mockito.any())).thenReturn(existingTokenList);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		tokenManagementServiceImpl.generateToken(generateTokenReq, platform, deviceId);
	}

	@Test
	public void testGenerateToken_RefreshToken() throws UnsupportedEncodingException {
		String platform = "mob";
		String deviceId = "xyz";
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		generateTokenReq.setLoginId("123");
		generateTokenReq.setUserId(1L);
		generateTokenReq.setUserType((short) 0);
		TokenEntity tokenEntity = Mockito.mock(TokenEntity.class);
		tokenEntity.setUserId(1L);
		tokenEntity.setUserType((short) 0);
		tokenEntity.setLoginId("123");
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		List<TokenEntity> existingTokenList = new ArrayList<>();
		existingTokenList.add(tokenEntity);
		tokenEntity.setUserId(1L);
		Mockito.when(userTokenMappingStore.fetchToken(Mockito.any())).thenReturn(existingTokenList);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		tokenManagementServiceImpl.generateToken(generateTokenReq, platform, deviceId);
	}
	
	@Test
	public void testGenerateToken_TokenExist() throws UnsupportedEncodingException {
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		generateTokenReq.setLoginId("123");
		generateTokenReq.setUserId(1L);
		generateTokenReq.setUserType((short) 0);
		AuthTokenEntity tokenEntity = new AuthTokenEntity(generateTokenReq, null, null, null);
		tokenEntity.setUserId(1L);
		tokenEntity.setUserType((short) 0);
		tokenEntity.setLoginId("123");
		tokenEntity.setToBeExpiredOn(System.currentTimeMillis() + 10000000l);
		
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		List<TokenEntity> existingTokenList = new ArrayList<>();
		existingTokenList.add(tokenEntity);
		
		Mockito.when(userTokenMappingStore.fetchToken(Mockito.any())).thenReturn(existingTokenList);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		tokenManagementServiceImpl.generateToken(generateTokenReq, null, null);
	}
	
	@Test
	public void testGenerateToken_ExpiredTokenExist() throws UnsupportedEncodingException {
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		generateTokenReq.setLoginId("123");
		generateTokenReq.setUserId(1L);
		generateTokenReq.setUserType((short) 0);
		AuthTokenEntity tokenEntity = new AuthTokenEntity(generateTokenReq, null, null, null);
		tokenEntity.setUserId(1L);
		tokenEntity.setUserType((short) 0);
		tokenEntity.setLoginId("123");
		tokenEntity.setToBeExpiredOn(System.currentTimeMillis() - 1000l);
		
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		List<TokenEntity> existingTokenList = new ArrayList<>();
		existingTokenList.add(tokenEntity);
		
		Mockito.when(userTokenMappingStore.fetchToken(Mockito.any())).thenReturn(existingTokenList);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		tokenManagementServiceImpl.generateToken(generateTokenReq, null, null);
	}
	
	@Test
	public void testGenerateToken_RefreshTokenExist() throws UnsupportedEncodingException {
		String platform = "mob";
		String deviceId = "xyz";
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		generateTokenReq.setLoginId("123");
		generateTokenReq.setUserId(1L);
		generateTokenReq.setUserType((short) 0);
		RefreshTokenEntity tokenEntity = new RefreshTokenEntity(generateTokenReq, deviceId, null);
		tokenEntity.setUserId(1L);
		tokenEntity.setUserType((short) 0);
		tokenEntity.setLoginId("123");
		tokenEntity.setToBeExpiredOn(System.currentTimeMillis() + 10000000l);
		
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		List<TokenEntity> existingTokenList = new ArrayList<>();
		existingTokenList.add(tokenEntity);
		
		Mockito.when(userTokenMappingStore.fetchToken(Mockito.any())).thenReturn(existingTokenList);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		tokenManagementServiceImpl.generateToken(generateTokenReq, platform, deviceId);
	}

	@Test
	public void testValidateAuthTokenAndGuardToken() {
		String authToken = "";
		String guardToken = "";
		tokenManagementServiceImpl.validateAuthToken(authToken, guardToken);
	}

	@Test
	public void testGetAuthTokenForRefreshToken() throws UnsupportedEncodingException {
		String salt = "1";
		String refreshToken = "";
		String guardToken = "";
		TokenEntity entity = null;
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		List<TokenEntity> existingTokenList = new ArrayList<>();
		TokenEntity entity2 = Mockito.mock(TokenEntity.class);
		existingTokenList.add(entity2);
		userTokenMappingStore.addToken(1L, entity);
		userTokenMappingStore.updateToken(1L, entity);
		userTokenMappingStore.removeParticularToken(1L, entity);
		ValidateRefreshTokenResponse refreshTokenResponse = new ValidateRefreshTokenResponse();
		refreshTokenResponse.setGuardToken(guardToken);
		refreshTokenResponse.setStatus("OK");
		refreshTokenResponse.setToken("123");
		ValidateTokenResponse tokenResponse = new ValidateTokenResponse();
		GenerateTokenRequest request = new GenerateTokenRequest();
		request.setLoginId("1");
		request.setUserId(1L);
		request.setUserType((short) 0);
		RefreshTokenStore refTokenStore = Mockito.mock(RefreshTokenStore.class);
		RefreshTokenEntity refEntity = new RefreshTokenEntity(request, "123", salt);
		refEntity.setAuthToken("ABC");
		refEntity.setDeviceId("deviceId");
		refEntity.setUserId(1L);
		refEntity.setPlatform("platform");
		refEntity.setSalt("salt");
		refEntity.setLoginId("arshaftab");
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		generateTokenReq.setLoginId("1");
		AuthTokenStore authTokenStore = Mockito.mock(AuthTokenStore.class);
		AuthTokenEntity authEntity = Mockito.mock(AuthTokenEntity.class);
		authEntity.setUserId(1L);
		authEntity.setBrowserId("101010");
		tokenResponse.setTokenStatus("VALID");
		Mockito.when(entityStoreFactory.getRefreshTokenStore()).thenReturn(refTokenStore);
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(refTokenStore.fetchToken(Mockito.anyString())).thenReturn(refEntity);
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(authEntity);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		Mockito.when(tokenValidator.validateRefreshToken(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(tokenResponse);
		Mockito.when(userTokenMappingStore.fetchToken(Mockito.anyString())).thenReturn(existingTokenList);
		tokenManagementServiceImpl.getAuthTokenForRefreshToken(refreshToken, guardToken);
	}

	@Test
	public void testReturnUserId() {
		String token = "abc";
		TokenEntity entity = null;
		UserIdResponse userResponse = new UserIdResponse();
		userResponse.setUserid(1L);
		AuthTokenStore authTokenStore = Mockito.mock(AuthTokenStore.class);
		authTokenStore.saveToken(token, (AuthTokenEntity) entity);
		RefreshTokenStore refreshTokenStore = Mockito.mock(RefreshTokenStore.class);
		refreshTokenStore.deleteAllTokensForUser(1L);
		refreshTokenStore.deleteToken("abc");
		refreshTokenStore.fetchToken("xyz");
		refreshTokenStore.saveToken("abc", null);
		Mockito.when(entityStoreFactory.getRefreshTokenStore()).thenReturn(refreshTokenStore);
		Mockito.when(refreshTokenStore.fetchToken(Mockito.anyString())).thenReturn(null);
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(null);
		tokenManagementServiceImpl.returnUserId(token);

	}

	@Test
	public void testExpireUserToken() {
		long userId = 1L;
		TokenEntity entity = null;

		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		userTokenMappingStore.addToken(1L, entity);
		userTokenMappingStore.updateToken(1L, entity);
		userTokenMappingStore.removeParticularToken(1L, entity);
		userTokenMappingStore.deleteAllTokensForUser(userId);
		List<TokenEntity> entities = new ArrayList<>();
		entities.add(null);
		userTokenMappingStore.saveToken("token", entities);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		tokenManagementServiceImpl.expireUserToken(userId);

	}

	@Test
	public void testSaveToken() {
		long userId = 1L;
		TokenEntity entity = null;
		TokenEntity tokenEntity = Mockito.mock(TokenEntity.class);
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		userTokenMappingStore.addToken(1L, entity);
		tokenEntity.setUserId(1L);
		userTokenMappingStore.updateToken(1L, entity);
		userTokenMappingStore.removeParticularToken(1L, entity);
		userTokenMappingStore.deleteAllTokensForUser(userId);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		tokenManagementServiceImpl.saveToken(tokenEntity);

	}

	@Test
	public void testSaveToken_Exception() {
		long userId = 1L;
		TokenEntity entity = null;
		TokenEntity tokenEntity = Mockito.mock(TokenEntity.class);
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		userTokenMappingStore.addToken(1L, entity);
		tokenEntity.setUserId(1L);
		userTokenMappingStore.updateToken(1L, entity);
		userTokenMappingStore.removeParticularToken(1L, entity);
		userTokenMappingStore.deleteAllTokensForUser(userId);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenThrow(Exception.class);
		tokenManagementServiceImpl.saveToken(tokenEntity);

	}

	@Test
	public void testSaveToken_Exception1() {
		long userId = 1L;
		TokenEntity entity = null;
		TokenEntity tokenEntity = Mockito.mock(TokenEntity.class);
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		userTokenMappingStore.addToken(1L, entity);
		tokenEntity.setUserId(1L);
		userTokenMappingStore.updateToken(1L, entity);
		userTokenMappingStore.removeParticularToken(1L, entity);
		userTokenMappingStore.deleteAllTokensForUser(userId);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenThrow(InterruptedException.class);
		tokenManagementServiceImpl.saveToken(tokenEntity);

	}

	@Test
	public void testEncryptGuardKey() {
		String guardKey = "";
		String authToken = "";
		TokenEncryptionResponse tokenEncryptionResponse = new TokenEncryptionResponse();
		tokenEncryptionResponse.setAuthToken("");
		tokenEncryptionResponse.setGuardToken("");
		tokenManagementServiceImpl.encryptGuardKey(guardKey, authToken);
	}
	
	@Test
	public void testExpireAuthToken() {
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		AuthTokenStore authTokenStore = Mockito.mock(AuthTokenStore.class);
		AuthTokenEntity tokenEntity = Mockito.mock(AuthTokenEntity.class);
		
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(tokenEntity);
		Assert.assertNotNull(tokenManagementServiceImpl.expireToken("token", "guardtoken", TMSConstants.TOKENTYPE_AUTH));
	}
	
	@Test
	public void testExpireRerreshToken() {
		UserTokenMappingStore userTokenMappingStore = Mockito.mock(UserTokenMappingStore.class);
		RefreshTokenStore authTokenStore = Mockito.mock(RefreshTokenStore.class);
		
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		Mockito.when(entityStoreFactory.getRefreshTokenStore()).thenReturn(authTokenStore);
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(null);
		Assert.assertNotNull(tokenManagementServiceImpl.expireToken("token", "guardtoken", TMSConstants.TOKENTYPE_REFRESH));
	}

	@Test
	public void testValidateAuthToken() {
		ValidateTokenResponse tokenResponse = new ValidateTokenResponse();
		tokenResponse.setTokenStatus("VALID");
		tokenResponse.setDefaultRole("pcustomer");
		tokenResponse.setLoginId("mobilenum@dateofbirth");
		tokenResponse.setUserId(999999999l);
		Mockito.when(tokenValidator.validateAuthToken(Mockito.anyString())).thenReturn(tokenResponse);

		Assert.assertEquals("pcustomer", tokenManagementServiceImpl.validateAuthToken("authtoken").getDefaultRole());
	}
}