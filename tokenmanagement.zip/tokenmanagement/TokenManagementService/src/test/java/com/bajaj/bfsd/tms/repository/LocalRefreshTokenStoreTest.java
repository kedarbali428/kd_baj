package com.bajaj.bfsd.tms.repository;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;
import com.bajaj.bfsd.tms.model.GenerateTokenRequest;

@SpringBootTest(classes = { BFLCommonRestClient.class })
@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({"classpath:error.properties"})
public class LocalRefreshTokenStoreTest {

	@InjectMocks
	LocalRefreshTokenStore localRefreshTokenStore;
	
	@Mock
	HashMap<String, RefreshTokenEntity> refreshTokenStore;
	
	@Mock
	LocalAuthTokenStore authTokenStore;
	
	@Before
	public void setUp() {
		
		localRefreshTokenStore = new LocalRefreshTokenStore();
		ReflectionTestUtils.setField(localRefreshTokenStore, "authTokenStore", authTokenStore);
		ReflectionTestUtils.setField(localRefreshTokenStore, "refreshTokenStore", refreshTokenStore);

	}
	@Test
	public void fetchToken() {
		String token="123";
		localRefreshTokenStore.fetchToken(token);
		
	}
	@Test
	public void saveToken() {
		String token="12";
		GenerateTokenRequest generateTokenReq=new GenerateTokenRequest();
		String deviceid="12";
		String salt="salt";
		RefreshTokenEntity entity=new RefreshTokenEntity(generateTokenReq, deviceid, salt);
	entity.setDeviceId("deviceId");
	entity.setAuthToken("authToken");
	localRefreshTokenStore.saveToken(token, entity);
	}
	
	@Test
	public void deleteToken() {
		ReflectionTestUtils.setField(localRefreshTokenStore, "authTokenStore",authTokenStore);
		ReflectionTestUtils.setField(localRefreshTokenStore, "refreshTokenStore", refreshTokenStore);

		String token="122";
		GenerateTokenRequest generateTokenReq=new GenerateTokenRequest();
		String deviceid="1";
		String salt="12";
		RefreshTokenEntity entity=new RefreshTokenEntity(generateTokenReq, deviceid, salt);
		entity.setAuthToken("12");
		entity.setDeviceId("1");
		
		localRefreshTokenStore.deleteToken(token);
	}
}