package com.bajaj.bfsd.tms.repository;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bajaj.bfsd.tms.entity.TokenEntity;
import com.bfl.common.exceptions.BFLTechnicalException;

@SpringBootTest(classes = { BFLCommonRestClient.class })
@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({"classpath:error.properties"})
public class CacheUserTokenMappingStoreTest {
	
	@InjectMocks
	CacheUserTokenMappingStore cacheUserTokenMappingStore ;
	
	
	@Mock
	SingleObjectCacheRepositoryImpl<String, List<TokenEntity>> cacheRepository; 
	@Mock
	CacheAuthTokenStore cacheAuthTokenStore;
	
	@Mock
	CacheRefreshTokenStore cacheRefreshTokenStore;
	
	@Autowired
	protected Environment env;
		
	@Mock
	RedisConfig redisConfig;
	
	@Mock
    BFLLoggerUtil logger;
	
	@Before
	public void setUp() {
		
		cacheUserTokenMappingStore = new CacheUserTokenMappingStore();
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "cacheAuthTokenStore",cacheAuthTokenStore);

		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "logger",logger);
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "cacheRefreshTokenStore",cacheRefreshTokenStore);
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "redisConfig",redisConfig);
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "env",env);
	}
	@Test
	public void fetchToken() {
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "cacheRepository",cacheRepository);

		String userId="1";
		cacheUserTokenMappingStore.fetchToken(userId);
	}
	
	@Test(expected=Exception.class)
	public void fetchToken1() throws  BFLTechnicalException{
		String userId="1";
		cacheUserTokenMappingStore.fetchToken(userId);
	}
	@Test
	public void saveToken1() {
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "cacheRepository",cacheRepository);
		String userId="123";
		List<TokenEntity> entity=new ArrayList<>();
		cacheUserTokenMappingStore.saveToken(userId,entity);
}
	@Test(expected=Exception.class)
	public void saveToken() throws BFLTechnicalException{
		String userId="123";
		List<TokenEntity> entity=new ArrayList<>();
		cacheUserTokenMappingStore.saveToken(userId,entity);

	}
	@Test
	public void deleteTokenTest() {
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "cacheRepository",cacheRepository);
		String userId="123";
		cacheUserTokenMappingStore.deleteToken(userId);
	}
	@Test(expected=Exception.class)
	public void deleteTokenTest1() throws  BFLTechnicalException {
		String userId="123";
		cacheUserTokenMappingStore.deleteToken(userId);
	}
	@Test
	public void deleteAssociatedEntities() {
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "cacheAuthTokenStore",cacheAuthTokenStore);
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "cacheRepository",cacheRepository);
		TokenEntity entity=Mockito.mock(TokenEntity.class);
		entity.setType((short) 0);
		entity.setType((short) 1);
		Mockito.doNothing().when(cacheAuthTokenStore).deleteToken(Mockito.anyString());
		Mockito.doNothing().when(cacheRefreshTokenStore).deleteToken(Mockito.anyString());

		cacheUserTokenMappingStore.deleteAssociatedEntities(entity);

	}
	
	@Test
	public void addAssociatedEntityTest() {
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "cacheAuthTokenStore",cacheAuthTokenStore);
		ReflectionTestUtils.setField(cacheUserTokenMappingStore, "cacheRepository",cacheRepository);
		AuthTokenEntity entity = Mockito.mock(AuthTokenEntity.class);
		entity.setType((short) 0);
		entity.setType((short) 1);
		Mockito.doNothing().when(cacheAuthTokenStore).saveToken(Mockito.anyString(),Mockito.any());
		Mockito.doNothing().when(cacheRefreshTokenStore).saveToken(Mockito.anyString(),Mockito.any());

		cacheUserTokenMappingStore.addAssociatedEntity(entity);

	}
	
}