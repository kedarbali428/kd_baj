package com.bajaj.bfsd.tms.repository;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bajaj.bfsd.tms.model.GenerateTokenRequest;
import com.bfl.common.exceptions.BFLTechnicalException;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { BFLCommonRestClient.class })
@TestPropertySource({"classpath:error.properties"})
public class LocalAuthTokenStoreTest {
	@InjectMocks
	private LocalAuthTokenStore localAuthTokenStore;
	
	
	@Mock
	HashMap<String, AuthTokenEntity> authTokenStore;

	@Before
	public void setUp() {
		
		localAuthTokenStore = new LocalAuthTokenStore();
		ReflectionTestUtils.setField(localAuthTokenStore, "authTokenStore",authTokenStore);

	}
	@Test
	public void fetchTokenTest() throws BFLTechnicalException {
		ReflectionTestUtils.setField(localAuthTokenStore, "authTokenStore",authTokenStore);

		String token="22122";

		localAuthTokenStore.fetchToken(token);
	}
	@Test
	public void deleteAllTokensForUser() {
		Long userId=1L;
		localAuthTokenStore.deleteAllTokensForUser(userId);
	}
	@Test
	public void saveToken() {
		String token="123";
		GenerateTokenRequest generateTokenReq=new GenerateTokenRequest();
		String platform="abc";
		String browserid="123";
		String salt="salt";
		AuthTokenEntity entity= new AuthTokenEntity(generateTokenReq, platform, browserid, salt);
entity.setBrowserId("123");
localAuthTokenStore.saveToken(token,entity);

	}
	
	@Test
	public void deleteToken() {
		String token="123";
		
localAuthTokenStore.deleteToken(token);

	}
}