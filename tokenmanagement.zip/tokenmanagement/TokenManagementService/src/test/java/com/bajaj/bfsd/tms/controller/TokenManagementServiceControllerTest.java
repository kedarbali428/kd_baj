package com.bajaj.bfsd.tms.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.tms.exception.ControllerExceptionHandler;
import com.bajaj.bfsd.tms.model.GenerateTokenRequest;
import com.bajaj.bfsd.tms.model.TokenEncryptionRequest;
import com.bajaj.bfsd.tms.service.TokenManagementService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootConfiguration
@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class TokenManagementServiceControllerTest {

	@InjectMocks
	TokenManagementServiceController tokenMangementServiceController;

	@Mock
	TokenManagementService tokenManagement;

	@Mock
	private BFLLoggerUtil logger;

	@Autowired
	Environment env;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(tokenMangementServiceController)
				.setControllerAdvice(ControllerExceptionHandler.class)
				.addPlaceholderValue("api.tokenmanagement.generatetoken.POST.uri",
						env.getProperty("api.tokenmanagement.generatetoken.POST.uri"))
				.addPlaceholderValue("api.tokenmanagement.validatetoken.GET.uri",
						env.getProperty("api.tokenmanagement.validatetoken.GET.uri"))
				.addPlaceholderValue("api.tokenmanagement.expiretoken.DELETE.uri",
						env.getProperty("api.tokenmanagement.expiretoken.DELETE.uri"))
				.addPlaceholderValue("api.tokenmanagement.getuser.GET.uri",
						env.getProperty("api.tokenmanagement.getuser.GET.uri"))
				.addPlaceholderValue("api.tokenmanagement.expireuser.DELETE.uri",
						env.getProperty("api.tokenmanagement.expireuser.DELETE.uri"))
				.addPlaceholderValue("api.tokenmanagement.accesstoken.GET.uri",
						env.getProperty("api.tokenmanagement.accesstoken.GET.uri"))
				.addPlaceholderValue("api.tokenmanagement.encrypttoken.POST.uri",
						env.getProperty("api.tokenmanagement.encrypttoken.POST.uri"))
				.addPlaceholderValue("api.tokenmanagement.authenticate.token.POST.uri",
						env.getProperty("api.tokenmanagement.authenticate.token.POST.uri"))
				.build();
	}

	@Test
	public void testGenerateTokens() throws Exception {
		mockMvc.perform(post(env.getProperty("api.tokenmanagement.generatetoken.POST.uri"))
				.content(prepareRequestJsonString(new GenerateTokenRequest())).headers(new HttpHeaders())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	public void testValidateToken() throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.set("authtoken", "authtoken");
		mockMvc.perform(get(env.getProperty("api.tokenmanagement.validatetoken.GET.uri")).headers(headers)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	public void testExpireToken() throws Exception {
		mockMvc.perform(delete(env.getProperty("api.tokenmanagement.expiretoken.DELETE.uri")).headers(new HttpHeaders())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	public void testgetUserIdFromToken() throws Exception {
		mockMvc.perform(get(env.getProperty("api.tokenmanagement.getuser.GET.uri")).headers(new HttpHeaders())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	public void testExpireTokenForUser() throws Exception {
		mockMvc.perform(delete(env.getProperty("api.tokenmanagement.expireuser.DELETE.uri"), 1234l)
				.headers(new HttpHeaders()).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	public void testGenerateAuthTokenForRefreshToken() throws Exception {
		mockMvc.perform(get(env.getProperty("api.tokenmanagement.accesstoken.GET.uri")).headers(new HttpHeaders())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	public void testGenerateEncryptedToken() throws Exception {
		TokenEncryptionRequest request = new TokenEncryptionRequest();
		request.setAuthToken("authtoken");
		request.setGuardKey("guardKey");
		mockMvc.perform(post(env.getProperty("api.tokenmanagement.encrypttoken.POST.uri"))
				.content(prepareRequestJsonString(request)).headers(new HttpHeaders())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	public void testValidateAuthToken_BadRequest() throws Exception {
		mockMvc.perform(post(env.getProperty("api.tokenmanagement.authenticate.token.POST.uri")).headers(new HttpHeaders()).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest());
	}

	@Test
	public void testValidateAuthToken() throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.add("authtoken", "authtoken");
		mockMvc.perform(post(env.getProperty("api.tokenmanagement.authenticate.token.POST.uri")).headers(headers).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	private String prepareRequestJsonString(Object requestObject) {
		String requestJson = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			requestJson = mapper.writeValueAsString(requestObject);
		} catch (JsonProcessingException e) {
		}
		return requestJson;
	}
}
