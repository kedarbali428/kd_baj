package com.bajaj.bfsd.tms.service;

import static com.bajaj.bfsd.tms.util.TMSConstants.USERTYPE_CUSTOMER;
import static com.bajaj.bfsd.tms.util.TMSConstants.USERTYPE_EMPLOYEE;
import static com.bajaj.bfsd.tms.util.TMSConstants.USERTYPE_SYSTEM;
import static com.bajaj.bfsd.tms.util.TMSConstants.USERTYPE_SYSTEM_PARTNER;
import static org.mockito.Mockito.mock;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;
import com.bajaj.bfsd.tms.repository.AuthTokenStore;
import com.bajaj.bfsd.tms.repository.EntityStoreFactory;
import com.bajaj.bfsd.tms.repository.RefreshTokenStore;
import com.bajaj.bfsd.tms.repository.UserTokenMappingStore;

@SpringBootTest
@SpringBootConfiguration
public class TokenValidatorTest {

	@InjectMocks
	TokenValidator tokenValidator;

	@Mock
	BFLLoggerUtil logger;

	@Mock
	EntityStoreFactory entityStoreFactory;
	
	private long guardTokenThreshold = 36000000;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		
		ReflectionTestUtils.setField(tokenValidator, "guardTokenThreshold", guardTokenThreshold);
	}

	@Test
	public void testValidateAuthToken() {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(false);
		
		Assert.assertEquals("VALID", tokenValidator.validateAuthToken("authtoken").getTokenStatus());
	}
	
	@Test
	public void testValidateAuthToken_ExpiredToken() {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(true);
		
		Assert.assertEquals("EXPIRED", tokenValidator.validateAuthToken("authtoken").getTokenStatus());
	}
	
	@Test
	public void testValidateAuthTokenAndGuardToken_EntityNull() {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(null);
		
		Assert.assertEquals("EXPIRED", tokenValidator.validateAuthToken("authtoken", "guardtoken").getTokenStatus());
	}
	
	@Test
	public void testValidateAuthTokenAndGuardToken_EntityExpired() {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		RefreshTokenStore refreshTokenStore = mock(RefreshTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		Mockito.when(entityStoreFactory.getRefreshTokenStore()).thenReturn(refreshTokenStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		RefreshTokenEntity refreshTokenEntity = mock(RefreshTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(true);
		Mockito.when(refreshTokenStore.fetchToken(Mockito.anyString())).thenReturn(refreshTokenEntity);
		Mockito.when(refreshTokenEntity.isExpired()).thenReturn(true);
		
		Assert.assertEquals("EXPIRED", tokenValidator.validateAuthToken("authtoken", "guardtoken").getTokenStatus());
		Assert.assertEquals("EXPIRED", tokenValidator.validateRefreshToken("authtoken", "guardtoken").getTokenStatus());
	}
	
	@Test
	public void testValidateAuthTokenAndGuardToken_EmployeeToken() {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(false);
		Mockito.when(entity.getUserType()).thenReturn(USERTYPE_EMPLOYEE);
		
		Assert.assertEquals("VALID", tokenValidator.validateAuthToken("authtoken", "guardtoken").getTokenStatus());
	}
	
	@Test
	public void testValidateAuthTokenAndGuardToken_SystemPartner() {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(false);
		Mockito.when(entity.getUserType()).thenReturn(USERTYPE_SYSTEM_PARTNER);
		
		Assert.assertEquals("VALID", tokenValidator.validateAuthToken("authtoken", "guardtoken").getTokenStatus());
	}
	
	@Test
	public void testValidateAuthTokenAndGuardToken_System() {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(false);
		Mockito.when(entity.getUserType()).thenReturn(USERTYPE_SYSTEM);
		
		Assert.assertEquals("VALID", tokenValidator.validateAuthToken("authtoken", "guardtoken").getTokenStatus());
	}
	
	@Test
	public void testValidAuthTokenAndGuardToken_Customer() throws UnsupportedEncodingException {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		RefreshTokenStore refreshTokenStore = mock(RefreshTokenStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		Mockito.when(entityStoreFactory.getRefreshTokenStore()).thenReturn(refreshTokenStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		RefreshTokenEntity refreshTokenEntity = mock(RefreshTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(false);
		Mockito.when(entity.getUserType()).thenReturn(USERTYPE_CUSTOMER);
		Mockito.when(entity.getGuardKey()).thenReturn("9jJx2LtMNS3p");
		Mockito.when(entity.getSalt()).thenReturn("B!&1j");
		
		Mockito.when(refreshTokenStore.fetchToken(Mockito.anyString())).thenReturn(refreshTokenEntity);
		Mockito.when(refreshTokenEntity.isExpired()).thenReturn(false);
		Mockito.when(refreshTokenEntity.getUserType()).thenReturn(USERTYPE_CUSTOMER);
		Mockito.when(refreshTokenEntity.getGuardKey()).thenReturn("9jJx2LtMNS3p");
		Mockito.when(refreshTokenEntity.getSalt()).thenReturn("B!&1j");
		
		String decodedGuardToken = "B!&1j" + "|" + System.currentTimeMillis() + "|" + "9jJx2LtMNS3p";
		String guardToken = new String(decodedGuardToken.getBytes(), "utf-8");
		
		Assert.assertEquals("VALID", tokenValidator.validateAuthToken("authtoken",
				Base64.getEncoder().encodeToString(guardToken.getBytes())).getTokenStatus());
		Assert.assertEquals("VALID", tokenValidator.validateRefreshToken("authtoken", 
				Base64.getEncoder().encodeToString(guardToken.getBytes())).getTokenStatus());
	}
	
//	@Test
	public void testValidAuthTokenAndGuardToken_Customer_InvalidTime() throws UnsupportedEncodingException {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(false);
		Mockito.when(entity.getUserType()).thenReturn(USERTYPE_CUSTOMER);
		Mockito.when(entity.getGuardKey()).thenReturn("9jJx2LtMNS3p");
		Mockito.when(entity.getSalt()).thenReturn("B!&1j");
		
		String decodedGuardToken = "B!&1j" + "|" + "invalidtime" + "|" + "9jJx2LtMNS3p";
		String guardToken = new String(decodedGuardToken.getBytes(), "utf-8");
		
		Assert.assertEquals("INVALID", tokenValidator.validateAuthToken("authtoken",
				Base64.getEncoder().encodeToString(guardToken.getBytes())).getTokenStatus());
	}
	
//	@Test
	public void testValidAuthTokenAndGuardToken_Customer_InvalidGuardToken() throws UnsupportedEncodingException {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(false);
		Mockito.when(entity.getUserType()).thenReturn(USERTYPE_CUSTOMER);
		Mockito.when(entity.getGuardKey()).thenReturn("9jJx2LtMNS3p");
		Mockito.when(entity.getSalt()).thenReturn("B!&1j");
		
		String decodedGuardToken = "B!&1j" + "|" + "invalidtime" + "|";
		String guardToken = new String(decodedGuardToken.getBytes(), "utf-8");
		
		Assert.assertEquals("INVALID", tokenValidator.validateAuthToken("authtoken",
				Base64.getEncoder().encodeToString(guardToken.getBytes())).getTokenStatus());
	}
	
//	@Test
	public void testValidAuthTokenAndGuardToken_Customer_InvalidGuardToken2() throws UnsupportedEncodingException {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(false);
		Mockito.when(entity.getUserType()).thenReturn(USERTYPE_CUSTOMER);
		Mockito.when(entity.getGuardKey()).thenReturn("9jJx2LtMNS3p");
		Mockito.when(entity.getSalt()).thenReturn("B!&1j");
		
		String decodedGuardToken = "B!&1j" + "invalidtime";
		String guardToken = new String(decodedGuardToken.getBytes(), "utf-8");
		
		Assert.assertEquals("INVALID", tokenValidator.validateAuthToken("authtoken",
				Base64.getEncoder().encodeToString(guardToken.getBytes())).getTokenStatus());
	}
	
//	@Test
	public void testValidAuthTokenAndGuardToken_Customer_InvalidGuardToken3() throws UnsupportedEncodingException {
		AuthTokenStore authTokenStore = mock(AuthTokenStore.class);
		RefreshTokenStore refreshTokenStore = mock(RefreshTokenStore.class);
		UserTokenMappingStore userTokenMappingStore = mock(UserTokenMappingStore.class);
		
		Mockito.when(entityStoreFactory.getAuthTokenStore()).thenReturn(authTokenStore);
		Mockito.when(entityStoreFactory.getUserTokenMappingStore()).thenReturn(userTokenMappingStore);
		Mockito.when(entityStoreFactory.getRefreshTokenStore()).thenReturn(refreshTokenStore);
		
		AuthTokenEntity entity = mock(AuthTokenEntity.class);
		RefreshTokenEntity refreshTokenEntity = mock(RefreshTokenEntity.class);
		
		Mockito.when(authTokenStore.fetchToken(Mockito.anyString())).thenReturn(entity);
		Mockito.when(entity.isExpired()).thenReturn(false);
		Mockito.when(entity.getUserType()).thenReturn(USERTYPE_CUSTOMER);
		Mockito.when(entity.getGuardKey()).thenReturn("9jJx2LtMNS3p");
		
		Mockito.when(refreshTokenStore.fetchToken(Mockito.anyString())).thenReturn(refreshTokenEntity);
		Mockito.when(refreshTokenEntity.isExpired()).thenReturn(false);
		Mockito.when(refreshTokenEntity.getUserType()).thenReturn(USERTYPE_CUSTOMER);
		Mockito.when(refreshTokenEntity.getGuardKey()).thenReturn("9jJx2LtMNS3p");
		
		String decodedGuardToken = "B!&1j" + "invalidtime";
		String guardToken = new String(decodedGuardToken.getBytes(), "utf-8");
		
		Assert.assertEquals("INVALID", tokenValidator.validateAuthToken("authtoken", null).getTokenStatus());
		Assert.assertEquals("INVALID", tokenValidator.validateRefreshToken("authtoken", 
				Base64.getEncoder().encodeToString(guardToken.getBytes())).getTokenStatus());
	}
}
