package com.bajaj.bfsd.tms.repository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.tms.entity.AuthTokenEntity;
import com.bajaj.bfsd.tms.model.GenerateTokenRequest;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { BFLCommonRestClient.class })
@TestPropertySource({"classpath:error.properties"})
public class CacheAuthTokenStoreTest {
	
	@InjectMocks
	private CacheAuthTokenStore cacheAuthTokenStore;

	@Mock
	Environment env;
	
	@Mock
	AuthTokenStore authTokenStore;
		
	@Mock
	RedisConfig redisConfig;
	
	@Mock
    BFLLoggerUtil logger;
	
	@Mock
	SingleObjectCacheRepositoryImpl<String, AuthTokenEntity> cacheRepository;
	
	@Before
	public void setUp() {
		
		cacheAuthTokenStore = new CacheAuthTokenStore();
		ReflectionTestUtils.setField(cacheAuthTokenStore, "logger",logger);
		ReflectionTestUtils.setField(cacheAuthTokenStore, "redisConfig",redisConfig);
		ReflectionTestUtils.setField(cacheAuthTokenStore, "env",env);
	}
	@Test
	public void fetchTokenTest() throws BFLTechnicalException {
		ReflectionTestUtils.setField(cacheAuthTokenStore, "cacheRepository",cacheRepository);

		String token="22122";

		cacheAuthTokenStore.fetchToken(token);
	}
	@Test(expected=Exception.class)
	public void fetchTokenTest1() throws BFLTechnicalException {

		String token="22122";

		cacheAuthTokenStore.fetchToken(token);
	}
	@Test
	public void saveToken()throws BFLTechnicalException{
		ReflectionTestUtils.setField(cacheAuthTokenStore, "cacheRepository",cacheRepository);

		String token="2112";
		GenerateTokenRequest generateTokenReq=new GenerateTokenRequest();
		String platform="12";
		String browserid="123";
		String salt="";
		AuthTokenEntity entity= new AuthTokenEntity(generateTokenReq, platform, browserid, salt);
		entity.setBrowserId("123");
		
		cacheAuthTokenStore.saveToken(token,entity);
	}
	
	@Test(expected=Exception.class)
	public void saveToken1()throws BFLTechnicalException{

		String token="2112";
		GenerateTokenRequest generateTokenReq=new GenerateTokenRequest();
		String platform="12";
		String browserid="123";
		String salt="";
		AuthTokenEntity entity= new AuthTokenEntity(generateTokenReq, platform, browserid, salt);
		entity.setBrowserId("123");
		
		cacheAuthTokenStore.saveToken(token,entity);
	}
	@Test
	public void deleteToken() {
		ReflectionTestUtils.setField(cacheAuthTokenStore, "cacheRepository",cacheRepository);

		String token="123";
		cacheAuthTokenStore.deleteToken(token);
		
	}
	@Test(expected=Exception.class)
	public void deleteToken1() {

		String token="123";
		cacheAuthTokenStore.deleteToken(token);
		
	}
	
}