package com.bajaj.bfsd.tms.repository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.tms.entity.RefreshTokenEntity;
import com.bajaj.bfsd.tms.model.GenerateTokenRequest;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { BFLCommonRestClient.class })
@TestPropertySource({"classpath:error.properties"})
public class CacheRefreshTokenStoreTest {
	@InjectMocks
	private CacheRefreshTokenStore cacheRefreshTokenStore;
	
	@Mock
	CacheAuthTokenStore authTokenStore;
	
	@Mock
	 Environment env;
		
	@Mock
	 RedisConfig redisConfig;
	
	@Mock
	SingleObjectCacheRepositoryImpl<String, RefreshTokenEntity> cacheRepository;
	
	@Before
	public void setUp() {
		
		cacheRefreshTokenStore = new CacheRefreshTokenStore();
		ReflectionTestUtils.setField(cacheRefreshTokenStore, "redisConfig",redisConfig);
		ReflectionTestUtils.setField(cacheRefreshTokenStore, "env",env);
		ReflectionTestUtils.setField(cacheRefreshTokenStore, "authTokenStore",authTokenStore);
		ReflectionTestUtils.setField(cacheRefreshTokenStore, "cacheRepository",cacheRepository);
	}
	@Test
	public void CacheRefreshTokenStore() {
		}
	@Test
	public void deleteToken() {
		ReflectionTestUtils.setField(cacheRefreshTokenStore, "authTokenStore",authTokenStore);
		String token="122";
		GenerateTokenRequest generateTokenReq=new GenerateTokenRequest();
		String deviceid="1";
		String salt="12";
		RefreshTokenEntity entity=new RefreshTokenEntity(generateTokenReq, deviceid, salt);
		Mockito.when(cacheRepository.find(Mockito.anyString())).thenReturn(entity);
		entity.setAuthToken("12");
		entity.setDeviceId("1");
		
		cacheRefreshTokenStore.deleteToken(token);
	}
	@Test
	public void fetchToken() {
		ReflectionTestUtils.setField(cacheRefreshTokenStore, "authTokenStore",authTokenStore);

		String token="123";
		cacheRefreshTokenStore.fetchToken(token);

	}
	@Test
	public void saveToken() {
		ReflectionTestUtils.setField(cacheRefreshTokenStore, "authTokenStore",authTokenStore);

		String token="123";
		 GenerateTokenRequest generateTokenReq=new GenerateTokenRequest();
		String deviceid="123";
		String salt="1";
		RefreshTokenEntity entity=new RefreshTokenEntity(generateTokenReq, deviceid, salt);
		cacheRefreshTokenStore.saveToken(token,entity);

	}
}