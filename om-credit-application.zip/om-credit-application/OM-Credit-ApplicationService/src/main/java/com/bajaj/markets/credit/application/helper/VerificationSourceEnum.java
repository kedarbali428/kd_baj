package com.bajaj.markets.credit.application.helper;

public enum VerificationSourceEnum {
	 BFSD;
}
