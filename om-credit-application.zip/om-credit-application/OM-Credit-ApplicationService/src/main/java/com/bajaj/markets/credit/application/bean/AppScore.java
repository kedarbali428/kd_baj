package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

public class AppScore {
	private BigDecimal finalScore;
	private BigDecimal lrScore;
	private BigDecimal mlScore;
	private String customerSegment;
	private String appsScoreKey;
	@NotBlank(message = "applicationKey can not be null/empty")
	@Digits(fraction = 0, integer = 20, message = "applicationKey can not be other than digits")
	private String applicationKey;
	private String productCode;
	private List<HMLScoreDetails> hmlScoreDetails;
	private BigDecimal lrScoreV2;
	
	
	public BigDecimal getFinalScore() {
		return finalScore;
	}
	public void setFinalScore(BigDecimal finalScore) {
		this.finalScore = finalScore;
	}
	public BigDecimal getLrScore() {
		return lrScore;
	}
	public void setLrScore(BigDecimal lrScore) {
		this.lrScore = lrScore;
	}
	public BigDecimal getMlScore() {
		return mlScore;
	}
	public void setMiScore(BigDecimal mlScore) {
		this.mlScore = mlScore;
	}
	public String getCustomerSegment() {
		return customerSegment;
	}
	public void setCustomerSegment(String customerSegment) {
		this.customerSegment = customerSegment;
	}
	public String getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	public String getAppsScoreKey() {
		return appsScoreKey;
	}
	public void setAppsScoreKey(String appsScoreKey) {
		this.appsScoreKey = appsScoreKey;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public List<HMLScoreDetails> getHmlScoreDetails() {
		return hmlScoreDetails;
	}
	public void setHmlScoreDetails(List<HMLScoreDetails> hmlScoreDetails) {
		this.hmlScoreDetails = hmlScoreDetails;
	}
	public BigDecimal getLrScoreV2() {
		return lrScoreV2;
	}
	public void setLrScoreV2(BigDecimal lrScoreV2) {
		this.lrScoreV2 = lrScoreV2;
	}
	@Override
	public String toString() {
		return "AppScore [finalScore=" + finalScore + ", lrScore=" + lrScore + ", mlScore=" + mlScore
				+ ", customerSegment=" + customerSegment + ", appsScoreKey=" + appsScoreKey + ", applicationKey="
				+ applicationKey + ", productCode=" + productCode + ", hmlScoreDetails=" + hmlScoreDetails
				+ ", lrScoreV2=" + lrScoreV2 + "]";
	}
}
