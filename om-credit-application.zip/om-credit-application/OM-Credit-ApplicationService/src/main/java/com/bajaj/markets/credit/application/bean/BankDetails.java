package com.bajaj.markets.credit.application.bean;

public class BankDetails {
	
	    private String accountNo;
        private String  bankBranchName;
        private String  bankName;
        private String  cName ;
        private String  ifscCode;
        private String  micrCode;
        private String  sourceName;
        private String  mandateAddedby;
        private String mandatereference;
		
		public void setBankBranchName(String bankBranchName) {
			this.bankBranchName = bankBranchName;
		}
		public void setBankName(String bankName) {
			this.bankName = bankName;
		}
		public void setcName(String cName) {
			this.cName = cName;
		}
		public void setIfscCode(String ifscCode) {
			this.ifscCode = ifscCode;
		}
		public void setMicrCode(String micrCode) {
			this.micrCode = micrCode;
		}
		public void setSourceName(String sourceName) {
			this.sourceName = sourceName;
		}
		public void setMandateAddedby(String mandateAddedby) {
			this.mandateAddedby = mandateAddedby;
		}
		public void setMandatereference(String mandatereference) {
			this.mandatereference = mandatereference;
		}
		
		public String getAccountNo() {
			return accountNo;
		}
		public void setAccountNo(String accountNo) {
			this.accountNo = accountNo;
		}
		public String getMandatereference() {
			return mandatereference;
		}
		/**
		 * @return the bankBranchName
		 */
		public String getBankBranchName() {
			return bankBranchName;
		}
		/**
		 * @return the bankName
		 */
		public String getBankName() {
			return bankName;
		}
		/**
		 * @return the cName
		 */
		public String getcName() {
			return cName;
		}
		/**
		 * @return the ifscCode
		 */
		public String getIfscCode() {
			return ifscCode;
		}
		/**
		 * @return the micrCode
		 */
		public String getMicrCode() {
			return micrCode;
		}
		/**
		 * @return the sourceName
		 */
		public String getSourceName() {
			return sourceName;
		}
		/**
		 * @return the mandateAddedby
		 */
		public String getMandateAddedby() {
			return mandateAddedby;
		}
        
        
        

}
