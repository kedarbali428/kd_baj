package com.bajaj.markets.credit.application.processor;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.bajaj.markets.credit.application.bean.SchedulerProduct;

@Component
public class CommonApplicationSchedulerProcessor implements ApplicationSchedulerProcessor {

	@Override
	public void callToGetApplicationsAndPushToEvent(SchedulerProduct request, HttpHeaders headers) {
		// TODO Auto-generated method stub
	}
	

}
