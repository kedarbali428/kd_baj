package com.bajaj.markets.credit.application.bean;

public class BolProgramCodeList {

	private String riskOfferType;
	private Integer eligibilityAmount;
	private Boolean isFinalOffer;
	private String principleProductCode;

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public Integer getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(Integer eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public Boolean getIsFinalOffer() {
		return isFinalOffer;
	}

	public void setIsFinalOffer(Boolean isFinalOffer) {
		this.isFinalOffer = isFinalOffer;
	}

	public String getPrincipleProductCode() {
		return principleProductCode;
	}

	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}

	@Override
	public String toString() {
		return "BolProgramCodeList [riskOfferType=" + riskOfferType + ", eligibilityAmount=" + eligibilityAmount
				+ ", isFinalOffer=" + isFinalOffer + ", principleProductCode=" + principleProductCode + "]";
	}

}