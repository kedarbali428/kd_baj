package com.bajaj.markets.credit.application.bean;

public class ApplicationEligibilityStatus {
	private Long appeligibilitystskey;

	private Long applicationkey;

	private Long prodkey;

	private String l3ProductCode;

	private String iseligible;

	private String source;

	public Long getAppeligibilitystskey() {
		return appeligibilitystskey;
	}

	public void setAppeligibilitystskey(Long appeligibilitystskey) {
		this.appeligibilitystskey = appeligibilitystskey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public String getIseligible() {
		return iseligible;
	}

	public void setIseligible(String iseligible) {
		this.iseligible = iseligible;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return "ApplicationEligibilityStatus [appeligibilitystskey=" + appeligibilitystskey + ", applicationkey="
				+ applicationkey + ", prodkey=" + prodkey + ", l3ProductCode=" + l3ProductCode + ", iseligible="
				+ iseligible + ", source=" + source + "]";
	}

}
