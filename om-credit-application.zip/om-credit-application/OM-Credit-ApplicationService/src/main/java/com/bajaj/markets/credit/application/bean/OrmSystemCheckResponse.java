package com.bajaj.markets.credit.application.bean;

public class OrmSystemCheckResponse {
	private String uwCheckCode;
	private String uwCheckDescription;
	private String applicationValue;
	private String verificationValue;
	private Integer matchPercentage;
	private String matchFlag;
	public String getUwCheckCode() {
		return uwCheckCode;
	}
	public void setUwCheckCode(String uwCheckCode) {
		this.uwCheckCode = uwCheckCode;
	}
	public String getUwCheckDescription() {
		return uwCheckDescription;
	}
	public void setUwCheckDescription(String uwCheckDescription) {
		this.uwCheckDescription = uwCheckDescription;
	}
	public String getApplicationValue() {
		return applicationValue;
	}
	public void setApplicationValue(String applicationValue) {
		this.applicationValue = applicationValue;
	}
	public String getVerificationValue() {
		return verificationValue;
	}
	public void setVerificationValue(String verificationValue) {
		this.verificationValue = verificationValue;
	}
	
	
	public Integer getMatchPercentage() {
		return matchPercentage;
	}
	public void setMatchPercentage(Integer matchPercentage) {
		this.matchPercentage = matchPercentage;
	}
	public String getMatchFlag() {
		return matchFlag;
	}
	public void setMatchFlag(String matchFlag) {
		this.matchFlag = matchFlag;
	}
	@Override
	public String toString() {
		return "OrmSystemCheckResponse [uwCheckCode=" + uwCheckCode + ", uwCheckDescription=" + uwCheckDescription
				+ ", applicationValue=" + applicationValue + ", verificationValue=" + verificationValue
				+ ", matchPercentage=" + matchPercentage + ", matchFlag=" + matchFlag + "]";
	}
	
	
	
}

