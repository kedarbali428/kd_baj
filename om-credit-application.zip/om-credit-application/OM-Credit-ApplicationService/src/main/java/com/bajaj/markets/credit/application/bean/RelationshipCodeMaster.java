package com.bajaj.markets.credit.application.bean;

public class RelationshipCodeMaster {

	private Long relationcodemastkey;
	
	private String rcmcode;
	
	private Integer rcmtype;
	
	private Integer rcmisactive;

	public Long getRelationcodemastkey() {
		return relationcodemastkey;
	}

	public void setRelationcodemastkey(Long relationcodemastkey) {
		this.relationcodemastkey = relationcodemastkey;
	}

	public String getRcmcode() {
		return rcmcode;
	}

	public void setRcmcode(String rcmcode) {
		this.rcmcode = rcmcode;
	}

	public Integer getRcmtype() {
		return rcmtype;
	}

	public void setRcmtype(Integer rcmtype) {
		this.rcmtype = rcmtype;
	}

	public Integer getRcmisactive() {
		return rcmisactive;
	}

	public void setRcmisactive(Integer rcmisactive) {
		this.rcmisactive = rcmisactive;
	}

	@Override
	public String toString() {
		return "RelationshipCodeMaster [relationcodemastkey=" + relationcodemastkey + ", rcmcode=" + rcmcode
				+ ", rcmtype=" + rcmtype + ", rcmisactive=" + rcmisactive + "]";
	}
}
