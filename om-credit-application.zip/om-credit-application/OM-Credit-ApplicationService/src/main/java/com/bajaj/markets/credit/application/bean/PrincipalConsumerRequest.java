package com.bajaj.markets.credit.application.bean;

import java.util.Map;

public class PrincipalConsumerRequest {
	
	private String l3ProductKey;
	private String principalKey;
	private String applicationKey;
	private String mobileNumber;
	private Map<String, String> additionalInfo;
	
	public String getL3ProductKey() {
		return l3ProductKey;
	}
	public void setL3ProductKey(String l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}
	public String getPrincipalKey() {
		return principalKey;
	}
	public void setPrincipalKey(String principalKey) {
		this.principalKey = principalKey;
	}
	public String getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Map<String, String> getAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(Map<String, String> additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "PrincipalRequest [l3ProductKey=" + l3ProductKey + ", principalKey=" + principalKey + ", applicationKey="
				+ applicationKey + ", mobileNumber=" + mobileNumber + ", additionalInfo=" + additionalInfo + "]";
	}
}
