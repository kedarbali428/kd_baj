package com.bajaj.markets.credit.application.bean;

public class AppUtmParam {

	private String utmCampaign;

	private String utmMedium;

	private String utmSource;

	private String channel;

	private String utmContent;

	public void setUtmCampaign(String utmCampaign) {
		this.utmCampaign = utmCampaign;
	}

	public void setUtmMedium(String utmMedium) {
		this.utmMedium = utmMedium;
	}

	public void setUtmSource(String utmSource) {
		this.utmSource = utmSource;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public void setUtmContent(String utmContent) {
		this.utmContent = utmContent;
	}

	@Override
	public String toString() {
		return "AppUtmParam [utmCampaign=" + utmCampaign + ", utmMedium=" + utmMedium + ", utmSource=" + utmSource
				+ ", channel=" + channel + ", utmContent=" + utmContent + "]";
	}

}
