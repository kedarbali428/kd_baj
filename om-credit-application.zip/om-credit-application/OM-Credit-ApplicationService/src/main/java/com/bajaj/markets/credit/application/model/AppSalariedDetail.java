package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the app_occupation_detail database table.
 * 
 */
@Entity
@Table(name = "app_occupation_detail", schema = "dmcredit")
public class AppSalariedDetail implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_occupation_detail_appoccupationkey_generator", sequenceName = "dmcredit.seq_pk_app_occupation_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_occupation_detail_appoccupationkey_generator")
	private Long appoccupationkey;

	private Integer declaredexperience;

	private Long declaredincome;

	private Long emplrdesigkey;

	private Long emprmastid;

	private Integer finalexperience;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long netmonthlysalary;

	private Long occupationtype;

	private Long perfiosincome;

	private Long smsincome;

	private String empnameforoth;

	private String designforoth;

	private String industryother;

	private Long emplrtype;
	
	private String emplrcategory;

	private Long appattrbkey;
	
	private Integer currentexperience;
	
	private Long avgbankbalance;
	
	private Long qlfymastkey;
	
	private Long spclmastkey;
	
	private String spclforoth;
	
	private BigDecimal graduationyear;
	
	private BigDecimal postgraduationyear;
	
	private Long rcmastkey;
	
	private Long hospitalkey;
	
	private String hospitalnameother;
	
	private String practicetype;
	
	private String medicalregistrationnumber;

	private Long empsectorservicekey;

	public Long getEmplrtype() {
		return emplrtype;
	}

	public void setEmplrtype(Long emplrtype) {
		this.emplrtype = emplrtype;
	}

	public String getEmplrcategory() {
		return emplrcategory;
	}

	public void setEmplrcategory(String emplrcategory) {
		this.emplrcategory = emplrcategory;
	}

	public Long getAppoccupationkey() {
		return appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public Integer getDeclaredexperience() {
		return declaredexperience;
	}

	public void setDeclaredexperience(Integer declaredexperience) {
		this.declaredexperience = declaredexperience;
	}

	public Long getDeclaredincome() {
		return declaredincome;
	}

	public void setDeclaredincome(Long declaredincome) {
		this.declaredincome = declaredincome;
	}

	public Long getEmplrdesigkey() {
		return emplrdesigkey;
	}

	public void setEmplrdesigkey(Long emplrdesigkey) {
		this.emplrdesigkey = emplrdesigkey;
	}

	public Long getEmprmastid() {
		return emprmastid;
	}

	public void setEmprmastid(Long emprmastid) {
		this.emprmastid = emprmastid;
	}

	public Integer getFinalexperience() {
		return finalexperience;
	}

	public void setFinalexperience(Integer finalexperience) {
		this.finalexperience = finalexperience;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getNetmonthlysalary() {
		return netmonthlysalary;
	}

	public void setNetmonthlysalary(Long netmonthlysalary) {
		this.netmonthlysalary = netmonthlysalary;
	}

	public Long getOccupationtype() {
		return occupationtype;
	}

	public void setOccupationtype(Long occupationtype) {
		this.occupationtype = occupationtype;
	}

	public Long getPerfiosincome() {
		return perfiosincome;
	}

	public void setPerfiosincome(Long perfiosincome) {
		this.perfiosincome = perfiosincome;
	}

	public Long getSmsincome() {
		return smsincome;
	}

	public void setSmsincome(Long smsincome) {
		this.smsincome = smsincome;
	}

	public String getEmpnameforoth() {
		return empnameforoth;
	}

	public void setEmpnameforoth(String empnameforoth) {
		this.empnameforoth = empnameforoth;
	}

	public String getDesignforoth() {
		return designforoth;
	}

	public void setDesignforoth(String designforoth) {
		this.designforoth = designforoth;
	}

	public String getIndustryother() {
		return industryother;
	}

	public void setIndustryother(String industryother) {
		this.industryother = industryother;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}
	
	public Long getAvgbankbalance() {
		return avgbankbalance;
	}

	public void setAvgbankbalance(Long avgbankbalance) {
		this.avgbankbalance = avgbankbalance;
	}

	public Integer getCurrentexperience() {
		return currentexperience;
	}

	public void setCurrentexperience(Integer currentexperience) {
		this.currentexperience = currentexperience;
	}

	public Long getQlfymastkey() {
		return qlfymastkey;
	}

	public void setQlfymastkey(Long qlfymastkey) {
		this.qlfymastkey = qlfymastkey;
	}

	public Long getSpclmastkey() {
		return spclmastkey;
	}

	public void setSpclmastkey(Long spclmastkey) {
		this.spclmastkey = spclmastkey;
	}

	public String getSpclforoth() {
		return spclforoth;
	}

	public void setSpclforoth(String spclforoth) {
		this.spclforoth = spclforoth;
	}

	public BigDecimal getGraduationyear() {
		return graduationyear;
	}

	public void setGraduationyear(BigDecimal graduationyear) {
		this.graduationyear = graduationyear;
	}

	public BigDecimal getPostgraduationyear() {
		return postgraduationyear;
	}

	public void setPostgraduationyear(BigDecimal postgraduationyear) {
		this.postgraduationyear = postgraduationyear;
	}

	public Long getRcmastkey() {
		return rcmastkey;
	}

	public void setRcmastkey(Long rcmastkey) {
		this.rcmastkey = rcmastkey;
	}

	public Long getHospitalkey() {
		return hospitalkey;
	}

	public void setHospitalkey(Long hospitalkey) {
		this.hospitalkey = hospitalkey;
	}

	public String getHospitalnameother() {
		return hospitalnameother;
	}

	public void setHospitalnameother(String hospitalnameother) {
		this.hospitalnameother = hospitalnameother;
	}

	public String getPracticetype() {
		return practicetype;
	}

	public void setPracticetype(String practicetype) {
		this.practicetype = practicetype;
	}

	public String getMedicalregistrationnumber() {
		return medicalregistrationnumber;
	}

	public void setMedicalregistrationnumber(String medicalregistrationnumber) {
		this.medicalregistrationnumber = medicalregistrationnumber;
	}

	public Long getEmpsectorservicekey() {
		return empsectorservicekey;
	}

	public void setEmpsectorservicekey(Long empsectorservicekey) {
		this.empsectorservicekey = empsectorservicekey;
	}

	@Override
	public AppSalariedDetail clone() throws CloneNotSupportedException {
		AppSalariedDetail appSalariedDetail = new AppSalariedDetail();
		appSalariedDetail.setDeclaredexperience(this.declaredexperience);
		appSalariedDetail.setDeclaredincome(this.declaredincome);
		appSalariedDetail.setEmplrdesigkey(this.emplrdesigkey);
		appSalariedDetail.setEmprmastid(this.emprmastid);
		appSalariedDetail.setFinalexperience(this.finalexperience);
		appSalariedDetail.setIsactive(this.isactive);
		appSalariedDetail.setLstupdateby(this.lstupdateby);
		appSalariedDetail.setLstupdatedt(this.lstupdatedt);
		appSalariedDetail.setNetmonthlysalary(this.netmonthlysalary);
		appSalariedDetail.setOccupationtype(this.occupationtype);
		appSalariedDetail.setPerfiosincome(this.perfiosincome);
		appSalariedDetail.setSmsincome(this.smsincome);
		appSalariedDetail.setEmpnameforoth(this.empnameforoth);
		appSalariedDetail.setDesignforoth(this.designforoth);
		appSalariedDetail.setIndustryother(this.industryother);
		appSalariedDetail.setEmplrtype(this.emplrtype);
		appSalariedDetail.setAppattrbkey(this.appattrbkey);
		appSalariedDetail.setCurrentexperience(this.currentexperience);
		appSalariedDetail.setAvgbankbalance(this.avgbankbalance);
		appSalariedDetail.setSpclforoth(this.spclforoth);
		appSalariedDetail.setSpclmastkey(this.spclmastkey);
		appSalariedDetail.setQlfymastkey(this.qlfymastkey);
		appSalariedDetail.setGraduationyear(this.graduationyear);
		appSalariedDetail.setPostgraduationyear(this.postgraduationyear);
		appSalariedDetail.setRcmastkey(this.rcmastkey);
		appSalariedDetail.setHospitalkey(this.hospitalkey);
		appSalariedDetail.setHospitalnameother(this.hospitalnameother);
		appSalariedDetail.setPracticetype(this.practicetype);
		appSalariedDetail.setMedicalregistrationnumber(this.medicalregistrationnumber);
		appSalariedDetail.setEmpsectorservicekey(this.empsectorservicekey);
		return appSalariedDetail;
	}


}