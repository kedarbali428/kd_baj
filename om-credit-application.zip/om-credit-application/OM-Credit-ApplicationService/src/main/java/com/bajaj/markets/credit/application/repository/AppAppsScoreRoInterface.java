package com.bajaj.markets.credit.application.repository;

import com.bajaj.markets.credit.application.model.AppAppsScore;

public interface AppAppsScoreRoInterface extends ReadInterface<AppAppsScore, Long> {

	AppAppsScore findByApplicationkeyAndIsactive(Long applicationkey, Integer isactive);

}
