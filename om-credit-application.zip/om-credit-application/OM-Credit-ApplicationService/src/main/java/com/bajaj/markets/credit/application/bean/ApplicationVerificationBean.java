package com.bajaj.markets.credit.application.bean;

import java.util.Date;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.Verificationdetail;

public class ApplicationVerificationBean {
	
	@NotBlank(groups = Verificationdetail.class,message = "applicationKey can not be null/empty")
	@Digits(groups = Verificationdetail.class,fraction = 0, integer = 20, message = "applicationKey can not be other than digits")
	private String applicationKey;
	
	@Digits(groups = Verificationdetail.class,fraction = 0, integer = 20, message = "applicantKey can not be other than digits")
	private String applicantKey;
	
	@NotBlank(groups = Verificationdetail.class,message = "verificationAttribute can not be null/empty")
	@Pattern(groups = Verificationdetail.class,regexp="^[a-zA-Z0-9\\s_-]+$", message = "verificationAttribute is invalid") 
	private String verificationAttribute;
	
	@Pattern(groups = Verificationdetail.class,regexp="^[a-zA-Z0-9\\s_-]+$", message = "verificationSource is invalid") 
	private String verificationSource;
	
	@NotNull(groups = Verificationdetail.class,message = "isVerified can not be null/empty")
	private Integer isVerified;
	
	private Long verificationReference;

	private Date verificationDate;
	
	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getVerificationAttribute() {
		return verificationAttribute;
	}

	public void setVerificationAttribute(String verificationAttribute) {
		this.verificationAttribute = verificationAttribute;
	}

	public String getVerificationSource() {
		return verificationSource;
	}

	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}

	public Integer getIsVerified() {
		return isVerified;
	}

	public void setIsVerified(Integer isVerified) {
		this.isVerified = isVerified;
	}

	public Long getVerificationReference() {
		return verificationReference;
	}

	public void setVerificationReference(Long verificationReference) {
		this.verificationReference = verificationReference;
	}

	public Date getVerificationDate() {
		return verificationDate;
	}

	public void setVerificationDate(Date verificationDate) {
		this.verificationDate = verificationDate;
	}

	@Override
	public String toString() {
		return "ApplicationVerificationBean [applicationKey=" + applicationKey + ", applicantKey=" + applicantKey
				+ ", verificationAttribute=" + verificationAttribute + ", verificationSource=" + verificationSource
				+ ", isVerified=" + isVerified + ", verificationReference=" + verificationReference
				+ ", verificationDate=" + verificationDate + "]";
	}
}
