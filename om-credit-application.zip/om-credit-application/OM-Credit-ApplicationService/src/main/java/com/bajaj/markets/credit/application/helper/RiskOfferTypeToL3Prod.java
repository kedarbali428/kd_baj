package com.bajaj.markets.credit.application.helper;

import java.util.HashMap;
import java.util.Map;

public enum RiskOfferTypeToL3Prod {
	BFSD_LINE("BFLSOL"), BFL_LINE("BFLSOL"), PA("BFLSOL"), PQ("BFLSOL"), PF("BFLSOL"), PLTB("BFLPLCS"),
	PLCS_HTS("BFLPLCS"),
	PLCS_MTS("BFLPLCS"), NTB_PLCS("BFLPLCS"),
	BFSD_PPL("BFLPPL"), PA_BL("BFLBOL"), PQ_BL("BFLBOL"), CD_BL("BFLBOL"),
	PA_DLAP("BHFLLAP"),PA_DLAPB("BHFLLAPBT"),PQ_DLAPB("BHFLLAPBT"),PQ_DHL("BHFLHLF"),LINE_DHL("BHFLHLF"),
	PA_DHB("BHFLHLBT"),PQ_DHB("BHFLHLBT"),PA_DHL("BHFLHLF"),PQ_DLAP("BHFLLAP"),LINE_DLAP("BHFLLAP"),
  	PLTB_SE("BFLPLCSSE"), PLCSHTS_SE("BFLPLCSSE"), PLCSMTS_SE("BFLPLCSSE"),
  	SOL_GIN("BFLSOL"),SOL_LINE("BFLSOL"),PLCS_GIN("BFLPLCS"),SOL_PA("BFLSOL"),SOL_Line("BFLSOL"),SOL_PQ("BFLSOL"),SOL_PF("BFLSOL"),SAL_PLTB("BFLPLCS"),
  	SAL_HTS("BFLPLCS"),SAL_MTS("BFLPLCS"),
  	BANKING("BFLBOL"),BOLBT("BFLBOL"),NO_OFFER("BFLBOL"),BOLBANKING("BFLBOL"),BOLGST("BFLBOL"),PLCS("BFLBOL"),BOLTO("BFLBOL"),BOLDOE3("BFLBOL"),BOLMODEL2("BFLBOL"),BOLPEAKEMI("BFLBOL"),BOLHLMULT("BFLBOL"),BOLUSLCLOSED("BFLBOL"),BOLRUNOFF("BFLBOL"),BREAIP("BFLSOL"),RT("BFLSOL"),RT2("BFLSOL"),
  	PA_CAL("BFLCAL"),PQ_CAL("BFLCAL"),PA_DOL("BFLDOL"),PQ_DOL("BFLDOL"),CABREAIP("BFLCAL"),DOCBREAIP("BFLDOL"),HDFCKOTAKSURROGATE("BFLBOL"),BANKINGSCORECARD("BFLBOL");

	private final String l3ProdCode;

	private static final Map<String, String> lookup = new HashMap<>();

	static {
		for (RiskOfferTypeToL3Prod d : RiskOfferTypeToL3Prod.values()) {
			lookup.put(d.name(), d.getL3ProdCode());
		}
	}

	private RiskOfferTypeToL3Prod(String l3ProdCode) {
		this.l3ProdCode = l3ProdCode;
	}

	public String getL3ProdCode() {
		return l3ProdCode;
	}


	public static String getL3ProductCode(String riskOfferType) {
		return lookup.get(riskOfferType);
	}

}

