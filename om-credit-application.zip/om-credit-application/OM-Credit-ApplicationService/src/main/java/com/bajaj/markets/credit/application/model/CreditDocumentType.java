package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "credit_document_type", schema = "dmcredit")
public class CreditDocumentType implements Serializable {
	

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer creditdoctype;
	
	private Long principalkey;
	
	private Integer prodmastkey;
	
	private Long prodcatkey;
	
	private Long prodkey;
	
	private String doccatcode;
	
	private String doctypecode;
	
	private String bfsddocname;
		
	private String partnerdocname;
	
	private Timestamp doccreateddt;
	
	private Integer isactive;
	
	private Long lstupdateby;
	
	private Timestamp lstupdatedt;
	
	private String partnerdoctype;
	
	private Integer filesizelimitkb;
	
	private String docformat;

	public Integer getCreditdoctype() {
		return creditdoctype;
	}

	public void setCreditdoctype(Integer creditdoctype) {
		this.creditdoctype = creditdoctype;
	}

	public Long getPrincipalkey() {
		return principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

	public Integer getProdmastkey() {
		return prodmastkey;
	}

	public void setProdmastkey(Integer prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public Long getProdcatkey() {
		return prodcatkey;
	}

	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getBfsddocname() {
		return bfsddocname;
	}

	public void setBfsddocname(String bfsddocname) {
		this.bfsddocname = bfsddocname;
	}

	public String getPartnerdocname() {
		return partnerdocname;
	}

	public void setPartnerdocname(String partnerdocname) {
		this.partnerdocname = partnerdocname;
	}

	public Timestamp getDoccreateddt() {
		return doccreateddt;
	}

	public void setDoccreateddt(Timestamp doccreateddt) {
		this.doccreateddt = doccreateddt;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getPartnerdoctype() {
		return partnerdoctype;
	}

	public void setPartnerdoctype(String partnerdoctype) {
		this.partnerdoctype = partnerdoctype;
	}

	public Integer getFilesizelimitkb() {
		return filesizelimitkb;
	}

	public void setFilesizelimitkb(Integer filesizelimitkb) {
		this.filesizelimitkb = filesizelimitkb;
	}

	public String getDocformat() {
		return docformat;
	}

	public void setDocformat(String docformat) {
		this.docformat = docformat;
	}
	

	public String getDoccatcode() {
		return doccatcode;
	}

	public void setDoccatcode(String doccatcode) {
		this.doccatcode = doccatcode;
	}

	public String getDoctypecode() {
		return doctypecode;
	}

	public void setDoctypecode(String doctypecode) {
		this.doctypecode = doctypecode;
	}

	@Override
	public String toString() {
		return "CreditDocumentType [creditdoctype=" + creditdoctype + ", prodmastkey=" + prodmastkey + ", prodcatkey="
				+ prodcatkey + ", prodkey=" + prodkey + ", doccatcode=" + doccatcode + ", doctypecode=" + doctypecode
				+ ", bfsddocname=" + bfsddocname + ", partnerdocname=" + partnerdocname + ", doccreateddt="
				+ doccreateddt + ", isactive=" + isactive + ", lstupdateby=" + lstupdateby + ", lstupdatedt="
				+ lstupdatedt + ", partnerdoctype=" + partnerdoctype + ", filesizelimitkb=" + filesizelimitkb
				+ ", docformat=" + docformat + "]";
	}

	

	 
	
}
