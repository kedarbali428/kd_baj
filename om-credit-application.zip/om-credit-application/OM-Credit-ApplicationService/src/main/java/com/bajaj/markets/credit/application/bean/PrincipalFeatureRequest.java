package com.bajaj.markets.credit.application.bean;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class PrincipalFeatureRequest {
	@Valid
	@NotNull(message = "PrincipalFeature is mandatory.")
	List<PrincipalFeature> principalFeatures;

	public List<PrincipalFeature> getPrincipalFeatures() {
		return principalFeatures;
	}

	public void setPrincipalFeatures(List<PrincipalFeature> principalFeatures) {
		this.principalFeatures = principalFeatures;
	}

	@Override
	public String toString() {
		return "PrincipalFeatureRequest [principalFeatures=" + principalFeatures + "]";
	}

}
