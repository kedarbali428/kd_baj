package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;
import java.util.List;

public class FppBundleResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3155332019475315571L;
	private Long applicationId;
	private Long l3ProductKey;
	private String l3ProductCode;
	private List<OpenArcFppOutput> openArcFppOutput;

	public Long getApplicationId() {
		return applicationId;
	}

	public Long getL3ProductKey() {
		return l3ProductKey;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public void setL3ProductKey(Long l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public List<OpenArcFppOutput> getOpenArcFppOutput() {
		return openArcFppOutput;
	}

	public void setOpenArcFppOutput(List<OpenArcFppOutput> openArcFppOutput) {
		this.openArcFppOutput = openArcFppOutput;
	}

}
