package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.PinCodeServiceableMaster;

public interface PinCodeServiceableMasterRoInterface extends ReadInterface<PinCodeServiceableMaster, Long> {

	List<PinCodeServiceableMaster> findByPincodekeyAndIsactive(Long pincodekey, Integer isActive);

	PinCodeServiceableMaster findByPincodekeyAndProdkeyAndIsactive(Long pincodekey, Long prodkey, Integer isActive);

}
