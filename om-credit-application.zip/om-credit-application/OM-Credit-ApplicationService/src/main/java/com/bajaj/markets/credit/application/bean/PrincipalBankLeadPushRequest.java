package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class PrincipalBankLeadPushRequest {
	
	private String bankAccountCatagory;
	private String bankMasterKey;
	private Integer bankAccountCategoryKey;
	private String source;
	private String accountNumber;
	private Integer branchKey;
	private List<PrincipalBankServiceableRequest> principalBanks;
	public String getBankAccountCatagory() {
		return bankAccountCatagory;
	}
	public void setBankAccountCatagory(String bankAccountCatagory) {
		this.bankAccountCatagory = bankAccountCatagory;
	}
	public String getBankMasterKey() {
		return bankMasterKey;
	}
	public void setBankMasterKey(String bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}
	public Integer getBankAccountCategoryKey() {
		return bankAccountCategoryKey;
	}
	public void setBankAccountCategoryKey(Integer bankAccountCategoryKey) {
		this.bankAccountCategoryKey = bankAccountCategoryKey;
	}

	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Integer getBranchKey() {
		return branchKey;
	}
	public void setBranchKey(Integer branchKey) {
		this.branchKey = branchKey;
	}
	public List<PrincipalBankServiceableRequest> getPrincipalBanks() {
		return principalBanks;
	}
	public void setPrincipalBanks(List<PrincipalBankServiceableRequest> principalBanks) {
		this.principalBanks = principalBanks;
	}
	@Override
	public String toString() {
		return "PrincipalBankLeadPushRequest [bankAccountCatagory=" + bankAccountCatagory + ", bankMasterKey="
				+ bankMasterKey + ", bankAccountCategoryKey=" + bankAccountCategoryKey + ", source=" + source
				+ ", accountNumber=" + accountNumber + ", branchKey=" + branchKey + ", principalBanks=" + principalBanks
				+ "]";
	}
	
}
