package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.Address;
import com.bajaj.markets.credit.application.bean.DocumentDetails;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationAddressService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Deals with application address resource. Saves user input address on
 * application table
 * 
 * @author 285213
 *
 */
@RestController
@Validated
public class ApplicationAddressController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	ApplicationAddressService applicationAddressService;

	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;

	private static final String CLASSNAME = ApplicationAddressController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Application address endpoint", notes = "This resource will be used to update address on application", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Address updated successfully.", response = DocumentDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/address", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> saveAddressDetails(@Valid @RequestBody Address addressDetails,
			@PathVariable(name = "applicationid", required = true) @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable(name = "userattributekey", required = true) @NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10, message = "userattributekey should be numeric & should not exceeds size") String userattributeKey,
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveAddressDetails method for applicationId :"
				+ applicationId + ", userattributeKey" + userattributeKey + ", addressDetails :" + addressDetails);
		creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userattributeKey);
		Address response = applicationAddressService.saveAddressDetails(addressDetails, applicationId,
				userattributeKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Completed saveAddressDetails method for addressDetails, applicationKey : "+applicationId);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@Secured(value = {Role.INTERNAL,Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.SYSTEM})
	@ApiOperation(value = "Fetch Address Detail", notes = "Fetch Address details on the basis of user attribute", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Address Detail found for the user attribute", response = Address.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Address Detail not found for the user attribute", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/address", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	// @EnableFineGrainCheck
	public ResponseEntity<?> getAddress(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable("userattributekey") @NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10, message = "userattributekey should be numeric & should not exceeds size") String userAttributeKey,
			@RequestParam("typeKey") @NotBlank(message = "typeKey can not be null or empty") @Digits(fraction = 0, integer = 10, message = "typeKey should be numeric & should not exceeds size") String typeKey,
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getAddress method controller - applicationId: "
				+ applicationId + " userattributeKey: " + userAttributeKey);

		creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userAttributeKey);

		return new ResponseEntity<>(
				applicationAddressService.getAddressDetails(Long.valueOf(userAttributeKey), Long.valueOf(typeKey)),
				HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiOperation(value = "Check negative area or not", notes = "Check negative area on particular pincode", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Negative Area found for the application", response = Boolean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Some details not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Unprocessable entity", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occured", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.checknegativearea.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> checkAddressNegativeArea(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestParam(name = "principalKey", required = false) String principalKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Input controller checkNegativeArea - applicationId: " + applicationId +", principalKey" + principalKey);
		boolean negativeAreaFlag = applicationAddressService.checkNegativeArea(Long.valueOf(applicationId),
				principalKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Exit controller checkNegativeArea with response: " + negativeAreaFlag +", for application : "+applicationId);
		return new ResponseEntity<>(negativeAreaFlag, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Update Application address", notes = "update address on application with source", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Address updated successfully.", response = DocumentDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.address.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> saveMultipleAddressDetails(@Valid @RequestBody Address addressDetails,
			@PathVariable(name = "applicationid", required = true) @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable(name = "userattributekey", required = true) @NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10, message = "userattributekey should be numeric & should not exceeds size") String userattributeKey,
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside saveMultipleAddressDetails method for applicationId :" + applicationId + ", userattributeKey"
						+ userattributeKey + ", addressDetails :" + addressDetails);
		creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userattributeKey);
		Address response = applicationAddressService.saveMultipleAddressDetails(addressDetails, applicationId,
				userattributeKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Completed saveMultipleAddressDetails method for addressDetails, applicationId : "+applicationId);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.SYSTEM })
	@ApiOperation(value = "Fetch Address Detail", notes = "Fetch Address details on the basis of user attribute", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Address Detail found for the user attribute", response = Address.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Address Detail not found for the user attribute", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.address.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	// @EnableFineGrainCheck
	public ResponseEntity<?> getMultipleAddress(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable("userattributekey") @NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10, message = "userattributekey should be numeric & should not exceeds size") String userAttributeKey,
			@RequestParam(value = "typeKey", required = false) Long typeKey,
			@RequestParam(value = "returnSingleCurrentAddressFlag", required = true) boolean returnSingleCurrentAddressFlag,
			@RequestParam(value = "removeExactMatchCurrentAddress", required = false) boolean removeExactMatchCurrentAddress,
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getMultipleAddress method controller - applicationId: " + applicationId + " userattributeKey: "
						+ userAttributeKey + ", typeKey : " + typeKey + ", returnSingleCurrentAddressFlag"
						+ returnSingleCurrentAddressFlag + "removeExactMatchCurrentAddress :"+removeExactMatchCurrentAddress);
		creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userAttributeKey);

		return new ResponseEntity<>(applicationAddressService.getMultipleAddress(Long.valueOf(applicationId),
				Long.valueOf(userAttributeKey), typeKey, returnSingleCurrentAddressFlag,removeExactMatchCurrentAddress), HttpStatus.OK);
	}
	

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.SYSTEM })
	@ApiOperation(value = "Check OGL or not", notes = "Check OGL or not on the basis of pincode", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OGL found", response = Address.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = " Details not found ", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.oglflg.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> checkOGL(
			@PathVariable("productKey") @NotNull(message = "prodkey can not be null or empty") Long productKey,
			@PathVariable("pincodeKey") @NotNull(message = "pincode can not be null or empty") Long pincodeKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside checkOGL method controller - prodkey: " + productKey + "pincodekey :" + pincodeKey);
		return new ResponseEntity<>(
				applicationAddressService.checkOGL(Long.valueOf(pincodeKey), Long.valueOf(productKey)), HttpStatus.OK);
	}
	
	
	
}
