package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="app_fin_eligibility",schema = "dmcredit")
public class AppFinEligibility implements Serializable,Cloneable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="app_fin_eligibility_appfineligibilitykey_generator", sequenceName="dmcredit.seq_pk_app_fin_eligibility",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_fin_eligibility_appfineligibilitykey_generator")
	private Long appfineligibilitykey;
    
	private Long applicationkey;
	
    private BigDecimal finalunsecuredfoir;
    
    private BigDecimal applicablemultiplier;
    
    private BigDecimal multipliereligibility;
    
    private BigDecimal finalfoir;
    
    private BigDecimal finalmultiplier;
   
    private BigDecimal maxemiasperfoir;
    
    private BigDecimal foireligibilityemi;
    
    //private String leadqualifiesbflflag;
    
    private Integer imputedsalary;
    
    private Long appprodlistkey;
    
    private Integer isactive;
    
    private Long lstupdateby;
    
    private Timestamp lstupdatedt;	
    
    private BigDecimal eligibilityamount;    
    

	public BigDecimal getEligibilityamount() {
		return eligibilityamount;
	}

	public void setEligibilityamount(BigDecimal eligibilityamount) {
		this.eligibilityamount = eligibilityamount;
	}

	public Long getAppprodlistkey() {
		return appprodlistkey;
	}

	public void setAppprodlistkey(Long appprodlistkey) {
		this.appprodlistkey = appprodlistkey;
	}

	public BigDecimal getFinalunsecuredfoir() {
		return finalunsecuredfoir;
	}

	public void setFinalunsecuredfoir(BigDecimal finalunsecuredfoir) {
		this.finalunsecuredfoir = finalunsecuredfoir;
	}

	public BigDecimal getApplicablemultiplier() {
		return applicablemultiplier;
	}

	public void setApplicablemultiplier(BigDecimal applicablemultiplier) {
		this.applicablemultiplier = applicablemultiplier;
	}

	public BigDecimal getMultipliereligibility() {
		return multipliereligibility;
	}

	public void setMultipliereligibility(BigDecimal multipliereligibility) {
		this.multipliereligibility = multipliereligibility;
	}

	public BigDecimal getFinalfoir() {
		return finalfoir;
	}

	public void setFinalfoir(BigDecimal finalfoir) {
		this.finalfoir = finalfoir;
	}

	public BigDecimal getFinalmultiplier() {
		return finalmultiplier;
	}

	public void setFinalmultiplier(BigDecimal finalmultiplier) {
		this.finalmultiplier = finalmultiplier;
	}

	public BigDecimal getMaxemiasperfoir() {
		return maxemiasperfoir;
	}

	public void setMaxemiasperfoir(BigDecimal maxemiasperfoir) {
		this.maxemiasperfoir = maxemiasperfoir;
	}

	public Long getAppfineligibilitykey() {
		return appfineligibilitykey;
	}

	public void setAppfineligibilitykey(Long appfineligibilitykey) {
		this.appfineligibilitykey = appfineligibilitykey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}
	
	public BigDecimal getFoireligibilityemi() {
		return foireligibilityemi;
	}

	public void setFoireligibilityemi(BigDecimal foireligibilityemi) {
		this.foireligibilityemi = foireligibilityemi;
	}

	public Integer getImputedsalary() {
		return imputedsalary;
	}

	public void setImputedsalary(Integer imputedsalary) {
		this.imputedsalary = imputedsalary;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
    	
    @Override
    public AppFinEligibility clone() throws CloneNotSupportedException { 
    	AppFinEligibility appFinEligibility = new AppFinEligibility();
    	appFinEligibility.setAppfineligibilitykey(this.appfineligibilitykey);
    	appFinEligibility.setApplicablemultiplier(this.applicablemultiplier);
    	appFinEligibility.setApplicationkey(this.applicationkey);
    	appFinEligibility.setAppprodlistkey(this.appprodlistkey);
    	appFinEligibility.setFinalfoir(this.finalfoir);
    	appFinEligibility.setFinalmultiplier(this.finalmultiplier);
    	appFinEligibility.setFinalunsecuredfoir(this.finalunsecuredfoir);
    	appFinEligibility.setFoireligibilityemi(this.foireligibilityemi);
    	appFinEligibility.setImputedsalary(this.imputedsalary);
    	appFinEligibility.setIsactive(this.isactive);
    	appFinEligibility.setLstupdateby(this.lstupdateby);
    	appFinEligibility.setLstupdatedt(this.lstupdatedt);
    	appFinEligibility.setMaxemiasperfoir(this.maxemiasperfoir);
    	appFinEligibility.setMultipliereligibility(this.multipliereligibility);
    	appFinEligibility.setEligibilityamount(eligibilityamount);    	
    	return appFinEligibility;
    }
}
