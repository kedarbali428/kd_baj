package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "serviceable_employer_sector", schema = "dmcredit")
public class ServiceableEmployerSector {

	@Id
	private Long empsectorservicekey;

	private Long principalkey;

	private String employersector;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	public Long getEmpsectorservicekey() {
		return empsectorservicekey;
	}

	public void setEmpsectorservicekey(Long empsectorservicekey) {
		this.empsectorservicekey = empsectorservicekey;
	}

	public Long getPrincipalkey() {
		return principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

	public String getEmployersector() {
		return employersector;
	}

	public void setEmployersector(String employersector) {
		this.employersector = employersector;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}
