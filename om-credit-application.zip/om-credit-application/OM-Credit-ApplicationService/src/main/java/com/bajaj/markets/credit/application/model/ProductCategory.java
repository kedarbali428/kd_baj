package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the product_category database table.
 * 
 */
@Entity
@Table(name = "product_category", schema = "dmcredit")
public class ProductCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String prodcatcode;

	private String prodcatdesc;
	@Id
	private Long prodcatkey;

	private Long prodmastkey;

	public ProductCategory() {
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getProdcatcode() {
		return this.prodcatcode;
	}

	public void setProdcatcode(String prodcatcode) {
		this.prodcatcode = prodcatcode;
	}

	public String getProdcatdesc() {
		return this.prodcatdesc;
	}

	public void setProdcatdesc(String prodcatdesc) {
		this.prodcatdesc = prodcatdesc;
	}

	public Long getProdcatkey() {
		return this.prodcatkey;
	}

	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public Long getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(Long prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

}