package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class PrincipalProductRejectionOutput {

	private String principleProductCode;
	private List<String> rejectCodeList;
	private Boolean isEligible;
	private Boolean isDisplay;
	private String l4ProductCode;
	private String riskOfferType;
	
	public String getPrincipleProductCode() {
		return principleProductCode;
	}
	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}
	public List<String> getRejectCodeList() {
		return rejectCodeList;
	}
	public void setRejectCodeList(List<String> rejectCodeList) {
		this.rejectCodeList = rejectCodeList;
	}
	public Boolean getIsEligible() {
		return isEligible;
	}
	public void setIsEligible(Boolean isEligible) {
		this.isEligible = isEligible;
	}
	public Boolean getIsDisplay() {
		return isDisplay;
	}
	public void setIsDisplay(Boolean isDisplay) {
		this.isDisplay = isDisplay;
	}
	@Override
	public String toString() {
		return "PrincipalProductRejectionOutput [principleProductCode=" + principleProductCode + ", rejectCodeList="
				+ rejectCodeList + ", isEligible=" + isEligible + ", isDisplay=" + isDisplay + "]";
	}
	public String getL4ProductCode() {
		return l4ProductCode;
	}
	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}
	public String getRiskOfferType() {
		return riskOfferType;
	}
	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}
}
