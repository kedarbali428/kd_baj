package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class TranchBean {
	
	private long tranchkey;
	private String accountHolderName;
	private BigDecimal accountHolderType;
	private String accountNumber;
	private Integer accountTypeKey;
	private Timestamp disbursementDate;
	private String disbursementMode;
	private Integer trancheAmount;
	private String trancheStatus;	
	private Integer tranchenum;
	private Date trancheDate;
	private Integer beneficiaryTypeKey;
	private String beneficiaryType;
	private String bankreferenceKey;
	private String branchcode;
	private String ifsccode;
	@JsonIgnore
	private Integer totalDisubursedAmt;
	private Integer disbursementFailureFlg;
	private String disbursementError;
	private Boolean omDisbursementFlag;
	
	
	public long getTranchkey() {
		return tranchkey;
	}
	public void setTranchkey(long tranchkey) {
		this.tranchkey = tranchkey;
	}
	public BigDecimal getAccountHolderType() {
		return accountHolderType;
	}
	public void setAccountHolderType(BigDecimal accountHolderType) {
		this.accountHolderType = accountHolderType;
	}
	public Integer getTrancheAmount() {
		return trancheAmount;
	}
	public void setTrancheAmount(Integer trancheAmount) {
		this.trancheAmount = trancheAmount;
	}
	public Integer getTranchenum() {
		return tranchenum;
	}
	public void setTranchenum(Integer tranchenum) {
		this.tranchenum = tranchenum;
	}
	
	public Integer getBeneficiaryTypeKey() {
		return beneficiaryTypeKey;
	}
	public void setBeneficiaryTypeKey(Integer beneficiaryTypeKey) {
		this.beneficiaryTypeKey = beneficiaryTypeKey;
	}
	public Date getTrancheDate() {
		return trancheDate;
	}
	public void setTrancheDate(Date trancheDate) {
		this.trancheDate = trancheDate;
	}
	
	public String getTrancheStatus() {
		return trancheStatus;
	}
	public void setTrancheStatus(String trancheStatus) {
		this.trancheStatus = trancheStatus;
	}
	public String getBeneficiaryType() {
		return beneficiaryType;
	}
	public void setBeneficiaryType(String beneficiaryType) {
		this.beneficiaryType = beneficiaryType;
	}
	
	public String getBankreferenceKey() {
		return bankreferenceKey;
	}
	public void setBankreferenceKey(String bankreferenceKey) {
		this.bankreferenceKey = bankreferenceKey;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBranchcode() {
		return branchcode;
	}
	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}
	public Timestamp getDisbursementDate() {
		return disbursementDate;
	}
	public void setDisbursementDate(Timestamp disbursementDate) {
		this.disbursementDate = disbursementDate;
	}
	public String getDisbursementMode() {
		return disbursementMode;
	}
	public void setDisbursementMode(String disbursementMode) {
		this.disbursementMode = disbursementMode;
	}
	public String getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
	public Integer getAccountTypeKey() {
		return accountTypeKey;
	}
	public void setAccountTypeKey(Integer accountTypeKey) {
		this.accountTypeKey = accountTypeKey;
	}
	public Integer getTotalDisubursedAmt() {
		return totalDisubursedAmt;
	}
	public void setTotalDisubursedAmt(Integer totalDisubursedAmt) {
		this.totalDisubursedAmt = totalDisubursedAmt;
	}
	public Integer getDisbursementFailureFlg() {
		return disbursementFailureFlg;
	}
	public void setDisbursementFailureFlg(Integer disbursementFailureFlg) {
		this.disbursementFailureFlg = disbursementFailureFlg;
	}
	public String getDisbursementError() {
		return disbursementError;
	}
	public void setDisbursementError(String disbursementError) {
		this.disbursementError = disbursementError;
	}
	public Boolean getOmDisbursementFlag() {
		return omDisbursementFlag;
	}
	public void setOmDisbursementFlag(Boolean omDisbursementFlag) {
		this.omDisbursementFlag = omDisbursementFlag;
	}
	
	
	
}
