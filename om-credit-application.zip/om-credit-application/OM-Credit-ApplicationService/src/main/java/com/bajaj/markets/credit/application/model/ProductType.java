package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product_type", schema = "dmcredit")
public class ProductType implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private Long prodtypekey;
	
    private Long prodkey;
    
    private String prodtypecode;
    
    private String prodtypedesc;
    
    private Integer isactive;
    
    private Long lstupdateby;
    
    private Timestamp lstupdatedt;
    
    private String isBpiApplicable;
    
    private String displayproductname;
    
    private String displayloantypename;
    
   	public String getIsBpiApplicable() {
   		return isBpiApplicable;
   	}

   	public void setIsBpiApplicable(String isBpiApplicable) {
   		this.isBpiApplicable = isBpiApplicable;
   	}


	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getProdtypecode() {
		return prodtypecode;
	}

	public void setProdtypecode(String prodtypecode) {
		this.prodtypecode = prodtypecode;
	}

	public String getProdtypedesc() {
		return prodtypedesc;
	}

	public void setProdtypedesc(String prodtypedesc) {
		this.prodtypedesc = prodtypedesc;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getDisplayproductname() {
		return displayproductname;
	}

	public void setDisplayproductname(String displayproductname) {
		this.displayproductname = displayproductname;
	}

	public String getDisplayloantypename() {
		return displayloantypename;
	}

	public void setDisplayloantypename(String displayloantypename) {
		this.displayloantypename = displayloantypename;
	}
        
	
}
