package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the app_gurantor_details database table.
 * 
 */
@Entity
@Table(name="app_gurantor_details", schema = "dmcredit")
public class AppGurantorDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="APP_GURANTOR_DETAILS_APPGURANTORKEY_GENERATOR" , sequenceName = "dmcredit.seq_pk_app_gurantor_details", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="APP_GURANTOR_DETAILS_APPGURANTORKEY_GENERATOR")
	private Long appgurantorkey;
	private Long applicationkey;
	private String fullname;
	private BigDecimal mobile;
	private Long relationcodemastkey;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private String addressline1;
	private String addressline2;
	private Long pincodekey;
	
	public AppGurantorDetail() {
	}

	public Long getAppgurantorkey() {
		return this.appgurantorkey;
	}

	public void setAppgurantorkey(Long appgurantorkey) {
		this.appgurantorkey = appgurantorkey;
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public String getFullname() {
		return this.fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public BigDecimal getMobile() {
		return this.mobile;
	}

	public void setMobile(BigDecimal mobile) {
		this.mobile = mobile;
	}

	public Long getRelationcodemastkey() {
		return this.relationcodemastkey;
	}

	public void setRelationcodemastkey(Long relationcodemastkey) {
		this.relationcodemastkey = relationcodemastkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getAddressline1() {
		return addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	public String getAddressline2() {
		return addressline2;
	}

	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}
}