package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the pin_code_serviceable_master database table.
 * 
 */
@Entity
@Table(name = "pin_code_serviceable_master", schema = "dmcredit")
public class PinCodeServiceableMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long pinservicekey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long pincodekey;

	private Long prodkey;

	private String cityname;

	private String tier;

	private String pennantbvcodesal;

	private String sourcecode;

	private String stdcode;

	private String statename;
	
	private String pennantbvcodese;
	
	private String citycode;

	public PinCodeServiceableMaster() {
	}

	public Long getPinservicekey() {
		return this.pinservicekey;
	}

	public void setPinservicekey(Long pinservicekey) {
		this.pinservicekey = pinservicekey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getPincodekey() {
		return this.pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public Long getProdkey() {
		return this.prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getPennantbvcodesal() {
		return pennantbvcodesal;
	}

	public void setPennantbvcodesal(String pennantbvcodesal) {
		this.pennantbvcodesal = pennantbvcodesal;
	}

	public String getSourcecode() {
		return sourcecode;
	}

	public void setSourcecode(String sourcecode) {
		this.sourcecode = sourcecode;
	}

	public String getStdcode() {
		return stdcode;
	}

	public void setStdcode(String stdcode) {
		this.stdcode = stdcode;
	}

	public String getStatename() {
		return statename;
	}

	public void setStatename(String statename) {
		this.statename = statename;
	}

	public String getPennantbvcodese() {
		return pennantbvcodese;
	}

	public void setPennantbvcodese(String pennantbvcodese) {
		this.pennantbvcodese = pennantbvcodese;
	}

	public String getCitycode() {
		return citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}
	
	
}