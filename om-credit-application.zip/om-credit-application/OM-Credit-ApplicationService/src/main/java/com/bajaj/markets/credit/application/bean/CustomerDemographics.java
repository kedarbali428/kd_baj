package com.bajaj.markets.credit.application.bean;

public class CustomerDemographics {

	private CustDemographics custDemographics;
	private Boolean isOtpValid;
	private String applicationId;

	public CustDemographics getCustDemographics() {
		return custDemographics;
	}

	public void setCustDemographics(CustDemographics custDemographics) {
		this.custDemographics = custDemographics;
	}

	public Boolean getIsOtpValid() {
		return isOtpValid;
	}

	public void setIsOtpValid(Boolean isOtpValid) {
		this.isOtpValid = isOtpValid;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}


}
