package com.bajaj.markets.credit.application.processor;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.application.bean.SchedulerProduct;

public interface ApplicationSchedulerProcessor {
	
	public void callToGetApplicationsAndPushToEvent(SchedulerProduct request, HttpHeaders headers);
	
	
}
