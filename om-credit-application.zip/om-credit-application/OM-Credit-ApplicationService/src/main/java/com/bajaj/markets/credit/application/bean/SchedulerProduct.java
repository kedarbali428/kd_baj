package com.bajaj.markets.credit.application.bean;

public class SchedulerProduct {
	
	private String l2ProdCode;
	private String principalCode;

	public String getL2ProdCode() {
		return l2ProdCode;
	}

	public void setL2ProdCode(String l2ProdCode) {
		this.l2ProdCode = l2ProdCode;
	}

	public String getPrincipalCode() {
		return principalCode;
	}

	public void setPrincipalCode(String principalCode) {
		this.principalCode = principalCode;
	}

	@Override
	public String toString() {
		return "SchedulerProduct [l2ProdCode=" + l2ProdCode + ", principalCode=" + principalCode + "]";
	}
	
}
