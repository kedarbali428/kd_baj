package com.bajaj.markets.credit.application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.bajaj.markets.credit.application.model.AppFinEligibilityRevision;

public interface AppFinEligibiltyRevisionRoInterface extends ReadInterface<AppFinEligibilityRevision, Long> {

	@Query("select a from AppFinEligibilityRevision a where a.application.applicationkey=:applicationkey  and a.prodkey = :prodkey and a.isactive=1 order by lstupdatedt")
	List<AppFinEligibilityRevision> findByApplicationkeyAndProdkey(Long applicationkey, Long prodkey);

}
