package com.bajaj.markets.credit.application.bean;


public class LoanApprovalDetails {

	private Long loanApprovalEligibility;
	private Long loanApprovalTenure;
	private String loanApprovalROT;

	public Long getLoanApprovalEligibility() {
		return loanApprovalEligibility;
	}

	public void setLoanApprovalEligibility(Long loanApprovalEligibility) {
		this.loanApprovalEligibility = loanApprovalEligibility;
	}

	public Long getLoanApprovalTenure() {
		return loanApprovalTenure;
	}

	public void setLoanApprovalTenure(Long loanApprovalTenure) {
		this.loanApprovalTenure = loanApprovalTenure;
	}

	public String getLoanApprovalROT() {
		return loanApprovalROT;
	}

	public void setLoanApprovalROT(String loanApprovalROT) {
		this.loanApprovalROT = loanApprovalROT;
	}

	@Override
	public String toString() {
		return "LoanApprovalDetails [loanApprovalEligibility=" + loanApprovalEligibility + ", loanApprovalTenure="
				+ loanApprovalTenure + ", loanApprovalROT=" + loanApprovalROT + "]";
	}

}
