package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class ApplicationDetails {

	private ApplicationUtmParam additionalParameterDetail;
	private Occupation occupation;
	private UserProfile userProfile;
	private ProdCategory prodCategory;
	private List<MCPAddressDetails> mcpAddressDetails;
	private PanDetails panDetails;
	private List<Address> addressList;

	// adding for len-652
	List<PrincialSelectedbyCustomerDetail> princialSelectedbyCustomerDetail;
	private List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails;

	private AppScoreDetails appScoreDetails;
	private Boolean existingCustomerFlag;

	private Integer additionalCibilFlag;

	private Integer subStagePercentage;

	private BigDecimal obligationAmount;

	private String officialEmailId;
	private String btBankMasterKey;

	private String btsSegment;

	private String hlProductIntent;

	private BigDecimal creditObligation;

	private Long coapplicantObligation;

	private Integer coApplicantIncome;
	private List<DeactivateOffer> deactivateOfferList;

	private Boolean propertyIdentifiedFlag;

	private Long cityKey;

	private Integer bflBranchKey;
	private Integer yearOfGraduation;
	private Integer yearOfPostGraduation;
	private String specialization;
	private String registrationCouncil;
	private String practiceType;

	private String appCreationDate;
	private String applicationStatusDesc;

	private CreditStatus creditStatus;
	private DispositionDetails dispositionDetails;
	private AppSegmentationInfo appSegmentation;
	private ApplicationLoanDetails applicationLoanDetails;

	private Long pincodekey;

	private PinCode pincode;

	private String approvedFlag;

	private String bmr1ApprovedFlag;

	private String bmr2ApprovedFlag;
	private String dentalCouncil;
	private String degree;
	private Integer specializationCode;
	private String degreeCategory;
	
	private String registrationNumber;
	
	private String yrOfAttainingCertificate;
	
	private  String journeyStamp;
	
	private Integer requiredLoanAmount;
	
	private Integer requiredTenor;

	public ApplicationUtmParam getAdditionalParameterDetail() {
		return additionalParameterDetail;
	}

	public void setAdditionalParameterDetail(ApplicationUtmParam additionalParameterDetail) {
		this.additionalParameterDetail = additionalParameterDetail;
	}

	public Occupation getOccupation() {
		return occupation;
	}

	public void setOccupation(Occupation occupation) {
		this.occupation = occupation;
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public ProdCategory getProdCategory() {
		return prodCategory;
	}

	public void setProdCategory(ProdCategory prodCategory) {
		this.prodCategory = prodCategory;
	}

	public List<MCPAddressDetails> getMcpAddressDetails() {
		return mcpAddressDetails;
	}

	public void setMcpAddressDetails(List<MCPAddressDetails> mcpAddressDetails) {
		this.mcpAddressDetails = mcpAddressDetails;
	}

	public PanDetails getPanDetails() {
		return panDetails;
	}

	public void setPanDetails(PanDetails panDetails) {
		this.panDetails = panDetails;
	}

	public List<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}

	public List<PrincialSelectedbyCustomerDetail> getPrincialSelectedbyCustomerDetail() {
		return princialSelectedbyCustomerDetail;
	}

	public void setPrincialSelectedbyCustomerDetail(List<PrincialSelectedbyCustomerDetail> princialSelectedbyCustomerDetail) {
		this.princialSelectedbyCustomerDetail = princialSelectedbyCustomerDetail;
	}

	public List<EstimatedNetMonthlySalaryDetails> getEstimatedNetMonthlySalaryDetails() {
		return estimatedNetMonthlySalaryDetails;
	}

	public void setEstimatedNetMonthlySalaryDetails(List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails) {
		this.estimatedNetMonthlySalaryDetails = estimatedNetMonthlySalaryDetails;
	}

	public AppScoreDetails getAppScoreDetails() {
		return appScoreDetails;
	}

	public void setAppScoreDetails(AppScoreDetails appScoreDetails) {
		this.appScoreDetails = appScoreDetails;
	}

	public Boolean getExistingCustomerFlag() {
		return existingCustomerFlag;
	}

	public void setExistingCustomerFlag(Boolean existingCustomerFlag) {
		this.existingCustomerFlag = existingCustomerFlag;
	}

	public Integer getAdditionalCibilFlag() {
		return additionalCibilFlag;
	}

	public void setAdditionalCibilFlag(Integer additionalCibilFlag) {
		this.additionalCibilFlag = additionalCibilFlag;
	}

	public Integer getSubStagePercentage() {
		return subStagePercentage;
	}

	public void setSubStagePercentage(Integer subStagePercentage) {
		this.subStagePercentage = subStagePercentage;
	}

	public BigDecimal getObligationAmount() {
		return obligationAmount;
	}

	public void setObligationAmount(BigDecimal obligationAmount) {
		this.obligationAmount = obligationAmount;
	}

	public String getOfficialEmailId() {
		return officialEmailId;
	}

	public void setOfficialEmailId(String officialEmailId) {
		this.officialEmailId = officialEmailId;
	}

	public String getBtBankMasterKey() {
		return btBankMasterKey;
	}

	public void setBtBankMasterKey(String btBankMasterKey) {
		this.btBankMasterKey = btBankMasterKey;
	}

	public String getBtsSegment() {
		return btsSegment;
	}

	public void setBtsSegment(String btsSegment) {
		this.btsSegment = btsSegment;
	}

	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public BigDecimal getCreditObligation() {
		return creditObligation;
	}

	public void setCreditObligation(BigDecimal creditObligation) {
		this.creditObligation = creditObligation;
	}

	public Long getCoapplicantObligation() {
		return coapplicantObligation;
	}

	public void setCoapplicantObligation(Long coapplicantObligation) {
		this.coapplicantObligation = coapplicantObligation;
	}

	public Integer getCoApplicantIncome() {
		return coApplicantIncome;
	}

	public void setCoApplicantIncome(Integer coApplicantIncome) {
		this.coApplicantIncome = coApplicantIncome;
	}

	public List<DeactivateOffer> getDeactivateOfferList() {
		return deactivateOfferList;
	}

	public void setDeactivateOfferList(List<DeactivateOffer> deactivateOfferList) {
		this.deactivateOfferList = deactivateOfferList;
	}

	public Boolean getPropertyIdentifiedFlag() {
		return propertyIdentifiedFlag;
	}

	public void setPropertyIdentifiedFlag(Boolean propertyIdentifiedFlag) {
		this.propertyIdentifiedFlag = propertyIdentifiedFlag;
	}

	public Long getCityKey() {
		return cityKey;
	}

	public void setCityKey(Long cityKey) {
		this.cityKey = cityKey;
	}

	public Integer getBflBranchKey() {
		return bflBranchKey;
	}

	public void setBflBranchKey(Integer bflBranchKey) {
		this.bflBranchKey = bflBranchKey;
	}

	public Integer getYearOfGraduation() {
		return yearOfGraduation;
	}

	public void setYearOfGraduation(Integer yearOfGraduation) {
		this.yearOfGraduation = yearOfGraduation;
	}

	public Integer getYearOfPostGraduation() {
		return yearOfPostGraduation;
	}

	public void setYearOfPostGraduation(Integer yearOfPostGraduation) {
		this.yearOfPostGraduation = yearOfPostGraduation;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public String getRegistrationCouncil() {
		return registrationCouncil;
	}

	public void setRegistrationCouncil(String registrationCouncil) {
		this.registrationCouncil = registrationCouncil;
	}

	public String getPracticeType() {
		return practiceType;
	}

	public void setPracticeType(String practiceType) {
		this.practiceType = practiceType;
	}

	public String getAppCreationDate() {
		return appCreationDate;
	}

	public void setAppCreationDate(String appCreationDate) {
		this.appCreationDate = appCreationDate;
	}

	public String getApplicationStatusDesc() {
		return applicationStatusDesc;
	}

	public void setApplicationStatusDesc(String applicationStatusDesc) {
		this.applicationStatusDesc = applicationStatusDesc;
	}

	public CreditStatus getCreditStatus() {
		return creditStatus;
	}

	public void setCreditStatus(CreditStatus creditStatus) {
		this.creditStatus = creditStatus;
	}

	public DispositionDetails getDispositionDetails() {
		return dispositionDetails;
	}

	public void setDispositionDetails(DispositionDetails dispositionDetails) {
		this.dispositionDetails = dispositionDetails;
	}

	public AppSegmentationInfo getAppSegmentation() {
		return appSegmentation;
	}

	public void setAppSegmentation(AppSegmentationInfo appSegmentation) {
		this.appSegmentation = appSegmentation;
	}

	public ApplicationLoanDetails getApplicationLoanDetails() {
		return applicationLoanDetails;
	}

	public void setApplicationLoanDetails(ApplicationLoanDetails applicationLoanDetails) {
		this.applicationLoanDetails = applicationLoanDetails;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public PinCode getPincode() {
		return pincode;
	}

	public void setPincode(PinCode pincode) {
		this.pincode = pincode;
	}

	public String getApprovedFlag() {
		return approvedFlag;
	}

	public void setApprovedFlag(String approvedFlag) {
		this.approvedFlag = approvedFlag;
	}

	public String getBmr1ApprovedFlag() {
		return bmr1ApprovedFlag;
	}

	public void setBmr1ApprovedFlag(String bmr1ApprovedFlag) {
		this.bmr1ApprovedFlag = bmr1ApprovedFlag;
	}

	public String getBmr2ApprovedFlag() {
		return bmr2ApprovedFlag;
	}

	public void setBmr2ApprovedFlag(String bmr2ApprovedFlag) {
		this.bmr2ApprovedFlag = bmr2ApprovedFlag;
	}

	public String getDentalCouncil() {
		return dentalCouncil;
	}

	public void setDentalCouncil(String dentalCouncil) {
		this.dentalCouncil = dentalCouncil;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public Integer getSpecializationCode() {
		return specializationCode;
	}

	public void setSpecializationCode(Integer specializationCode) {
		this.specializationCode = specializationCode;
	}

	public String getDegreeCategory() {
		return degreeCategory;
	}

	public void setDegreeCategory(String degreeCategory) {
		this.degreeCategory = degreeCategory;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getYrOfAttainingCertificate() {
		return yrOfAttainingCertificate;
	}

	public void setYrOfAttainingCertificate(String yrOfAttainingCertificate) {
		this.yrOfAttainingCertificate = yrOfAttainingCertificate;
	}
	public String getJourneyStamp() {
		return journeyStamp;
	}

	public Integer getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(Integer requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public Integer getRequiredTenor() {
		return requiredTenor;
	}

	public void setRequiredTenor(Integer requiredTenor) {
		this.requiredTenor = requiredTenor;
	}

	public void setJourneyStamp(String journeyStamp) {
		this.journeyStamp = journeyStamp;
	}

	@Override
	public String toString() {
		return "ApplicationDetails [additionalParameterDetail=" + additionalParameterDetail + ", occupation="
				+ occupation + ", userProfile=" + userProfile + ", prodCategory=" + prodCategory
				+ ", mcpAddressDetails=" + mcpAddressDetails + ", panDetails=" + panDetails + ", addressList="
				+ addressList + ", princialSelectedbyCustomerDetail=" + princialSelectedbyCustomerDetail
				+ ", estimatedNetMonthlySalaryDetails=" + estimatedNetMonthlySalaryDetails + ", appScoreDetails="
				+ appScoreDetails + ", existingCustomerFlag=" + existingCustomerFlag + ", additionalCibilFlag="
				+ additionalCibilFlag + ", subStagePercentage=" + subStagePercentage + ", obligationAmount="
				+ obligationAmount + ", officialEmailId=" + officialEmailId + ", btBankMasterKey=" + btBankMasterKey
				+ ", btsSegment=" + btsSegment + ", hlProductIntent=" + hlProductIntent + ", creditObligation="
				+ creditObligation + ", coapplicantObligation=" + coapplicantObligation + ", coApplicantIncome="
				+ coApplicantIncome + ", deactivateOfferList=" + deactivateOfferList + ", propertyIdentifiedFlag="
				+ propertyIdentifiedFlag + ", cityKey=" + cityKey + ", bflBranchKey=" + bflBranchKey
				+ ", yearOfGraduation=" + yearOfGraduation + ", yearOfPostGraduation=" + yearOfPostGraduation
				+ ", specialization=" + specialization + ", registrationCouncil=" + registrationCouncil
				+ ", practiceType=" + practiceType + ", appCreationDate=" + appCreationDate + ", applicationStatusDesc="
				+ applicationStatusDesc + ", creditStatus=" + creditStatus + ", dispositionDetails="
				+ dispositionDetails + ", appSegmentation=" + appSegmentation + ", applicationLoanDetails="
				+ applicationLoanDetails + ", pincodekey=" + pincodekey + ", pincode=" + pincode + ", approvedFlag="
				+ approvedFlag + ", bmr1ApprovedFlag=" + bmr1ApprovedFlag + ", bmr2ApprovedFlag=" + bmr2ApprovedFlag
				+ ", dentalCouncil=" + dentalCouncil + ", degree=" + degree + ", specializationCode="
				+ specializationCode + ", degreeCategory=" + degreeCategory + ", registrationNumber="
				+ registrationNumber + ", yrOfAttainingCertificate=" + yrOfAttainingCertificate + ", journeyStamp="
				+ journeyStamp + ", requiredLoanAmount=" + requiredLoanAmount + ", requiredTenor=" + requiredTenor
				+ "]";
	}

}
