package com.bajaj.markets.credit.application.controller;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.helper.ResponseBean;

@ControllerAdvice
public class ApplicationsControllerAdvice extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(value = { CreditApplicationServiceException.class,ConstraintViolationException.class })
	protected ResponseEntity<?> handleConflict(RuntimeException ex, WebRequest request) {
		if(ex instanceof CreditApplicationServiceException){
			CreditApplicationServiceException exception = (CreditApplicationServiceException) ex;	
			if(null != exception.getErrorBean() && null != exception.getPayload()){
				return handleExceptionInternal(ex, new ResponseBean(exception.getPayload(), exception.getErrorBean()), new HttpHeaders(), exception.getCode(), request);
			}else if (null != exception.getErrorBean()){
				return handleExceptionInternal(ex, exception.getErrorBean(), new HttpHeaders(), exception.getCode(),request);
			}else if (null != exception.getPayload()){
				return handleExceptionInternal(ex, exception.getPayload(), new HttpHeaders(), exception.getCode(),request);
			}else{
				return handleExceptionInternal(ex, exception.getMessage(), new HttpHeaders(), exception.getCode(),request);
			}
		}else if(ex instanceof ConstraintViolationException){
			ConstraintViolationException exception = (ConstraintViolationException) ex;
			ConstraintViolation<?> constraintViolation = exception.getConstraintViolations().stream().findFirst().get();
			Integer size = constraintViolation.getPropertyPath().toString().split("\\.").length;
			String message = constraintViolation.getMessage();
			if(size<3){
				ErrorBean errorBean = new ErrorBean(HttpStatus.NOT_FOUND.name(), message);
				return handleExceptionInternal(ex, errorBean, new HttpHeaders(), HttpStatus.NOT_FOUND,request);
			}else{
				ErrorBean errorBean = new ErrorBean(HttpStatus.UNPROCESSABLE_ENTITY.name(), message);
				return handleExceptionInternal(ex, errorBean, new HttpHeaders(), HttpStatus.UNPROCESSABLE_ENTITY,request);
			}	
		}
		ErrorBean errorBean = new ErrorBean(HttpStatus.INTERNAL_SERVER_ERROR.name(), ex.getMessage());
		return handleExceptionInternal(ex, errorBean, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR,request);
		
	}

}
