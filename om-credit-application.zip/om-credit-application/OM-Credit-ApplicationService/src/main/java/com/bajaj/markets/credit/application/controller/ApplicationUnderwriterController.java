package com.bajaj.markets.credit.application.controller;

import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.BrePreferredBankResponse;
import com.bajaj.markets.credit.application.bean.MandateBreRequest;
import com.bajaj.markets.credit.application.bean.OrmSystemCheckRequest;
import com.bajaj.markets.credit.application.bean.OrmSystemCheckResponse;
import com.bajaj.markets.credit.application.bean.OrmVerificationSourceDetail;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationUnderwriterService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationUnderwriterController {
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	ApplicationUnderwriterService  applicationUnderwriterService;
	private static final String CLASSNAME = ApplicationUnderwriterController.class.getName();
	
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Application uwchecks  detail endpoint", notes = "save application uwchecks detail", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "uwchecks Details updated Successfully.", response = String.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/creditapplication/applications/{applicationKey}/underwriter-checks", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> updateApplicationUwchecks(@RequestBody List<OrmVerificationSourceDetail> ormVerificationSourceDetailList,
			@PathVariable("applicationKey") @NotBlank(message = "applicationKey can not be null or empty")@Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size")  String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateApplicationUwchecks controller with applicationId: " + applicationId);
			
		return new ResponseEntity<> (applicationUnderwriterService.updateUnderwriterChecksDetail(applicationId,ormVerificationSourceDetailList,headers), HttpStatus.OK);
	}
	
	
	
}
