package com.bajaj.markets.credit.application.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "interface_system", schema = "dmcredit")
public class InterfaceSystem implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long systemkey;

	private Integer isactive;

	private Long principalkey;

	private String systemcode;


	public InterfaceSystem() {
		// Not required
	}

	public Long getSystemkey() {
		return this.systemkey;
	}

	public void setSystemkey(Long systemkey) {
		this.systemkey = systemkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getPrincipalkey() {
		return principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

	public String getSystemcode() {
		return systemcode;
	}

	public void setSystemcode(String systemcode) {
		this.systemcode = systemcode;
	}

}