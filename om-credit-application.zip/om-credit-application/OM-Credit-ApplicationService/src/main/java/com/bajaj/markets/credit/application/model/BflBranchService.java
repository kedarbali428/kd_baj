package com.bajaj.markets.credit.application.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the BFL_BRANCH_SERVICES database table.
 * 
 */
@Entity
@Table(name="BFL_BRANCH_SERVICES", schema = "dmcredit")
public class BflBranchService implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long bflbranchservicekey;

	private BigDecimal prodcatkey;

	private Integer citykey;
	
	private BigDecimal occupationkey;

	private BigDecimal isactive;
	
	private String prodkey;
	
	private Integer bflbranchkey;

	public long getBflbranchservicekey() {
		return bflbranchservicekey;
	}

	public void setBflbranchservicekey(long bflbranchservicekey) {
		this.bflbranchservicekey = bflbranchservicekey;
	}

	public BigDecimal getProdcatkey() {
		return prodcatkey;
	}

	public void setProdcatkey(BigDecimal prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public int getCitykey() {
		return citykey;
	}

	public void setCitykey(int citykey) {
		this.citykey = citykey;
	}

	public BigDecimal getOccupationkey() {
		return occupationkey;
	}

	public void setOccupationkey(BigDecimal occupationkey) {
		this.occupationkey = occupationkey;
	}

	public BigDecimal getIsactive() {
		return isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getProdkey() {
		return prodkey;
	}

	public void setProdkey(String prodkey) {
		this.prodkey = prodkey;
	}

	public Integer getBflbranchkey() {
		return bflbranchkey;
	}

	public void setBflbranchkey(Integer bflbranchkey) {
		this.bflbranchkey = bflbranchkey;
	}

	public void setCitykey(Integer citykey) {
		this.citykey = citykey;
	}

}
