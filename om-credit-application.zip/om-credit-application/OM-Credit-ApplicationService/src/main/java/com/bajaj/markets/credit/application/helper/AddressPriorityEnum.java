package com.bajaj.markets.credit.application.helper;


public enum AddressPriorityEnum {

	JOURNEY(1), 
	OFFERAPI(2), 
	APPLICANT(3), 
	BMR(4), 
	BMR2(5), 
	KYC_BFL(6), 
	CIBIL(7);

	private final Integer value;

	private AddressPriorityEnum(Integer value) {
		this.value = value;
	}

	public Integer getValue() {
		return this.value;
	}

}
