package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.bajaj.markets.credit.application.helper.CamelCaseConverter;
import com.bajaj.markets.credit.application.helper.UpperCaseConverter;

/**
 * The persistent class for the application_attribute database table.
 * 
 */
@Entity
@Table(name = "application_attribute", schema = "dmcredit")
public class ApplicationAttribute implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "application_attribute_appattrbkey_generator", sequenceName = "dmcredit.seq_pk_application_attribute", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_attribute_appattrbkey_generator")
	private Long appattrbkey;

	@Temporal(TemporalType.DATE)
	private Date dob;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long mobile;

	@Convert(converter = CamelCaseConverter.class)
	private String firstname;

	@Convert(converter = CamelCaseConverter.class)
	private String middlename;

	@Convert(converter = CamelCaseConverter.class)
	private String lastname;

	private Long salutationkey;

	private Long maritalstatuskey;

	private Long genderkey;

	private Long residencetypekey;

	private Long applicantkey;

	@Convert(converter = UpperCaseConverter.class)
	private String pan;

	private Long applicanttype;

	private String qualification;

	private String mothername;

	private String fathername;

	private Long langkey;

	private Long nationalitykey;

	private Integer custcategorycdkey;

	private Long relationcodemastkey;

	private Long coapplicantobligation;
	
	private String segment;

	private Long cibilreferencekey;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "applicationkey")
	private Application application;
	
	private Boolean workemailrequired;
	
	private String nametobeprintedoncard;

	public ApplicationAttribute() {
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public Long getAppattrbkey() {
		return this.appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getMobile() {
		return this.mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Long getSalutationkey() {
		return salutationkey;
	}

	public void setSalutationkey(Long salutationkey) {
		this.salutationkey = salutationkey;
	}

	public Long getMaritalstatuskey() {
		return maritalstatuskey;
	}

	public void setMaritalstatuskey(Long maritalstatuskey) {
		this.maritalstatuskey = maritalstatuskey;
	}

	public Long getGenderkey() {
		return genderkey;
	}

	public void setGenderkey(Long genderkey) {
		this.genderkey = genderkey;
	}

	public Long getResidencetypekey() {
		return residencetypekey;
	}

	public void setResidencetypekey(Long residencetypekey) {
		this.residencetypekey = residencetypekey;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public Long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public Long getApplicanttype() {
		return applicanttype;
	}

	public void setApplicanttype(Long applicanttype) {
		this.applicanttype = applicanttype;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getMothername() {
		return mothername;
	}

	public void setMothername(String mothername) {
		this.mothername = mothername;
	}

	public String getFathername() {
		return fathername;
	}

	public void setFathername(String fathername) {
		this.fathername = fathername;
	}

	public Long getLangkey() {
		return langkey;
	}

	public void setLangkey(Long langkey) {
		this.langkey = langkey;
	}

	public Long getNationalitykey() {
		return nationalitykey;
	}

	public void setNationalitykey(Long nationalitykey) {
		this.nationalitykey = nationalitykey;
	}

	public Integer getCustcategorycdkey() {
		return custcategorycdkey;
	}

	public void setCustcategorycdkey(Integer custcategorycdkey) {
		this.custcategorycdkey = custcategorycdkey;
	}

	public Long getRelationcodemastkey() {
		return relationcodemastkey;
	}

	public void setRelationcodemastkey(Long relationcodemastkey) {
		this.relationcodemastkey = relationcodemastkey;
	}

	public Long getCoapplicantobligation() {
		return coapplicantobligation;
	}

	public void setCoapplicantobligation(Long coapplicantobligation) {
		this.coapplicantobligation = coapplicantobligation;
	}
	

	public Boolean getWorkemailrequired() {
		return workemailrequired;
	}

	public void setWorkemailrequired(Boolean workemailrequired) {
		this.workemailrequired = workemailrequired;
	}

	public String getNametobeprintedoncard() {
		return nametobeprintedoncard;
	}

	public void setNametobeprintedoncard(String nametobeprintedoncard) {
		this.nametobeprintedoncard = nametobeprintedoncard;
	}

	public Long getCibilreferencekey() {
		return cibilreferencekey;
	}

	public void setCibilreferencekey(Long cibilreferencekey) {
		this.cibilreferencekey = cibilreferencekey;
	}

	@Override
	public ApplicationAttribute clone() throws CloneNotSupportedException {
		ApplicationAttribute attribute = new ApplicationAttribute();
		attribute.setDob(this.dob);
		attribute.setIsactive(this.isactive);
		attribute.setLstupdateby(this.lstupdateby);
		attribute.setLstupdatedt(this.lstupdatedt);
		attribute.setMobile(this.mobile);
		attribute.setFirstname(this.firstname);
		attribute.setMiddlename(this.middlename);
		attribute.setLastname(this.lastname);
		attribute.setSalutationkey(this.salutationkey);
		attribute.setMaritalstatuskey(this.maritalstatuskey);
		attribute.setGenderkey(this.genderkey);
		attribute.setResidencetypekey(this.residencetypekey);
		attribute.setApplicantkey(this.applicantkey);
		attribute.setPan(this.pan);
		attribute.setApplicanttype(this.applicanttype);
		attribute.setQualification(this.qualification);
		attribute.setMothername(this.mothername);
		attribute.setFathername(this.fathername);
		attribute.setApplication(this.application);
		attribute.setLangkey(this.langkey);
		attribute.setNationalitykey(this.nationalitykey);
		attribute.setCoapplicantobligation(this.coapplicantobligation);
		attribute.setWorkemailrequired(this.workemailrequired);
		attribute.setNametobeprintedoncard(this.nametobeprintedoncard);
		return attribute;
	}


}
