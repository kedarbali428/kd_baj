package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_credit_review_detail", schema = "dmcredit")
public class AppCreditReviewDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "appCreditReviewDetail_creditreviewdetkey_generator", sequenceName = "dmcredit.seq_pk_app_credit_review_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "appCreditReviewDetail_creditreviewdetkey_generator")
	private Long creditreviewdetkey;

	private Long applicationkey;

	private Long prodkey;

	private String source;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	@ManyToOne
	@JoinColumn(name = "creditreviewkey")
	private CreditReviewCode creditReviewCode;

	public Long getCreditreviewdetkey() {
		return creditreviewdetkey;
	}

	public void setCreditreviewdetkey(Long creditreviewdetkey) {
		this.creditreviewdetkey = creditreviewdetkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public CreditReviewCode getCreditReviewCode() {
		return creditReviewCode;
	}

	public void setCreditReviewCode(CreditReviewCode creditReviewCode) {
		this.creditReviewCode = creditReviewCode;
	}

}
