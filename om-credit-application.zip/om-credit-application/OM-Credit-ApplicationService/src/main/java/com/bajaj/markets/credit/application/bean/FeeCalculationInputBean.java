package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.NotNull;

public class FeeCalculationInputBean {

	@NotNull(message = "occupationtype can not be null")
	private String occupationtype;

	public String getOccupationtype() {
		return occupationtype;
	}

	public void setOccupationtype(String occupationtype) {
		this.occupationtype = occupationtype;
	}

	@Override
	public String toString() {
		return "FeeCalculationInputBean [occupationtype=" + occupationtype + "]";
	}




}
