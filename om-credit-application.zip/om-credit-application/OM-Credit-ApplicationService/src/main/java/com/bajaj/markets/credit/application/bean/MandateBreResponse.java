package com.bajaj.markets.credit.application.bean;

public class MandateBreResponse {
	
	private MandateOutput mandateOutput;
	private String action;
	/**
	 * @return the mandateOutput
	 */
	public MandateOutput getMandateOutput() {
		return mandateOutput;
	}
	/**
	 * @param mandateOutput the mandateOutput to set
	 */
	public void setMandateOutput(MandateOutput mandateOutput) {
		this.mandateOutput = mandateOutput;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
     
}
