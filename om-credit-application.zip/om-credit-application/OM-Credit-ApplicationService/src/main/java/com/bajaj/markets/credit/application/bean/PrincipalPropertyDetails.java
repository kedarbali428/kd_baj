package com.bajaj.markets.credit.application.bean;

public class PrincipalPropertyDetails {

	private Long appPropertyDetKey;

	private Integer isPropertyIdentified;

	public Long getAppPropertyDetKey() {
		return appPropertyDetKey;
	}

	public void setAppPropertyDetKey(Long appPropertyDetKey) {
		this.appPropertyDetKey = appPropertyDetKey;
	}

	public Integer getIsPropertyIdentified() {
		return isPropertyIdentified;
	}

	public void setIsPropertyIdentified(Integer isPropertyIdentified) {
		this.isPropertyIdentified = isPropertyIdentified;
	}

	@Override
	public String toString() {
		return "PrincipalPropertyDetails [appPropertyDetKey=" + appPropertyDetKey + ", isPropertyIdentified="
				+ isPropertyIdentified + "]";
	}

}
