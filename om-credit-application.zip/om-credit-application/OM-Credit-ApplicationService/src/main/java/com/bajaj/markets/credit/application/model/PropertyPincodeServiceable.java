package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author sujit.lole
 *
 *         Aug 11, 2020
 *
 */
@Entity
@Table(name = "property_pincode_serviceable", schema = "dmcredit")
public class PropertyPincodeServiceable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer proppinservicekey;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Long pincodekey;
	private Long prodkey;
	private String citycode;

	public PropertyPincodeServiceable() {
	}

	public Integer getProppinservicekey() {
		return this.proppinservicekey;
	}

	public void setProppinservicekey(Integer proppinservicekey) {
		this.proppinservicekey = proppinservicekey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getPincodekey() {
		return this.pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public Long getProdkey() {
		return this.prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getCitycode() {
		return citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

}