package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class EmployeeRequest implements Serializable{

	private static final long serialVersionUID = 1L;

    private String emprmastId;
	
	private String employerName;
	
	private String officialEmailID;
	
	private String otherEmployerName;
	
	public String getEmprmastId() {
		return emprmastId;
	}

	public void setEmprmastId(String emprmastId) {
		this.emprmastId = emprmastId;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getOfficialEmailID() {
		return officialEmailID;
	}

	public void setOfficialEmailID(String officialEmailID) {
		this.officialEmailID = officialEmailID;
	}

	public String getOtherEmployerName() {
		return otherEmployerName;
	}

	public void setOtherEmployerName(String otherEmployerName) {
		this.otherEmployerName = otherEmployerName;
	}
	
}
