package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class PrincialSelectedbyCustomer {

	private String principalSelectedByCustomer;
	private Long requiredLoanAmount;
	private Integer tenor;
	private Boolean isEligible;
	private String principleProductCode;
	private String offerType;
	private String eligibilityType;
	private String riskOfferType;
	private String loanTypeRecommendation;
	private String loanTypeName;
	private String promotionalOffer;
	private List<FeesList> feesList;
	private Integer isTenor;
	private Integer dropLineTenor;
	private Float emiAmount;
	private BaseRate baseRate;
	private List<DueDateDetails> dueDateDetails;
	private List<NextDueDateDetails> nextDueDateDetails;
	private BigDecimal roi;
	private String preApproved;
	private Float bScore;
	private String approvalChances;
	private Integer priorityOrder;
	private Boolean fppApplicable;
	private Boolean perfiosRequired;
	private String productSize;
	private String pennantloanTypeRecommendation;
	private Long eligibilityAmount;
	private BigDecimal finalUnsecuredFoir;
	private BigDecimal applicableMultiplier;
	private BigDecimal multiplierEligibility;
	private BigDecimal finalFoir;
	private BigDecimal finalMultiplier;
	private BigDecimal maxEmiAsPerFoir;
	private BigDecimal foirEligibilityEmi;
	private List<String> rejectCodeList;
	private String cardTag;
	private String ctaName;
	private List<String> creditReviewCodes;
	private List<String> deviationCodes;
	private String isEligiblityChanged;
	private Boolean toBeDisplayedOnListingPage;
	private String statementToBeCollected;
	private Boolean pricingFlag;
	private BigDecimal netDisbursementAmount;
	private BigDecimal testPricingRoi;
	private String honouredPricingSource;

	public String getHonouredPricingSource() {
		return honouredPricingSource;
	}

	public void setHonouredPricingSource(String honouredPricingSource) {
		this.honouredPricingSource = honouredPricingSource;
	}
	
	public BigDecimal getTestPricingRoi() {
		return testPricingRoi;
	}

	public void setTestPricingRoi(BigDecimal testPricingRoi) {
		this.testPricingRoi = testPricingRoi;
	}

	public String getIsEligiblityChanged() {
		return isEligiblityChanged;
	}

	public void setIsEligiblityChanged(String isEligiblityChanged) {
		this.isEligiblityChanged = isEligiblityChanged;
	}

	public String getLoanTypeName() {
		return loanTypeName;
	}

	public void setLoanTypeName(String loanTypeName) {
		this.loanTypeName = loanTypeName;
	}

	public String getPromotionalOffer() {
		return promotionalOffer;
	}

	public void setPromotionalOffer(String promotionalOffer) {
		this.promotionalOffer = promotionalOffer;
	}

	public String getProductSize() {
		return productSize;
	}

	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}

	public BigDecimal getFinalUnsecuredFoir() {
		return finalUnsecuredFoir;
	}

	public void setFinalUnsecuredFoir(BigDecimal finalUnsecuredFoir) {
		this.finalUnsecuredFoir = finalUnsecuredFoir;
	}

	public BigDecimal getFinalFoir() {
		return finalFoir;
	}

	public void setFinalFoir(BigDecimal finalFoir) {
		this.finalFoir = finalFoir;
	}

	public BigDecimal getMaxEmiAsPerFoir() {
		return maxEmiAsPerFoir;
	}

	public void setMaxEmiAsPerFoir(BigDecimal maxEmiAsPerFoir) {
		this.maxEmiAsPerFoir = maxEmiAsPerFoir;
	}

	public BigDecimal getFoirEligibilityEmi() {
		return foirEligibilityEmi;
	}

	public void setFoirEligibilityEmi(BigDecimal foirEligibilityEmi) {
		this.foirEligibilityEmi = foirEligibilityEmi;
	}

	public Long getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(Long requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public Integer getTenor() {
		return tenor;
	}

	public void setTenor(Integer tenor) {
		this.tenor = tenor;
	}

	public Long getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(Long eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public List<String> getRejectCodeList() {
		return rejectCodeList;
	}

	public void setRejectCodeList(List<String> rejectCodeList) {
		this.rejectCodeList = rejectCodeList;
	}

	public BigDecimal getApplicableMultiplier() {
		return applicableMultiplier;
	}

	public void setApplicableMultiplier(BigDecimal applicableMultiplier) {
		this.applicableMultiplier = applicableMultiplier;
	}

	public BigDecimal getMultiplierEligibility() {
		return multiplierEligibility;
	}

	public void setMultiplierEligibility(BigDecimal multiplierEligibility) {
		this.multiplierEligibility = multiplierEligibility;
	}

	public BigDecimal getFinalMultiplier() {
		return finalMultiplier;
	}

	public void setFinalMultiplier(BigDecimal finalMultiplier) {
		this.finalMultiplier = finalMultiplier;
	}

	public List<DueDateDetails> getDueDateDetails() {
		return dueDateDetails;
	}

	public void setDueDateDetails(List<DueDateDetails> dueDateDetails) {
		this.dueDateDetails = dueDateDetails;
	}

	public List<NextDueDateDetails> getNextDueDateDetails() {
		return nextDueDateDetails;
	}

	public void setNextDueDateDetails(List<NextDueDateDetails> nextDueDateDetails) {
		this.nextDueDateDetails = nextDueDateDetails;
	}

	public String getPennantloanTypeRecommendation() {
		return pennantloanTypeRecommendation;
	}

	public void setPennantloanTypeRecommendation(String pennantloanTypeRecommendation) {
		this.pennantloanTypeRecommendation = pennantloanTypeRecommendation;
	}

	public Boolean getIsEligible() {
		return isEligible;
	}

	public void setIsEligible(Boolean isEligible) {
		this.isEligible = isEligible;
	}

	public String getPrincipleProductCode() {
		return principleProductCode;
	}

	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getEligibilityType() {
		return eligibilityType;
	}

	public void setEligibilityType(String eligibilityType) {
		this.eligibilityType = eligibilityType;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public String getLoanTypeRecommendation() {
		return loanTypeRecommendation;
	}

	public void setLoanTypeRecommendation(String loanTypeRecommendation) {
		this.loanTypeRecommendation = loanTypeRecommendation;
	}

	public List<FeesList> getFeesList() {
		return feesList;
	}

	public void setFeesList(List<FeesList> feesList) {
		this.feesList = feesList;
	}

	public Integer getIsTenor() {
		return isTenor;
	}

	public void setIsTenor(Integer isTenor) {
		this.isTenor = isTenor;
	}

	public Integer getDropLineTenor() {
		return dropLineTenor;
	}

	public void setDropLineTenor(Integer dropLineTenor) {
		this.dropLineTenor = dropLineTenor;
	}

	public Float getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(Float emiAmount) {
		this.emiAmount = emiAmount;
	}

	public BaseRate getBaseRate() {
		return baseRate;
	}

	public void setBaseRate(BaseRate baseRate) {
		this.baseRate = baseRate;
	}

	public BigDecimal getRoi() {
		return roi;
	}

	public void setRoi(BigDecimal roi) {
		this.roi = roi;
	}

	public String getPreApproved() {
		return preApproved;
	}

	public void setPreApproved(String preApproved) {
		this.preApproved = preApproved;
	}

	public Float getbScore() {
		return bScore;
	}

	public void setbScore(Float bScore) {
		this.bScore = bScore;
	}

	public String getApprovalChances() {
		return approvalChances;
	}

	public void setApprovalChances(String approvalChances) {
		this.approvalChances = approvalChances;
	}

	public Integer getPriorityOrder() {
		return priorityOrder;
	}

	public void setPriorityOrder(Integer priorityOrder) {
		this.priorityOrder = priorityOrder;
	}

	public Boolean getFppApplicable() {
		return fppApplicable;
	}

	public void setFppApplicable(Boolean fppApplicable) {
		this.fppApplicable = fppApplicable;
	}

	public Boolean getPerfiosRequired() {
		return perfiosRequired;
	}

	public void setPerfiosRequired(Boolean perfiosRequired) {
		this.perfiosRequired = perfiosRequired;
	}

	public String getCardTag() {
		return cardTag;
	}

	public void setCardTag(String cardTag) {
		this.cardTag = cardTag;
	}

	public String getCtaName() {
		return ctaName;
	}

	public void setCtaName(String ctaName) {
		this.ctaName = ctaName;
	}

	public List<String> getCreditReviewCodes() {
		return creditReviewCodes;
	}

	public void setCreditReviewCodes(List<String> creditReviewCodes) {
		this.creditReviewCodes = creditReviewCodes;
	}

	public List<String> getDeviationCodes() {
		return deviationCodes;
	}

	public void setDeviationCodes(List<String> deviationCodes) {
		this.deviationCodes = deviationCodes;
	}

	public Boolean getToBeDisplayedOnListingPage() {
		return toBeDisplayedOnListingPage;
	}

	public void setToBeDisplayedOnListingPage(Boolean toBeDisplayedOnListingPage) {
		this.toBeDisplayedOnListingPage = toBeDisplayedOnListingPage;
	}

	public String getPrincipalSelectedByCustomer() {
		return principalSelectedByCustomer;
	}

	public void setPrincipalSelectedByCustomer(String principalSelectedByCustomer) {
		this.principalSelectedByCustomer = principalSelectedByCustomer;
	}

	public String getStatementToBeCollected() {
		return statementToBeCollected;
	}

	public void setStatementToBeCollected(String statementToBeCollected) {
		this.statementToBeCollected = statementToBeCollected;
	}

	public Boolean getPricingFlag() {
		return pricingFlag;
	}

	public void setPricingFlag(Boolean pricingFlag) {
		this.pricingFlag = pricingFlag;
	}

	public BigDecimal getNetDisbursementAmount() {
		return netDisbursementAmount;
	}

	public void setNetDisbursementAmount(BigDecimal netDisbursementAmount) {
		this.netDisbursementAmount = netDisbursementAmount;
	}

	@Override
	public String toString() {
		return "PrincialSelectedbyCustomer [principalSelectedByCustomer=" + principalSelectedByCustomer
				+ ", requiredLoanAmount=" + requiredLoanAmount + ", tenor=" + tenor + ", isEligible=" + isEligible
				+ ", principleProductCode=" + principleProductCode + ", offerType=" + offerType + ", eligibilityType="
				+ eligibilityType + ", riskOfferType=" + riskOfferType + ", loanTypeRecommendation="
				+ loanTypeRecommendation + ", loanTypeName=" + loanTypeName + ", promotionalOffer=" + promotionalOffer
				+ ", feesList=" + feesList + ", isTenor=" + isTenor + ", dropLineTenor=" + dropLineTenor
				+ ", emiAmount=" + emiAmount + ", baseRate=" + baseRate + ", dueDateDetails=" + dueDateDetails
				+ ", nextDueDateDetails=" + nextDueDateDetails + ", roi=" + roi + ", preApproved=" + preApproved
				+ ", bScore=" + bScore + ", approvalChances=" + approvalChances + ", priorityOrder=" + priorityOrder
				+ ", fppApplicable=" + fppApplicable + ", perfiosRequired=" + perfiosRequired + ", productSize="
				+ productSize + ", pennantloanTypeRecommendation=" + pennantloanTypeRecommendation
				+ ", eligibilityAmount=" + eligibilityAmount + ", finalUnsecuredFoir=" + finalUnsecuredFoir
				+ ", applicableMultiplier=" + applicableMultiplier + ", multiplierEligibility=" + multiplierEligibility
				+ ", finalFoir=" + finalFoir + ", finalMultiplier=" + finalMultiplier + ", maxEmiAsPerFoir="
				+ maxEmiAsPerFoir + ", foirEligibilityEmi=" + foirEligibilityEmi + ", rejectCodeList=" + rejectCodeList
				+ ", cardTag=" + cardTag + ", ctaName=" + ctaName + ", creditReviewCodes=" + creditReviewCodes
				+ ", deviationCodes=" + deviationCodes + ", isEligiblityChanged=" + isEligiblityChanged
				+ ", toBeDisplayedOnListingPage=" + toBeDisplayedOnListingPage + ", statementToBeCollected="
				+ statementToBeCollected + ", pricingFlag=" + pricingFlag + ", netDisbursementAmount="
				+ netDisbursementAmount + ", testPricingRoi=" + testPricingRoi + ", honouredPricingSource="
				+ honouredPricingSource + "]";
	}

}
