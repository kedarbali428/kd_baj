package com.bajaj.markets.credit.application.dao;

import com.bajaj.markets.credit.application.model.AppAppsScore;
import com.bajaj.markets.credit.application.model.AppFinObligation;
import com.bajaj.markets.credit.application.model.AppSegmentation;

public interface ApplicationAnalyticsDataDao {

	/**
	 * 
	 * This method is used to create or update app_segmentation record bases applicationkey
	 * 
	 * @param appSegmentation
	 * @return
	 */
	public AppSegmentation updateAppSegmentation(AppSegmentation appSegmentation);
	
	/**
	 * This method is used to create or update app_apps_score record bases applicationkey
	 * 
	 * @param appAppsScore
	 * @return
	 */
	public AppAppsScore updateAppAppsScore(AppAppsScore appAppsScore);
	
	/**
	 * 
	 * This method is used to create or update app_fin_obligation record bases applicationkey and source
	 * 
	 * @param appFinObligation
	 * @return
	 */
	public AppFinObligation updateAppFinObligation(AppFinObligation appFinObligation);
}
