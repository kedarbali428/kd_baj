package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/* Bean to hold required data of AppPlanDetCost (Cost details of application)
*/
public class AppPlanDetCostBean implements Serializable {
	private static final long serialVersionUID = -5087969800341921896L;

	private String appPlanDetkey;
	
	private String applicationKey;
	  
	@NotNull(message = "FloorPrice can not be null")
	@Digits(fraction = 2, integer = 20, message = "floorPrice can not be other than digits")
    private double floorPrice;
    private double maxPrice;
    private double oldProfit;
    private double newProfit;
    @NotNull(message = "actualPrice can not be null")
    @Digits(fraction = 2, integer = 20, message = "actualPrice can not be other than digits")
    private double actualPrice;
    private float saveRoi;
    private float withPlanRoi;
    private double savingAmount;
    
	@Pattern(regexp = "JOURNEY|EMPLOYEE_PORTAL", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Please enter a valid value - JOURNEY|EMPLOYEE_PORTAL")
    @NotBlank(message = "Source can not be null/empty")
    private String source; // sample value "JOURNEY", "EMPLOYEE_PORTAL"
    
    @NotBlank(message = "Status can not be null/empty")
    @Pattern(regexp = "Pending_Approval|Rejected|Approved", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Please enter a valid value - Pending_Approval|Rejected|Approved")
    private String status; // sample value "APPROVED", "PENDING_APPROVAL", "REJECTED"
    
    private String raisedBy;
    private String approvedBy;
    
    public AppPlanDetCostBean() {
    	//Constructor
	}
    
	public String getAppPlanDetkey() {
		return appPlanDetkey;
	}

	public void setAppPlanDetkey(String appPlanDetkey) {
		this.appPlanDetkey = appPlanDetkey;
	}
	public String getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	public double getFloorPrice() {
		return floorPrice;
	}
	public void setFloorPrice(double floorPrice) {
		this.floorPrice = floorPrice;
	}
	public double getMaxPrice() {
		return maxPrice;
	}
	public void setMaxPrice(double maxPrice) {
		this.maxPrice = maxPrice;
	}
	public double getOldProfit() {
		return oldProfit;
	}
	public void setOldProfit(double oldProfit) {
		this.oldProfit = oldProfit;
	}
	public double getNewProfit() {
		return newProfit;
	}
	public void setNewProfit(double newProfit) {
		this.newProfit = newProfit;
	}
	public double getActualPrice() {
		return actualPrice;
	}
	public void setActualPrice(double actualPrice) {
		this.actualPrice = actualPrice;
	}
	public float getSaveRoi() {
		return saveRoi;
	}
	public void setSaveRoi(float saveRoi) {
		this.saveRoi = saveRoi;
	}
	public float getWithPlanRoi() {
		return withPlanRoi;
	}

	public void setWithPlanRoi(float withPlanRoi) {
		this.withPlanRoi = withPlanRoi;
	}

	public double getSavingAmount() {
		return savingAmount;
	}

	public void setSavingAmount(double savingAmount) {
		this.savingAmount = savingAmount;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getRaisedBy() {
		return raisedBy;
	}
	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}