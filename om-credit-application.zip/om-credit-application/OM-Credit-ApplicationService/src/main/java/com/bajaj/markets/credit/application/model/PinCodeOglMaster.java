package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "pin_code_ogl_master", schema = "dmcredit")
public class PinCodeOglMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long pincodeoglkey;
	
	private Long pincodekey;
	
	private Long prodkey;
	
	private String cityname;
	
	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;
	
	public PinCodeOglMaster() {
	}

	public Long getPincodeoglkey() {
		return pincodeoglkey;
	}

	public void setPincodeoglkey(Long pincodeoglkey) {
		this.pincodeoglkey = pincodeoglkey;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

}
