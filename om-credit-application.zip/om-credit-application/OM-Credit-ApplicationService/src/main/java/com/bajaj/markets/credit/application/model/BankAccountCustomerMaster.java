package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bank_account_catagory_master", schema = "dmcredit")
public class BankAccountCustomerMaster {

	@Id
	private Integer bankacctcatkey;
	private String bankacctcatcode;
	private String bankacctcatname;
	private Integer isactive;
	private Timestamp lstupdatedt;

	public BankAccountCustomerMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getBankacctcatkey() {
		return bankacctcatkey;
	}

	public void setBankacctcatkey(Integer bankacctcatkey) {
		this.bankacctcatkey = bankacctcatkey;
	}

	public String getBankacctcatcode() {
		return bankacctcatcode;
	}

	public void setBankacctcatcode(String bankacctcatcode) {
		this.bankacctcatcode = bankacctcatcode;
	}

	public String getBankacctcatname() {
		return bankacctcatname;
	}

	public void setBankacctcatname(String bankacctcatname) {
		this.bankacctcatname = bankacctcatname;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}
