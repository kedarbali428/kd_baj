package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class PrincipalProductOutput {
	
	private Integer cardPriority;
	private String principleProductCode;
	private List<String> rejectCodeList;
	private Boolean isEligible;
	private Float bScore;
	private String cardTag;
	private String approvalChances;
	private String ctaName;
	private Boolean toBeDisplayedOnListingPage; 
	
	public Float getbScore() {
		return bScore;
	}
	public void setbScore(Float bScore) {
		this.bScore = bScore;
	}
	public Integer getCardPriority() {
		return cardPriority;
	}
	public void setCardPriority(Integer cardPriority) {
		this.cardPriority = cardPriority;
	}
	public String getPrincipleProductCode() {
		return principleProductCode;
	}
	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}
	public List<String> getRejectCodeList() {
		return rejectCodeList;
	}
	public void setRejectCodeList(List<String> rejectCodeList) {
		this.rejectCodeList = rejectCodeList;
	}
	public Boolean getIsEligible() {
		return isEligible;
	}
	public void setIsEligible(Boolean isEligible) {
		this.isEligible = isEligible;
	}

	public String getCardTag() {
		return cardTag;
	}

	public void setCardTag(String cardTag) {
		this.cardTag = cardTag;
	}

	public String getApprovalChances() {
		return approvalChances;
	}

	public void setApprovalChances(String approvalChances) {
		this.approvalChances = approvalChances;
	}

	public String getCtaName() {
		return ctaName;
	}

	public void setCtaName(String ctaName) {
		this.ctaName = ctaName;
	}
	
	public Boolean getToBeDisplayedOnListingPage() {
		return toBeDisplayedOnListingPage;
	}
	
	public void setToBeDisplayedOnListingPage(Boolean toBeDisplayedOnListingPage) {
		this.toBeDisplayedOnListingPage = toBeDisplayedOnListingPage;
	}
	

}
