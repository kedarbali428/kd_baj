package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the btbank_serviceable database table.
 * OMSECURED-21
 */
@Entity
@Table(name = "btbank_serviceable", schema = "dmcredit")
public class BtbankServiceable implements Serializable  {
	

	private static final long serialVersionUID = 1L;

	@Id
	private Integer btbankservicekey;
	private Integer bankmastkey;
	private Long prodkey;
	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;





	public BtbankServiceable() {
	}

	

	public Integer getBtbankservicekey() {
		return btbankservicekey;
	}



	public void setBtbankservicekey(Integer btbankservicekey) {
		this.btbankservicekey = btbankservicekey;
	}



	public Integer getBankmastkey() {
		return bankmastkey;
	}



	public void setBankmastkey(Integer bankmastkey) {
		this.bankmastkey = bankmastkey;
	}



	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	

	public Long getProdkey() {
		return this.prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}


}
