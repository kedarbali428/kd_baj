package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class PrincipalProductDet {

	String principleProductCode;
	private List<Rejection> rejectionList;
	private PinCode pincode;
	private PinCode officePinCode;
	
	//adding for len-527
	private List<OfferDetails> offerDetails;
	private String employerType;
	private String employerCat;
	private String employerSubCat;
	private Boolean existingCustomerType;
	//private String existingCustomerType;
	private String principleCustType;
	//Adding Additional parameter as part of JIRAID Len-535
	private String dedupeJson;
	private List<String> deviationCodes;
	private Boolean bflApplicableLocationFlag;
	// OMSECURED-21 start
	private PropertyPincode propertyPincode;
	private Boolean isBTBankServicebaleFlag;
	private LoanApprovalDetails loanApprovalDetails;
	private Long principleKey;
	
	private String partnerDetailsJson;
	
	public PropertyPincode getPropertyPincode() {
		return propertyPincode;
	}

	public void setPropertyPincode(PropertyPincode propertyPincode) {
		this.propertyPincode = propertyPincode;
	}

	public Boolean getIsBTBankServicebaleFlag() {
		return isBTBankServicebaleFlag;
	}

	public void setIsBTBankServicebaleFlag(Boolean isBTBankServicebaleFlag) {
		this.isBTBankServicebaleFlag = isBTBankServicebaleFlag;
	}

	// OMSECURED-21 End
	public String getPrincipleCustType() {
		return principleCustType;
	}

	public void setPrincipleCustType(String principleCustType) {
		this.principleCustType = principleCustType;
	}

	public List<OfferDetails> getOfferDetails() {
		return offerDetails;
	}

	public void setOfferDetails(List<OfferDetails> offerDetails) {
		this.offerDetails = offerDetails;
	}

	public String getEmployerType() {
		return employerType;
	}

	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}

	public String getEmployerCat() {
		return employerCat;
	}

	public void setEmployerCat(String employerCat) {
		this.employerCat = employerCat;
	}

	public Boolean getExistingCustomerType() {
		return existingCustomerType;
	}

	public void setExistingCustomerType(Boolean existingCustomerType) {
		this.existingCustomerType = existingCustomerType;
	}

	public String getDedupeJson() {
		return dedupeJson;
	}

	public void setDedupeJson(String dedupeJson) {
		this.dedupeJson = dedupeJson;
	}

	public List<String> getDeviationCodes() {
		return deviationCodes;
	}

	public void setDeviationCodes(List<String> deviationCodes) {
		this.deviationCodes = deviationCodes;
	}

	public Boolean getBflApplicableLocationFlag() {
		return bflApplicableLocationFlag;
	}

	public void setBflApplicableLocationFlag(Boolean bflApplicableLocationFlag) {
		this.bflApplicableLocationFlag = bflApplicableLocationFlag;
	}

	public String getPrincipleProductCode() {
		return principleProductCode;
	}

	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}

	public List<Rejection> getRejectionList() {
		return rejectionList;
	}

	public void setRejectionList(List<Rejection> rejectionList) {
		this.rejectionList = rejectionList;
	}

	public PinCode getPincode() {
		return pincode;
	}

	public void setPincode(PinCode pincode) {
		this.pincode = pincode;
	}
	
	public PinCode getofficePinCode() {
		return officePinCode;
	}

	public void setofficePinCode(PinCode officePinCode) {
		this.officePinCode = officePinCode;
	}

	public LoanApprovalDetails getLoanApprovalDetails() {
		return loanApprovalDetails;
	}

	public void setLoanApprovalDetails(LoanApprovalDetails loanApprovalDetails) {
		this.loanApprovalDetails = loanApprovalDetails;
	}
	
	public String getEmployerSubCat() {
		return employerSubCat;
	}

	public void setEmployerSubCat(String employerSubCat) {
		this.employerSubCat = employerSubCat;
	}
	
	public Long getPrincipleKey() {
		return principleKey;
	}

	public void setPrincipleKey(Long principleKey) {
		this.principleKey = principleKey;
	}
	public String getPartnerDetailsJson() {
		return partnerDetailsJson;
	}

	public void setPartnerDetailsJson(String partnerDetailsJson) {
		this.partnerDetailsJson = partnerDetailsJson;
	}

	@Override
	public String toString() {
		return "PrincipalProductDet [principleProductCode=" + principleProductCode + ", rejectionList=" + rejectionList
				+ ", pincode=" + pincode + ", offerDetails=" + offerDetails + ", employerType=" + employerType
				+ ", employerCat=" + employerCat + ", employerSubCat=" + employerSubCat + ", existingCustomerType="
				+ existingCustomerType + ", principleCustType=" + principleCustType + ", dedupeJson=" + dedupeJson
				+ ", deviationCodes=" + deviationCodes + ", bflApplicableLocationFlag=" + bflApplicableLocationFlag
				+ ", propertyPincode=" + propertyPincode + ", isBTBankServicebaleFlag=" + isBTBankServicebaleFlag
				+ ", loanApprovalDetails=" + loanApprovalDetails + ", principleKey=" + principleKey
				+ ", partnerDetailsJson=" + partnerDetailsJson + "]";
	}

}
