package com.bajaj.markets.credit.application.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bajaj.markets.credit.application.model.BtbankServiceable;

public interface BtbankServiceableRoInterface extends ReadInterface<BtbankServiceable, Long> {

	@Query("select a.isactive from BtbankServiceable a where a.bankmastkey=:bankMastKey AND a.prodkey=:prodKey")
	public Integer findIsactiveByBankmastkeyAndProdkey(@Param("bankMastKey") Integer bankMastKey,
			@Param("prodKey") Long prodKey);

}
