/**
 * 
 */
package com.bajaj.markets.credit.application.bean;

/**
 * @author pranoti.pandole
 *
 */
public class MandateOutput {
	 private Boolean bankDetailsEditableFlag;
	 private Boolean  mandateRequiredFlag; 
     private Boolean   accountNumberEditFlag;
	 private String mandatePartner;
	 private Boolean eMandateFlag;
	 private String principal;
	 private String bankDetailsTobeConsidered;
     private MandateDetails mandateDetails;
     private BankDetails bankDetails;
	/**
	 * @return the bankDetailsEditableFlag
	 */
	public Boolean getBankDetailsEditableFlag() {
		return bankDetailsEditableFlag;
	}
	/**
	 * @param bankDetailsEditableFlag the bankDetailsEditableFlag to set
	 */
	public void setBankDetailsEditableFlag(Boolean bankDetailsEditableFlag) {
		this.bankDetailsEditableFlag = bankDetailsEditableFlag;
	}
	/**
	 * @return the mandateRequiredFlag
	 */
	public Boolean getMandateRequiredFlag() {
		return mandateRequiredFlag;
	}
	/**
	 * @param mandateRequiredFlag the mandateRequiredFlag to set
	 */
	public void setMandateRequiredFlag(Boolean mandateRequiredFlag) {
		this.mandateRequiredFlag = mandateRequiredFlag;
	}
	/**
	 * @return the accountNumberEditFlag
	 */
	public Boolean getAccountNumberEditFlag() {
		return accountNumberEditFlag;
	}
	/**
	 * @param accountNumberEditFlag the accountNumberEditFlag to set
	 */
	public void setAccountNumberEditFlag(Boolean accountNumberEditFlag) {
		this.accountNumberEditFlag = accountNumberEditFlag;
	}
	/**
	 * @return the mandatePartner
	 */
	public String getMandatePartner() {
		return mandatePartner;
	}
	/**
	 * @param mandatePartner the mandatePartner to set
	 */
	public void setMandatePartner(String mandatePartner) {
		this.mandatePartner = mandatePartner;
	}
	public Boolean geteMandateFlag() {
		return eMandateFlag;
	}
	public void seteMandateFlag(Boolean eMandateFlag) {
		this.eMandateFlag = eMandateFlag;
	}
	/**
	 * @return the principal
	 */
	public String getPrincipal() {
		return principal;
	}
	/**
	 * @param principal the principal to set
	 */
	public void setPrincipal(String principal) {
		this.principal = principal;
	}
	/**
	 * @return the bankDetailsTobeConsidered
	 */
	public String getBankDetailsTobeConsidered() {
		return bankDetailsTobeConsidered;
	}
	/**
	 * @param bankDetailsTobeConsidered the bankDetailsTobeConsidered to set
	 */
	public void setBankDetailsTobeConsidered(String bankDetailsTobeConsidered) {
		this.bankDetailsTobeConsidered = bankDetailsTobeConsidered;
	}
	/**
	 * @return the mandateDetails
	 */
	public MandateDetails getMandateDetails() {
		return mandateDetails;
	}
	/**
	 * @param mandateDetails the mandateDetails to set
	 */
	public void setMandateDetails(MandateDetails mandateDetails) {
		this.mandateDetails = mandateDetails;
	}
	/**
	 * @return the bankDetails
	 */
	public BankDetails getBankDetails() {
		return bankDetails;
	}
	/**
	 * @param bankDetails the bankDetails to set
	 */
	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}
     
     

}
