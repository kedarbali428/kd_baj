package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the app_occupation_detail database table.
 * 
 */
@Entity
@Table(name = "app_occupation_detail", schema = "dmcredit")
public class AppOccupationDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_occupation_detail_appoccupationkey_generator", sequenceName = "dmcredit.seq_pk_app_occupation_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_occupation_detail_appoccupationkey_generator")
	private Long appoccupationkey;

	private String annualturnover;

	private Long appattrbkey;

	private BigDecimal avgbankbalance;

	private Long businesskey;

	private String businessname;

	private String businesspan;

	private Integer businessvintage;

	private Long custindmastkey;

	private Integer declaredexperience;

	private Long declaredincome;

	private String designforoth;

	private String emplrcategory;

	private Long emplrdesigkey;

	private Long emplrtype;

	private String empnameforoth;

	private Long emprmastid;

	private Integer finalexperience;

	private String gstnumber;

	private String industryother;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String medicalregistrationnumber;

	private BigDecimal netmonthlysalary;

	private BigDecimal netmthincome;

	private Long nobkey;

	private Long occupationtype;

	private Long perfiosincome;

	private String practicetype;

	private BigDecimal profitaftertax;

	private Long smsincome;

	private Long subindumastkey;

	private String officetype;
	
    private Integer currentexperience;
		
	private Integer presentbusinessvintage;
	
	private Long qlfymastkey;
	
	private Long spclmastkey;
	
	private String spclforoth;
	
	private BigDecimal graduationyear;
	
	private BigDecimal postgraduationyear;
	private String degreecategory;
	
	//Added for LEN-1473
	private String caregistrationnumber;
	
	private Integer certificateofpractice;
	
	private Long rcmastkey;
	
	private Long hospitalkey;
	
	private String hospitalnameother;
	
	private String shopstatus;
	
	private String corporatelinkagetype;

	private Long empsectorservicekey;

	private Long businessnaturekey;
	private String profileemptype;


	public String getShopstatus() {
		return shopstatus;
	}

	public void setShopstatus(String shopstatus) {
		this.shopstatus = shopstatus;
	}

	public String getCorporatelinkagetype() {
		return corporatelinkagetype;
	}

	public void setCorporatelinkagetype(String corporatelinkagetype) {
		this.corporatelinkagetype = corporatelinkagetype;
	}

	public BigDecimal getProfitaftertax() {
		return profitaftertax;
	}

	public void setProfitaftertax(BigDecimal profitaftertax) {
		this.profitaftertax = profitaftertax;
	}

	public BigDecimal getAvgbankbalance() {
		return avgbankbalance;
	}

	public void setAvgbankbalance(BigDecimal avgbankbalance) {
		this.avgbankbalance = avgbankbalance;
	}

	public BigDecimal getNetmthincome() {
		return netmthincome;
	}

	public void setNetmthincome(BigDecimal netmthincome) {
		this.netmthincome = netmthincome;
	}

	public String getBusinesspan() {
		return businesspan;
	}

	public void setBusinesspan(String businesspan) {
		this.businesspan = businesspan;
	}

	public String getGstnumber() {
		return gstnumber;
	}

	public void setGstnumber(String gstnumber) {
		this.gstnumber = gstnumber;
	}

	public String getAnnualturnover() {
		return annualturnover;
	}

	public void setAnnualturnover(String annualturnover) {
		this.annualturnover = annualturnover;
	}

	public Long getCustindmastkey() {
		return custindmastkey;
	}

	public void setCustindmastkey(Long custindmastkey) {
		this.custindmastkey = custindmastkey;
	}

	public Long getEmplrtype() {
		return emplrtype;
	}

	public void setEmplrtype(Long emplrtype) {
		this.emplrtype = emplrtype;
	}

	public String getIndustryother() {
		return industryother;
	}

	public void setIndustryother(String industryother) {
		this.industryother = industryother;
	}

	public String getEmplrcategory() {
		return emplrcategory;
	}

	public void setEmplrcategory(String emplrcategory) {
		this.emplrcategory = emplrcategory;
	}

	public AppOccupationDetail() {
	}

	public Long getAppoccupationkey() {
		return this.appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public Long getAppattrbkey() {
		return this.appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public String getBusinessname() {
		return this.businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public Long getBusinesskey() {
		return businesskey;
	}

	public void setBusinesskey(Long businesskey) {
		this.businesskey = businesskey;
	}

	public Integer getBusinessvintage() {
		return this.businessvintage;
	}

	public void setBusinessvintage(Integer businessvintage) {
		this.businessvintage = businessvintage;
	}

	public Integer getDeclaredexperience() {
		return this.declaredexperience;
	}

	public void setDeclaredexperience(Integer declaredexperience) {
		this.declaredexperience = declaredexperience;
	}

	public Long getDeclaredincome() {
		return this.declaredincome;
	}

	public void setDeclaredincome(Long declaredincome) {
		this.declaredincome = declaredincome;
	}

	public String getDesignforoth() {
		return this.designforoth;
	}

	public void setDesignforoth(String designforoth) {
		this.designforoth = designforoth;
	}

	public Long getEmplrdesigkey() {
		return this.emplrdesigkey;
	}

	public void setEmplrdesigkey(Long emplrdesigkey) {
		this.emplrdesigkey = emplrdesigkey;
	}

	public String getEmpnameforoth() {
		return this.empnameforoth;
	}

	public void setEmpnameforoth(String empnameforoth) {
		this.empnameforoth = empnameforoth;
	}

	public Long getEmprmastid() {
		return this.emprmastid;
	}

	public void setEmprmastid(Long emprmastid) {
		this.emprmastid = emprmastid;
	}

	public Integer getFinalexperience() {
		return this.finalexperience;
	}

	public void setFinalexperience(Integer finalexperience) {
		this.finalexperience = finalexperience;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getMedicalregistrationnumber() {
		return this.medicalregistrationnumber;
	}

	public void setMedicalregistrationnumber(String medicalregistrationnumber) {
		this.medicalregistrationnumber = medicalregistrationnumber;
	}

	public BigDecimal getNetmonthlysalary() {
		return this.netmonthlysalary;
	}

	public void setNetmonthlysalary(BigDecimal netmonthlysalary) {
		this.netmonthlysalary = netmonthlysalary;
	}

	public Long getNobkey() {
		return this.nobkey;
	}

	public void setNobkey(Long nobkey) {
		this.nobkey = nobkey;
	}

	public Long getOccupationtype() {
		return this.occupationtype;
	}

	public void setOccupationtype(Long occupationtype) {
		this.occupationtype = occupationtype;
	}

	public Long getPerfiosincome() {
		return this.perfiosincome;
	}

	public void setPerfiosincome(Long perfiosincome) {
		this.perfiosincome = perfiosincome;
	}

	public String getPracticetype() {
		return this.practicetype;
	}

	public void setPracticetype(String practicetype) {
		this.practicetype = practicetype;
	}

	public Long getSmsincome() {
		return this.smsincome;
	}

	public void setSmsincome(Long smsincome) {
		this.smsincome = smsincome;
	}

	public Long getSubindumastkey() {
		return this.subindumastkey;
	}

	public void setSubindumastkey(Long subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

	public String getOfficetype() {
		return officetype;
	}

	public void setOfficetype(String officetype) {
		this.officetype = officetype;
	}

	public Integer getCurrentexperience() {
		return currentexperience;
	}

	public void setCurrentexperience(Integer currentexperience) {
		this.currentexperience = currentexperience;
	}

	public Integer getPresentbusinessvintage() {
		return presentbusinessvintage;
	}

	public void setPresentbusinessvintage(Integer presentbusinessvintage) {
		this.presentbusinessvintage = presentbusinessvintage;
	}
	
	public Long getSpclmastkey() {
		return spclmastkey;
	}

	public void setSpclmastkey(Long spclmastkey) {
		this.spclmastkey = spclmastkey;
	}

	public BigDecimal getGraduationyear() {
		return graduationyear;
	}

	public void setGraduationyear(BigDecimal graduationyear) {
		this.graduationyear = graduationyear;
	}

	public BigDecimal getPostgraduationyear() {
		return postgraduationyear;
	}

	public void setPostgraduationyear(BigDecimal postgraduationyear) {
		this.postgraduationyear = postgraduationyear;
	}
	
	public Long getQlfymastkey() {
		return qlfymastkey;
	}
	
	public void setQlfymastkey(Long qlfymastkey) {
		this.qlfymastkey = qlfymastkey;
	}

	public String getSpclforoth() {
		return spclforoth;
	}

	public void setSpclforoth(String spclforoth) {
		this.spclforoth = spclforoth;
	}

	public Long getRcmastkey() {
		return rcmastkey;
	}

	public void setRcmastkey(Long rcmastkey) {
		this.rcmastkey = rcmastkey;
	}

	public Long getHospitalkey() {
		return hospitalkey;
	}

	public void setHospitalkey(Long hospitalkey) {
		this.hospitalkey = hospitalkey;
	}

	public String getHospitalnameother() {
		return hospitalnameother;
	}

	public void setHospitalnameother(String hospitalnameother) {
		this.hospitalnameother = hospitalnameother;
	}

	public String getDegreecategory() {
		return degreecategory;
	}

	public void setDegreecategory(String degreecategory) {
		this.degreecategory = degreecategory;
	}

	

	public String getCaregistrationnumber() {
		return caregistrationnumber;
	}

	public void setCaregistrationnumber(String caregistrationnumber) {
		this.caregistrationnumber = caregistrationnumber;
	}

	public Integer getCertificateofpractice() {
		return certificateofpractice;
	}

	public void setCertificateofpractice(Integer certificateofpractice) {
		this.certificateofpractice = certificateofpractice;
	}

	public Long getEmpsectorservicekey() {
		return empsectorservicekey;
	}

	public void setEmpsectorservicekey(Long empsectorservicekey) {
		this.empsectorservicekey = empsectorservicekey;
	}

	public Long getBusinessnaturekey() {
		return businessnaturekey;
	}

	public void setBusinessnaturekey(Long businessnaturekey) {
		this.businessnaturekey = businessnaturekey;
	}
	
	public String getProfileemptype() {
		return profileemptype;
	}

	public void setProfileemptype(String profileemptype) {
		this.profileemptype = profileemptype;
	}

    @Override
	public AppOccupationDetail clone() throws CloneNotSupportedException {
		AppOccupationDetail appOccupationDetail = new AppOccupationDetail();
		if (null != annualturnover) {
		appOccupationDetail.setAnnualturnover(this.annualturnover);
		}
		if (null != appattrbkey) {
		appOccupationDetail.setAppattrbkey(this.appattrbkey);
		}
		if (null != avgbankbalance) {
		appOccupationDetail.setAvgbankbalance(this.avgbankbalance);
		}
		if (null != businesskey) {
		appOccupationDetail.setBusinesskey(this.businesskey);
		}
		if (null != businessvintage) {
		appOccupationDetail.setBusinessvintage(this.businessvintage);
		}
		if (null != businesspan) {
		appOccupationDetail.setBusinesspan(this.businesspan);
		}
		if (null != declaredincome) {
		appOccupationDetail.setDeclaredincome(this.declaredincome);
		}
		if (null != declaredexperience) {
		appOccupationDetail.setDeclaredexperience(this.declaredexperience);
		}
		if (null != designforoth) {
		appOccupationDetail.setDesignforoth(this.designforoth);
		}
		if (null != emplrcategory) {
		appOccupationDetail.setEmplrcategory(this.emplrcategory);
		}
		if (null != emplrdesigkey) {
		appOccupationDetail.setEmplrdesigkey(this.emplrdesigkey);
		}
		if (null != emplrtype) {
		appOccupationDetail.setEmplrtype(this.emplrtype);
		}
		if (null != empnameforoth) {
		appOccupationDetail.setEmpnameforoth(this.empnameforoth);
		}
		if (null != emprmastid) {
		appOccupationDetail.setEmprmastid(this.emprmastid);
		}
		if (null != finalexperience) {
		appOccupationDetail.setFinalexperience(this.finalexperience);
		}
		if (null != gstnumber) {
		appOccupationDetail.setGstnumber(this.gstnumber);
		}
		if (null != isactive) {
		appOccupationDetail.setIsactive(this.isactive);
		}
		if (null != lstupdateby) {
		appOccupationDetail.setLstupdateby(this.lstupdateby);
		}
		if (null != lstupdatedt) {
		appOccupationDetail.setLstupdatedt(this.lstupdatedt);
		}
		if (null != medicalregistrationnumber) {
		appOccupationDetail.setMedicalregistrationnumber(this.medicalregistrationnumber);
		}
		if (null != netmonthlysalary) {
		appOccupationDetail.setNetmonthlysalary(this.netmonthlysalary);
		}
		if (null != netmthincome) {
		appOccupationDetail.setNetmthincome(this.netmthincome);
		}
		if (null != nobkey) {
		appOccupationDetail.setNobkey(this.nobkey);
		}
		if (null != occupationtype) {
		appOccupationDetail.setOccupationtype(this.occupationtype);
		}
		if (null != perfiosincome) {
		appOccupationDetail.setPerfiosincome(this.perfiosincome);
		}
		if (null != practicetype) {
		appOccupationDetail.setPracticetype(this.practicetype);
		}
		if (null != profitaftertax) {
		appOccupationDetail.setProfitaftertax(this.profitaftertax);
		}
		if (null != smsincome) {
		appOccupationDetail.setSmsincome(this.smsincome);
		}
		if (null != subindumastkey) {
		appOccupationDetail.setSubindumastkey(this.subindumastkey);
		}
		if (null != custindmastkey) {
		appOccupationDetail.setCustindmastkey(this.custindmastkey);
		}
		if (null != industryother) {
		appOccupationDetail.setIndustryother(this.industryother);
		}
		if (null != businessname) {
		appOccupationDetail.setBusinessname(this.businessname);
		}
		if (null != officetype) {
		appOccupationDetail.setOfficetype(this.officetype);
		}
		if (null != currentexperience) {
		appOccupationDetail.setCurrentexperience(this.currentexperience);
		}
		if (null != presentbusinessvintage) {
		appOccupationDetail.setPresentbusinessvintage(this.presentbusinessvintage);
		}
		if (null != qlfymastkey) {
		appOccupationDetail.setQlfymastkey(this.qlfymastkey);
		}
		if (null != degreecategory) {
		appOccupationDetail.setDegreecategory(this.degreecategory);
		}
		if (null != caregistrationnumber) {
		appOccupationDetail.setCaregistrationnumber(this.caregistrationnumber);
		}
		if (null != certificateofpractice) {
		appOccupationDetail.setCertificateofpractice(this.certificateofpractice);
		}
		if (null != spclforoth) {
		appOccupationDetail.setSpclforoth(this.spclforoth);
		}
		if (null != spclmastkey) {
		appOccupationDetail.setSpclmastkey(this.spclmastkey);
		}
		if (null != graduationyear) {
		appOccupationDetail.setGraduationyear(this.graduationyear);
		}
		if (null != postgraduationyear) {
		appOccupationDetail.setPostgraduationyear(this.postgraduationyear);
		}
		if (null != rcmastkey) {
		appOccupationDetail.setRcmastkey(this.rcmastkey);
		}
		if (null != hospitalkey) {
		appOccupationDetail.setHospitalkey(this.hospitalkey);
		}
		if (null != hospitalnameother) {
		appOccupationDetail.setHospitalnameother(this.hospitalnameother);
		}
		if (null != empsectorservicekey) {
		appOccupationDetail.setEmpsectorservicekey(this.empsectorservicekey);
		}
		if (null != businessnaturekey) {
		appOccupationDetail.setBusinessnaturekey(this.businessnaturekey);
		}
		return appOccupationDetail;
	}
	
	public AppOccupationDetail copySourceOccupationToDestination(AppOccupationDetail destinationOccupationDetail) {
		destinationOccupationDetail.setAnnualturnover(null != this.annualturnover ?
				this.annualturnover : destinationOccupationDetail.getAnnualturnover());
		destinationOccupationDetail.setAvgbankbalance(null != this.avgbankbalance ?
				this.avgbankbalance : destinationOccupationDetail.getAvgbankbalance());
		destinationOccupationDetail.setBusinesskey(null != this.businesskey ?
				this.businesskey : destinationOccupationDetail.getBusinesskey());
		destinationOccupationDetail.setBusinessvintage(null != this.businessvintage ?
				this.businessvintage : destinationOccupationDetail.getBusinessvintage());
		destinationOccupationDetail.setBusinesspan(null != this.businesspan ?
				this.businesspan : destinationOccupationDetail.getBusinesspan());
		destinationOccupationDetail.setDeclaredincome(null != this.declaredincome ?
				this.declaredincome : destinationOccupationDetail.getDeclaredincome());
		destinationOccupationDetail.setDeclaredexperience(null != this.declaredexperience ?
				this.declaredexperience : destinationOccupationDetail.getDeclaredexperience());
		destinationOccupationDetail.setDesignforoth(null != this.designforoth ? 
				this.designforoth : destinationOccupationDetail.getDesignforoth());
		destinationOccupationDetail.setEmplrcategory(null != this.emplrcategory ?
				this.emplrcategory : destinationOccupationDetail.getEmplrcategory());
		destinationOccupationDetail.setEmplrdesigkey(null != this.emplrdesigkey ?
				this.emplrdesigkey : destinationOccupationDetail.getEmplrdesigkey());
		destinationOccupationDetail.setEmplrtype(null != this.emplrtype ?
				this.emplrtype : destinationOccupationDetail.getEmplrtype());
		destinationOccupationDetail.setEmpnameforoth(null != this.empnameforoth ?
				this.empnameforoth : destinationOccupationDetail.getEmpnameforoth());
		destinationOccupationDetail.setEmprmastid(null != this.emprmastid ?
				this.emprmastid : destinationOccupationDetail.getEmprmastid());
		destinationOccupationDetail.setFinalexperience(null != this.finalexperience ?
				this.finalexperience : destinationOccupationDetail.getFinalexperience());
		destinationOccupationDetail.setGstnumber(null != this.gstnumber ? 
				this.gstnumber : destinationOccupationDetail.getGstnumber());
		destinationOccupationDetail.setMedicalregistrationnumber(null != this.medicalregistrationnumber ?
				this.medicalregistrationnumber : destinationOccupationDetail.getMedicalregistrationnumber());
		destinationOccupationDetail.setNetmonthlysalary(null != this.netmonthlysalary ?
				this.netmonthlysalary : destinationOccupationDetail.getNetmonthlysalary());
		destinationOccupationDetail.setNetmthincome(null != this.netmthincome ?
				this.netmthincome : destinationOccupationDetail.getNetmthincome());
		destinationOccupationDetail.setNobkey(null != this.nobkey ?
				this.nobkey : destinationOccupationDetail.nobkey);
		destinationOccupationDetail.setOccupationtype(null != this.occupationtype ?
				this.occupationtype : destinationOccupationDetail.getOccupationtype());
		destinationOccupationDetail.setPerfiosincome(null != this.perfiosincome ?
				this.perfiosincome : destinationOccupationDetail.getPerfiosincome());
		destinationOccupationDetail.setPracticetype(null != this.practicetype ?
				this.practicetype : destinationOccupationDetail.getPracticetype());
		destinationOccupationDetail.setProfitaftertax(null != this.profitaftertax ?
				this.profitaftertax : destinationOccupationDetail.getProfitaftertax());
		destinationOccupationDetail.setSmsincome(null != this.smsincome ?
				this.smsincome : destinationOccupationDetail.getSmsincome());
		destinationOccupationDetail.setSubindumastkey(null != this.subindumastkey ?
				this.subindumastkey : destinationOccupationDetail.getSubindumastkey());
		destinationOccupationDetail.setCustindmastkey(null != this.custindmastkey ?
				this.custindmastkey : destinationOccupationDetail.custindmastkey);
		destinationOccupationDetail.setIndustryother(null != this.industryother ?
				this.industryother : destinationOccupationDetail.getIndustryother());
		destinationOccupationDetail.setBusinessname(null != this.businessname ?
				this.businessname : destinationOccupationDetail.getBusinessname());
		destinationOccupationDetail.setOfficetype(null != this.officetype ?
				this.officetype : destinationOccupationDetail.getOfficetype());
		destinationOccupationDetail.setCurrentexperience(null != this.currentexperience ?
				this.currentexperience : destinationOccupationDetail.getCurrentexperience());
		destinationOccupationDetail.setPresentbusinessvintage(null != this.presentbusinessvintage ?
				this.presentbusinessvintage : destinationOccupationDetail.getPresentbusinessvintage());
		destinationOccupationDetail.setDegreecategory(null != this.degreecategory ?
				this.degreecategory : destinationOccupationDetail.getDegreecategory());
		destinationOccupationDetail.setQlfymastkey(null != this.qlfymastkey ?
				this.qlfymastkey : destinationOccupationDetail.getQlfymastkey());
		destinationOccupationDetail.setHospitalkey(this.hospitalkey);
		destinationOccupationDetail.setHospitalnameother(this.hospitalnameother);
		destinationOccupationDetail.setRcmastkey(null != this.rcmastkey ?
				this.rcmastkey : destinationOccupationDetail.getRcmastkey());
		destinationOccupationDetail.setGraduationyear(null != this.graduationyear ?
				this.graduationyear : destinationOccupationDetail.getGraduationyear());
		destinationOccupationDetail.setPostgraduationyear(this.postgraduationyear);
		destinationOccupationDetail.setSpclforoth(this.spclforoth);
		destinationOccupationDetail.setSpclmastkey(this.spclmastkey);
		destinationOccupationDetail.setCertificateofpractice(null != this.certificateofpractice ?
				this.certificateofpractice : destinationOccupationDetail.getCertificateofpractice());
		destinationOccupationDetail.setCaregistrationnumber(null != this.caregistrationnumber ?
				this.caregistrationnumber : destinationOccupationDetail.getCaregistrationnumber());
		destinationOccupationDetail.setEmpsectorservicekey(null != this.empsectorservicekey ? this.empsectorservicekey
				: destinationOccupationDetail.getEmpsectorservicekey());
		destinationOccupationDetail.setBusinessnaturekey(null != this.businessnaturekey ? this.businessnaturekey
				: destinationOccupationDetail.getBusinessnaturekey());
		destinationOccupationDetail.setProfileemptype(null != this.profileemptype ? this.profileemptype
				: destinationOccupationDetail.getProfileemptype());
		return destinationOccupationDetail;
	}

	@Override
	public String toString() {
		return "AppOccupationDetail [appoccupationkey=" + appoccupationkey + ", annualturnover=" + annualturnover
				+ ", appattrbkey=" + appattrbkey + ", avgbankbalance=" + avgbankbalance + ", businesskey=" + businesskey
				+ ", businessname=" + businessname + ", businesspan=" + businesspan + ", businessvintage="
				+ businessvintage + ", custindmastkey=" + custindmastkey + ", declaredexperience=" + declaredexperience
				+ ", declaredincome=" + declaredincome + ", designforoth=" + designforoth + ", emplrcategory="
				+ emplrcategory + ", emplrdesigkey=" + emplrdesigkey + ", emplrtype=" + emplrtype + ", empnameforoth="
				+ empnameforoth + ", emprmastid=" + emprmastid + ", finalexperience=" + finalexperience + ", gstnumber="
				+ gstnumber + ", industryother=" + industryother + ", isactive=" + isactive + ", lstupdateby="
				+ lstupdateby + ", lstupdatedt=" + lstupdatedt + ", medicalregistrationnumber="
				+ medicalregistrationnumber + ", netmonthlysalary=" + netmonthlysalary + ", netmthincome="
				+ netmthincome + ", nobkey=" + nobkey + ", occupationtype=" + occupationtype + ", perfiosincome="
				+ perfiosincome + ", practicetype=" + practicetype + ", profitaftertax=" + profitaftertax
				+ ", smsincome=" + smsincome + ", subindumastkey=" + subindumastkey + ", officetype=" + officetype
				+ ", currentexperience=" + currentexperience + ", presentbusinessvintage=" + presentbusinessvintage
				+ ", qlfymastkey=" + qlfymastkey + ", spclmastkey=" + spclmastkey + ", spclforoth=" + spclforoth
				+ ", graduationyear=" + graduationyear + ", postgraduationyear=" + postgraduationyear
				+ ", degreecategory=" + degreecategory + ", caregistrationnumber=" + caregistrationnumber
				+ ", certificateofpractice=" + certificateofpractice + ", rcmastkey=" + rcmastkey + ", hospitalkey="
				+ hospitalkey + ", hospitalnameother=" + hospitalnameother + ", shopstatus=" + shopstatus
				+ ", corporatelinkagetype=" + corporatelinkagetype + ", empsectorservicekey=" + empsectorservicekey
				+ ", businessnaturekey=" + businessnaturekey + ", profileemptype=" + profileemptype + "]";
	}

}