package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "serviceable_business_nature", schema = "dmcredit")
public class ServiceableBusinessNature {

	@Id
	private Long businessnaturekey;

	private Long principalkey;

	private String natureofbusiness;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	public Long getBusinessnaturekey() {
		return businessnaturekey;
	}

	public void setBusinessnaturekey(Long businessnaturekey) {
		this.businessnaturekey = businessnaturekey;
	}

	public Long getPrincipalkey() {
		return principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

	public String getNatureofbusiness() {
		return natureofbusiness;
	}

	public void setNatureofbusiness(String natureofbusiness) {
		this.natureofbusiness = natureofbusiness;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}
