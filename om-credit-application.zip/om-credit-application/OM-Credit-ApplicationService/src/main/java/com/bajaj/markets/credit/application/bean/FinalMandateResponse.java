package com.bajaj.markets.credit.application.bean;

public class FinalMandateResponse {

    private Long appattrbKey;
	
	private Long finalMandateKey;

	public Long getAppattrbKey() {
		return appattrbKey;
	}

	public void setAppattrbKey(Long appattrbKey) {
		this.appattrbKey = appattrbKey;
	}

	public Long getFinalMandateKey() {
		return finalMandateKey;
	}

	public void setFinalMandateKey(Long finalMandateKey) {
		this.finalMandateKey = finalMandateKey;
	}
}
