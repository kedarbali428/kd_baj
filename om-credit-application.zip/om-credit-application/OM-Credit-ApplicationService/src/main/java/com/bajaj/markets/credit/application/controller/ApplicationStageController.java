package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.ApplicationStageDetails;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationStageService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationStageController {
	
	@Autowired
	ApplicationStageService applicationStageService;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = ApplicationStageController.class.getName();
	
	@Secured(value = { Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL, Role.PSEUDO_CUSTOMER,
			Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update Application StageSubstage of parent & child application", notes = "Update stageSubstage details with applicationId,stage,substage percentage", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Application stages updated successfully"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Substage details not found, application not found or stage completion percentage is invalid", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid Input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)	})
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/status", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> updateApplicationStageSubstage(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@Valid @RequestBody ApplicationStageDetails applicationStageDetails,BindingResult bindingResult, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, 
				"Inside updateApplicationStageSubstage method for applicationId: "+applicationId );
		applicationStageService.updateApplicationStageSubstage(applicationId, applicationStageDetails);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, 
				"Inside updateApplicationStageSubstage method End for applicationId: "+applicationId );
		return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get Application StageSubstage details", notes = "Get stageSubstage details with applicationId", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application stageSubstage details fetched successfully", response = ApplicationStageDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application stage substage details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/status", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> getApplicationStageSubstage(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getApplicationStageSubstage method for applicationId: "+applicationId);
		ApplicationStageDetails appstageDetails = applicationStageService.getApplicationStageSubstage(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, 
				"Exit From getApplicationStageSubstage method End for applicationId: "+applicationId);
		return new ResponseEntity<>(appstageDetails, HttpStatus.OK);
	}
}
