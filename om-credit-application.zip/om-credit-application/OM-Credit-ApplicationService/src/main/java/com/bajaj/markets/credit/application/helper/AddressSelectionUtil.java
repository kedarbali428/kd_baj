package com.bajaj.markets.credit.application.helper;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.application.model.ApplicationAddress;
import com.bajaj.markets.credit.application.repository.tx.ApplicationAddressRepository;

@Component
public class AddressSelectionUtil {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private ApplicationAddressRepository applicationAddressRepository;

	private static final String CLASSNAME = AddressSelectionUtil.class.getCanonicalName();

	public ApplicationAddress selectApplicationAddress(Long userAttributeKey, Long typeKey, String addressSource,ApplicationAddress...addresses) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "START - selectApplicationAddress, userAttributeKey : "
				+ userAttributeKey + ", typeKey : " + typeKey + ", addressSource : " + addressSource);
		ApplicationAddress appAddress = null;
		List<ApplicationAddress> listApplicationAddress;
		try {
			if(ArrayUtils.isNotEmpty(addresses)) {
				listApplicationAddress = Arrays.asList(addresses);
			}else {
				listApplicationAddress = applicationAddressRepository
						.findByAddrtypkeyAndAppattrbkeyAndIsactive(typeKey, userAttributeKey, 1);
			}
			if (!CollectionUtils.isEmpty(listApplicationAddress)) {
				if (listApplicationAddress.size() == 1) {
					// If single, then return
					appAddress = listApplicationAddress.get(0);
				} else {
					for (ApplicationAddress applicationAddress : listApplicationAddress) {
						if (null != addressSource && null != applicationAddress.getAddrsrc()
								&& addressSource.equalsIgnoreCase(applicationAddress.getAddrsrc())) {
							// same source most priority
							appAddress = applicationAddress;
							break;
						} else if (null != applicationAddress.getPrefferedflg()
								&& applicationAddress.getPrefferedflg().compareTo(1L) == 0) {
							// next priority preferred address
							appAddress = applicationAddress;
						}
					}
					if (null == appAddress) {
						appAddress = getHighestPriorityAddress(listApplicationAddress);
					}
				}
				// Still not found, then get latest record
				if (null == appAddress) {
					appAddress = listApplicationAddress.stream()
							.sorted(Comparator.comparing(ApplicationAddress::getLstupdatedt,
									Comparator.nullsLast(Comparator.reverseOrder())))
							.findFirst().get();
				}
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Exception in selectApplicationAddress, userAttributeKey : " + userAttributeKey + ", typeKey : "
							+ typeKey + ", addressSource : " + addressSource,
					e);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"END - selectApplicationAddress, userAttributeKey : " + userAttributeKey + ", typeKey : " + typeKey
						+ ", addressSource : " + addressSource + ", appAddress got : " + appAddress);
		return appAddress;
	}

	private ApplicationAddress getHighestPriorityAddress(List<ApplicationAddress> dataSources) {
		dataSources.sort(new Comparator<ApplicationAddress>() {
			@Override
			public int compare(ApplicationAddress o1, ApplicationAddress o2) {
				return AddressPriorityEnum
						.valueOf(o1.getAddrsrc().toUpperCase()).getValue().compareTo(AddressPriorityEnum
								.valueOf(o2.getAddrsrc().toUpperCase()).getValue());
			}
		});
		return dataSources.get(0);
	}
}