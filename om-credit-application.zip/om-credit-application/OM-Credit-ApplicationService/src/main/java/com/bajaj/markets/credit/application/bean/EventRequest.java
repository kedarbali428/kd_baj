package com.bajaj.markets.credit.application.bean;

import java.util.Arrays;

public class EventRequest {

	private Header header;
	private String[] tags;
	private String context;
	private String source;
	private Object data;
	private Metadata metadata;
	private String applicationId;
	private String cmptcorrid;
	
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public String[] getTags() {
		return tags;
	}
	public void setTags(String[] tags) {
		this.tags = tags;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Metadata getMetadata() {
		return metadata;
	}
	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getCmptcorrid() {
		return cmptcorrid;
	}
	public void setCmptcorrid(String cmptcorrid) {
		this.cmptcorrid = cmptcorrid;
	}

	@Override
	public String toString() {
		return "EventReqeust [header=" + header + ", tags=" + Arrays.toString(tags) + ", context=" + context
				+ ", source=" + source + ", data=" + data + ", metadata=" + metadata + ", applicationId="
				+ applicationId + ", cmptcorrid=" + cmptcorrid + "]";
	}
}