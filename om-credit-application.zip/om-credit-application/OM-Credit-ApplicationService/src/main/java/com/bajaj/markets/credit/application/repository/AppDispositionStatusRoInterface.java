package com.bajaj.markets.credit.application.repository;

import com.bajaj.markets.credit.application.model.AppDispositionStatus;

public interface AppDispositionStatusRoInterface extends ReadInterface<AppDispositionStatus, Long> {

	AppDispositionStatus findByApplicationkeyAndFunctionKeyAndIsactive(Long applicationkey, Integer functionKey,
			Integer isActive);

	AppDispositionStatus findByApplicationkeyAndIsactive(Long applicationkey, Integer isActive);

}
