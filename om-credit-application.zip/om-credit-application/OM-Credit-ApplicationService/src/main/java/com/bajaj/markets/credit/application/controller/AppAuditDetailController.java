package com.bajaj.markets.credit.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.AddressAuditDetails;
import com.bajaj.markets.credit.application.bean.AppAuditRequest;
import com.bajaj.markets.credit.application.bean.AuditApplicantDetails;
import com.bajaj.markets.credit.application.bean.EmailAuditDetails;
import com.bajaj.markets.credit.application.bean.EmployeeRequest;
import com.bajaj.markets.credit.application.bean.NameDetail;
import com.bajaj.markets.credit.application.bean.UTMRequest;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.AppAuditDetail;
import com.bajaj.markets.credit.application.service.AppAuditDetailService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
@RestController
public class AppAuditDetailController {
	@Autowired
	BFLLoggerUtil logger;
	
	@Autowired
	private AppAuditDetailService appAuditDetailService;
	
	private static final String CLASSNAME = AppAuditDetailController.class.getName();
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update Application fields details for audit", notes = "Update Application fields details for audit", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Application field details updated for audit", response = AppAuditDetail.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/creditapplication/applications/{applicationid}/updateauditdetails", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateApplicationDetailsForAudit(@PathVariable("applicationid") String applicationId,
			@RequestBody List<AppAuditRequest> appAuditRequest,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In getApplicationAuditDetailsField method with applicationId :" +applicationId);
		Boolean appAuditDetail = appAuditDetailService.updateApplicationDetailsForAudit(applicationId,appAuditRequest,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateApplicationDetailsForAudit method with auditDetails :"+appAuditDetail);
		return new ResponseEntity<>(appAuditDetail, HttpStatus.CREATED);
	}
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update Applicant details for audit", notes = "Update Applicant details for audit", httpMethod = "PUT")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Application field details updated for audit", response = AppAuditDetail.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/updateapplicant", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateApplicantDetailsForAudit(@PathVariable("applicationid") String applicationId,
			@RequestBody AuditApplicantDetails auditApplicantDetails,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateApplicantDetailsForAudit method with applicationId :" +applicationId);
		AuditApplicantDetails auditApplicant = appAuditDetailService.updateApplicantDetailsForAudit(applicationId,auditApplicantDetails,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateApplicantDetailsForAudit method with auditApplicant :"+auditApplicant);
		return new ResponseEntity<>(auditApplicant, HttpStatus.CREATED);
	}
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update Address details for audit", notes = "Update Address details for audit", httpMethod = "PUT")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Address field details updated for audit", response = AppAuditDetail.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/address", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateAddressDetailsForAudit(@PathVariable("applicationid") String applicationId,
			@RequestBody AddressAuditDetails addressAuditDetails,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateAddressDetailsForAudit method with applicationId :" +applicationId);
		AddressAuditDetails addressDetails = appAuditDetailService.updateAddressDetailsForAudit(applicationId,addressAuditDetails,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateAddressDetailsForAudit method with addressDetails :"+addressDetails);
		return new ResponseEntity<>(addressDetails, HttpStatus.CREATED);
	}
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update Employee details for audit", notes = "Update Employee details for audit", httpMethod = "PUT")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Employee field details updated for audit", response = EmployeeRequest.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/employeedetails", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateEmployeeDetailsForAudit(@PathVariable("applicationid") String applicationId,
			@RequestBody EmployeeRequest employeeRequest,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateEmployeeDetailsForAudit method with applicationId :" +applicationId);
		EmployeeRequest employeeDetails = appAuditDetailService.updateEmployeeDetailsForAudit(applicationId,employeeRequest,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateEmployeeDetailsForAudit method with employeeDetails :"+employeeRequest);
		return new ResponseEntity<>(employeeDetails, HttpStatus.CREATED);
	}
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update UTM details for audit", notes = "Update UTM details for audit", httpMethod = "PUT")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "UTM Parameters updated for audit", response = UTMRequest.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/utmparameters", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateUTMDetails(@PathVariable("applicationid") String applicationId,
			@RequestBody UTMRequest utmRequest,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateUTMDetails method with applicationId :" +applicationId);
		UTMRequest utmRespose = appAuditDetailService.updateUTMDetails(applicationId,utmRequest,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateUTMDetails method with UTMDetails :"+utmRequest);
		return new ResponseEntity<>(utmRespose, HttpStatus.CREATED);
	}
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update name detail for audit", notes = "Update name detail for audit", httpMethod = "PUT")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Address field details updated for audit", response = AppAuditDetail.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/applicantname", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateNameDetailsForAudit(@PathVariable("applicationid") String applicationId,
			@RequestBody NameDetail auditNameDetail,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateNameDetailsForAudit method with applicationId :" +applicationId);
		NameDetail nameDetail = appAuditDetailService.updateNameDetailsForAudit(applicationId,auditNameDetail,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateNameDetailsForAudit method with addressDetails :"+nameDetail);
		return new ResponseEntity<>(nameDetail, HttpStatus.CREATED);
	}
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update Email details for audit", notes = "Update Email details for audit", httpMethod = "PUT")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Email field details updated for audit", response = AppAuditDetail.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/email", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateEmailDetailsForAudit(@PathVariable("applicationid") String applicationId,
			@RequestBody EmailAuditDetails emailAuditDetails,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateEmailDetailsForAudit method with applicationId :" +applicationId);
		EmailAuditDetails response = appAuditDetailService.updateEmailDetailsForAudit(applicationId,emailAuditDetails,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateEmailDetailsForAudit method with addressDetails :"+emailAuditDetails);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}
}
