package com.bajaj.markets.credit.application.bean;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;


public class PricingConsentRequest {

	private List<ConsentMethod> consentMethodlist;
	
	@Pattern(regexp = "JOURNEY|EP", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Please enter a valid value - JOURNEY|EP")
    @NotBlank(message = "Source can not be null/empty")
	private String source;

	public List<ConsentMethod> getConsentMethodlist() {
		return consentMethodlist;
	}

	public void setConsentMethodlist(List<ConsentMethod> consentMethodlist) {
		this.consentMethodlist = consentMethodlist;
	}

	@Override
	public String toString() {
		return "PricingConsentRequest [consentMethodlist=" + consentMethodlist + ", source=" + source + "]";
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
