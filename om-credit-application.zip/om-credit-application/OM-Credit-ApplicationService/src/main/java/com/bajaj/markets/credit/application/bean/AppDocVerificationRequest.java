package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class AppDocVerificationRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer docScanned;

	private Integer disbursmentKitToBops;

	public AppDocVerificationRequest() {
	
	}

	public Integer getDocScanned() {
		return docScanned;
	}

	public void setDocScanned(Integer docScanned) {
		this.docScanned = docScanned;
	}

	public Integer getDisbursmentKitToBops() {
		return disbursmentKitToBops;
	}

	public void setDisbursmentKitToBops(Integer disbursmentKitToBops) {
		this.disbursmentKitToBops = disbursmentKitToBops;
	}

	@Override
	public String toString() {
		return "AppDocVerificationRequest [docScanned=" + docScanned + ", disbursmentKitToBops=" + disbursmentKitToBops
				+ "]";
	}
	
}
