package com.bajaj.markets.credit.application.controller;

import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.ApplicationEligibilityStatus;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationEligibilityStatusService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationEligibilityStatusController {

	private static final String CLASSNAME = ApplicationEligibilityStatusController.class.getName();

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private ApplicationEligibilityStatusService applicationEligibilityStatusService;

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE ,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch list of products with eligible status for application", notes = "Fetch list of products with eligible status for application", httpMethod = "GET")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Application Updated successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class) })
	@GetMapping(value = "/v1/applications/{applicationid}/eligiblestatus")
	@CrossOrigin
	public ResponseEntity<List<ApplicationEligibilityStatus>> eligibleProducts(
			@PathVariable("applicationid") @NotBlank(message = "applicationId can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationkey should be numeric & should not exceeds size") String applicationId,
			@RequestParam(required = false) String source) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Start eligibleProducts controller method for " + applicationId + " source " + source);
		List<ApplicationEligibilityStatus> eligibleProduct = applicationEligibilityStatusService
				.getEligibleProduct(applicationId, source);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "End eligibleProducts controller method for "
				+ applicationId + " eligible product list: " + eligibleProduct);
		return new ResponseEntity<>(eligibleProduct, HttpStatus.OK);
	}

}
