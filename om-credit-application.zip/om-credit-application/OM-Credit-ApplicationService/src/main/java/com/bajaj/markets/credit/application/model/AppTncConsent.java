package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the app_tnc_consent database table.
 * 
 */
@Entity
@Table(name="app_tnc_consent", schema="dmcredit")
@NamedQuery(name="AppTncConsent.findAll", query="SELECT a FROM AppTncConsent a")
public class AppTncConsent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="seq_pk_app_tnc_consent_generator", sequenceName="dmcredit.seq_pk_app_tnc_consent",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_pk_app_tnc_consent_generator")
	private Long apptncconsentkey;

	private Long applicationkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long prodcatkey;

	private Integer tncconsent;

	private String tncversion;

	public AppTncConsent() {
	}

	public Long getApptncconsentkey() {
		return this.apptncconsentkey;
	}

	public void setApptncconsentkey(Long apptncconsentkey) {
		this.apptncconsentkey = apptncconsentkey;
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdcatkey() {
		return this.prodcatkey;
	}

	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public Integer getTncconsent() {
		return this.tncconsent;
	}

	public void setTncconsent(Integer tncconsent) {
		this.tncconsent = tncconsent;
	}

	public String getTncversion() {
		return this.tncversion;
	}

	public void setTncversion(String tncversion) {
		this.tncversion = tncversion;
	}

}