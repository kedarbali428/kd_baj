package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.PricingConsentCaptureBean;
import com.bajaj.markets.credit.application.bean.PricingConsentRequest;
import com.bajaj.markets.credit.application.bean.PricingConsentResponse;
import com.bajaj.markets.credit.application.bean.VasPricingCheckBean;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.PricingNotificationService;
import com.bajaj.markets.credit.application.service.VasApplicationIssueService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class VasApplicationIssueController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	VasApplicationIssueService vasApplicationIssueService;

	@Autowired
	PricingNotificationService pricingNotificationService;

	private static final String CLASSNAME = VasApplicationIssueController.class.getName();

	/*
	 * PUT Method Raise disbursement event - INITIATE_DISBURSEMENT for vas
	 * application
	 */
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.SYSTEM, Role.EMPLOYEE,Role.INTERNAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Raise disbursement event for vas application", notes = "Raise disbursement event for vas application", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Disbursement event for vas application raised Successfully.", response = String.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.vas.disbursementeventraise.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> disbursementEventRaise(
			@PathVariable("applicationKey") @NotBlank(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") String applicationKey,
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Start - disbursementEventRaise method for - applicationKey : " + applicationKey);
		String response = vasApplicationIssueService.disbursementEventRaise(applicationKey, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"End - disbursementEventRaise method for - applicationKey : " + applicationKey
						+ "\n INITIATE_DISBURSEMENT Event raise response : " + response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/*
	 * Get Method to precheck disbursement event - INITIATE_DISBURSEMENT for vas and
	 * get pricing
	 */
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.SYSTEM, Role.EMPLOYEE,Role.INTERNAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Precheck disbursement event and get pricing for vas application", notes = "Precheck disbursement event and get pricing for vas application", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Disbursement event precheck for vas application processed Successfully.", response = VasPricingCheckBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.vas.disbursementeventpricing.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> precheckVasDisbursementEventAndPricing(
			@PathVariable("applicationKey") @NotBlank(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") String applicationKey,
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Start - precheckVasDisbursementEventAndPricing method for - applicationKey : " + applicationKey);
		VasPricingCheckBean response = vasApplicationIssueService
				.precheckVasDisbursementEventAndPricing(applicationKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"End - precheckVasDisbursementEventAndPricing method for - applicationKey : " + applicationKey
						+ "\n  response : " + response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/*
	 * POST Method Pricing communication and consent - EP and JOURNEY
	 */
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.SYSTEM, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Pricing communication and consent", notes = "Pricing communication and consent", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Pricing communication and consent sent Successfully.", response = PricingConsentResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "${api.omcreditapplicationservice.pricingnotification.consent.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> notifyPricingConsent(
			@PathVariable("applicationKey") @NotBlank(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") String applicationKey,
			@Valid @RequestBody PricingConsentRequest pricingConsentRequest, BindingResult bindindResult,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Start - notifyPricingConsent method for - applicationKey : " + applicationKey
						+ ", pricingConsentRequest : " + pricingConsentRequest);
		PricingConsentResponse response = pricingNotificationService.notifyPricingConsent(applicationKey,
				pricingConsentRequest);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"End - notifyPricingConsent method for - applicationKey : " + applicationKey + "\n Response : "
						+ response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/*
	 * PUT Method Capture Pricing consent - EP and JOURNEY
	 */
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.SYSTEM, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Capture Pricing consent for applicationId", notes = "Capture Pricing consent for applicationId", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Pricing consent captured Successfully.", response = PricingConsentResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.pricingconsent.capture.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> capturePricingConsent(
			@PathVariable("applicationKey") @NotBlank(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") String applicationKey,
			@PathVariable("channel") @NotBlank(message = "channel can not be null or empty") String channel,
			@Valid @RequestBody PricingConsentCaptureBean pricingConsentCaptureBean, BindingResult bindindResult,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Start - capturePricingConsent method for - applicationKey : " + applicationKey + ", channel : "
						+ channel + ", pricingConsentCaptureBean : " + pricingConsentCaptureBean);
		PricingConsentResponse response = pricingNotificationService.capturePricingConsent(applicationKey, channel,
				pricingConsentCaptureBean);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"End - capturePricingConsent method for - applicationKey : " + applicationKey + "\n Response : "
						+ response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
