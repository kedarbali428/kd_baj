package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class EmployerMaster {
	private Integer isactive;
	private Long emprmastid;
	private String emprmastname;

	private List<EmployerMasterServiceableInfo> serviceableinfo;

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getEmprmastid() {
		return emprmastid;
	}

	public void setEmprmastid(Long emprmastid) {
		this.emprmastid = emprmastid;
	}

	public String getEmprmastname() {
		return emprmastname;
	}

	public void setEmprmastname(String emprmastname) {
		this.emprmastname = emprmastname;
	}

	public List<EmployerMasterServiceableInfo> getServiceableinfo() {
		return serviceableinfo;
	}

	public void setServiceableinfo(List<EmployerMasterServiceableInfo> serviceableinfo) {
		this.serviceableinfo = serviceableinfo;
	}

	@Override
	public String toString() {
		return "EmployerMaster [isactive=" + isactive + ", emprmastid=" + emprmastid + ", emprmastname=" + emprmastname
				+ ", serviceableinfo=" + serviceableinfo + "]";
	}
}
