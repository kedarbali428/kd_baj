package com.bajaj.markets.credit.application.controller;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.AppUdfVerificationRequest;
import com.bajaj.markets.credit.application.bean.Application;
import com.bajaj.markets.credit.application.bean.ApplicationDetail;
import com.bajaj.markets.credit.application.bean.ApplicationDetails;
import com.bajaj.markets.credit.application.bean.ApplicationParameter;
import com.bajaj.markets.credit.application.bean.ChildRecord;
import com.bajaj.markets.credit.application.bean.HLProductIntentBean;
import com.bajaj.markets.credit.application.bean.LoanPurposeApplication;
import com.bajaj.markets.credit.application.bean.LoanPurposeBean;
import com.bajaj.markets.credit.application.bean.UdfFlagDetailKeyBean;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.ChildApplication;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.ParentApplication;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.AppUdfVerification;
import com.bajaj.markets.credit.application.model.ApplicationUtmParameter;
import com.bajaj.markets.credit.application.service.ApplicationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller for creating & fetching application resource
 * Updating application resource for applicant
 * @author 738768
 *
 */
@RestController
@Validated
public class ApplicationsController {
	
	@Autowired
	private Validator validator;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private ApplicationService applicationService;
	@Autowired
    Environment env;
	
	private static final String CLASSNAME = ApplicationsController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE, Role.SYSTEMPARTNER }) 
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Create Credit application", notes = "Create credit parent application on the basis of MOB, DOB & L2 product category code and child application on the "
					+ "basis of L3 Product code & Parent application.", httpMethod = "POST")
	@ApiResponses(value = {
			 	@ApiResponse(code = 201, message = "Application created Successfully.", response = Application.class),
			 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		        @ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
		        @ApiResponse(code = 409, message = "conflict application already exists.",response = Application.class),
			 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PostMapping(value = "${api.omcreditapplicationservice.createapplication.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> createApplication(@RequestBody Application application,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Recieved Header : " + headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside createApplication method controller - application resource :" +application);

		Set<ConstraintViolation<Application>> validationErrors = validator.validate(application, 
				StringUtils.isEmpty(application.getParentApplicationKey()) ? ParentApplication.class : ChildApplication.class);

		if (!CollectionUtils.isEmpty(validationErrors)) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Inside createApplication method controller - resource validation failed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_001", validationErrors.stream().findFirst().get().getMessage()));
		} else if ((StringUtils.isBlank(application.getL2ProductCode()) && (null == application.getL2ProductKey()))
				|| (!StringUtils.isBlank(application.getParentApplicationKey())
						&& StringUtils.isBlank(application.getL3ProductCode())
						&& (null == application.getL3ProductKey()))) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Inside createApplication method controller - resource validation failed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_001", "Input Error"));
		}

		else {
			return new ResponseEntity<>(applicationService.createApplication(application, headers), HttpStatus.CREATED);
		}
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update Credit application", notes = "Update credit application with applicant id", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Application updated Successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/applicants", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateApplication(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			 @RequestParam("applicantid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicantid should be numeric & should not exceeds size") String applicantId, 
			 @RequestHeader HttpHeaders headers){

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateApplication method controller - application :" + applicationId + " update started " + "for applicant :"+ applicantId);
		applicationService.updateApplication(applicationId, applicantId);
		
		return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get MCP Credit application ", notes = "Get credit application details for MCP with applicationId", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application Details", response = ApplicationDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "${api.omcreditapplicationservice.applicationdetails.mcp.GET.uri}")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<ApplicationDetails> application(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
		@PathVariable("userattributekey")@NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10,message = "userattributekey should be numeric & should not exceeds size") String userAttributeKey,
		@RequestParam(name = "applicationresources", required = false) String applicationResources,
		@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start get application for applicationId :"+applicationId);
		ApplicationDetails application = applicationService.getApplicationDetails(applicationId, userAttributeKey, applicationResources);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "End get application."+application);
		return new ResponseEntity<>(application, HttpStatus.OK);
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.SYSTEM, Role.EMPLOYEE, Role.SYSTEMPARTNER })  
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get application for parentApplicationKey", notes = "Get application for parentApplicationKey", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application Details", response = ApplicationDetail.class, responseContainer = "List"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.application.GET.uri}")
	@CrossOrigin
	public ResponseEntity<Object> getApplication(
			@RequestParam("mobile") @Pattern(regexp = "(0/91)?[6-9][0-9]{9}", message = "mobile is not valid") String mobile,
			@RequestParam("dateOfBirth") @Pattern(regexp = "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", message = "Invalid date") String dateOfBirth,
			@RequestParam("productKey") String productKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Recieved Header : " + headers);
		if(!StringUtils.isEmpty(mobile)&& !StringUtils.isEmpty(dateOfBirth) &&!StringUtils.isEmpty(productKey))
		{
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In controller:fetching application details");
			List<ApplicationDetail> application = applicationService.getApplication(mobile, dateOfBirth, productKey,
					headers);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In controller:fetching application details completed sucessfully.");
			return new ResponseEntity<>(application, HttpStatus.OK);
		}
		else {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In controller:Invalid request");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_422", "Invalid request"));
		}
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.SYSTEM, Role.B2BPARTNER, Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get application", notes = "Fetch application details with applicationId", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching Application successful", response = ApplicationDetail.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}")
	@CrossOrigin
	//@EnableFineGrainCheck
	public ResponseEntity<ApplicationDetail> getApplicationProduct(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside controller: fetching application details started.");
		ApplicationDetail applicationDetail = applicationService.getApplicationProduct(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Fetching application details ended.");
		return new ResponseEntity<>(applicationDetail, HttpStatus.OK);
	}
	
	@Secured(value = { Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL, Role.PSEUDO_CUSTOMER,
			Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL,Role.SYSTEM, Role.INTERNAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get child applications from parentApplicationId", notes = "Get child applications from parentApplicationId", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching child Application successful", response = ApplicationDetail.class, responseContainer = "List"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Child Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/application/{applicationkey}/childs")
	@CrossOrigin
	//@EnableFineGrainCheck
	public ResponseEntity<?> getChildApplications(@PathVariable("applicationkey")  @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, @RequestParam("isInProcessing") String isInProcessing, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside controller: fetching child application details started for application : "+applicationId);
		List<ApplicationDetail> applicationDetail = applicationService.getChildApplications(applicationId, Boolean.parseBoolean(isInProcessing));
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside controller: fetching child application details ended for application : "+applicationId);
		return new ResponseEntity<>(applicationDetail, HttpStatus.OK);
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Data copy over for bank details from parent to child and vice versa", notes = "Data copy over for bank details from parent to child and vice versa", httpMethod = "POST")
	@ApiResponses(value = {
			 	@ApiResponse(code = 201, message = "Data copy over for bank details completed Successfully."),
			 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		        @ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PostMapping(value = "${api.omcreditapplicationservice.datacopyover.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> dataCopyOver(@PathVariable("applicationid")@NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationid,
			@PathVariable("destinationApplicationId")@NotBlank(message = "destinationApplicationId can not be null or empty") @Digits(fraction = 0, integer = 20,message = "destinationApplicationId should be numeric & should not exceeds size") String destinationApplication,
			@RequestBody List<String> sourceList,@RequestHeader HttpHeaders headers ) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside controller: dataCopyOver() method start with sourceApplicationId : "+applicationid +" and destinationApplicationId : "+destinationApplication);
		applicationService.dataCopyOver(applicationid,destinationApplication,sourceList);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside controller: Data copy over for bank details from parent to child and vice versa completed successfully.");
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update child application status", notes = "Update child application inProcess flag to active status", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Child application status updated Successfully.", response = ChildRecord.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)})
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/activate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateChildApplicationStatus(@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationId, 
			 @RequestHeader HttpHeaders headers){

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateChildApplicationStatus method applicationId :" + applicationId );
		//service call
		ChildRecord response = applicationService.updateChildApplicationStatus(applicationId);
		
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateChildApplicationStatus method with reponse : "+response);
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update manual flag details", notes = "Update manual flag for application", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Flag  updated Successfully.", response = AppUdfVerification.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)})
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/manualflag", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateManualFlagDetails(@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestBody AppUdfVerificationRequest udfVerificationRequest , 
			@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateManualFlagDetails method applicationId :" + applicationId );
		UdfFlagDetailKeyBean response = applicationService.updateManualFlagDetails(applicationId,udfVerificationRequest);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "ManualFlag Detais updated successfully: ");
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	@Secured(value = { Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL, Role.PSEUDO_CUSTOMER,
			Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.SYSTEMPARTNER,Role.INTERNAL }) 
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update application", notes = "Update Application for given application id.", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application Updated successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.creditapplication.PUT.uri}")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> updateApplicationParameters(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestBody ApplicationParameter applicationParameter, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"updateApplication : Start with " + applicationId + " for " + applicationParameter);
		applicationService.updateApplication(applicationId, applicationParameter);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Update application completed.");
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get list of Loan Purpose", notes = "Get list of Loan Purpose", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching child Application successful", response = LoanPurposeBean.class, responseContainer = "List"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Child Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.loanpurpose.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> getLoanPurpose(@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside controller: fetching loan purpose list started");
		List<LoanPurposeBean> loanPurposeList = applicationService.getLoanPurpose();
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside controller: fetching loan purpose list  ended ");
		return new ResponseEntity<>(loanPurposeList, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update Loan Purpose", notes = "Update Loan Purpose for application", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Loan Purpose for application updated successfully", response = LoanPurposeApplication.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.loanpurpose.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> putLoanPurpose(
			@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") 
			@Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@Valid @RequestBody  LoanPurposeBean loanPurpose, BindingResult bindingResult,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Started putLoanPurpose method applicationId :" + applicationId);
		if (bindingResult.hasErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("UNPROCESSABLE_ENTITY", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}
		LoanPurposeApplication response = applicationService.putLoanPurpose(applicationId, loanPurpose);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Started putLoanPurpose method applicationId : " + applicationId);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = { Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL, Role.PSEUDO_CUSTOMER,
			Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch application parameters", notes = "Fetch application parameters like loan & card limit for given application id.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application Parameter detail fetched successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.creditapplication.parameters.uri}")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> fetchApplicationParameters(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Input fetchApplicationParameters, applicationId : " + applicationId);
		ApplicationParameter applicationParameter = applicationService.fetchApplicationParameter(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Output fetchApplicationParameters, applicationId : "
				+ applicationId + " applicationParameter : " + applicationParameter);
		return new ResponseEntity<>(applicationParameter, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update Credit application HLProductIntent", notes = "Update Credit application HLProductIntent", httpMethod = "PUT")
	@ApiResponses(value = { @ApiResponse(code = 204, message = "Application intent updated Successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.hlproductintent.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateApplicationHlProductIntent(
			@PathVariable("applicationKey") @NotBlank(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers, @Valid @RequestBody HLProductIntentBean hlProductIntentBean) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateApplicationIntent method controller - application :" + applicationId + " update started "
						+ "for hl produtIntent" + hlProductIntentBean.toString());
		applicationService.updateApplicationHlProductIntent(applicationId, hlProductIntentBean);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get UTM parameters for the application and event", notes = "Get UTM params", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "UTMs fetched successfully", responseContainer = "List", response = ApplicationUtmParameter.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "UTM not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.applicationutmparameters.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<List<ApplicationUtmParameter>> fetchUTMParams(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestParam(name = "event", required = false) String event) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "start - fetchUTMParams with applicationId: "
			+ applicationId + " and event: " + event);
		return new ResponseEntity<List<ApplicationUtmParameter>>(applicationService.fetchUTMs(applicationId, event), HttpStatus.OK);
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Stamp BFL branch on application", notes = "Set BFL branch", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "BFL branch stamped successfully", response = ApplicationDetail.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.applications.city.PUT.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<ApplicationDetail> setBflBranch(
			@PathVariable("applicationkey") @NotBlank(message = "applicationkey can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationkey should be numeric & should not exceeds size") String applicationkey,
			@PathVariable("citykey") @NotBlank(message = "citykey can not be null or empty") @Digits(fraction = 0, integer = 10, message = "citykey should be numeric & should not exceeds size") String citykey,
			@RequestParam(value = "occupationTypeKey", required = false) String occupationTypeKey,
			@RequestParam(value = "pincodekey", required = false) String pincodekey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "start - BFL branch stamping on application : "+applicationkey+" for cityKey : "+citykey);
		return new ResponseEntity<ApplicationDetail>(applicationService.setBflBranch(applicationkey, citykey, occupationTypeKey,pincodekey), HttpStatus.OK);
	}
	
	
    @Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.SYSTEM, Role.EMPLOYEE,
            Role.SYSTEMPARTNER })
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
    @ApiOperation(value = "Get application Based on Search Parameter", notes = "Get application Based on Search Parameter", httpMethod = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Application Details", response = ApplicationDetail.class, responseContainer = "List"),
            @ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
            @ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
            @ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
            @ApiResponse(code = 422, message = "Invalid request", response = ErrorBean.class),
            @ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
    @GetMapping(value = "${api.omcreditapplicationservice.applications.GET.uri}")
    @CrossOrigin
    public ResponseEntity<Object> getApplications(
            @RequestParam(name = "mobile", required = false) @Pattern(regexp = "(0/91)?[6-9][0-9]{9}", message = "mobile is not valid") String mobile,
            @RequestParam(name = "dateOfBirth", required = false) @Pattern(regexp = "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", message = "Invalid date") String dateOfBirth,
            @RequestParam(name = "productKey", required = false) String productKey,
            @RequestParam(name = "userattributekey", required = false) String userAttributeKey,
            @RequestHeader HttpHeaders headers) {
        logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Recieved Header : " + headers);
        validateRequest(mobile, dateOfBirth, productKey, userAttributeKey);
        logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In controller:fetching application details");
        List<ApplicationDetail> application = applicationService.getApplications(mobile, dateOfBirth, productKey,
                userAttributeKey, headers);
        logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
                "In controller:fetching application details completed sucessfully.");
        return new ResponseEntity<>(application, HttpStatus.OK);

    }

    public void validateRequest(String mobile, String dateOfBirth, String productKey, String userAttributeKey) {
        logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
                "Inside validateRequest method For userAttributeKey: " + userAttributeKey + "||dateOfBirth :"
                        + dateOfBirth + "||mobile: " + mobile + "||productKey: " + productKey);
        if ((StringUtils.isEmpty(userAttributeKey)) && (StringUtils.isEmpty(mobile) && StringUtils.isEmpty(dateOfBirth)
                && StringUtils.isEmpty(productKey))) {
            throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
                    new ErrorBean(ApplicationConstants.OMCA_422, env.getProperty(ApplicationConstants.OMCA_422)));
        }
        if ((StringUtils.isEmpty(userAttributeKey)) && (StringUtils.isEmpty(mobile) || StringUtils.isEmpty(dateOfBirth)
                || StringUtils.isEmpty(productKey))) {
            throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
                    new ErrorBean(ApplicationConstants.OMCA_423, env.getProperty(ApplicationConstants.OMCA_423)));
        }
    }
	
}
