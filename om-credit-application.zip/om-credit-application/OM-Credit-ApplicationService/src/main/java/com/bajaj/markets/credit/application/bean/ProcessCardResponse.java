package com.bajaj.markets.credit.application.bean;

public class ProcessCardResponse {

	private Boolean isCaseCreated;
	private String caseReferenceId;
	private String failureReason;
	private String transactionId;

	public Boolean getIsCaseCreated() {
		return isCaseCreated;
	}

	public void setIsCaseCreated(Boolean isCaseCreated) {
		this.isCaseCreated = isCaseCreated;
	}

	public String getCaseReferenceId() {
		return caseReferenceId;
	}

	public void setCaseReferenceId(String caseReferenceId) {
		this.caseReferenceId = caseReferenceId;
	}

	public String getFailureReason() {
		return failureReason;
	}

	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	@Override
	public String toString() {
		return "ProcessCardResponse [isCaseCreated=" + isCaseCreated + ", caseReferenceId=" + caseReferenceId
				+ ", failureReason=" + failureReason + ", transactionId=" + transactionId + "]";
	}

}
