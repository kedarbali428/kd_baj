package com.bajaj.markets.credit.application.bean;

public class ApplicationDispositionResponse {

	private String applicationId;
	
	private String dispositionCode;
	
	private String subdispositionCode;

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getDispositionCode() {
		return dispositionCode;
	}

	public void setDispositionCode(String dispositionCode) {
		this.dispositionCode = dispositionCode;
	}

	public String getSubdispositionCode() {
		return subdispositionCode;
	}

	public void setSubdispositionCode(String subdispositionCode) {
		this.subdispositionCode = subdispositionCode;
	}
}
