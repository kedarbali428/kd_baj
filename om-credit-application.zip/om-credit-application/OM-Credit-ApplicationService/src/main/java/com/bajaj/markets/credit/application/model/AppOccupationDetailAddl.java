package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_occupation_detail_addl", schema = "dmcredit")
public class AppOccupationDetailAddl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="app_occupation_detail_addl_generator", sequenceName="dmcredit.seq_pk_app_occupation_detail_addl", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_occupation_detail_addl_generator")
	private Long appoccupationaddlkey;
	
	private Long appoccupationkey;
	
	private Integer principalindmastkey;
	
	private Integer isactive;
	
	private Long lstupdateby;
	
	private Timestamp lstupdatedt;

	public Long getAppoccupationaddlkey() {
		return appoccupationaddlkey;
	}

	public void setAppoccupationaddlkey(Long appoccupationaddlkey) {
		this.appoccupationaddlkey = appoccupationaddlkey;
	}

	public Long getAppoccupationkey() {
		return appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public Integer getPrincipalindmastkey() {
		return principalindmastkey;
	}

	public void setPrincipalindmastkey(Integer principalindmastkey) {
		this.principalindmastkey = principalindmastkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	
	@Override
	public AppOccupationDetailAddl clone() throws CloneNotSupportedException {
		AppOccupationDetailAddl addl = new AppOccupationDetailAddl();
		addl.setAppoccupationkey(this.appoccupationkey);
		addl.setIsactive(this.isactive);
		addl.setLstupdateby(this.lstupdateby);
		addl.setLstupdatedt(this.lstupdatedt);
		addl.setPrincipalindmastkey(this.principalindmastkey);
		return addl;
	}


	@Override
	public String toString() {
		return "AppOccupationDetailAddl [appoccupationaddlkey=" + appoccupationaddlkey + ", appoccupationkey="
				+ appoccupationkey + ", principalindmastkey=" + principalindmastkey + ", isactive=" + isactive
				+ ", lstupdateby=" + lstupdateby + ", lstupdatedt=" + lstupdatedt + "]";
	}
}