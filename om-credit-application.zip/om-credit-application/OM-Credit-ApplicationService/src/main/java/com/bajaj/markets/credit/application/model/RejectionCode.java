package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the rejection_code database table.
 * 
 */
@Entity
@Table(name = "rejection_code", schema = "dmcredit")
public class RejectionCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long rejectcodekey;

	private String applicationlvlflag;

	private String categorycd;

	private Integer coolperioddays;

	private Integer coolprdapplicableflg;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long prodcatkey;

	private Long prodkey;

	private String rejectcode;

	private String rejectcodedesc;

	//bi-directional many-to-one association to AppRejectionDetail
	@OneToMany(mappedBy="rejectionCode")
	private Set<AppRejectionDetail> appRejectionDetails;

	public RejectionCode() {
	}

	public Long getRejectcodekey() {
		return this.rejectcodekey;
	}

	public void setRejectcodekey(Long rejectcodekey) {
		this.rejectcodekey = rejectcodekey;
	}

	public String getApplicationlvlflag() {
		return this.applicationlvlflag;
	}

	public void setApplicationlvlflag(String applicationlvlflag) {
		this.applicationlvlflag = applicationlvlflag;
	}

	public String getCategorycd() {
		return this.categorycd;
	}

	public void setCategorycd(String categorycd) {
		this.categorycd = categorycd;
	}

	public Integer getCoolperioddays() {
		return this.coolperioddays;
	}

	public void setCoolperioddays(Integer coolperioddays) {
		this.coolperioddays = coolperioddays;
	}

	public Integer getCoolprdapplicableflg() {
		return this.coolprdapplicableflg;
	}

	public void setCoolprdapplicableflg(Integer coolprdapplicableflg) {
		this.coolprdapplicableflg = coolprdapplicableflg;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdcatkey() {
		return this.prodcatkey;
	}

	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public Long getProdkey() {
		return this.prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getRejectcode() {
		return this.rejectcode;
	}

	public void setRejectcode(String rejectcode) {
		this.rejectcode = rejectcode;
	}

	public String getRejectcodedesc() {
		return this.rejectcodedesc;
	}

	public void setRejectcodedesc(String rejectcodedesc) {
		this.rejectcodedesc = rejectcodedesc;
	}

	public Set<AppRejectionDetail> getAppRejectionDetails() {
		return this.appRejectionDetails;
	}

	public void setAppRejectionDetails(Set<AppRejectionDetail> appRejectionDetails) {
		this.appRejectionDetails = appRejectionDetails;
	}

	public AppRejectionDetail addAppRejectionDetail(AppRejectionDetail appRejectionDetail) {
		getAppRejectionDetails().add(appRejectionDetail);
		appRejectionDetail.setRejectionCode(this);

		return appRejectionDetail;
	}

	public AppRejectionDetail removeAppRejectionDetail(AppRejectionDetail appRejectionDetail) {
		getAppRejectionDetails().remove(appRejectionDetail);
		appRejectionDetail.setRejectionCode(null);

		return appRejectionDetail;
	}

}