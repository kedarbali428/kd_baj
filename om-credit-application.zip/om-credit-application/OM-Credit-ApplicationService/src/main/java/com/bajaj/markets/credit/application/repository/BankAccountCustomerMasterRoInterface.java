package com.bajaj.markets.credit.application.repository;

import java.util.Optional;

import com.bajaj.markets.credit.application.model.BankAccountCustomerMaster;

public interface BankAccountCustomerMasterRoInterface extends ReadInterface<BankAccountCustomerMaster, Integer> {

	Optional<BankAccountCustomerMaster> findByBankacctcatcodeAndIsactive(String bankAccountCatCode, Integer isActive);

}
