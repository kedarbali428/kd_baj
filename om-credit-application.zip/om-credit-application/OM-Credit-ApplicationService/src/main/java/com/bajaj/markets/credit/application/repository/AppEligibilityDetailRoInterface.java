package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.AppEligibilityDetail;

public interface AppEligibilityDetailRoInterface extends ReadInterface<AppEligibilityDetail, Long> {
	AppEligibilityDetail findByAppattrbkeyAndIsactive(Long appattrbkey, Integer isactive);

	List<AppEligibilityDetail> findByAppattrbkeyAndIsactiveOrderByLstupdatedtDesc(Long appattrbkey, Integer isactive);

}
