package com.bajaj.markets.credit.application.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;

import com.bajaj.markets.credit.application.model.AppPropertyDetail;

public interface AppPropertyDetailRoInterface extends ReadInterface<AppPropertyDetail, Long> {

	public Optional<AppPropertyDetail> findByApplicationKeyAndIsActive(Long applicationkey, Integer isActive);

	@Query("select a from AppPropertyDetail a where a.applicationKey=:applicationKey AND a.isActive=:isActive")
	public List<AppPropertyDetail> findByApplicationKeyAndIsActiveFlag(Long applicationKey, Integer isActive);

}
