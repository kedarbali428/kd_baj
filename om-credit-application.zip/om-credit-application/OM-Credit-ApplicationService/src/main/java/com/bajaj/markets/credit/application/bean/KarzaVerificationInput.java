package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;
import java.util.List;

public class KarzaVerificationInput implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String branch;
	private String applicationID;
	private String l3Product;
	private String occupationType;
	private String l4Product;
	private String principalName;
	private Boolean existingCustomerFlag;
	private Integer subStagePercentage;
	private Long emplrScore;
	private Double nameConfidence;
	private Boolean settledFlag;
	private Boolean recentFlag;
	private Boolean uniqueFlag;
	private List<String> deviationCodes;
	private String officialEmailDomain;
	private String creditVidyaStatus;
	private Boolean nameExactFlag;
	private String karzaApproach;
	private String karzaId;
	private Long status;
	private String companyCatogery;
	private String companyType;
	private List<OfferDetails> offerDetails;
	private String customerProfileSegment;
    private String microSegment;
    private String journeyStamp;

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public void setApplicationID(String applicationID) {
		this.applicationID = applicationID;
	}

	public void setL3Product(String l3Product) {
		this.l3Product = l3Product;
	}

	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}

	public void setL4Product(String l4Product) {
		this.l4Product = l4Product;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public void setExistingCustomerFlag(Boolean existingCustomerFlag) {
		this.existingCustomerFlag = existingCustomerFlag;
	}

	public void setSubStagePercentage(Integer subStagePercentage) {
		this.subStagePercentage = subStagePercentage;
	}

	public void setEmplrScore(Long emplrScore) {
		this.emplrScore = emplrScore;
	}

	public void setNameConfidence(Double nameConfidence) {
		this.nameConfidence = nameConfidence;
	}

	public void setSettledFlag(Boolean settledFlag) {
		this.settledFlag = settledFlag;
	}

	public void setRecentFlag(Boolean recentFlag) {
		this.recentFlag = recentFlag;
	}

	public void setUniqueFlag(Boolean uniqueFlag) {
		this.uniqueFlag = uniqueFlag;
	}

	public void setDeviationCodes(List<String> deviationCodes) {
		this.deviationCodes = deviationCodes;
	}

	public void setOfficialEmailDomain(String officialEmailDomain) {
		this.officialEmailDomain = officialEmailDomain;
	}

	public void setCreditVidyaStatus(String creditVidyaStatus) {
		this.creditVidyaStatus = creditVidyaStatus;
	}

	public void setNameExactFlag(Boolean nameExactFlag) {
		this.nameExactFlag = nameExactFlag;
	}

	public void setKarzaApproach(String karzaApproach) {
		this.karzaApproach = karzaApproach;
	}

	public void setKarzaId(String karzaId) {
		this.karzaId = karzaId;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public void setCompanyCatogery(String companyCatogery) {
		this.companyCatogery = companyCatogery;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public void setOfferDetails(List<OfferDetails> offerDetails) {
		this.offerDetails = offerDetails;
	}
	
	public String getCustomerProfileSegment() {
		return customerProfileSegment;
	}

	public void setCustomerProfileSegment(String customerProfileSegment) {
		this.customerProfileSegment = customerProfileSegment;
	}

	public String getMicroSegment() {
		return microSegment;
	}

	public void setMicroSegment(String microSegment) {
		this.microSegment = microSegment;
	}

	public String getJourneyStamp() {
		return journeyStamp;
	}

	public void setJourneyStamp(String journeyStamp) {
		this.journeyStamp = journeyStamp;
	}

	@Override
	public String toString() {
		return "KarzaVerificationInput [branch=" + branch + ", applicationID=" + applicationID + ", l3Product="
				+ l3Product + ", occupationType=" + occupationType + ", l4Product=" + l4Product + ", principalName="
				+ principalName + ", existingCustomerFlag=" + existingCustomerFlag + ", subStagePercentage="
				+ subStagePercentage + ", emplrScore=" + emplrScore + ", nameConfidence=" + nameConfidence
				+ ", settledFlag=" + settledFlag + ", recentFlag=" + recentFlag + ", uniqueFlag=" + uniqueFlag
				+ ", deviationCodes=" + deviationCodes + ", officialEmailDomain=" + officialEmailDomain
				+ ", creditVidyaStatus=" + creditVidyaStatus + ", nameExactFlag=" + nameExactFlag + ", karzaApproach="
				+ karzaApproach + ", karzaId=" + karzaId + ", status=" + status + ", companyCatogery=" + companyCatogery
				+ ", companyType=" + companyType + ", offerDetails=" + offerDetails + ", customerProfileSegment="
				+ customerProfileSegment + ", microSegment=" + microSegment + ", journeyStamp=" + journeyStamp + "]";
	}

	 

}
