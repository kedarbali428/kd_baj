package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class AdditionalCustomerDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private String alternateMobileNumber;
	private Long lstUpdateBy;
	private Long phoneTypeKey;

	public String getAlternateMobileNumber() {
		return alternateMobileNumber;
	}

	public void setAlternateMobileNumber(String alternateMobileNumber) {
		this.alternateMobileNumber = alternateMobileNumber;
	}

	public Long getLstUpdateBy() {
		return lstUpdateBy;
	}

	public void setLstUpdateBy(Long lstUpdateBy) {
		this.lstUpdateBy = lstUpdateBy;
	}

	public Long getTypeKey() {
		return phoneTypeKey;
	}

	public void setTypeKey(Long typeKey) {
		this.phoneTypeKey = typeKey;
	}

}
