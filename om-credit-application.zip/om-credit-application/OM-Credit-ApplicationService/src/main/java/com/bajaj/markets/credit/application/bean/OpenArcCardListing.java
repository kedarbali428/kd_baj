package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class OpenArcCardListing {

	private List<PrincipalProductOutput> principleProductDetails;
	private Boolean cibilRequired;

	public List<PrincipalProductOutput> getPrincipleProductDetails() {
		return principleProductDetails;
	}

	public void setPrincipleProductDetails(List<PrincipalProductOutput> principleProductDetails) {
		this.principleProductDetails = principleProductDetails;
	}

	public Boolean getCibilRequired() {
		return cibilRequired;
	}

	public void setCibilRequired(Boolean cibilRequired) {
		this.cibilRequired = cibilRequired;
	}

	@Override
	public String toString() {
		return "EligibilityRejectionOutput [principleProductDetails=" + principleProductDetails + ", cibilRequired="
				+ cibilRequired + "]";
	}

}
