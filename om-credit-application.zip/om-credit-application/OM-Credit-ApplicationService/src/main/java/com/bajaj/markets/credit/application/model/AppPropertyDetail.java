package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_property_detail", schema = "dmcredit")
public class AppPropertyDetail implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_property_detail_apppropertydetkey_generator", sequenceName = "dmcredit.seq_pk_app_property_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_property_detail_apppropertydetkey_generator")
	@Column(name = "apppropertydetkey")
	private Long appPropertyDetKey;

	@Column(name = "applicationkey")
	private Long applicationKey;

	@Column(name = "buildername")
	private String builderName;

	@Column(name = "isactive")
	private Integer isActive;

	@Column(name = "ispropertyidentified")
	private Integer isPropertyIdentified;

	@Column(name = "lstupdateby")
	private Long lstUpdateBy;

	@Column(name = "lstupdatedt")
	private Timestamp lstUpdateDt;

	@Column(name = "projectname")
	private String projectName;

	@Column(name = "propertycost")
	private BigDecimal propertyCost;

	@Column(name = "propertysizebhk")
	private BigDecimal propertySizeBhk;

	@Column(name = "propertysizeinsqrfeet")
	private BigDecimal propertySizeInSqrFeet;

	@Column(name = "propertystatus")
	private String propertyStatus;

	@Column(name = "propertytype")
	private String propertyType;

	@Column(name = "propertyusage")
	private String propertyUsage;

	@Column(name = "searchassistrequired")
	private Integer searchAssistRequired;

	@Column(name = "userbudget")
	private BigDecimal userBudget;
	
	@Column(name = "propertymarketvalue")
	private BigDecimal propertyMarketValue;

	public AppPropertyDetail() {
	}

	public Long getAppPropertyDetKey() {
		return appPropertyDetKey;
	}

	public void setAppPropertyDetKey(Long appPropertyDetKey) {
		this.appPropertyDetKey = appPropertyDetKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getBuilderName() {
		return builderName;
	}

	public void setBuilderName(String builderName) {
		this.builderName = builderName;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public Integer getIsPropertyIdentified() {
		return isPropertyIdentified;
	}

	public void setIsPropertyIdentified(Integer isPropertyIdentified) {
		this.isPropertyIdentified = isPropertyIdentified;
	}

	public Long getLstUpdateBy() {
		return lstUpdateBy;
	}

	public void setLstUpdateBy(Long lstUpdateBy) {
		this.lstUpdateBy = lstUpdateBy;
	}

	public Timestamp getLstUpdateDt() {
		return lstUpdateDt;
	}

	public void setLstUpdateDt(Timestamp lstUpdateDt) {
		this.lstUpdateDt = lstUpdateDt;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public BigDecimal getPropertyCost() {
		return propertyCost;
	}

	public void setPropertyCost(BigDecimal propertyCost) {
		this.propertyCost = propertyCost;
	}

	public BigDecimal getPropertySizeBhk() {
		return propertySizeBhk;
	}

	public void setPropertySizeBhk(BigDecimal propertySizeBhk) {
		this.propertySizeBhk = propertySizeBhk;
	}

	public BigDecimal getPropertySizeInSqrFeet() {
		return propertySizeInSqrFeet;
	}

	public void setPropertySizeInSqrFeet(BigDecimal propertySizeInSqrFeet) {
		this.propertySizeInSqrFeet = propertySizeInSqrFeet;
	}

	public String getPropertyStatus() {
		return propertyStatus;
	}

	public void setPropertyStatus(String propertyStatus) {
		this.propertyStatus = propertyStatus;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public String getPropertyUsage() {
		return propertyUsage;
	}

	public void setPropertyUsage(String propertyUsage) {
		this.propertyUsage = propertyUsage;
	}

	public Integer getSearchAssistRequired() {
		return searchAssistRequired;
	}

	public void setSearchAssistRequired(Integer searchAssistRequired) {
		this.searchAssistRequired = searchAssistRequired;
	}

	public BigDecimal getUserBudget() {
		return userBudget;
	}

	public void setUserBudget(BigDecimal userBudget) {
		this.userBudget = userBudget;
	}
	
	public BigDecimal getPropertyMarketValue() {
		return propertyMarketValue;
	}

	public void setPropertyMarketValue(BigDecimal propertyMarketValue) {
		this.propertyMarketValue = propertyMarketValue;
	}

	@Override
	public AppPropertyDetail clone() throws CloneNotSupportedException {
		AppPropertyDetail appPropertyDetail = new AppPropertyDetail();
		appPropertyDetail.setIsActive(this.isActive);
		appPropertyDetail.setIsPropertyIdentified(this.isPropertyIdentified);
		appPropertyDetail.setLstUpdateBy(this.lstUpdateBy);
		appPropertyDetail.setLstUpdateDt(this.getLstUpdateDt());
		appPropertyDetail.setPropertySizeBhk(this.propertySizeBhk);
		appPropertyDetail.setPropertySizeInSqrFeet(this.propertySizeInSqrFeet);
		appPropertyDetail.setApplicationKey(this.applicationKey);
		appPropertyDetail.setBuilderName(this.builderName);
		appPropertyDetail.setProjectName(this.projectName);
		appPropertyDetail.setPropertyCost(this.propertyCost);
		appPropertyDetail.setPropertyStatus(this.propertyStatus);
		appPropertyDetail.setPropertyType(this.propertyType);
		appPropertyDetail.setPropertyUsage(this.propertyUsage);
		appPropertyDetail.setSearchAssistRequired(this.searchAssistRequired);
		appPropertyDetail.setUserBudget(this.userBudget);
		appPropertyDetail.setPropertyMarketValue(this.propertyMarketValue);
		return appPropertyDetail;
	}
}
