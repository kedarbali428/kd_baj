package com.bajaj.markets.credit.application.bean;

public class PrincipalPinCodeServiceable {

	private Long pinservicekey;

	private Long pincodekey;

	private Long prodkey;

	private String cityname;

	private String tier;

	private String pennantbvcodesal;

	private String sourcecode;

	private String stdcode;

	private String statename;
	
	private String citycode;

	public Long getPinservicekey() {
		return pinservicekey;
	}

	public void setPinservicekey(Long pinservicekey) {
		this.pinservicekey = pinservicekey;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getPennantbvcodesal() {
		return pennantbvcodesal;
	}

	public void setPennantbvcodesal(String pennantbvcodesal) {
		this.pennantbvcodesal = pennantbvcodesal;
	}

	public String getSourcecode() {
		return sourcecode;
	}

	public void setSourcecode(String sourcecode) {
		this.sourcecode = sourcecode;
	}

	public String getStdcode() {
		return stdcode;
	}

	public void setStdcode(String stdcode) {
		this.stdcode = stdcode;
	}

	public String getStatename() {
		return statename;
	}

	public void setStatename(String statename) {
		this.statename = statename;
	}

	public String getCitycode() {
		return citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

}
