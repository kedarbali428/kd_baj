package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class FeesList {

	private BigDecimal feesInPercent;	
	private BigDecimal feesInAmount;
	private String feeCode;
	public BigDecimal getFeesInPercent() {
		return feesInPercent;
	}
	public void setFeesInPercent(BigDecimal feesInPercent) {
		this.feesInPercent = feesInPercent;
	}
	public BigDecimal getFeesInAmount() {
		return feesInAmount;
	}
	public void setFeesInAmount(BigDecimal feesInAmount) {
		this.feesInAmount = feesInAmount;
	}
	public String getFeeCode() {
		return feeCode;
	}
	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}
	@Override
	public String toString() {
		return "FeesList [feesInPercent=" + feesInPercent + ", feesInAmount=" + feesInAmount + ", feeCode=" + feeCode
				+ "]";
	} 
	
	
}
