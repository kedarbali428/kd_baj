package com.bajaj.markets.credit.application.helper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.bflrlock.lib.model.RedisLockResponse;
import com.bajaj.bfsd.bflrlock.lib.utility.RedisUtility;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.application.bean.ApplicationPhoneNumberDetails;
import com.bajaj.markets.credit.application.model.AppBusinessDetail;
import com.bajaj.markets.credit.application.model.AppFinEligibility;
import com.bajaj.markets.credit.application.model.AppLoanPricing;
import com.bajaj.markets.credit.application.model.AppLoanPricingFees;
import com.bajaj.markets.credit.application.model.AppOccupationDetail;
import com.bajaj.markets.credit.application.model.AppOccupationDetailAddl;
import com.bajaj.markets.credit.application.model.AppOccupationSalary;
import com.bajaj.markets.credit.application.model.AppProductListing;
import com.bajaj.markets.credit.application.model.AppPropertyDetail;
import com.bajaj.markets.credit.application.model.AppSalariedDetail;
import com.bajaj.markets.credit.application.model.AppVerificationDetail;
import com.bajaj.markets.credit.application.model.Application;
import com.bajaj.markets.credit.application.model.ApplicationAddress;
import com.bajaj.markets.credit.application.model.ApplicationAttribute;
import com.bajaj.markets.credit.application.model.ApplicationBankDetail;
import com.bajaj.markets.credit.application.model.ApplicationEmail;
import com.bajaj.markets.credit.application.model.ApplicationPhoneNumber;
import com.bajaj.markets.credit.application.repository.tx.AppBusinessDetailRepository;
import com.bajaj.markets.credit.application.repository.tx.AppFinEligibilityRepository;
import com.bajaj.markets.credit.application.repository.tx.AppLoanPricingFeesRepository;
import com.bajaj.markets.credit.application.repository.tx.AppLoanPricingRepository;
import com.bajaj.markets.credit.application.repository.tx.AppOccupationDetailAddlRepository;
import com.bajaj.markets.credit.application.repository.tx.AppOccupationDetailRepository;
import com.bajaj.markets.credit.application.repository.tx.AppOccupationSalaryRepository;
import com.bajaj.markets.credit.application.repository.tx.AppPropertyDetailRepository;
import com.bajaj.markets.credit.application.repository.tx.AppSalariedDetailRepository;
import com.bajaj.markets.credit.application.repository.tx.AppVerificationDetailRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationAddressRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationAttributeRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationBankDetailRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationEmailRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationPhoneNumberRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationProductListingRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationRepository;

/**
 * Helper Class to copy data from parent application to child application
 *
 */
@Component
public class ApplicationDataCopyHelper {
	
	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;

	@Autowired
	private ApplicationEmailRepository applicationEmailRepository;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private AppVerificationDetailRepository appVerificationDetailRepository;
	
	@Autowired
	AppSalariedDetailRepository appSalariedDetailRepository;
	
	@Autowired
	AppBusinessDetailRepository appBusinessDetailRepository;
	
	@Autowired 
	ApplicationAttributeRepository applicationAttributeRepository;
	
	@Autowired
	AppOccupationDetailAddlRepository appOccupationDetailAddlRepository;
	
	@Autowired
	private ApplicationAddressRepository applicationAddressRepository;

	@Autowired
	private AppOccupationDetailRepository appOccupationDetailRepository;
	
	@Autowired
	private ApplicationBankDetailRepository applicationBankDetailRepository;

	@Autowired
	private AppOccupationSalaryRepository appOccupationSalaryRepository;

	@Autowired
	private ApplicationProductListingRepository applicationProductListingRepository;

	@Autowired
	private AppLoanPricingRepository appLoanPricingRepository;

	@Autowired
	private AppLoanPricingFeesRepository appLoanPricingFeesRepository;

	@Autowired
	private AppFinEligibilityRepository appFinEligibilityRepository;
	
	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private AppPropertyDetailRepository appPropertyDetailRepository;
	
	private static final String CLASSNAME = ApplicationDataCopyHelper.class.getName();

	@Autowired
	private RedisUtility redisUtility;

	private RedissonClient redisson;

	@Value("${application.redis.lock.timeout.seconds}")
	private int redisLockTimeOutSeconds;
	
	@Value("${application.redis.host}")
	private String redisHost;

	@Value("${application.redis.port}")
	private String redisPort;

	@Value("${application.redis.clustersetup}")
	private String clusterSetUpFlag;
	
	@Autowired
	private ApplicationPhoneNumberRepository applicationPhoneNumberRepository;
	
	@PostConstruct
	public void init() {
		redisson = redisUtility.getRedissonConnection(Boolean.parseBoolean(clusterSetUpFlag), redisHost, redisPort);
	}
	
	/**
	 * Method used to copy ApplicationAttributes from parent to child
	 * 
	 * @return ApplicationBuilder
	 * @throws Exception
	 */
	public void copyApplicationAttributes(Application parentApplication, Application childApplication)
			throws Exception {
        if (childApplication != null && parentApplication != null
                && !CollectionUtils.isEmpty(parentApplication.getApplicationAttributes())) {
            Set<ApplicationAttribute> childAttributes = childApplication.getApplicationAttributes();
            if (childAttributes == null) {
                childAttributes = new HashSet<>();
            }
           
            HashMap<String, Date> map = new HashMap<>();
            for (ApplicationAttribute sourceAttribute : parentApplication.getApplicationAttributes()) {
                for(ApplicationAttribute eachExistingChild : childAttributes) {
                    if(eachExistingChild.getDob().compareTo(sourceAttribute.getDob()) == 0
                            && eachExistingChild.getMobile().longValue() == sourceAttribute.getMobile().longValue() && sourceAttribute.getApplicanttype() == 1l) {
                        //found existing row, update data
                        copyNewData(eachExistingChild, sourceAttribute);
                        map.put(sourceAttribute.getMobile().toString(), sourceAttribute.getDob());
                    }
                }
            }
           
            for (ApplicationAttribute sourceAttribute : parentApplication.getApplicationAttributes()) {
                if(null!= sourceAttribute.getMobile() && !map.containsKey(sourceAttribute.getMobile().toString())) {
                   if(sourceAttribute.getApplicanttype() == 1l) {
                	 ApplicationAttribute newAttrb = sourceAttribute.clone();
                     newAttrb.setLstupdateby(customDefaultHeaders.getUserKey());
                     newAttrb.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
                     newAttrb.setApplication(childApplication);
                     childAttributes.add(newAttrb);
                   }
                }
            }
           
            childApplication.setApplicationAttributes(childAttributes);
            applicationRepository.save(childApplication);
        }
    }

	/**
	 * Method used to copy Application Emails from parent to child
	 * @return ApplicationBuilder
	 * @throws Exception
	 */
	public void copyEmails(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute) throws CloneNotSupportedException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying emails from parent to child ...");
		List<ApplicationEmail> sourceEmailList = applicationEmailRepository.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		List<ApplicationEmail> existingChildEmailList = applicationEmailRepository.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);
		emailCopyOver(sourceEmailList,existingChildEmailList,childAttribute);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Email copy from parent to child finished");
	}
	
	
	/**
	 * Method used to copy Application Address from parent to child
	 * 
	 * @return ApplicationBuilder
	 * @throws Exception
	 */
	public void copyAddress(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute) throws CloneNotSupportedException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying address from parent to child ...");
		List<ApplicationAddress> sourceAddressList = applicationAddressRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		List<ApplicationAddress>existingAddressList = applicationAddressRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(),1);
		if(!CollectionUtils.isEmpty(existingAddressList)) {
			for(ApplicationAddress existingAddress : existingAddressList ) {
				existingAddress.setIsactive(0);	
				existingAddress.setLstupdateby(customDefaultHeaders.getUserKey());
				existingAddress.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
				applicationAddressRepository.save(existingAddress);
			}
		}
		if (!CollectionUtils.isEmpty(sourceAddressList)) {
			List<ApplicationAddress> childAddressList = new ArrayList<>();
			for (ApplicationAddress sourceAddress : sourceAddressList) {
				ApplicationAddress clonedAddress = sourceAddress.clone();
				clonedAddress.setAppattrbkey(childAttribute.getAppattrbkey());
				childAddressList.add(clonedAddress);
			}
			if (!CollectionUtils.isEmpty(childAddressList)) {
				applicationAddressRepository.saveAll(childAddressList);
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Address copy from parent to child finished");
	}
	
	
	/**
	 * Method used to copy Application Address from parent to child
	 * 
	 * @return ApplicationBuilder
	 * @throws CloneNotSupportedException
	 * @throws Exception
	 */
	public void copyOccupation(ApplicationAttribute sourceAttribute, ApplicationAttribute destinationAttribute) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying occupation from source attribute: " +  sourceAttribute.getAppattrbkey()
				+ " to destination attribute: " + destinationAttribute.getAppattrbkey());

		AppOccupationDetail sourceOccupation = appOccupationDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		AppOccupationDetail destinationOccupation = appOccupationDetailRepository
				.findByAppattrbkeyAndIsactive(destinationAttribute.getAppattrbkey(), 1); 
		if (null != sourceOccupation) {
			if(null == destinationOccupation)
				destinationOccupation = new AppOccupationDetail();
			destinationOccupation = sourceOccupation.copySourceOccupationToDestination(destinationOccupation);
			destinationOccupation.setAppattrbkey(destinationAttribute.getAppattrbkey());
			destinationOccupation.setIsactive(1);
			destinationOccupation.setLstupdateby(customDefaultHeaders.getUserKey());
			destinationOccupation.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
			appOccupationDetailRepository.save(destinationOccupation);
			
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Occupation copied from source: " + sourceAttribute.getAppattrbkey()
				+ " to destination: " + destinationAttribute.getAppattrbkey());
		}
	}

	/**
	 * Method used to copy Application Verifcation Details from parent to child
	 * @param Application parentApp
	 * @throws Exception
	 */
	public void copyAppVerificationWithSource(Application parentApp, String source) throws CloneNotSupportedException {
		if (parentApp != null) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside copyVerificationsOnChild method fetching child for application : "
					+ parentApp.getApplicationkey() + " and copying its verifiaction data on it ");
			List<Application> childApplications = applicationRepository.findByParentapplicationkeyAndApplicationkeyNotAndIsactive(parentApp.getApplicationkey(),
					parentApp.getApplicationkey(), 1);
			if (!CollectionUtils.isEmpty(childApplications)) {
				AppVerificationDetail parentVerification = appVerificationDetailRepository
						.findByApplicationkeyAndIsactiveAndVerificationsrc(parentApp.getApplicationkey(), 1, source);
				if (parentVerification != null) {
					saveVerification(source, childApplications, parentVerification);
				}
			}
			//LEN-1308 copying verification status against parent application Id
			else{
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside copyVerificationsOnChild method. Checking if given aaplication Id is child application Id. Fetching parent for application.");
				if(!(parentApp.getApplicationkey().equals(parentApp.getParentapplicationkey()))) {
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside copyVerificationsOnChild method. Given aaplication Id is child application Id. Fetching parent for application : "
							+ parentApp.getApplicationkey() + " and copying its verifiaction data on it ");
					//fetching parent application for given application Id
					List<Application> parentApplication = applicationRepository.findByParentapplicationkeyAndApplicationkeyAndIsactive(parentApp.getParentapplicationkey(),parentApp.getParentapplicationkey(),1);
					if(!CollectionUtils.isEmpty(parentApplication)) {
						AppVerificationDetail childVerification = appVerificationDetailRepository
								.findByApplicationkeyAndIsactiveAndVerificationsrc(parentApp.getApplicationkey(), 1, source);
						if(childVerification !=null) {
							saveVerification(source,parentApplication,childVerification);	
						}
					}
				}
				
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "copyVerificationsOnChild method completed");
		}

	}

	private void saveVerification(String source, List<Application> applications, AppVerificationDetail verification) throws CloneNotSupportedException {
		List<AppVerificationDetail> clonedVerifications = new ArrayList<>();
		for (Application app : applications) {
			AppVerificationDetail existingVerification = appVerificationDetailRepository
					.findByApplicationkeyAndIsactiveAndVerificationsrc(app.getApplicationkey(), 1, source);
			if (existingVerification != null) {
				existingVerification.setIsactive(0);
				existingVerification.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
				existingVerification.setLstupdateby(customDefaultHeaders.getUserKey());
				appVerificationDetailRepository.save(existingVerification);
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"Existing record of  application " + app.getApplicationkey() + " marked as inactive");
			}
			AppVerificationDetail clonedVerification = verification.clone();
			clonedVerification.setApplicationkey(app.getApplicationkey());
			clonedVerifications.add(clonedVerification);
		}
		if (!CollectionUtils.isEmpty(clonedVerifications))
			appVerificationDetailRepository.saveAll(clonedVerifications);
	}

	public void copyBankDetails(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute,
			String source) throws CloneNotSupportedException {

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying bank details from ");
		List<ApplicationBankDetail> sourceBankDetailList = applicationBankDetailRepository
				.findByAppattrbkeyAndIsactiveAndSourceIgnoreCase(sourceAttribute.getAppattrbkey(), 1, source);

		List<ApplicationBankDetail> childBankDetailList = applicationBankDetailRepository
				.findByAppattrbkeyAndIsactiveAndSourceIgnoreCase(childAttribute.getAppattrbkey(), 1, source);

		if (!CollectionUtils.isEmpty(sourceBankDetailList) && !CollectionUtils.isEmpty(childBankDetailList)) {
			for (ApplicationBankDetail sourceBankDetail : sourceBankDetailList) {
				for (ApplicationBankDetail childBankDetail : childBankDetailList) {
					if (sourceBankDetail.getBankacctcatkey()==null || (sourceBankDetail.getBankacctcatkey().equals(childBankDetail.getBankacctcatkey()))) {
						ApplicationBankDetail clonedBankDetail = sourceBankDetail.clone();
						clonedBankDetail.setApplicationbankdetkey(childBankDetail.getApplicationbankdetkey());
						clonedBankDetail.setAppattrbkey(childAttribute.getAppattrbkey());
						clonedBankDetail.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
						applicationBankDetailRepository.save(clonedBankDetail);
					}
				}
			}
		}
		if (!CollectionUtils.isEmpty(sourceBankDetailList) && CollectionUtils.isEmpty(childBankDetailList)) {
			childBankDetailList = new ArrayList<>();
			for (ApplicationBankDetail sourceBankDetail : sourceBankDetailList) {
				ApplicationBankDetail clonedBankDetail = sourceBankDetail.clone();
				clonedBankDetail.setAppattrbkey(childAttribute.getAppattrbkey());
				clonedBankDetail.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
				childBankDetailList.add(clonedBankDetail);
			}
			applicationBankDetailRepository.saveAll(childBankDetailList);
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Bank details copy finished" + childBankDetailList.toString());
	}
	
	public void copyBankDetailsSecured(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute)
			throws CloneNotSupportedException {

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying all bank details from ");
		List<ApplicationBankDetail> sourceBankDetailList = applicationBankDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		List<ApplicationBankDetail> childBankDetailList = applicationBankDetailRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);
		if (!CollectionUtils.isEmpty(childBankDetailList)) {
			for (ApplicationBankDetail childBankDetail : childBankDetailList) {
				childBankDetail.setIsactive(0);
				childBankDetail.setLstupdateby(customDefaultHeaders.getUserKey());
				childBankDetail.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
				applicationBankDetailRepository.save(childBankDetail);
			}
		}
		for (ApplicationBankDetail sourceBankDetail : sourceBankDetailList) {
			ApplicationBankDetail clonedBankDetail = sourceBankDetail.clone();
			clonedBankDetail.setAppattrbkey(childAttribute.getAppattrbkey());
			clonedBankDetail.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
			childBankDetailList.add(clonedBankDetail);
		}
		if (!CollectionUtils.isEmpty(childBankDetailList)) {
			applicationBankDetailRepository.saveAll(childBankDetailList);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Bank details copy finished" + childBankDetailList.toString());
	}

	/**
	 * Method used to copy Application property details from parent to child
	 * 
	 * @throws Exception
	 */
	public void copyPropertyDetails(Application parentApplication, Application childApplication) throws Exception {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying property details from parent to child ...");
		Optional<AppPropertyDetail> appPropertyDetails = appPropertyDetailRepository
				.findByApplicationKeyAndIsActive(parentApplication.getApplicationkey(), ApplicationConstants.IS_ACTIVE);
		List<AppPropertyDetail> existingChildPropertyList = appPropertyDetailRepository
				.findByApplicationKeyAndIsActiveFlag(childApplication.getApplicationkey(), ApplicationConstants.IS_ACTIVE);
		if (!CollectionUtils.isEmpty(existingChildPropertyList)) {
			for (AppPropertyDetail existingPropertyDeatails : existingChildPropertyList) {
				existingPropertyDeatails.setIsActive(0);
				existingPropertyDeatails.setLstUpdateDt(new Timestamp(Calendar.getInstance().getTime().getTime()));
				existingPropertyDeatails.setLstUpdateBy(customDefaultHeaders.getUserKey());
				appPropertyDetailRepository.save(existingPropertyDeatails);
			}
		}
		if (appPropertyDetails.isPresent()) {
			AppPropertyDetail clonedAppPropertyDetails = appPropertyDetails.get().clone();
			clonedAppPropertyDetails.setApplicationKey(childApplication.getApplicationkey());
			clonedAppPropertyDetails.setLstUpdateDt(new Timestamp(Calendar.getInstance().getTime().getTime()));
			appPropertyDetailRepository.save(clonedAppPropertyDetails);
		} else {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
					"parent property details not present for application: " + parentApplication.getApplicationkey());
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "copyPropertyDetails from parent to child finished");

	}

	
	public void copyLoanPurpose(Application sourceApplication, Application destinationApplication) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying application from parent to child ...");
		if(null!=sourceApplication.getLoanPurpose()) {
			destinationApplication.setLoanPurpose(sourceApplication.getLoanPurpose());
			applicationRepository.save(destinationApplication);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Application copy from parent to child finished");
	}
	
	public void copyCurrentExperience(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute){
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying currentExperience from source to destination ...");
		AppSalariedDetail sourceOccupation = appSalariedDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		AppSalariedDetail destinationOccupation = appSalariedDetailRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);
		if(null!=destinationOccupation && null!=sourceOccupation && null!=sourceOccupation.getCurrentexperience()) {
			destinationOccupation.setCurrentexperience(sourceOccupation.getCurrentexperience());
			appSalariedDetailRepository.save(destinationOccupation);
		}
		
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying currentExperience from source to destination finished");
	}
	
	public void copyCurrentBusinessExperience(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute){
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying currentBusinessExperience from source to destination ...");
		AppBusinessDetail sourceOccupation = appBusinessDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		AppBusinessDetail destinationOccupation = appBusinessDetailRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);
		if(null!=destinationOccupation && null!=sourceOccupation && null!=sourceOccupation.getPresentbusinessvintage()) {
			destinationOccupation.setPresentbusinessvintage(sourceOccupation.getPresentbusinessvintage());
			appBusinessDetailRepository.save(destinationOccupation);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying currentBusinessExperience from source to destination finished");
	}
	
	public void copyAdditionalDetails(Application sourceApplication, Application destinationApplication) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Copying additional details from source to destination ...");
		ApplicationAttribute sourceApplicationAttribute = applicationAttributeRepository
				.findByApplication_ApplicationkeyAndIsactiveAndApplicanttype(sourceApplication.getApplicationkey(), 1,1L).get(0);
		ApplicationAttribute destinationApplicationAttribute = applicationAttributeRepository
				.findByApplication_ApplicationkeyAndIsactiveAndApplicanttype(destinationApplication.getApplicationkey(), 1,1L).get(0);
		if (null != sourceApplicationAttribute && null != destinationApplicationAttribute) {
			if (StringUtils.isNotEmpty(sourceApplicationAttribute.getMothername())) {
				destinationApplicationAttribute.setMothername(sourceApplicationAttribute.getMothername());
			}
			if (StringUtils.isNotEmpty(sourceApplicationAttribute.getFathername())) {
				destinationApplicationAttribute.setFathername(sourceApplicationAttribute.getFathername());
			}
			if (StringUtils.isNotEmpty(sourceApplicationAttribute.getQualification())) {
				destinationApplicationAttribute.setQualification(sourceApplicationAttribute.getQualification());
			}
			applicationAttributeRepository.save(destinationApplicationAttribute);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Copying additional details from source to destination ended");
	}

    private void setApplicationAddressParam(ApplicationAddress eachSourceAddress, ApplicationAddress eachDestinationAddress) {
        if (!StringUtils.isBlank(eachSourceAddress.getAddrsrc()))
            eachDestinationAddress.setAddrsrc(eachSourceAddress.getAddrsrc());
        if (null != eachSourceAddress.getCitykey())
            eachDestinationAddress.setCitykey(eachSourceAddress.getCitykey());
        if (null != eachSourceAddress.getCountryKey())
            eachDestinationAddress.setCountryKey(eachSourceAddress.getCountryKey());
        if (null != eachSourceAddress.getPincodekey())
            eachDestinationAddress.setPincodekey(eachSourceAddress.getPincodekey());
        if (null != eachSourceAddress.getLocalitykey())
            eachDestinationAddress.setLocalitykey(eachSourceAddress.getLocalitykey());
        if (null != eachSourceAddress.getStatekey())
            eachDestinationAddress.setStatekey(eachSourceAddress.getStatekey());
        if (!StringUtils.isBlank(eachSourceAddress.getAddressline1()))
            eachDestinationAddress.setAddressline1(eachSourceAddress.getAddressline1());
        if (!StringUtils.isBlank(eachSourceAddress.getAddressline2()))
            eachDestinationAddress.setAddressline2(eachSourceAddress.getAddressline2());
        if (null != eachSourceAddress.getCurrentaddressduration())
            eachDestinationAddress.setCurrentaddressduration(eachSourceAddress.getCurrentaddressduration());
        if (null != eachSourceAddress.getPrefferedflg()) {
            eachDestinationAddress.setPrefferedflg(eachSourceAddress.getPrefferedflg());
        }
        eachDestinationAddress.setEffstartdt(new Timestamp(Calendar.getInstance().getTime().getTime()));
        eachDestinationAddress.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
    }
	public void copyAddressWithAdressType(ApplicationAttribute sourceAttribute, ApplicationAttribute destinationAttribute, Long addrTypeKey) throws CloneNotSupportedException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"START - Copying Address from source to destination," + " sourceAttributekey :"
						+ sourceAttribute.getAppattrbkey() + ", destinationAttributeKey : "
						+ destinationAttribute.getAppattrbkey());

		List<ApplicationAddress> sourceAddressList = applicationAddressRepository
				.findByAddrtypkeyAndAppattrbkeyAndIsactive(addrTypeKey, sourceAttribute.getAppattrbkey(), 1);
		List<ApplicationAddress> destinationAddressList = applicationAddressRepository
				.findByAddrtypkeyAndAppattrbkeyAndIsactive(addrTypeKey, destinationAttribute.getAppattrbkey(), 1);
		
		if (!CollectionUtils.isEmpty(sourceAddressList)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "sourceAddressList size : "+sourceAddressList.size());
			if (CollectionUtils.isEmpty(destinationAddressList)) {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "No destination address found, copying all source address to destination");
				destinationAddressList = new ArrayList<ApplicationAddress>();
				for(ApplicationAddress eachSourceAddress : sourceAddressList) {
					ApplicationAddress clonedAddress = eachSourceAddress.clone();
					clonedAddress.setAppattrbkey(destinationAttribute.getAppattrbkey());
					destinationAddressList.add(clonedAddress);
				}
				applicationAddressRepository.saveAll(destinationAddressList);
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Found destination address found, updating them with same source.. "
						+ "destinationAddressList size : "+destinationAddressList.size());
				List<ApplicationAddress> destinationAddressListAddedNewly = new ArrayList<>();
				for(ApplicationAddress eachSourceAddress : sourceAddressList) {
					boolean sourceMatched = false;
					for(ApplicationAddress eachDestinationAddress : destinationAddressList) {
                        if (!AddressTypeEnum.CURRENT.getValue().equals(eachSourceAddress.getAddrtypkey())
                                || (null != eachDestinationAddress.getAddrsrc() && eachDestinationAddress.getAddrsrc()
                                        .equalsIgnoreCase(eachSourceAddress.getAddrsrc()))) {
                            sourceMatched = true;
                            setApplicationAddressParam(eachSourceAddress, eachDestinationAddress);
                        }
                    }
					if(!sourceMatched && AddressTypeEnum.CURRENT.getValue().equals(eachSourceAddress.getAddrtypkey())) {
						//If source and destination record address source didn't match then insert new
						ApplicationAddress newClonedAddress = eachSourceAddress.clone();
						newClonedAddress.setAppattrbkey(destinationAttribute.getAppattrbkey());
						destinationAddressListAddedNewly.add(newClonedAddress);
					}
				}
				if(!CollectionUtils.isEmpty(destinationAddressListAddedNewly)) {
					destinationAddressList.addAll(destinationAddressListAddedNewly);
				}
				applicationAddressRepository.saveAll(destinationAddressList);
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"END - Address from source to destination successful, " + " sourceAttributekey :"
						+ sourceAttribute.getAppattrbkey() + ", destinationAttributeKey : "
						+ destinationAttribute.getAppattrbkey());
	}
	
	public void copyIndustryType(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute) throws CloneNotSupportedException{
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying Industry type from parent to child ...");
		AppOccupationDetail sourceOccupation = appOccupationDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);

		AppOccupationDetail destinationOccupation = appOccupationDetailRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);

		AppOccupationDetailAddl sourceOccupationAddlDetail = appOccupationDetailAddlRepository.findByAppoccupationkeyAndIsactive(sourceOccupation.getAppoccupationkey(), 1);
		AppOccupationDetailAddl destinationOccupationAddlDetail = appOccupationDetailAddlRepository.findByAppoccupationkeyAndIsactive(destinationOccupation.getAppoccupationkey(), 1);

		if (null!=sourceOccupationAddlDetail && null!=destinationOccupationAddlDetail && null!=sourceOccupationAddlDetail.getPrincipalindmastkey()) {
			destinationOccupationAddlDetail.setPrincipalindmastkey(sourceOccupationAddlDetail.getPrincipalindmastkey());
			appOccupationDetailAddlRepository.save(destinationOccupationAddlDetail);
		}
		if(null!=sourceOccupationAddlDetail && null==destinationOccupationAddlDetail) {
			AppOccupationDetailAddl clonedOccupation = sourceOccupationAddlDetail.clone();
			clonedOccupation.setAppoccupationkey(destinationOccupation.getAppoccupationkey());
			appOccupationDetailAddlRepository.save(clonedOccupation);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Industry type copy from parent to child finished");
	}

	public void copyOccupatioSalary(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute)
			throws CloneNotSupportedException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying Occupation Salary from parent to child ...");
		AppOccupationDetail sourceOccupation = appOccupationDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);

		AppOccupationDetail destinationOccupation = appOccupationDetailRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);

		List<AppOccupationSalary> appOccupationSalaryList = appOccupationSalaryRepository
				.findByAppoccupationkeyAndIsactive(sourceOccupation.getAppoccupationkey(), 1);
		List<AppOccupationSalary> childOccupationSalaryList = appOccupationSalaryRepository
				.findByAppoccupationkeyAndIsactive(destinationOccupation.getAppoccupationkey(), 1);

		if (!CollectionUtils.isEmpty(appOccupationSalaryList) && CollectionUtils.isEmpty(childOccupationSalaryList)) {
			childOccupationSalaryList = new ArrayList<>();
			for (AppOccupationSalary appOccupationSalary : appOccupationSalaryList) {
				AppOccupationSalary clonedOccupationSal = appOccupationSalary.clone();
				clonedOccupationSal.setAppoccupationkey(destinationOccupation.getAppoccupationkey());
				childOccupationSalaryList.add(clonedOccupationSal);
			}
			if (!CollectionUtils.isEmpty(childOccupationSalaryList)) {
				appOccupationSalaryRepository.saveAll(childOccupationSalaryList);
			}
		} else if (!CollectionUtils.isEmpty(appOccupationSalaryList)
				&& !CollectionUtils.isEmpty(childOccupationSalaryList)) {
			for (AppOccupationSalary appOccupationSalary : appOccupationSalaryList) {
				for (AppOccupationSalary childOccupationSalary : childOccupationSalaryList) {
					if (appOccupationSalary.getSalarysource()
							.equalsIgnoreCase(childOccupationSalary.getSalarysource())) {
						childOccupationSalary.setSalary(appOccupationSalary.getSalary());
						childOccupationSalary.setSalarysource(appOccupationSalary.getSalarysource());
						childOccupationSalary.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
					}
				}
			}
			if (!CollectionUtils.isEmpty(childOccupationSalaryList)) {
				appOccupationSalaryRepository.saveAll(childOccupationSalaryList);
			}

		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Occupation Salary copy from parent to child finished");
	}
	private void copyNewData(ApplicationAttribute attribute, ApplicationAttribute sourceAttribute) {
        attribute.setDob(sourceAttribute.getDob());
        attribute.setIsactive(sourceAttribute.getIsactive());
        attribute.setLstupdateby(sourceAttribute.getLstupdateby());
        attribute.setLstupdatedt(sourceAttribute.getLstupdatedt());
        attribute.setMobile(sourceAttribute.getMobile());
        attribute.setFirstname(sourceAttribute.getFirstname());
        attribute.setMiddlename(sourceAttribute.getMiddlename());
        attribute.setLastname(sourceAttribute.getLastname());
        attribute.setSalutationkey(sourceAttribute.getSalutationkey());
        attribute.setMaritalstatuskey(sourceAttribute.getMaritalstatuskey());
        attribute.setGenderkey(sourceAttribute.getGenderkey());
        attribute.setResidencetypekey(sourceAttribute.getResidencetypekey());
        attribute.setApplicantkey(sourceAttribute.getApplicantkey());
        attribute.setPan(sourceAttribute.getPan());
        attribute.setApplicanttype(sourceAttribute.getApplicanttype());
        attribute.setQualification(sourceAttribute.getQualification());
        attribute.setMothername(sourceAttribute.getMothername());
        attribute.setFathername(sourceAttribute.getFathername());
        attribute.setLangkey(sourceAttribute.getLangkey());
        attribute.setNationalitykey(sourceAttribute.getNationalitykey());
        attribute.setLstupdateby(customDefaultHeaders.getUserKey());
        attribute.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
    }
	
	@Transactional
	public void copyIncomeVerificationDataToChildApplication(Application parentApplication,
			Application childApplication) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Inside copyIncomeVerificationDataToChildApplication method - copy over for L3 started");
		Timestamp applicationCreateDate = new Timestamp(Calendar.getInstance().getTime().getTime());
		long userKey = customDefaultHeaders.getUserKey();
		AppProductListing appProductListingCloned = null;
		AppLoanPricing appLoanPricingCloned = null;
		AppFinEligibility appFinEligibilityCloned = null;
		List<AppLoanPricingFees> parentAppLoanPricingFeesList;
		List<AppLoanPricingFees> childAppLoanPricingFeesList = null;
		AppLoanPricing parentAppLoanPricing;
		AppLoanPricing childAppLoanPricing = null;
		AppFinEligibility parentAppFinEligibility;
		AppFinEligibility childAppFinEligibility = null;
		Long appLoanPricingKey = null;
		RedisLockResponse redisLock = null;		
		try {
			List<AppProductListing> childAppProductListing = applicationProductListingRepository
					.findByApplicationkeyAndIsactive(childApplication.getApplicationkey(), 1);
			
			redisLock = redisUtility.getRedisLock(redisson,
					redisLockTimeOutSeconds,
					parentApplication.getApplicationkey() + childAppProductListing.get(0).getProdkey() + childAppProductListing.get(0).getProdtypekey()
							+ ApplicationConstants.APPPRODUCTLISTINGDETAIL_INFOLOCK);
			
			AppProductListing parentAppProductListing = applicationProductListingRepository
					.findByApplicationkeyAndIsactiveAndRiskoffertypeAndProdkeyAndProdtypekey(parentApplication.getApplicationkey(), 1,childAppProductListing.get(0).getRiskoffertype(),childAppProductListing.get(0).getProdkey(),childAppProductListing.get(0).getProdtypekey());
			if (parentAppProductListing == null || parentAppProductListing.getAppprodlistkey() == null) {
				throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND, new ErrorBean("OMCA_100",
						"copyIncomeVerificationDataToChildApplication: No details found in AppProductListing table over child application : "+parentApplication.getApplicationkey()));
			}
			parentAppLoanPricing = appLoanPricingRepository.findByApplicationkeyAndAppprodlistkey(
					parentApplication.getApplicationkey(), parentAppProductListing.getAppprodlistkey());
			parentAppLoanPricingFeesList = null != parentAppLoanPricing
					? appLoanPricingFeesRepository
							.findByApploanpricingkeyAndIsactive(parentAppLoanPricing.getApploanpricingkey(), 1)
					: null;
			parentAppFinEligibility = appFinEligibilityRepository.findByApplicationkeyAndIsactiveAndAppprodlistkey(
					parentApplication.getApplicationkey(), 1, parentAppProductListing.getAppprodlistkey());

			if (!CollectionUtils.isEmpty(childAppProductListing)) {
				childAppLoanPricing = appLoanPricingRepository.findByApplicationkeyAndAppprodlistkeyAndSourceAndIsactive(
						childApplication.getApplicationkey(),childAppProductListing.get(0).getAppprodlistkey(), ApplicationConstants.JOURNEY, 1);
				if (null != childAppLoanPricing) {
					childAppLoanPricingFeesList = appLoanPricingFeesRepository
							.findByApploanpricingkeyAndIsactive(childAppLoanPricing.getApploanpricingkey(), 1);
					if (null != childAppLoanPricingFeesList  && parentApplication.getProdcdl2()!=10002l) {
						for (AppLoanPricingFees fees : childAppLoanPricingFeesList) {
							fees.setApploanpricingkey(childAppLoanPricing.getApploanpricingkey());
							fees.setIsactive(0);
							fees.setLstupdateby(userKey);
							fees.setLstupdatedt(applicationCreateDate);
							appLoanPricingFeesRepository.save(fees);
						}
					}
				}
				childAppFinEligibility = appFinEligibilityRepository.findByApplicationkeyAndIsactiveAndAppprodlistkey(
						childApplication.getApplicationkey(), 1, childAppProductListing.get(0).getAppprodlistkey());
			}

			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Inside copyIncomeVerificationDataToChildApplication method - Cloning Existing record for AppProductListing for childApplication: "+childApplication.getApplicationkey() +" & parentApplication: "+parentApplication.getApplicationkey());
			appProductListingCloned = parentAppProductListing.clone();
			appLoanPricingCloned = parentAppLoanPricing != null ? parentAppLoanPricing.clone() : null;
			appFinEligibilityCloned = parentAppFinEligibility != null ? parentAppFinEligibility.clone() : null;

			if (!CollectionUtils.isEmpty(childAppProductListing))
				appProductListingCloned.setAppprodlistkey(childAppProductListing.get(0).getAppprodlistkey());
			else
				appProductListingCloned.setAppprodlistkey(null);

			appProductListingCloned.setApplicationkey(childApplication.getApplicationkey());
			appProductListingCloned.setLstupdateby(userKey);
			appProductListingCloned.setLstupdatedt(applicationCreateDate);			
			appProductListingCloned = applicationProductListingRepository.save(appProductListingCloned);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
					"copyIncomeVerificationDataToChildApplication: Successfully updated applicationProductListing for childApplication: "+childApplication.getApplicationkey() +" & parentApplication: "+parentApplication.getApplicationkey());
			
			if (appFinEligibilityCloned != null) {
				appFinEligibilityCloned.setAppfineligibilitykey(
						null != childAppFinEligibility ? childAppFinEligibility.getAppfineligibilitykey() : null);
				appFinEligibilityCloned.setApplicationkey(childApplication.getApplicationkey());
				appFinEligibilityCloned.setAppprodlistkey(appProductListingCloned.getAppprodlistkey());
				appFinEligibilityCloned.setLstupdateby(userKey);
				appFinEligibilityCloned.setLstupdatedt(applicationCreateDate);
				appFinEligibilityRepository.save(appFinEligibilityCloned);
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"copyIncomeVerificationDataToChildApplication : Successfully updated appFinEligibility for childApplication: "+childApplication.getApplicationkey() +" & parentApplication: "+parentApplication.getApplicationkey());
			}

			if (appLoanPricingCloned != null) {
				appLoanPricingCloned.setApploanpricingkey(
						null != childAppLoanPricing ? childAppLoanPricing.getApploanpricingkey() : null);
				appLoanPricingCloned.setApplicationkey(childApplication.getApplicationkey());
				appLoanPricingCloned.setAppprodlistkey(appProductListingCloned.getAppprodlistkey());
				if (null != childAppLoanPricing) {
					appLoanPricingCloned.setRoi(childAppLoanPricing.getRoi());
					appLoanPricingCloned.setRoiwithbundle(childAppLoanPricing.getRoiwithbundle());
					appLoanPricingCloned.setLoanamountwithbundle(childAppLoanPricing.getLoanamountwithbundle());
					appLoanPricingCloned.setFinalloanamount(childAppLoanPricing.getFinalloanamount());
					appLoanPricingCloned.setFinalroi(childAppLoanPricing.getFinalroi());
					appLoanPricingCloned.setEmiamount(childAppLoanPricing.getEmiamount());
					appLoanPricingCloned.setIsemi(childAppLoanPricing.getIsemi());
					appLoanPricingCloned.setDroplineemi(childAppLoanPricing.getDroplineemi());
					appLoanPricingCloned.setIstenure(childAppLoanPricing.getIstenure());
					appLoanPricingCloned.setDroplinetenure(childAppLoanPricing.getDroplinetenure());
					appLoanPricingCloned.setNetdisbursementamt(childAppLoanPricing.getNetdisbursementamt());
					appLoanPricingCloned.setLoanamt(childAppLoanPricing.getLoanamt());
					appLoanPricingCloned.setPricingflag(childAppLoanPricing.getPricingflag());
				}
				appLoanPricingCloned.setLstupdateby(userKey);
				appLoanPricingCloned.setLstupdatedt(applicationCreateDate);
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"copyIncomeVerificationDataToChildApplication :Before updating appLoanPricingcloned for childApplication: "+childApplication.getApplicationkey() +" & parentApplication: "+parentApplication.getApplicationkey());
				appLoanPricingCloned = appLoanPricingRepository.save(appLoanPricingCloned);
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"copyIncomeVerificationDataToChildApplication: Successfully updated appLoanPricing for childApplication: "+childApplication.getApplicationkey() +" & parentApplication: "+parentApplication.getApplicationkey());
				appLoanPricingKey = appLoanPricingCloned.getApploanpricingkey();
			}

			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
					"copyIncomeVerificationDataToChildApplication: appLoanPricingFeesList "
							+ parentAppLoanPricingFeesList);
			if (parentAppLoanPricingFeesList != null && parentApplication.getProdcdl2()!=10002l) {
				Long appLoanPricKey = appLoanPricingKey;
				parentAppLoanPricingFeesList.forEach(appLoanPricingFees -> {

					AppLoanPricingFees appLoanPricingFeesCloned = null;
					try {
						logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
								"Inside copyIncomeVerificationDataToChildApplication method - Cloning Existing record for AppLoanPricingFees");
						appLoanPricingFeesCloned = appLoanPricingFees.clone();
					} catch (CloneNotSupportedException exception) {
						logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
								"copyIncomeVerificationDataToChildApplication: Technical exception occurred while creating clone for AppLoanPricingFees for childApplication: "+childApplication.getApplicationkey() +" & parentApplication: "+parentApplication.getApplicationkey(),
								exception);
						throw new CreditApplicationServiceException(HttpStatus.CONFLICT, exception);
					}
					appLoanPricingFeesCloned.setApploanpricingfeeskey(null);
					appLoanPricingFeesCloned.setApploanpricingkey(appLoanPricKey);
					appLoanPricingFeesCloned.setLstupdateby(userKey);
					appLoanPricingFeesCloned.setLstupdatedt(applicationCreateDate);
					appLoanPricingFeesRepository.save(appLoanPricingFeesCloned);
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
							"copyIncomeVerificationDataToChildApplication: Successfully updated appLoanPricingFees for childApplication: "+childApplication.getApplicationkey() +" & parentApplication: "+parentApplication.getApplicationkey());
				});
			}

		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"copyIncomeVerificationDataToChildApplication: Technical exception occurred while cloning over for childApplication: "+childApplication.getApplicationkey() +" & parentApplication: "+parentApplication.getApplicationkey(),
					exception);

			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCA_100",
					"copyIncomeVerificationDataToChildApplication: Technical exception occurred while cloning over child application : "));

		} finally {
			if (null != redisLock) {
				String redisUnLock = redisUtility.getRedisUnLock(redisLock.getLock());
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"populateAndSaveAppProductListingDetails RedisUtility UnLock Response : " + redisUnLock);
			}
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Inside copyIncomeVerificationDataToChildApplication method - copy over for L3 Ended");

	}
	
	/**
	 * Copy average bank balance from source to destination
	 * @param sourceAttribute For copying data from source
	 * @param childAttribute  For moving data into destination
	 * @throws CloneNotSupportedException
	 */
	public void copyAverageBankBalance(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute) throws CloneNotSupportedException{
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying averageBankBalance from source to destination ...");
		AppSalariedDetail sourceOccupation = appSalariedDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		AppSalariedDetail destinationOccupation = appSalariedDetailRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);
		if(null!=destinationOccupation && null!=sourceOccupation && null!=sourceOccupation.getAvgbankbalance()) {
			destinationOccupation.setAvgbankbalance(sourceOccupation.getAvgbankbalance());
			appSalariedDetailRepository.save(destinationOccupation);
		}
		
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying averageBankBalance from source to destination finished");
	}
		
	public void copyApplicationData(Application sourceApplication, Application destinationApplication) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying application data in application from parent to child ...");
		if(null!=sourceApplication.getCitykey()) {
			destinationApplication.setCitykey(sourceApplication.getCitykey());
		}
		if(null!=sourceApplication.getBflbranchkey()) {
			destinationApplication.setBflbranchkey(sourceApplication.getBflbranchkey());
		}
		if(null!=sourceApplication.getPincodekey()) {
			destinationApplication.setPincodekey(sourceApplication.getPincodekey());
		}
		if (null != sourceApplication.getAppprocessidentifier()) {
			destinationApplication.setAppprocessidentifier(sourceApplication.getAppprocessidentifier());
		}
		if (null != sourceApplication.getRequestedcreditamount()) {
			destinationApplication.setRequestedcreditamount(sourceApplication.getRequestedcreditamount());
		}
		if(null != sourceApplication.getRequestedtenuremonths()) {
			destinationApplication.setRequestedtenuremonths(sourceApplication.getRequestedtenuremonths());
		}
		applicationRepository.save(destinationApplication);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Application application data copy from parent to child finished");
	}

	public void copyEmailsWithType(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute, Long typeKey) throws CloneNotSupportedException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside copyEmailsWithType, Copying emails from parent to child ...");
		List<Long> typeList = new ArrayList<Long>();
		typeList.add(typeKey);
		if(ApplicationConstants.EMAIL_TYPE_KEY.equals(typeKey)) {
			typeList.add(ApplicationConstants.OTHER_EMAIL_TYPE_KEY);
		}
		List<ApplicationEmail> sourceEmailList = applicationEmailRepository.findByAppattrbkeyAndIsactiveAndEmailtypekey(sourceAttribute.getAppattrbkey(), 1, typeList);
		List<ApplicationEmail> existingChildEmailList = applicationEmailRepository.findByAppattrbkeyAndIsactiveAndEmailtypekey(childAttribute.getAppattrbkey(), 1, typeList);
		emailCopyOver(sourceEmailList,existingChildEmailList,childAttribute);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside copyEmailsWithType, Email copy from parent to child finished");
	}

	private void emailCopyOver(List<ApplicationEmail> sourceEmailList, List<ApplicationEmail> existingChildEmailList, ApplicationAttribute childAttribute) throws CloneNotSupportedException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside emailCopyOver, Copying emails from parent to child ...");
		if(!CollectionUtils.isEmpty(existingChildEmailList)) {
			for(ApplicationEmail existingChildEmail : existingChildEmailList ) {
				existingChildEmail.setIsactive(0);
				existingChildEmail.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
				existingChildEmail.setLstupdateby(customDefaultHeaders.getUserKey());
				applicationEmailRepository.save(existingChildEmail);
			}
		}
		if (!CollectionUtils.isEmpty(sourceEmailList)) {
			List<ApplicationEmail> childEmailList = new ArrayList<>();
			for (ApplicationEmail sourceEmail : sourceEmailList) {
				ApplicationEmail clonedEmail = sourceEmail.clone();
				clonedEmail.setAppattrbkey(childAttribute.getAppattrbkey());
				childEmailList.add(clonedEmail);
			}
			if (!CollectionUtils.isEmpty(childEmailList)) {
				applicationEmailRepository.saveAll(childEmailList);
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside emailCopyOver, Email copy from parent to child finished");
	}	
	
	/**
	 * Copy profit after tax from source to destination (child to parent)
	 * @param sourceAttribute For moving data into destination
	 * @param childAttribute For copying data from source
	 * @throws CloneNotSupportedException
	 */
	public void copyProfitAfterTax(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute) throws CloneNotSupportedException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying profitAfterTax from source to destination ...");
		AppBusinessDetail sourceDetail = appBusinessDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		AppBusinessDetail destinationDetail = appBusinessDetailRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);
		if (null!=destinationDetail && null!=sourceDetail && null!=sourceDetail.getProfitaftertax()) {
			destinationDetail.setProfitaftertax(sourceDetail.getProfitaftertax());
			appBusinessDetailRepository.save(destinationDetail);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying profitAfterTax from source to destination finished");
	}

	public void copyAlternateMobileNo(ApplicationAttribute sourceAttribute, ApplicationAttribute destinationAttribute) throws CloneNotSupportedException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying alternate mobile number from parent to child or viseversa start");
	
		ApplicationPhoneNumber applicationPhoneNumberSource=applicationPhoneNumberRepository.findByAppattrbkeyAndIsactiveAndPhonetypekey(sourceAttribute.getAppattrbkey(), 1, 49L);
		ApplicationPhoneNumber applicationPhoneNumberDestination=applicationPhoneNumberRepository.findByAppattrbkeyAndIsactiveAndPhonetypekey(destinationAttribute.getAppattrbkey(), 1, 49L);
		if(applicationPhoneNumberDestination!=null) {
			applicationPhoneNumberDestination.setIsactive(0);
			applicationPhoneNumberDestination.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
			applicationPhoneNumberDestination.setLstupdateby(customDefaultHeaders.getUserKey());
			applicationPhoneNumberRepository.save(applicationPhoneNumberDestination);
		}
		if(null!=applicationPhoneNumberSource && null==applicationPhoneNumberDestination) {
			ApplicationPhoneNumber clonedAlternateMobNo = applicationPhoneNumberSource.clone();
			clonedAlternateMobNo.setAppattrbkey(destinationAttribute.getAppattrbkey());
			applicationPhoneNumberRepository.save(clonedAlternateMobNo);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "alternate mobile number copy from parent to child and viseversa finished");
	}
	
	public void copyExperience(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute){
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying Experience from source to destination ..."+sourceAttribute.getAppattrbkey());
		AppSalariedDetail sourceOccupation = appSalariedDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		AppSalariedDetail destinationOccupation = appSalariedDetailRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);
		if(null!=destinationOccupation && null!=sourceOccupation && null!=sourceOccupation.getDeclaredexperience()) {
			destinationOccupation.setDeclaredexperience(sourceOccupation.getDeclaredexperience());
			appSalariedDetailRepository.save(destinationOccupation);
		}
		
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying Experience from source to destination finished"+sourceAttribute.getAppattrbkey());
	}
	
	public void copyDesignation(ApplicationAttribute sourceAttribute, ApplicationAttribute childAttribute){
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying Designation from source to destination ..."+sourceAttribute.getAppattrbkey());
		AppSalariedDetail sourceOccupation = appSalariedDetailRepository
				.findByAppattrbkeyAndIsactive(sourceAttribute.getAppattrbkey(), 1);
		AppSalariedDetail destinationOccupation = appSalariedDetailRepository
				.findByAppattrbkeyAndIsactive(childAttribute.getAppattrbkey(), 1);
		if(null!=destinationOccupation && null!=sourceOccupation && null!=sourceOccupation.getDesignforoth()) {
			destinationOccupation.setDesignforoth(sourceOccupation.getDesignforoth());
			appSalariedDetailRepository.save(destinationOccupation);
		}
		
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Copying Designation from source to destination finished"+sourceAttribute.getAppattrbkey());
	}
}
