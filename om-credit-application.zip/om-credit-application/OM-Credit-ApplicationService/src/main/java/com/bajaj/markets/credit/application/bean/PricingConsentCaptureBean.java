package com.bajaj.markets.credit.application.bean;

public class PricingConsentCaptureBean {

	private String consentToken;
	private String employeeUserKey;
	
	public String getConsentToken() {
		return consentToken;
	}
	public void setConsentToken(String consentToken) {
		this.consentToken = consentToken;
	}
	public String getEmployeeUserKey() {
		return employeeUserKey;
	}
	public void setEmployeeUserKey(String employeeUserKey) {
		this.employeeUserKey = employeeUserKey;
	}
	@Override
	public String toString() {
		return "PricingConsentCaptureBean [consentToken=" + consentToken + ", employeeUserKey=" + employeeUserKey + "]";
	}
}