package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.ApplicationStatus;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationStatusService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationStatusController {

	@Autowired
	private BFLLoggerUtilExt logger;
	@Autowired
	private ApplicationStatusService applicationStatusService;
	private static final String CLASSNAME = ApplicationStatusController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL,Role.INTERNAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update status of application and child application.", notes = "Update status of application and child application.", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Status Update Successfull."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found.", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Unprocessable Entity.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.application.credit.status.PUT.uri}")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> statusUpdate(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@Valid @RequestBody ApplicationStatus applicationStatus, BindingResult bindingResult,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside statusUpdate method for applicationId: " + applicationId);
		applicationStatusService.updateStatus(applicationId, applicationStatus);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside statusUpdate method End for applicationId : " + applicationId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.VENDORPARTNER, Role.B2BPARTNER, Role.PRINCIPAL,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get status of application and child application.", notes = "Get status of application and child application.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get application status success", response = ApplicationStatus.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.application.credit.status.GET.uri}")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> getStatus(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getStatus method for applicationId :" + applicationId);
		ApplicationStatus applicationStatus = applicationStatusService.getAppStatus(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getStatusmethod End for applicationId: " + applicationId);
		return new ResponseEntity<>(applicationStatus, HttpStatus.OK);
	}
}
