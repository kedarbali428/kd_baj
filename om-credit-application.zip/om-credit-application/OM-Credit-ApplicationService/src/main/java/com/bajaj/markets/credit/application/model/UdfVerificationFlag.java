package com.bajaj.markets.credit.application.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema="dmcredit", name="UDF_VERIFICATION_FLAGS")
public class UdfVerificationFlag {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long udfFlgKey; 
	
	private String flagCode; 
	
	private String description; 
	
	private Integer isactive; 
	
	private Integer lstUpdateBy; 
	
	private Timestamp lstUpdatedt; 
	
	private  BigDecimal flagCategory;

	public Long getUdfFlgKey() {
		return udfFlgKey;
	}

	public void setUdfFlgKey(Long udfFlgKey) {
		this.udfFlgKey = udfFlgKey;
	}

	public String getFlagCode() {
		return flagCode;
	}

	public void setFlagCode(String flagCode) {
		this.flagCode = flagCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Integer getLstUpdateBy() {
		return lstUpdateBy;
	}

	public void setLstUpdateBy(Integer lstUpdateBy) {
		this.lstUpdateBy = lstUpdateBy;
	}

	public Timestamp getLstUpdatedt() {
		return lstUpdatedt;
	}

	public void setLstUpdatedt(Timestamp lstUpdatedt) {
		this.lstUpdatedt = lstUpdatedt;
	}

	public BigDecimal getFlagCategory() {
		return flagCategory;
	}

	public void setFlagCategory(BigDecimal flagCategory) {
		this.flagCategory = flagCategory;
	}
	
}
