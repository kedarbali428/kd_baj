package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class AppUdfVerificationRequest {

	private long udfflagkey;
	private long userrolekey;
	private BigDecimal flagstatus;
	
	
	public long getUdfflagkey() {
		return udfflagkey;
	}
	public void setUdfflagkey(long udfflagkey) {
		this.udfflagkey = udfflagkey;
	}
	public long getUserrolekey() {
		return userrolekey;
	}
	public void setUserrolekey(long userrolekey) {
		this.userrolekey = userrolekey;
	}
	public BigDecimal getFlagstatus() {
		return flagstatus;
	}
	public void setFlagstatus(BigDecimal flagstatus) {
		this.flagstatus = flagstatus;
	}
}
