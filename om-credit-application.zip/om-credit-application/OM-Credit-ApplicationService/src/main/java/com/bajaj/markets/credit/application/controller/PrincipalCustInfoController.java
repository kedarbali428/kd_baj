/**
 * 
 */
package com.bajaj.markets.credit.application.controller;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.PrincipalCustomer;
import com.bajaj.markets.credit.application.bean.PrincipalCustomerMongoBean;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.PrincipalCustInfoService;
import com.bajaj.markets.credit.offer.bfl.bean.BMR2Response;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller for persisting customer info based on application & principal
 */
@RestController
@Validated
public class PrincipalCustInfoController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private PrincipalCustInfoService custInfoService;
	
	private static final String CLASSNAME = PrincipalCustInfoController.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.PRINCIPAL, Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update user customer information", notes = "Update customer information for user", httpMethod = "PUT")
	@ApiResponses(value = {
			 	@ApiResponse(code = 200, message = "Cust info updated successfully.", response = PrincipalCustomer.class),
			 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			 	@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PutMapping(value = "${api.omcreditapplicationservice.principalcustinfo.offers.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> updateCustomerInfo(@PathVariable("applicationid")@NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@PathVariable("principalkey")@NotBlank(message = "principalkey can not be null or empty") String principalKey ,@Valid @RequestBody PrincipalCustomer customer,
			 BindingResult result, 
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateCustInfo method controller for applicationId: "+applicationId);
		return new ResponseEntity<>(custInfoService.updateCustomerInfo(applicationId, principalKey, customer),
				HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get Bmr status", notes = "Get Bmr status", httpMethod = "GET")
	@ApiResponses(value = {
			 	@ApiResponse(code = 200, message = "Fetched Bmr status successfully.", response = PrincipalCustomer.class),
			 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			 	@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "${api.omcreditapplicationservice.bestmatch.status.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> getBmrStatus(@PathVariable("applicationid")@NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getBmrStatus method controller for applicationId: " +applicationId);
		return new ResponseEntity<>(custInfoService.getBmrStatus(applicationId),
				HttpStatus.OK);
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get BMR Details from MongoDB", notes = "Get BMR Details from MongoDB on the basis applicationId", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "BMR details fetched successfully from mongodb", response = PrincipalCustomerMongoBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "BMR details not found in mongodb", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.bmrdetails.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> getBMRFromMongoDB(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getBMRFromMongoDB method for applicationId: "+applicationId);
		PrincipalCustomerMongoBean principalCustomerMongoBean = custInfoService.getBMRFromMongoDB(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getBMRFromMongoDB method completed successfully, applicationId: " +applicationId);
		return new ResponseEntity<>(principalCustomerMongoBean, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.PRINCIPAL, Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get principle customer information", notes = "Get principle customer information", httpMethod = "GET")
	@ApiResponses(value = {
			 	@ApiResponse(code = 200, message = "Success.", response = PrincipalCustomer.class),
			 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			 	@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "${api.omcreditapplicationservice.principalcustinfo.offers.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<PrincipalCustomer> getPrincipleCustomerInfo(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@PathVariable("principalkey") @NotBlank(message = "principalkey can not be null or empty") String principalKey ,
			@RequestHeader HttpHeaders headers) {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, 
					"Inside getPrincipleCustomerInfo method for applicationId: " + applicationId + ", Principle key: " + principalKey);
			PrincipalCustomer response = custInfoService.getPrincipleCustomerInfo(applicationId, principalKey);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, 
					"Inside getPrincipleCustomerInfo method completed successfully, applicationId: "+applicationId);
			return ResponseEntity.ok(response);
	}
	

	@ApiImplicitParams({
		@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch bmr2 response From Mongodb", notes = "Fetch bmr2 response From Mongodb", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched bmr2 response from mongodb", response = BMR2Response.class, responseContainer = "List"),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@CrossOrigin
	@GetMapping(value = "${api.omcreditapplicationservice.bmr2response.mongodetail.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getBMRResponseMongoDetails(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 16,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers) {	
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getBMRResponseMongoDetails method for applicationId: " + applicationId);
		BMR2Response bmrResponse = custInfoService.fetchBMR2ResponsefromMongo(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getBMRResponseMongoDetails method completed sucessfully, applicationId: " + applicationId );
		return new ResponseEntity<>(bmrResponse, HttpStatus.OK);
	}
}
