package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_document_tracking", schema = "dmcredit")
public class AppDocumentTracking {

	
	@Id
	@SequenceGenerator(name = "app_document_tracking_key_generator", sequenceName = "dmcredit.seq_pk_app_document_tracking", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_document_tracking_key_generator")
	private Long appdocumenttrackingkey;

	private Integer creditdoctype;

	private Timestamp docsentdate;

	private Long docsentby;

	private String docsentstatus;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String docerrorcode;

	private String docerrordesc;

	private Timestamp docerrordt;

	private String partnerrefid;

	private String docsource;

	private Long applicationkey;

	public Long getAppdocumenttrackingkey() {
		return appdocumenttrackingkey;
	}

	public void setAppdocumenttrackingkey(Long appdocumenttrackingkey) {
		this.appdocumenttrackingkey = appdocumenttrackingkey;
	}

	public Integer getCreditdoctype() {
		return creditdoctype;
	}

	public void setCreditdoctype(Integer creditdoctype) {
		this.creditdoctype = creditdoctype;
	}

	public Timestamp getDocsentdate() {
		return docsentdate;
	}

	public void setDocsentdate(Timestamp docsentdate) {
		this.docsentdate = docsentdate;
	}

	public Long getDocsentby() {
		return docsentby;
	}

	public void setDocsentby(Long docsentby) {
		this.docsentby = docsentby;
	}

	public String getDocsentstatus() {
		return docsentstatus;
	}

	public void setDocsentstatus(String docsentstatus) {
		this.docsentstatus = docsentstatus;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getDocerrorcode() {
		return docerrorcode;
	}

	public void setDocerrorcode(String docerrorcode) {
		this.docerrorcode = docerrorcode;
	}

	public String getDocerrordesc() {
		return docerrordesc;
	}

	public void setDocerrordesc(String docerrordesc) {
		this.docerrordesc = docerrordesc;
	}

	public Timestamp getDocerrordt() {
		return docerrordt;
	}

	public void setDocerrordt(Timestamp docerrordt) {
		this.docerrordt = docerrordt;
	}

	public String getPartnerrefid() {
		return partnerrefid;
	}

	public void setPartnerrefid(String partnerrefid) {
		this.partnerrefid = partnerrefid;
	}

	public String getDocsource() {
		return docsource;
	}

	public void setDocsource(String docsource) {
		this.docsource = docsource;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	@Override
	public String toString() {
		return "AppDocumentTracking [appdocumenttrackingkey=" + appdocumenttrackingkey + ", creditdoctype="
				+ creditdoctype + ", docsentdate=" + docsentdate + ", docsentby=" + docsentby + ", docsentstatus="
				+ docsentstatus + ", isactive=" + isactive + ", lstupdateby=" + lstupdateby + ", lstupdatedt="
				+ lstupdatedt + ", docerrorcode=" + docerrorcode + ", docerrordesc=" + docerrordesc + ", docerrordt="
				+ docerrordt + ", partnerrefid=" + partnerrefid + ", docsource=" + docsource + ", applicationkey="
				+ applicationkey + "]";
	}

}
