package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Digits;

public class ProcessCardRequest {
	@Digits(fraction = 0, integer = 6, message = "OTP should be digit only.")
	private String otp;

	private Integer cibilScore;

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Integer getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(Integer cibilScore) {
		this.cibilScore = cibilScore;
	}

	@Override
	public String toString() {
		return "ProcessCardRequest [otp=" + otp + ", cibilScore=" + cibilScore + "]";
	}

}
