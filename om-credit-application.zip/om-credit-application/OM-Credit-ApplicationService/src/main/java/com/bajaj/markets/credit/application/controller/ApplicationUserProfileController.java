package com.bajaj.markets.credit.application.controller;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.Name;
import com.bajaj.markets.credit.application.bean.UserProfile;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.CreateUserProfileAttribute;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.UserProfileAttribute;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationUserProfileService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationUserProfileController {
	
	@Autowired
	private Validator validator;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private ApplicationUserProfileService applicationUserProfileService;
	
	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;
	
	private static final String CLASSNAME = ApplicationUserProfileController.class.getName();
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "add/update user Profile for an application", notes = "Add user profile name, marital status, gender & residence type ", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "User profile added Successfully.", response = UserProfile.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application attribute not found",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> addUserProfile(
			@PathVariable("applicationid") @NotBlank(message = "Applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable("userattributekey") @NotBlank(message = "Userattributekey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Userattributekey should be numeric & should not exceeds size") String userattributeKey,
			@Valid @RequestBody UserProfile userProfile, BindingResult bindingResult, 
			@RequestHeader HttpHeaders headers) {
		
		userProfile.setApplicationKey(applicationId);
		userProfile.setApplicationUserAttributeKey(userattributeKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, 
				"Inside addUserProfile method controller ,applicationId: "+applicationId);
		creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userattributeKey);
		return new ResponseEntity<>(applicationUserProfileService.addUserProfile(userProfile), HttpStatus.OK);
		
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL,Role.SYSTEM,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch user profiles", notes = "Fetch user profiles on the basis of application id", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "User profile found for the application.", response = UserProfile.class, responseContainer = "List"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserProfiles(
			@PathVariable("applicationid") @NotBlank(message = "Applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestParam(value = "allApplicantRquired", defaultValue = "false") Boolean allApplicantRquired,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getUserProfiles method controller , applicationId: " +applicationId);
		return new ResponseEntity<>(applicationUserProfileService.getUserProfiles(applicationId, allApplicantRquired), HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch user profile Detail", notes = "Fetch user profile details on the basis of user attribute id", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "User profile Detail found for the user attribute id", response = UserProfile.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "User profile Detail not found for the user attribute id",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> getUserProfile(
			@PathVariable("applicationid") @NotBlank(message = "Applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable("userattributekey") @NotBlank(message = "Userattributekey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Userattributekey should be numeric & should not exceeds size") String userattributeKey, 
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getUserProfile method controller - applicationId: "+ applicationId + "with userattributeKey: " + userattributeKey);
		creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userattributeKey);
		return new ResponseEntity<>(applicationUserProfileService.getUserProfileDetail(userattributeKey),HttpStatus.OK);
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.SYSTEM})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch customer name", notes = "Fetch customer name on the basis of application id and userattributetype", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Customer Name found for the application", response = Name.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "${api.omcreditapplicationservice.application.userprofiles.customername.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getCustomerName(
			@PathVariable("applicationid") @NotBlank(message = "Applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationid should be numeric & should not exceeds size") String applicationId, 
			@PathVariable("userattributetype") @NotBlank(message = "userattributetype can not be null or empty") @Digits(fraction = 0, integer = 2, message = "userattributetype should be numeric & should not exceeds size") String userAttributeType, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getCustomerName method controller - applicationId : " +applicationId);
		Object response=applicationUserProfileService.getCustomerName(applicationId,userAttributeType);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "GetCustomerName method completed successfully, applicationId: " +applicationId);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "create user Profile for an application", notes = "create user profile detail", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "User profile added Successfully.", response = UserProfile.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class)})
	@PostMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> createUserProfile(
			@PathVariable("applicationid") @NotBlank(message = "Applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestBody UserProfile userProfile, BindingResult bindingResult, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside createUserProfile method controller, applicationId: "+applicationId);
		userProfile.setApplicationKey(applicationId);
		Set<ConstraintViolation<UserProfile>> validationErrors = validator.validate(userProfile, getValidationClass(userProfile));
		if (!CollectionUtils.isEmpty(validationErrors)) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Inside createUserProfile method controller - resource validation failed for application: "+applicationId);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_005", validationErrors.stream().findFirst().get().getMessage()));
		}
		creditApplicationServiceUtility.validateApplication(applicationId,userProfile.getApplicationUserAttributeType());
		return new ResponseEntity<>(applicationUserProfileService.createUserProfile(userProfile), HttpStatus.OK);
	}

	private Class getValidationClass(UserProfile userProfile) {
		if (null != userProfile.getApplicationUserAttributeType()
				&& ApplicationConstants.APPLICANT_TYPE.equals(userProfile.getApplicationUserAttributeType())) {
			return UserProfileAttribute.class;
		} else {
			return CreateUserProfileAttribute.class;
		}
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "deactivate user Profile for an application", notes = "deactivate user profile detail", httpMethod = "DELETE")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "User profile deactivated Successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class)})
	@DeleteMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@EnableFineGrainCheck
	@CrossOrigin
	public ResponseEntity<?> deactivateUserProfile(
			@PathVariable("applicationid") @NotBlank(message = "Applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable("userattributekey") @NotBlank(message = "Userattributekey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Userattributekey should be numeric & should not exceeds size") String userattributeKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside deActiveUserProfile method controller for applicationId: "+ applicationId
						+ " and userAttributeKey: "+ userattributeKey);
		applicationUserProfileService.deactivateUserProfile(applicationId, userattributeKey);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
