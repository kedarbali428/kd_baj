package com.bajaj.markets.credit.application.bean;

import java.util.Map;

import javax.validation.constraints.NotNull;

public class UpdateApplication {
	// If in future anyone add some more parameter here then remove the validation
	// or change the message for validation.
	@NotNull(message = "Provide atleast one parameter to update.")
	private Map<String, String> applicationParameters;

	public Map<String, String> getApplicationParameters() {
		return applicationParameters;
	}

	public void setApplicationParameters(Map<String, String> applicationParameters) {
		this.applicationParameters = applicationParameters;
	}

	@Override
	public String toString() {
		return "UpdateApplication [applicationParameters=" + applicationParameters + "]";
	}


}
