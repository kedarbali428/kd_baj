package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_loan_pricing", schema = "dmcredit")
public class AppLoanPricing implements Serializable,Cloneable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="app_loan_pricing_generator", sequenceName="dmcredit.seq_pk_app_loan_pricing",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_loan_pricing_generator")
	private Long apploanpricingkey;
	
    private Long applicationkey;
    
    private Long appprodlistkey;
    
    private Integer istenure;
    
    private Integer droplinetenure;
    
    private BigDecimal emiamount;
    
    private String baseratecode;
    
    private BigDecimal baseratevalue;
    
    private Date firstduedate;   
    
    private BigDecimal graceterm;
    
    private Date nextduedate;
    
    private BigDecimal roi;
    
    private Integer isactive;
    
    private Long lstupdateby;
    
    private Timestamp lstupdatedt;
    
    private Integer dueday;  
    
    private BigDecimal loanamt;
    
    private BigDecimal roiwithbundle;
    
    private BigDecimal finalroi;
    
    private BigDecimal loanamountwithbundle;
    
    private BigDecimal finalloanamount;
    
    private String source;
    
    private String status;
    
    private BigDecimal raisedby;
    
    private BigDecimal approvedby;
     
    private String isemi;
    
    private BigDecimal droplineemi;
    
    private String pennantloantype;
    
    private BigDecimal netdisbursementamt;
   
    private Timestamp raiseddt;
   
    private Timestamp approveddt;
     
    private Integer pricingflag;
    
    private BigDecimal testpricingroi;
    
	public BigDecimal getTestpricingroi() {
		return testpricingroi;
	}

	public void setTestpricingroi(BigDecimal testpricingroi) {
		this.testpricingroi = testpricingroi;
	}

	public Timestamp getRaiseddt() {
		return raiseddt;
	}

	public void setRaiseddt(Timestamp raiseddt) {
		this.raiseddt = raiseddt;
	}

	public Timestamp getApproveddt() {
		return approveddt;
	}

	public void setApproveddt(Timestamp approveddt) {
		this.approveddt = approveddt;
	}

	public BigDecimal getLoanamt() {
		return loanamt;
	}

	public void setLoanamt(BigDecimal loanamt) {
		this.loanamt = loanamt;
	}

	public Integer getDueday() {
		return dueday;
	}

	public void setDueday(Integer dueday) {
		this.dueday = dueday;
	}

	public Long getAppprodlistkey() {
		return appprodlistkey;
	}

	public void setAppprodlistkey(Long appprodlistkey) {
		this.appprodlistkey = appprodlistkey;
	}

	public Long getApploanpricingkey() {
		return apploanpricingkey;
	}

	public void setApploanpricingkey(Long apploanpricingkey) {
		this.apploanpricingkey = apploanpricingkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getIstenure() {
		return istenure;
	}

	public void setIstenure(Integer istenure) {
		this.istenure = istenure;
	}

	public Integer getDroplinetenure() {
		return droplinetenure;
	}

	public void setDroplinetenure(Integer droplinetenure) {
		this.droplinetenure = droplinetenure;
	}

	public BigDecimal getEmiamount() {
		return emiamount;
	}

	public void setEmiamount(BigDecimal emiamount) {
		this.emiamount = emiamount;
	}

	public String getBaseratecode() {
		return baseratecode;
	}

	public void setBaseratecode(String baseratecode) {
		this.baseratecode = baseratecode;
	}

	public BigDecimal getBaseratevalue() {
		return baseratevalue;
	}

	public void setBaseratevalue(BigDecimal baseratevalue) {
		this.baseratevalue = baseratevalue;
	}

	public Date getFirstduedate() {
		return firstduedate;
	}

	public void setFirstduedate(Date firstduedate) {
		this.firstduedate = firstduedate;
	}

	public BigDecimal getGraceterm() {
		return graceterm;
	}

	public void setGraceterm(BigDecimal graceterm) {
		this.graceterm = graceterm;
	}

	public Date getNextduedate() {
		return nextduedate;
	}

	public void setNextduedate(Date nextduedate) {
		this.nextduedate = nextduedate;
	}

	public BigDecimal getRoi() {
		return roi;
	}

	public void setRoi(BigDecimal roi) {
		this.roi = roi;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
	public AppLoanPricing clone()throws CloneNotSupportedException{  
		AppLoanPricing appLoanPricing = new AppLoanPricing();
		//appLoanPricing =(AppLoanPricing) super.clone();
		appLoanPricing.setApploanpricingkey(this.apploanpricingkey);
		appLoanPricing.setApplicationkey(this.applicationkey);
		appLoanPricing.setAppprodlistkey(this.appprodlistkey);
		appLoanPricing.setBaseratecode(this.baseratecode);
		appLoanPricing.setBaseratevalue(this.baseratevalue);
		appLoanPricing.setDroplinetenure(this.droplinetenure);
		appLoanPricing.setDueday(this.dueday);
		appLoanPricing.setEmiamount(this.emiamount);
		appLoanPricing.setFirstduedate(this.firstduedate);
		appLoanPricing.setGraceterm(this.graceterm);
		appLoanPricing.setIsactive(this.isactive);
		appLoanPricing.setIstenure(this.istenure);
		appLoanPricing.setLoanamt(this.loanamt);
		appLoanPricing.setLstupdateby(this.lstupdateby);
		appLoanPricing.setLstupdatedt(this.lstupdatedt);
		appLoanPricing.setNextduedate(this.nextduedate);
		appLoanPricing.setPennantloantype(this.pennantloantype);
		appLoanPricing.setRoi(this.roi);
		appLoanPricing.setSource(this.source);
		appLoanPricing.setStatus(this.status);
		appLoanPricing.setFinalroi(this.finalroi);
		appLoanPricing.setFinalloanamount(this.finalloanamount);
		appLoanPricing.setPricingflag(this.pricingflag);
		appLoanPricing.setNetdisbursementamt(netdisbursementamt);
		
		return appLoanPricing;  
	}

	public String getIsemi() {
		return isemi;
	}

	public void setIsemi(String isemi) {
		this.isemi = isemi;
	}

	public BigDecimal getDroplineemi() {
		return droplineemi;
	}

	public void setDroplineemi(BigDecimal droplineemi) {
		this.droplineemi = droplineemi;
	}

	public String getPennantloantype() {
		return pennantloantype;
	}

	public void setPennantloantype(String pennantloantype) {
		this.pennantloantype = pennantloantype;
	}

	public BigDecimal getNetdisbursementamt() {
		return netdisbursementamt;
	}

	public void setNetdisbursementamt(BigDecimal netdisbursementamt) {
		this.netdisbursementamt = netdisbursementamt;
	}

	public BigDecimal getRoiwithbundle() {
		return roiwithbundle;
	}

	public void setRoiwithbundle(BigDecimal roiwithbundle) {
		this.roiwithbundle = roiwithbundle;
	}

	public BigDecimal getFinalroi() {
		return finalroi;
	}

	public void setFinalroi(BigDecimal finalroi) {
		this.finalroi = finalroi;
	}

	public BigDecimal getLoanamountwithbundle() {
		return loanamountwithbundle;
	}

	public void setLoanamountwithbundle(BigDecimal loanamountwithbundle) {
		this.loanamountwithbundle = loanamountwithbundle;
	}

	public BigDecimal getFinalloanamount() {
		return finalloanamount;
	}

	public void setFinalloanamount(BigDecimal finalloanamount) {
		this.finalloanamount = finalloanamount;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public BigDecimal getRaisedby() {
		return raisedby;
	}

	public void setRaisedby(BigDecimal raisedby) {
		this.raisedby = raisedby;
	}

	public BigDecimal getApprovedby() {
		return approvedby;
	}

	public void setApprovedby(BigDecimal approvedby) {
		this.approvedby = approvedby;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getPricingflag() {
		return pricingflag;
	}

	public void setPricingflag(Integer pricingflag) {
		this.pricingflag = pricingflag;
	} 
	
}
