package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class PrincipalCustomer {

	private Long principleCustKey;
	
	private Long applicationKey;
	
	private Long principalKey;
	
	private String principleCustRefId;
	
	private String principleCustRefSrc;
	
	private Boolean isEtb;
	
	private BigDecimal livepos;
	
	private String principleCustSegment;
	
	private String principleCustType;
	
	private Object additionalDetails;
	
	private String btsSegment;
	
	private Long appattrbkey;
	
	private String etbSrc;

	private Integer wipFlag;

	private Integer approvedFlag;

	private Integer fraudFlag;

	private Integer rejectFlag;
	
	private Integer bmrOneApprovedFlag;
	
	private Integer bmrTwoApprovedFlag;
	
	private Integer bmrTwoBadFlag;
	
	private Integer bmrTwoDisbursedFlag;
	
	private Integer bmrTwoRejectFlag;
	
	private String edwStatus;
	
	private Long finnoneId;

	public Long getPrincipleCustKey() {
		return principleCustKey;
	}

	public void setPrincipleCustKey(Long principleCustKey) {
		this.principleCustKey = principleCustKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public String getPrincipleCustRefId() {
		return principleCustRefId;
	}

	public void setPrincipleCustRefId(String principleCustRefId) {
		this.principleCustRefId = principleCustRefId;
	}

	public String getPrincipleCustRefSrc() {
		return principleCustRefSrc;
	}

	public void setPrincipleCustRefSrc(String principleCustRefSrc) {
		this.principleCustRefSrc = principleCustRefSrc;
	}

	public Boolean getIsEtb() {
		return isEtb;
	}

	public void setIsEtb(Boolean isEtb) {
		this.isEtb = isEtb;
	}
	
	public BigDecimal getLivepos() {
		return livepos;
	}

	public void setLivepos(BigDecimal livepos) {
		this.livepos = livepos;
	}

	public String getPrincipleCustSegment() {
		return principleCustSegment;
	}

	public void setPrincipleCustSegment(String principleCustSegment) {
		this.principleCustSegment = principleCustSegment;
	}

	public String getPrincipleCustType() {
		return principleCustType;
	}

	public void setPrincipleCustType(String principleCustType) {
		this.principleCustType = principleCustType;
	}

	public Object getAdditionalDetails() {
		return additionalDetails;
	}

	public void setAdditionalDetails(Object additionalDetails) {
		this.additionalDetails = additionalDetails;
	}

	public String getBtsSegment() {
		return btsSegment;
	}

	public void setBtsSegment(String btsSegment) {
		this.btsSegment = btsSegment;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public String getEtbSrc() {
		return etbSrc;
	}

	public void setEtbSrc(String etbSrc) {
		this.etbSrc = etbSrc;
	}

	public Integer getWipFlag() {
		return wipFlag;
	}

	public void setWipFlag(Integer wipFlag) {
		this.wipFlag = wipFlag;
	}

	public Integer getApprovedFlag() {
		return approvedFlag;
	}

	public void setApprovedFlag(Integer approvedFlag) {
		this.approvedFlag = approvedFlag;
	}

	public Integer getFraudFlag() {
		return fraudFlag;
	}

	public void setFraudFlag(Integer fraudFlag) {
		this.fraudFlag = fraudFlag;
	}

	public Integer getRejectFlag() {
		return rejectFlag;
	}

	public void setRejectFlag(Integer rejectFlag) {
		this.rejectFlag = rejectFlag;
	}

	public Integer getBmrOneApprovedFlag() {
		return bmrOneApprovedFlag;
	}

	public void setBmrOneApprovedFlag(Integer bmrOneApprovedFlag) {
		this.bmrOneApprovedFlag = bmrOneApprovedFlag;
	}

	public Integer getBmrTwoApprovedFlag() {
		return bmrTwoApprovedFlag;
	}

	public void setBmrTwoApprovedFlag(Integer bmrTwoApprovedFlag) {
		this.bmrTwoApprovedFlag = bmrTwoApprovedFlag;
	}

	public Integer getBmrTwoBadFlag() {
		return bmrTwoBadFlag;
	}

	public void setBmrTwoBadFlag(Integer bmrTwoBadFlag) {
		this.bmrTwoBadFlag = bmrTwoBadFlag;
	}

	public Integer getBmrTwoDisbursedFlag() {
		return bmrTwoDisbursedFlag;
	}

	public void setBmrTwoDisbursedFlag(Integer bmrTwoDisbursedFlag) {
		this.bmrTwoDisbursedFlag = bmrTwoDisbursedFlag;
	}

	public Integer getBmrTwoRejectFlag() {
		return bmrTwoRejectFlag;
	}

	public void setBmrTwoRejectFlag(Integer bmrTwoRejectFlag) {
		this.bmrTwoRejectFlag = bmrTwoRejectFlag;
	}

	public String getEdwStatus() {
		return edwStatus;
	}

	public void setEdwStatus(String edwStatus) {
		this.edwStatus = edwStatus;
	}

	public Long getFinnoneId() {
		return finnoneId;
	}

	public void setFinnoneId(Long finnoneId) {
		this.finnoneId = finnoneId;
	}

	@Override
	public String toString() {
		return "PrincipalCustomer [principleCustKey=" + principleCustKey + ", applicationKey=" + applicationKey
				+ ", principalKey=" + principalKey + ", principleCustRefId=" + principleCustRefId
				+ ", principleCustRefSrc=" + principleCustRefSrc + ", isEtb=" + isEtb + ", livepos=" + livepos
				+ ", principleCustSegment=" + principleCustSegment + ", principleCustType=" + principleCustType
				+ ", additionalDetails=" + additionalDetails + ", btsSegment=" + btsSegment + ", appattrbkey="
				+ appattrbkey + ", etbSrc=" + etbSrc + ", wipFlag=" + wipFlag + ", approvedFlag=" + approvedFlag
				+ ", fraudFlag=" + fraudFlag + ", rejectFlag=" + rejectFlag + ", bmrOneApprovedFlag="
				+ bmrOneApprovedFlag + ", bmrTwoApprovedFlag=" + bmrTwoApprovedFlag + ", bmrTwoBadFlag=" + bmrTwoBadFlag
				+ ", bmrTwoDisbursedFlag=" + bmrTwoDisbursedFlag + ", bmrTwoRejectFlag=" + bmrTwoRejectFlag
				+ ", edwStatus=" + edwStatus + ", finnoneId=" + finnoneId + "]";
	}


}
