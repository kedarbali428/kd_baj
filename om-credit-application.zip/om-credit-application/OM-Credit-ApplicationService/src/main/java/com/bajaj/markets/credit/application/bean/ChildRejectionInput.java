package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class ChildRejectionInput {

	private String applicationId;
	private String product;
	private Float subStagePercentage;
	private String occupationType;
	private String rejectionType;
	private List<PrincipalProductRejectionInput> principleProductDetails;
	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public Float getSubStagePercentage() {
		return subStagePercentage;
	}
	public void setSubStagePercentage(Float subStagePercentage) {
		this.subStagePercentage = subStagePercentage;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public String getRejectionType() {
		return rejectionType;
	}
	public void setRejectionType(String rejectionType) {
		this.rejectionType = rejectionType;
	}
	public List<PrincipalProductRejectionInput> getPrincipleProductDetails() {
		return principleProductDetails;
	}
	public void setPrincipleProductDetails(List<PrincipalProductRejectionInput> principleProductDetails) {
		this.principleProductDetails = principleProductDetails;
	}
	@Override
	public String toString() {
		return "ChildRejectionInput [applicationId=" + applicationId + ", product=" + product + ", subStagePercentage="
				+ subStagePercentage + ", occupationType=" + occupationType + ", rejectionType=" + rejectionType
				+ ", principleProductDetails=" + principleProductDetails + "]";
	}
}
