package com.bajaj.markets.credit.application.bean;

public class PricingConsentResponse {

	private String consentRef;
	private Long pricingKey;
	private String consentMechanism;
	private Integer consentCaptured;
	private Integer consentSent;
	private String personalEmail;
	private String consentPassCode;
	private String consentStatus;
	private Integer employeeCature;
	private String consentSource;
	private Long employeeUserKey;
	
	public String getConsentRef() {
		return consentRef;
	}

	public void setConsentRef(String consentRef) {
		this.consentRef = consentRef;
	}

	public Long getPricingKey() {
		return pricingKey;
	}

	public void setPricingKey(Long pricingKey) {
		this.pricingKey = pricingKey;
	}

	public String getConsentMechanism() {
		return consentMechanism;
	}

	public void setConsentMechanism(String consentMechanism) {
		this.consentMechanism = consentMechanism;
	}

	public Integer getConsentCaptured() {
		return consentCaptured;
	}

	public void setConsentCaptured(Integer consentCaptured) {
		this.consentCaptured = consentCaptured;
	}

	public Integer getConsentSent() {
		return consentSent;
	}

	public void setConsentSent(Integer consentSent) {
		this.consentSent = consentSent;
	}

	public String getPersonalEmail() {
		return personalEmail;
	}

	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}

	public String getConsentPassCode() {
		return consentPassCode;
	}

	public void setConsentPassCode(String consentPassCode) {
		this.consentPassCode = consentPassCode;
	}

	public String getConsentStatus() {
		return consentStatus;
	}

	public void setConsentStatus(String consentStatus) {
		this.consentStatus = consentStatus;
	}

	public Integer getEmployeeCature() {
		return employeeCature;
	}

	public void setEmployeeCature(Integer employeeCature) {
		this.employeeCature = employeeCature;
	}

	public String getConsentSource() {
		return consentSource;
	}

	public void setConsentSource(String consentSource) {
		this.consentSource = consentSource;
	}

	public Long getEmployeeUserKey() {
		return employeeUserKey;
	}

	public void setEmployeeUserKey(Long employeeUserKey) {
		this.employeeUserKey = employeeUserKey;
	}

	@Override
	public String toString() {
		return "PricingConsentResponse [consentRef=" + consentRef + ", pricingKey=" + pricingKey + ", consentMechanism="
				+ consentMechanism + ", consentCaptured=" + consentCaptured + ", consentSent=" + consentSent
				+ ", personalEmail=" + personalEmail + ", consentPassCode=" + consentPassCode + ", consentStatus="
				+ consentStatus + ", employeeCature=" + employeeCature + ", consentSource=" + consentSource
				+ ", employeeUserKey=" + employeeUserKey + "]";
	}

}
