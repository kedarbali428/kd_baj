package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class ApplicationLoanDetails {
	private BigDecimal maxeligibility;

	public BigDecimal getMaxeligibility() {
		return maxeligibility;
	}

	public void setMaxeligibility(BigDecimal maxeligibility) {
		this.maxeligibility = maxeligibility;
	}

}
