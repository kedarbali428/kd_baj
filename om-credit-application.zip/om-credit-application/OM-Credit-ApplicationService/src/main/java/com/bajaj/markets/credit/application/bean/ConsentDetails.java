package com.bajaj.markets.credit.application.bean;

public class ConsentDetails {
	private String consentChannelTypeDesc;
	private String consentChannel;
	private String consentToken;
	private String consentUrl;
	
	public String getConsentChannelTypeDesc() {
		return consentChannelTypeDesc;
	}
	public void setConsentChannelTypeDesc(String consentChannelTypeDesc) {
		this.consentChannelTypeDesc = consentChannelTypeDesc;
	}
	public String getConsentChannel() {
		return consentChannel;
	}
	public void setConsentChannel(String consentChannel) {
		this.consentChannel = consentChannel;
	}
	public String getConsentToken() {
		return consentToken;
	}
	public void setConsentToken(String consentToken) {
		this.consentToken = consentToken;
	}
	public String getConsentUrl() {
		return consentUrl;
	}
	public void setConsentUrl(String consentUrl) {
		this.consentUrl = consentUrl;
	}
	@Override
	public String toString() {
		return "ConsentDetails [consentChannelTypeDesc=" + consentChannelTypeDesc + ", consentChannel=" + consentChannel
				+ ", consentToken=" + consentToken + ", consentUrl=" + consentUrl + "]";
	}
}