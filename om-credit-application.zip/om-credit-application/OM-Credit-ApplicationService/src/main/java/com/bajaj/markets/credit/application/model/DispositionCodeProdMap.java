package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the stage_master database table.
 * 
 */
@Entity
@Table(name = "disposition_code_prod_map", schema = "dmcredit")
public class DispositionCodeProdMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long disposcdprodmapkey;
	private Long dispostionkey;
	private Long functionkey;
	private Long prodcatkey;
	private Long prodkey;
	private Long prodmastkey;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	public Long getDisposcdprodmapkey() {
		return disposcdprodmapkey;
	}
	public void setDisposcdprodmapkey(Long disposcdprodmapkey) {
		this.disposcdprodmapkey = disposcdprodmapkey;
	}
	public Long getDispostionkey() {
		return dispostionkey;
	}
	public void setDispostionkey(Long dispostionkey) {
		this.dispostionkey = dispostionkey;
	}
	public Long getFunctionkey() {
		return functionkey;
	}
	public void setFunctionkey(Long functionkey) {
		this.functionkey = functionkey;
	}
	public Long getProdcatkey() {
		return prodcatkey;
	}
	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}
	public Long getProdkey() {
		return prodkey;
	}
	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}
	public Long getProdmastkey() {
		return prodmastkey;
	}
	public void setProdmastkey(Long prodmastkey) {
		this.prodmastkey = prodmastkey;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	public Long getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}