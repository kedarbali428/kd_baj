package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.ApplicationUtmParameter;

public interface ApplicationUtmParameterRoInterface extends ReadInterface<ApplicationUtmParameter, Long> {

	ApplicationUtmParameter findByApplicationkeyAndIsactive(Long applicationkey, Integer isActive);

	ApplicationUtmParameter findByApplicationkeyAndEventAndIsactive(Long applicationkey, String event,
			Integer isActive);

	List<ApplicationUtmParameter> findByApplicationkeyAndIsactiveAndEvent(Long applicationkey, Integer isActive,
			String event);

	List<ApplicationUtmParameter> findByIsactiveAndApplicationkey(Integer isActive, Long applicationkey);

}
