package com.bajaj.markets.credit.application.bean;

public class OpenArcCardListingOutput {

	private OpenArcCardListing openArcCardListing;
	private OpenMarketsLoanListing openMarketsLoanListing;

	public OpenArcCardListing getOpenArcCardListing() {
		return openArcCardListing;
	}

	public void setOpenArcCardListing(OpenArcCardListing openArcCardListing) {
		this.openArcCardListing = openArcCardListing;
	}

	public OpenMarketsLoanListing getOpenMarketsLoanListing() {
		return openMarketsLoanListing;
	}

	public void setOpenMarketsLoanListing(OpenMarketsLoanListing openMarketsLoanListing) {
		this.openMarketsLoanListing = openMarketsLoanListing;
	}

	@Override
	public String toString() {
		return "OpenArcCardListingOutput [openArcCardListing=" + openArcCardListing + ", openMarketsLoanListing="
				+ openMarketsLoanListing + "]";
	}

}
