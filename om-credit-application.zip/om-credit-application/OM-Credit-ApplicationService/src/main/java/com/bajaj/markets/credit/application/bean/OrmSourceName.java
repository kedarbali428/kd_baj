package com.bajaj.markets.credit.application.bean;

public enum OrmSourceName {
	PERFIOS,NSDL,CIBIL
}
