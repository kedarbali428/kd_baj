package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class PrincipalLoanDetails {

	private String loanPurpose;
	private BigDecimal loanAmount;
	private Integer tenure;
	private Integer finalTenure;
	private BigDecimal roi;
	private BigDecimal emiAmount;
	private List<FeeDetails> pricingFee;
	
	public String getLoanPurpose() {
		return loanPurpose;
	}
	public void setLoanPurpose(String loanPurpose) {
		this.loanPurpose = loanPurpose;
	}
	public BigDecimal getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}
	public Integer getTenure() {
		return tenure;
	}
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}
	public Integer getFinalTenure() {
		return finalTenure;
	}
	public void setFinalTenure(Integer finalTenure) {
		this.finalTenure = finalTenure;
	}

	public BigDecimal getRoi() {
		return roi;
	}
	public void setRoi(BigDecimal roi) {
		this.roi = roi;
	}
	public BigDecimal getEmiAmount() {
		return emiAmount;
	}
	public void setEmiAmount(BigDecimal emiAmount) {
		this.emiAmount = emiAmount;
	}
	public List<FeeDetails> getPricingFee() {
		return pricingFee;
	}
	public void setPricingFee(List<FeeDetails> pricingFee) {
		this.pricingFee = pricingFee;
	}
	
	@Override
	public String toString() {
		return "PrincipalLoanDetails [loanPurpose=" + loanPurpose + ", loanAmount=" + loanAmount + ", tenure=" + tenure
				+ ", finalTenure=" + finalTenure + ", roi=" + roi + ", emiAmount=" + emiAmount + ", pricingFee="
				+ pricingFee + "]";
	}
	
}
