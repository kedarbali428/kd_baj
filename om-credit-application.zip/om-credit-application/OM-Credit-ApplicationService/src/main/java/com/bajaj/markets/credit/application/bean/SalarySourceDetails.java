package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class SalarySourceDetails {

	private List<SalarySource> salarySources;

	public List<SalarySource> getSalarySources() {
		return salarySources;
	}

	public void setSalarySources(List<SalarySource> salarySources) {
		this.salarySources = salarySources;
	}

	@Override
	public String toString() {
		return "salarySources=" + salarySources;
	}
}
