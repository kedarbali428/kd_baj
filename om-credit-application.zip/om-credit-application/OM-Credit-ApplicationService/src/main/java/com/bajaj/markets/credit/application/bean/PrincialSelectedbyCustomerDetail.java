package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class PrincialSelectedbyCustomerDetail {

	private BigDecimal requiredLoanAmount;
	private Integer tenor;
	private Boolean isEligible;
	private String principleProductCode;
	private Integer offerType;
	private String eligibilityType;
	private String riskOfferType;
	private BigDecimal offerAmount;
	private String loanTypeRecommendation;
	private List<FeesList> feesList;
	private Integer isTenor;
	private BigDecimal dropLineTenor;
	private BigDecimal emiAmount;
	private BaseRate baseRate;
	private List<DueDateDetails> dueDateDetails;
	private List<NextDueDateDetails> nextDueDateDetails;
	private BigDecimal roi;
	private String preApproved;
	private Float bScore;
	private String approvalChances;
	private Integer priorityOrder;
	private Boolean fppApplicable;
	private Boolean perfiosRequired;

	private String productSize;
	private String pennantloanTypeRecommendation;
	private BigDecimal eligibilityAmount;
	private BigDecimal finalUnsecuredFoir;
	private BigDecimal applicableMultiplier;
	private BigDecimal multiplierEligibility;
	private BigDecimal finalFoir;
	private BigDecimal finalMultiplier;
	private BigDecimal maxEmiAsPerFoir;
	private BigDecimal foirEligibilityEmi;
	private String pricingSource;
	private String pricingStatus;
	
	public String getPricingStatus() {
		return pricingStatus;
	}

	public void setPricingStatus(String pricingStatus) {
		this.pricingStatus = pricingStatus;
	}

	public String getPricingSource() {
		return pricingSource;
	}

	public void setPricingSource(String pricingSource) {
		this.pricingSource = pricingSource;
	}
	
	public BigDecimal getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(BigDecimal eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public String getProductSize() {
		return productSize;
	}

	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}

	public String getPennantloanTypeRecommendation() {
		return pennantloanTypeRecommendation;
	}

	public void setPennantloanTypeRecommendation(String pennantloanTypeRecommendation) {
		this.pennantloanTypeRecommendation = pennantloanTypeRecommendation;
	}

	public BigDecimal getFinalUnsecuredFoir() {
		return finalUnsecuredFoir;
	}

	public void setFinalUnsecuredFoir(BigDecimal finalUnsecuredFoir) {
		this.finalUnsecuredFoir = finalUnsecuredFoir;
	}

	public BigDecimal getApplicableMultiplier() {
		return applicableMultiplier;
	}

	public void setApplicableMultiplier(BigDecimal applicableMultiplier) {
		this.applicableMultiplier = applicableMultiplier;
	}

	public BigDecimal getMultiplierEligibility() {
		return multiplierEligibility;
	}

	public void setMultiplierEligibility(BigDecimal multiplierEligibility) {
		this.multiplierEligibility = multiplierEligibility;
	}

	public BigDecimal getFinalFoir() {
		return finalFoir;
	}

	public void setFinalFoir(BigDecimal finalFoir) {
		this.finalFoir = finalFoir;
	}

	public BigDecimal getFinalMultiplier() {
		return finalMultiplier;
	}

	public void setFinalMultiplier(BigDecimal finalMultiplier) {
		this.finalMultiplier = finalMultiplier;
	}

	public BigDecimal getMaxEmiAsPerFoir() {
		return maxEmiAsPerFoir;
	}

	public void setMaxEmiAsPerFoir(BigDecimal maxEmiAsPerFoir) {
		this.maxEmiAsPerFoir = maxEmiAsPerFoir;
	}

	public BigDecimal getFoirEligibilityEmi() {
		return foirEligibilityEmi;
	}

	public void setFoirEligibilityEmi(BigDecimal foirEligibilityEmi) {
		this.foirEligibilityEmi = foirEligibilityEmi;
	}

	public BigDecimal getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(BigDecimal requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public Integer getTenor() {
		return tenor;
	}

	public void setTenor(Integer tenor) {
		this.tenor = tenor;
	}

	public Boolean getIsEligible() {
		return isEligible;
	}

	public void setIsEligible(Boolean isEligible) {
		this.isEligible = isEligible;
	}

	public String getPrincipleProductCode() {
		return principleProductCode;
	}

	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}

	public Integer getOfferType() {
		return offerType;
	}

	public void setOfferType(Integer offerType) {
		this.offerType = offerType;
	}

	public String getEligibilityType() {
		return eligibilityType;
	}

	public void setEligibilityType(String eligibilityType) {
		this.eligibilityType = eligibilityType;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public BigDecimal getOfferAmount() {
		return offerAmount;
	}

	public void setOfferAmount(BigDecimal offerAmount) {
		this.offerAmount = offerAmount;
	}

	public String getLoanTypeRecommendation() {
		return loanTypeRecommendation;
	}

	public void setLoanTypeRecommendation(String loanTypeRecommendation) {
		this.loanTypeRecommendation = loanTypeRecommendation;
	}

	public List<FeesList> getFeesList() {
		return feesList;
	}

	public void setFeesList(List<FeesList> feesList) {
		this.feesList = feesList;
	}

	public Integer getIsTenor() {
		return isTenor;
	}

	public void setIsTenor(Integer isTenor) {
		this.isTenor = isTenor;
	}

	public BigDecimal getDropLineTenor() {
		return dropLineTenor;
	}

	public void setDropLineTenor(BigDecimal dropLineTenor) {
		this.dropLineTenor = dropLineTenor;
	}

	public BigDecimal getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(BigDecimal emiAmount) {
		this.emiAmount = emiAmount;
	}

	public BaseRate getBaseRate() {
		return baseRate;
	}

	public void setBaseRate(BaseRate baseRate) {
		this.baseRate = baseRate;
	}

	public List<DueDateDetails> getDueDateDetails() {
		return dueDateDetails;
	}

	public void setDueDateDetails(List<DueDateDetails> dueDateDetails) {
		this.dueDateDetails = dueDateDetails;
	}

	public List<NextDueDateDetails> getNextDueDateDetails() {
		return nextDueDateDetails;
	}

	public void setNextDueDateDetails(List<NextDueDateDetails> nextDueDateDetails) {
		this.nextDueDateDetails = nextDueDateDetails;
	}

	public BigDecimal getRoi() {
		return roi;
	}

	public void setRoi(BigDecimal roi) {
		this.roi = roi;
	}

	public String getPreApproved() {
		return preApproved;
	}

	public void setPreApproved(String preApproved) {
		this.preApproved = preApproved;
	}

	public Float getbScore() {
		return bScore;
	}

	public void setbScore(Float bScore) {
		this.bScore = bScore;
	}

	public String getApprovalChances() {
		return approvalChances;
	}

	public void setApprovalChances(String approvalChances) {
		this.approvalChances = approvalChances;
	}

	public Integer getPriorityOrder() {
		return priorityOrder;
	}

	public void setPriorityOrder(Integer priorityOrder) {
		this.priorityOrder = priorityOrder;
	}

	public Boolean getFppApplicable() {
		return fppApplicable;
	}

	public void setFppApplicable(Boolean fppApplicable) {
		this.fppApplicable = fppApplicable;
	}

	public Boolean getPerfiosRequired() {
		return perfiosRequired;
	}

	public void setPerfiosRequired(Boolean perfiosRequired) {
		this.perfiosRequired = perfiosRequired;
	}

	@Override
	public String toString() {
		return "PrincialSelectedbyCustomerDetail [requiredLoanAmount=" + requiredLoanAmount + ", tenor=" + tenor
				+ ", isEligible=" + isEligible + ", principleProductCode=" + principleProductCode + ", offerType="
				+ offerType + ", eligibilityType=" + eligibilityType + ", riskOfferType=" + riskOfferType
				+ ", offerAmount=" + offerAmount + ", loanTypeRecommendation=" + loanTypeRecommendation + ", feesList="
				+ feesList + ", isTenor=" + isTenor + ", dropLineTenor=" + dropLineTenor + ", emiAmount=" + emiAmount
				+ ", baseRate=" + baseRate + ", dueDateDetails=" + dueDateDetails + ", nextDueDateDetails="
				+ nextDueDateDetails + ", roi=" + roi + ", preApproved=" + preApproved + ", bScore=" + bScore
				+ ", approvalChances=" + approvalChances + ", priorityOrder=" + priorityOrder + ", fppApplicable="
				+ fppApplicable + ", perfiosRequired=" + perfiosRequired + ", productSize=" + productSize
				+ ", pennantloanTypeRecommendation=" + pennantloanTypeRecommendation + ", eligibilityAmount="
				+ eligibilityAmount + ", finalUnsecuredFoir=" + finalUnsecuredFoir + ", applicableMultiplier="
				+ applicableMultiplier + ", multiplierEligibility=" + multiplierEligibility + ", finalFoir=" + finalFoir
				+ ", finalMultiplier=" + finalMultiplier + ", maxEmiAsPerFoir=" + maxEmiAsPerFoir
				+ ", foirEligibilityEmi=" + foirEligibilityEmi + "]";
	}
}
