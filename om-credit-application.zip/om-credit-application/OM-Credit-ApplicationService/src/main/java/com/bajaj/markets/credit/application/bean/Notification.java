package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class Notification {

	private String applicationId;
	private String mobileNumber;
	private String personalEmailId;
	private String customerName;
	private String product;
	private List<String> productList;
	private String link;
	private String productCount;
	private String notificationCode;
    private String productName;
    private String maxeligibility;
    private String occupationTypeCode;
    
	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPersonalEmailId() {
		return personalEmailId;
	}

	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public List<String> getProductList() {
		return productList;
	}

	public void setProductList(List<String> productList) {
		this.productList = productList;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getProductCount() {
		return productCount;
	}

	public void setProductCount(String productCount) {
		this.productCount = productCount;
	}
	public String getNotificationCode() {
		return notificationCode;
	}

	public void setNotificationCode(String notificationCode) {
		this.notificationCode = notificationCode;
	}
	
	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getMaxeligibility() {
		return maxeligibility;
	}

	public void setMaxeligibility(String maxeligibility) {
		this.maxeligibility = maxeligibility;
	}

	public String getOccupationTypeCode() {
		return occupationTypeCode;
	}

	public void setOccupationTypeCode(String occupationTypeCode) {
		this.occupationTypeCode = occupationTypeCode;
	}

	@Override
	public String toString() {
		return "Notification [applicationId=" + applicationId + ", mobileNumber=" + mobileNumber + ", personalEmailId="
				+ personalEmailId + ", customerName=" + customerName + ", product=" + product + ", productList="
				+ productList + ", link=" + link + ", productCount=" + productCount + ", notificationCode="
				+ notificationCode + ", productName=" + productName + ", maxeligibility=" + maxeligibility
				+ ", occupationTypeCode=" + occupationTypeCode + "]";
	}
}
