package com.bajaj.markets.credit.application.bean;

public class ChildRecord {
	
	private Long childApplicationId;
	
	private Long inProcessFlag;
	
	public Long getChildApplicationId() {
		return childApplicationId;
	}
	public void setChildApplicationId(Long childApplicationId) {
		this.childApplicationId = childApplicationId;
	}
	public Long getInProcessFlag() {
		return inProcessFlag;
	}
	public void setInProcessFlag(Long inProcessFlag) {
		this.inProcessFlag = inProcessFlag;
	}
	
	
}
