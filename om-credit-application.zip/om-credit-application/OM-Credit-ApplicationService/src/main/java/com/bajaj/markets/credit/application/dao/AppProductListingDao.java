package com.bajaj.markets.credit.application.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bajaj.markets.credit.application.bean.CardsAndLoansProductDetails;
import com.bajaj.markets.credit.application.model.AppFinEligibility;
import com.bajaj.markets.credit.application.model.AppLoanPricing;
import com.bajaj.markets.credit.application.model.AppLoanPricingFees;
import com.bajaj.markets.credit.application.model.AppProductListing;

@Repository
public interface AppProductListingDao {

	/**
	 * This method copy app_product_listing, app_loan_pricing, app_loan_princing, app_fin_eligibility table data
	 * to the provided applicationkey  
	 * 
	 * @param childApplicationKey
	 * @param appProductListing
	 * @param appLoanPricing
	 * @param appLoanPricingFeesList
	 * @param appFinEligibility
	 * @throws CloneNotSupportedException
	 */
	public void copyOverProductDataToDestinationApplication(Long applicationKey, AppProductListing appProductListing,
			AppLoanPricing appLoanPricing, List<AppLoanPricingFees> appLoanPricingFeesList,
			AppFinEligibility appFinEligibility) throws CloneNotSupportedException;
	
	/**
	 * This method is used to create or update app_product_listing record bases on applicationkey, product, product type and riskoffertype
	 * 
	 * @param appProductListing
	 * @return
	 */
	public AppProductListing updateAppProductListing(AppProductListing appProductListing);
	
	/**
	 * This method is used to create or update app_fin_eligibility record bases on applicationkey and appproductlistingkey
	 * 
	 * @param appFinEligibility
	 * @return
	 */
	public AppFinEligibility updateAppFinEligibility(AppFinEligibility appFinEligibility);
	
	/**
	 * This method is used to create or update app_eligibility_detail record bases on appattrbkey
	 * 
	 * @return
	 */
	public void updateAppEligibilityDetail(String applicationKey, Long appattrbkey,CardsAndLoansProductDetails productDetails);
			
}
