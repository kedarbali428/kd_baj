package com.bajaj.markets.credit.application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.bajaj.markets.credit.application.model.AppFinObligation;

public interface AppFinObligationRoInterface extends ReadInterface<AppFinObligation, Long> {

	AppFinObligation findByApplicationkeyAndIsactive(Long applicationkey, Integer isActive);

	List<AppFinObligation> findByApplicationkeyAndObligationsrcAndIsactive(Long applicationkey, String obligationsrc,
			Integer isActive);

	@Query("select a from AppFinObligation a where a.applicationkey=:applicationkey AND a.isactive=1")
	List<AppFinObligation> findByApplicationkeyAndIsactive(Long applicationkey);

	AppFinObligation findByApplicationkeyAndIsactiveAndObligationsrc(Long applicationkey, Integer isActive,
			String obligationsrc);

}
