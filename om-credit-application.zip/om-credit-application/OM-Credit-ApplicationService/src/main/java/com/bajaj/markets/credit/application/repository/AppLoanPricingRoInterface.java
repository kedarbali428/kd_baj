package com.bajaj.markets.credit.application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.bajaj.markets.credit.application.model.AppLoanPricing;

public interface AppLoanPricingRoInterface extends ReadInterface<AppLoanPricing, Long> {

	AppLoanPricing findByApplicationkeyAndIsactive(Long applicationkey, Integer isActive);

	AppLoanPricing findByApplicationkeyAndIsactiveAndAppprodlistkey(Long applicationkey, Integer isActive,
			Long appprodlistkey);

	AppLoanPricing findByApplicationkeyAndAppprodlistkey(Long applicationkey, Long appprodlistkey);

	List<AppLoanPricing> findByApplicationkeyAndAppprodlistkeyAndSourceInAndIsactive(Long applicationkey,
			Long appprodlistkey, List<String> sources, Integer isActive);

	List<AppLoanPricing> findByIsactiveAndApplicationkey(Integer isActive, Long applicationkey);

	@Query("select a from AppLoanPricing a where a.applicationkey=:applicationkey  and a.status='APPROVED' and a.isactive=1  order by lstupdatedt desc")
	List<AppLoanPricing> findByApplicationkeyAndStatusAndIsactive(Long applicationkey);

	AppLoanPricing findByApplicationkeyAndAppprodlistkeyAndSourceAndIsactive(Long applicationId, Long appprodlistkey,
			String source, Integer isActive);

	List<AppLoanPricing> findByApplicationkeyAndAppprodlistkeyAndIsactive(Long chldAppKey, Long appprodlistkey, Integer isactive);

}
