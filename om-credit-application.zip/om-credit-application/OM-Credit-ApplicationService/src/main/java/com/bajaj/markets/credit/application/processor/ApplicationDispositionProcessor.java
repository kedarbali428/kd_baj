package com.bajaj.markets.credit.application.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.application.bean.DispositionRequest;
import com.bajaj.markets.credit.application.bean.UserName;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class ApplicationDispositionProcessor {

	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	Environment env;
	
	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;
	
	@Value("${api.omcommondialerbusiness.disposition.post.url}")
	private String getDispositionDialerUrl;
	
	@Value("${api.usermanagement.userprofiles.GET.url}")
	private String userProfileUrl;
	
	private static final String CLASS_NAME = ApplicationDispositionProcessor.class.getCanonicalName();

	public ResponseEntity<String> callDispositionDialer(DispositionRequest dispositionRequest, String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Inside callDispositionDialer method for applicationId : "+ applicationId);
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<String> responseEntity = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			String jsonReq = mapper.writeValueAsString(dispositionRequest);
			params.put(ApplicationConstants.APPLICATIONID, applicationId);
			ResponseEntity<Object> dispositionResponse = creditApplicationServiceUtility.excuteRestCall(
					getDispositionDialerUrl, HttpMethod.POST, String.class, params, jsonReq, headers);
			if (dispositionResponse.getStatusCode().equals(HttpStatus.OK)) {
				responseEntity = new ResponseEntity<>(HttpStatus.OK);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in Dialer Business service." + dispositionResponse.getBody().toString());
				throw new CreditApplicationServiceException(dispositionResponse.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_4100,
								env.getProperty(ApplicationConstants.CAS_4100)));
			}
		}catch (CreditApplicationServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while calling disposition dialer for applicationId : " +applicationId, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		return responseEntity;
	}
	
	@SuppressWarnings("unchecked")
	public List<UserName> getUserDetailsByUserRoleKey(Long userRoleKey, Boolean isPrincipleFlag) {
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		params.put("userKey", userRoleKey.toString());
		params.put("isPrinciple", String.valueOf(isPrincipleFlag));
		params.put("isUserkey", String.valueOf(true));
		List<UserName> userList = new ArrayList<UserName>();
		ResponseEntity<Object> excuteRestCall = creditApplicationServiceUtility
				.excuteRestCall(userProfileUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				String payload = getPayload(excuteRestCall.getBody().toString());
				UserName[] username = gson.fromJson(payload, UserName[].class);
				userList = Arrays.asList(username);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND, "");
		}
		return userList;
	}

	private String getPayload(String requestBody) {
		String newStr = requestBody.substring(0, requestBody.indexOf("]"));
		String s1 = newStr.substring(newStr.indexOf("[") + 1);
		String s2 = s1.trim();
		String s3 = "[".concat(s2).concat("]");
		return s3;
	}
}