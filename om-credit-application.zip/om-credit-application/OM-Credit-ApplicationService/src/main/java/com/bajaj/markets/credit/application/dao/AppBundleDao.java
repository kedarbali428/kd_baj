package com.bajaj.markets.credit.application.dao;

public interface AppBundleDao {
	
	/**
	 * This method is used for copying fpp bundle data from EP to journey
	 * @param applicationKey
	 */

	public void copyAppBundlFromEpToJrny(String applicationKey);
}
