package com.bajaj.markets.credit.application.repository;

import com.bajaj.markets.credit.application.model.AppSegmentation;

public interface AppSegmentationRoInterface extends ReadInterface<AppSegmentation, Long> {

	AppSegmentation findByApplicationkeyAndIsactive(Long applicationkey, Integer isactive);

}
