package com.bajaj.markets.credit.application.helper;

import org.springframework.web.client.RestTemplate;

public class RestTemplateInstance {
	private static RestTemplate client = getRestTemplate();

	private RestTemplateInstance() {

	}

	private static RestTemplate getRestTemplate() {
		if (client == null) {
			client = new RestTemplate();
		}
		return client;
	}

	public static RestTemplate getRestTemplateInstance() {
		return client;
	}
}