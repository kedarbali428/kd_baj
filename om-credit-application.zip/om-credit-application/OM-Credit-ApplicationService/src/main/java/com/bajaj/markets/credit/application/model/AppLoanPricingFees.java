package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_loan_pricing_fees", schema = "dmcredit")
public class AppLoanPricingFees  implements Serializable,Cloneable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="app_loan_pricing_fees_generator", sequenceName="dmcredit.seq_pk_app_loan_pricing_fees",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_loan_pricing_fees_generator")
	private Long apploanpricingfeeskey;
	
    private Long apploanpricingkey;
    
    private BigDecimal feesinpercent;
    
    private BigDecimal feesinamount;
    
    private String feecode;
    
    private Integer isactive;
    
    private Long lstupdateby;
    
    private Timestamp lstupdatedt;

	public Long getApploanpricingfeeskey() {
		return apploanpricingfeeskey;
	}

	public void setApploanpricingfeeskey(Long apploanpricingfeeskey) {
		this.apploanpricingfeeskey = apploanpricingfeeskey;
	}

	public Long getApploanpricingkey() {
		return apploanpricingkey;
	}

	public void setApploanpricingkey(Long apploanpricingkey) {
		this.apploanpricingkey = apploanpricingkey;
	}

	public BigDecimal getFeesinpercent() {
		return feesinpercent;
	}

	public void setFeesinpercent(BigDecimal feesinpercent) {
		this.feesinpercent = feesinpercent;
	}

	public BigDecimal getFeesinamount() {
		return feesinamount;
	}

	public void setFeesinamount(BigDecimal feesinamount) {
		this.feesinamount = feesinamount;
	}

	public String getFeecode() {
		return feecode;
	}

	public void setFeecode(String feecode) {
		this.feecode = feecode;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
	public AppLoanPricingFees clone()throws CloneNotSupportedException{ 
		AppLoanPricingFees appLoanPricingFees = new AppLoanPricingFees();
		//appLoanPricingFees = (AppLoanPricingFees) super.clone();
		appLoanPricingFees.setApploanpricingfeeskey(this.apploanpricingfeeskey);
		appLoanPricingFees.setApploanpricingkey(this.apploanpricingkey);
		appLoanPricingFees.setFeecode(this.feecode);
		appLoanPricingFees.setFeesinamount(this.feesinamount);
		appLoanPricingFees.setFeesinpercent(this.feesinpercent);
		appLoanPricingFees.setIsactive(this.isactive);
		appLoanPricingFees.setLstupdateby(this.lstupdateby);
		appLoanPricingFees.setLstupdatedt(this.lstupdatedt);
		
		return appLoanPricingFees;  
	} 
}
