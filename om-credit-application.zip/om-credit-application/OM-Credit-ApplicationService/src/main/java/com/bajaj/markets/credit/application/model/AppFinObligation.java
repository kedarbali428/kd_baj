package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="app_fin_obligation",schema = "dmcredit")
public class AppFinObligation implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@SequenceGenerator(name="app_fin_obligation_generator", sequenceName="dmcredit.seq_pk_app_fin_obligation",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_fin_obligation_generator")
	private Long appobligationkey;
	
	private Long applicationkey;
	
	private BigDecimal breobligationamt;
	
	private BigDecimal crdtobligationamt;
	
	private String obligationsrc;
	
	private Integer isactive;
	
	private Long lstupdateby;
	
	private Timestamp lstupdatedt;
	
	private BigDecimal currentbalance;

	public Long getAppobligationkey() {
		return appobligationkey;
	}

	public void setAppobligationkey(Long appobligationkey) {
		this.appobligationkey = appobligationkey;
	}
  
	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public BigDecimal getBreobligationamt() {
		return breobligationamt;
	}

	public void setBreobligationamt(BigDecimal breobligationamt) {
		this.breobligationamt = breobligationamt;
	}

	public BigDecimal getCrdtobligationamt() {
		return crdtobligationamt;
	}

	public void setCrdtobligationamt(BigDecimal crdtobligationamt) {
		this.crdtobligationamt = crdtobligationamt;
	}

	public String getObligationsrc() {
		return obligationsrc;
	}

	public void setObligationsrc(String obligationsrc) {
		this.obligationsrc = obligationsrc;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getCurrentbalance() {
		return currentbalance;
	}

	public void setCurrentbalance(BigDecimal currentbalance) {
		this.currentbalance = currentbalance;
	}
	
}
