package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class OrmSystemCheckRequest {
	private List<OrmVerificationSourceDetail>verificationSourceDetails;
	private List<ApplicationSourceDetail>applicationSourceDetails;
	public List<OrmVerificationSourceDetail> getVerificationSourceDetails() {
		return verificationSourceDetails;
	}
	public void setVerificationSourceDetails(List<OrmVerificationSourceDetail> verificationSourceDetails) {
		this.verificationSourceDetails = verificationSourceDetails;
	}
	public List<ApplicationSourceDetail> getApplicationSourceDetails() {
		return applicationSourceDetails;
	}
	public void setApplicationSourceDetails(List<ApplicationSourceDetail> applicationSourceDetails) {
		this.applicationSourceDetails = applicationSourceDetails;
	}
	@Override
	public String toString() {
		return "OrmSystemCheckRequest [verificationSourceDetails=" + verificationSourceDetails
				+ ", applicationSourceDetails=" + applicationSourceDetails + "]";
	}
	
	
}
