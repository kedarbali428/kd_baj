package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;
import java.util.List;

public class BundleProduct implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7210009140806948361L;
	private String productCode;
	private String productName;
	private String productUserFriendlyName;
	private String productType;
	private Double premiumWithGst;
	private Double costWithGst;
	private Double premiumWithoutGST;
	private Double sumAssured;
	private Integer tenure;
	private Double pv;
	private List<BundleProductRider> riders;

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public void setPremiumWithGst(Double premiumWithGst) {
		this.premiumWithGst = premiumWithGst;
	}

	public void setCostWithGst(Double costWithGst) {
		this.costWithGst = costWithGst;
	}

	public void setSumAssured(Double sumAssured) {
		this.sumAssured = sumAssured;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	public void setRiders(List<BundleProductRider> riders) {
		this.riders = riders;
	}

	public void setPv(Double pv) {
		this.pv = pv;
	}

	public String getProductCode() {
		return productCode;
	}

	public List<BundleProductRider> getRiders() {
		return riders;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setProductUserFriendlyName(String productUserFriendlyName) {
		this.productUserFriendlyName = productUserFriendlyName;
	}

	public String getProductName() {
		return productName;
	}

	public String getProductUserFriendlyName() {
		return productUserFriendlyName;
	}

	public Double getPremiumWithGst() {
		return premiumWithGst;
	}

	public Double getCostWithGst() {
		return costWithGst;
	}

	public Double getSumAssured() {
		return sumAssured;
	}

	public Integer getTenure() {
		return tenure;
	}

	public Double getPv() {
		return pv;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public Double getPremiumWithoutGST() {
		return premiumWithoutGST;
	}

	public void setPremiumWithoutGST(Double premiumWithoutGST) {
		this.premiumWithoutGST = premiumWithoutGST;
	}

	@Override
	public String toString() {
		return "BundleProduct [productCode=" + productCode + ", productName=" + productName + ", productUserFriendlyName=" + productUserFriendlyName
				+ ", productType=" + productType + ", premiumWithGst=" + premiumWithGst + ", costWithGst=" + costWithGst + ", premiumWithoutGST="
				+ premiumWithoutGST + ", sumAssured=" + sumAssured + ", tenure=" + tenure + ", pv=" + pv + ", riders=" + riders + "]";
	}

}
