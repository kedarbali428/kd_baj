package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class BreUnderWriterCheckResponse {
private List<OrmSystemCheckResponse>ormSystemCheckResponse;

public List<OrmSystemCheckResponse> getOrmSystemCheckResponse() {
	return ormSystemCheckResponse;
}

public void setOrmSystemCheckResponse(List<OrmSystemCheckResponse> ormSystemCheckResponse) {
	this.ormSystemCheckResponse = ormSystemCheckResponse;
}

@Override
public String toString() {
    return "BreUnderWriterCheckResponse [ormSystemCheckResponse=" + ormSystemCheckResponse + "]";
}




}
