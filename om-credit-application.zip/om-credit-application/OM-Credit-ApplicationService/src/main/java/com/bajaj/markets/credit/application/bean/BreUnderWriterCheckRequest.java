package com.bajaj.markets.credit.application.bean;

public class BreUnderWriterCheckRequest {
private OrmSystemCheckRequest ormSystemCheckRequest;

public OrmSystemCheckRequest getOrmSystemCheckRequest() {
	return ormSystemCheckRequest;
}

public void setOrmSystemCheckRequest(OrmSystemCheckRequest ormSystemCheckRequest) {
	this.ormSystemCheckRequest = ormSystemCheckRequest;
}

@Override
public String toString() {
    return "BreUnderWriterCheckRequest [ormSystemCheckRequest=" + ormSystemCheckRequest + "]";
}





}
