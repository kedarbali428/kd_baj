package com.bajaj.markets.credit.application.bean;

public class AppSegmentationInfo {
	private String segDesc;
	
	private String customerProfileSegment;
	
	private String  microSegment;
	
	private String customerSegment;
	
	private String profileIncomeSegment ;
	
	public String getSegDesc() {
		return segDesc;
	}

	public void setSegDesc(String segDesc) {
		this.segDesc = segDesc;
	}

	public String getCustomerProfileSegment() {
		return customerProfileSegment;
	}

	public void setCustomerProfileSegment(String customerProfileSegment) {
		this.customerProfileSegment = customerProfileSegment;
	}

	public String getMicroSegment() {
		return microSegment;
	}

	public void setMicroSegment(String microSegment) {
		this.microSegment = microSegment;
	}

	public String getCustomerSegment() {
		return customerSegment;
	}

	public void setCustomerSegment(String customerSegment) {
		this.customerSegment = customerSegment;
	}

	public String getProfileIncomeSegment() {
		return profileIncomeSegment;
	}

	public void setProfileIncomeSegment(String profileIncomeSegment) {
		this.profileIncomeSegment = profileIncomeSegment;
	}



}