package com.bajaj.markets.credit.application.bean;

public class Header {
	
	private String eventActor;
	private String dataType;
	private String eventSource;
	private String eventName;
	private String eventType;
	private String timestamp;

	public String getEventActor() {
		return eventActor;
	}
	public void setEventActor(String eventActor) {
		this.eventActor = eventActor;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getEventSource() {
		return eventSource;
	}
	public void setEventSource(String eventSource) {
		this.eventSource = eventSource;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "ClassPojo [eventActor = " + eventActor + ", dataType = " + dataType + ", eventSource = " + eventSource
				+ ", eventName = " + eventName + ", eventType = " + eventType + ", timestamp = " + timestamp + "]";
	}
}