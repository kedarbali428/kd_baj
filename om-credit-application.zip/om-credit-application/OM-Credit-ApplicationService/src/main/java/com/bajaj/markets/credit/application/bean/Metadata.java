package com.bajaj.markets.credit.application.bean;

public class Metadata {
	
	private String partner;
	private String callbackURL;

	public String getPartner() {
		return partner;
	}
	public void setPartner(String partner) {
		this.partner = partner;
	}
	public String getCallbackURL() {
		return callbackURL;
	}
	public void setCallbackURL(String callbackURL) {
		this.callbackURL = callbackURL;
	}

	@Override
	public String toString() {
		return "ClassPojo [partner = " + partner + ", callbackURL = " + callbackURL + "]";
	}
}