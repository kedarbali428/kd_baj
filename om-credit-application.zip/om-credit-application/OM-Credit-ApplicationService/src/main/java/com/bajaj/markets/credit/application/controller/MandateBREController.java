package com.bajaj.markets.credit.application.controller;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.Application;
import com.bajaj.markets.credit.application.bean.BrePreferredBankResponse;
import com.bajaj.markets.credit.application.bean.BrePreferredMandateResponse;
import com.bajaj.markets.credit.application.bean.MandateBreRequest;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.MandateBREService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller for Mandate BRE call used while updating bank details
 * 
 * @author Pranoti Pandole
 *
 */
@RestController

public class MandateBREController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	MandateBREService mandateBREService;

	private static final String CLASSNAME = MandateBREController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE,
			Role.PRINCIPAL, Role.VENDORPARTNER })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get Prefered bank Details", notes = "Get Preferred bank Details from BRE", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "BRE Details updated Successfully.", response = BrePreferredBankResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/applications/{applicationKey}/bankdetails/preferedbank", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> getPreferredBank(@RequestBody MandateBreRequest mandateBreRequest,
			@PathVariable("applicationKey") @NotBlank(message = "applicationid can not be null or empty") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getPreferredBank method controller for applicationId: " + applicationId);
		mandateBreRequest.setApplicationId(Long.parseLong(applicationId));
		BrePreferredBankResponse mandateBreResponse = mandateBREService.getPreferredBank(mandateBreRequest, headers);
		return new ResponseEntity<> (mandateBreResponse, HttpStatus.OK);
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE,
			Role.PRINCIPAL, Role.VENDORPARTNER })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get Prefered Mandate Details", notes = "Get Prefered Mandate Details", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "BRE Details updated Successfully.", response = BrePreferredMandateResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/applications/{applicationKey}/bankdetails/{bankdetailskey}/preferedMandate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> getPreferredMandate(@RequestBody MandateBreRequest mandateBreRequest,
			@PathVariable("applicationKey") @NotBlank(message = "applicationid can not be null or empty") String applicationId,
			@PathVariable("bankdetailskey") @NotBlank(message = "bankdetailskey can not be null or empty") String bankdetailskey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getPreferredMandate method controller for applicationId: " + applicationId);
		mandateBreRequest.setApplicationId(Long.parseLong(applicationId));
		BrePreferredMandateResponse mandateBreResponse = mandateBREService.getPreferredMandate(mandateBreRequest, headers);
		return new ResponseEntity<>(mandateBreResponse, HttpStatus.OK);
	}

}
