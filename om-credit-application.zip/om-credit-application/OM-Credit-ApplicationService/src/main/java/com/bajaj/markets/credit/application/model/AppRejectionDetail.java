package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the app_rejection_detail database table.
 * 
 */
@Entity
@Table(name = "app_rejection_detail", schema = "dmcredit")
public class AppRejectionDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_rejection_detailkey_generator", sequenceName = "dmcredit.seq_pk_app_rejection_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_rejection_detailkey_generator")
	private Long apprejectdetkey;

	private Long applicationkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long prodkey;

	private Timestamp rejectcoolprdenddt;

	private Long rejectedbyuserkey;

	private Timestamp rejectiondt;

	private String rejectionsrc;

	private Integer rejectiontype;
	
	private Long prodtypekey;
	
	private String riskoffertype;

	//bi-directional many-to-one association to RejectionCode
	@ManyToOne
	@JoinColumn(name="rejectcodekey")
	private RejectionCode rejectionCode;
	
	//bi-directional many-to-one association to RejectionSystemMaster
	@ManyToOne
	@JoinColumn(name="rejectionsystemmastkey")
	private RejectionSystemMaster rejectionSystemMaster;
	 
	public AppRejectionDetail() {
	}

	public Long getApprejectdetkey() {
		return this.apprejectdetkey;
	}

	public void setApprejectdetkey(Long apprejectdetkey) {
		this.apprejectdetkey = apprejectdetkey;
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdkey() {
		return this.prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public Timestamp getRejectcoolprdenddt() {
		return this.rejectcoolprdenddt;
	}

	public void setRejectcoolprdenddt(Timestamp rejectcoolprdenddt) {
		this.rejectcoolprdenddt = rejectcoolprdenddt;
	}

	public Long getRejectedbyuserkey() {
		return this.rejectedbyuserkey;
	}

	public void setRejectedbyuserkey(Long rejectedbyuserkey) {
		this.rejectedbyuserkey = rejectedbyuserkey;
	}

	public Timestamp getRejectiondt() {
		return this.rejectiondt;
	}

	public void setRejectiondt(Timestamp rejectiondt) {
		this.rejectiondt = rejectiondt;
	}

	public String getRejectionsrc() {
		return this.rejectionsrc;
	}

	public void setRejectionsrc(String rejectionsrc) {
		this.rejectionsrc = rejectionsrc;
	}

	public Integer getRejectiontype() {
		return this.rejectiontype;
	}

	public void setRejectiontype(Integer rejectiontype) {
		this.rejectiontype = rejectiontype;
	}

	public RejectionCode getRejectionCode() {
		return this.rejectionCode;
	}

	public void setRejectionCode(RejectionCode rejectionCode) {
		this.rejectionCode = rejectionCode;
	}
	
	public RejectionSystemMaster getRejectionSystemMaster() {
		return this.rejectionSystemMaster;
	}

	public void setRejectionSystemMaster(RejectionSystemMaster rejectionSystemMaster) {
		this.rejectionSystemMaster = rejectionSystemMaster;
	}

	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}
	
}