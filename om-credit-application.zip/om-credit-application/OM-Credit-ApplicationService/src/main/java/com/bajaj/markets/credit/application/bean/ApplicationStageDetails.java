package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

/**
 * Application Stage Details resource
 * 
 * @author 736919
 * 
 */
public class ApplicationStageDetails {

	private Integer stageKey;

	private Integer subStageKey;

	private Integer statusKey;

	@NotNull(message = "percentage cannot be null or empty")
	@Digits(fraction = 0, integer = 3, message = "percentage should be numeric & should not exceeds size")
	@Max(value = 100, message = "percentage should be numeric & should not exceeds size")
	private Integer percentageCompletion;

	private String stageDesc;
	private String subStageDesc;
	private String stageInTime;

	public Integer getStageKey() {
		return stageKey;
	}

	public void setStageKey(Integer stageKey) {
		this.stageKey = stageKey;
	}

	public Integer getSubStageKey() {
		return subStageKey;
	}

	public void setSubStageKey(Integer subStageKey) {
		this.subStageKey = subStageKey;
	}

	public Integer getStatusKey() {
		return statusKey;
	}

	public void setStatusKey(Integer statusKey) {
		this.statusKey = statusKey;
	}

	public Integer getPercentageCompletion() {
		return percentageCompletion;
	}

	public void setPercentageCompletion(Integer percentageCompletion) {
		this.percentageCompletion = percentageCompletion;
	}

	public String getStageDesc() {
		return stageDesc;
	}

	public void setStageDesc(String stageDesc) {
		this.stageDesc = stageDesc;
	}

	public String getSubStageDesc() {
		return subStageDesc;
	}

	public void setSubStageDesc(String subStageDesc) {
		this.subStageDesc = subStageDesc;
	}

	public String getStageInTime() {
		return stageInTime;
	}

	public void setStageInTime(String stageInTime) {
		this.stageInTime = stageInTime;
	}

	@Override
	public String toString() {
		return "ApplicationStageDetails [stageKey=" + stageKey + ", subStageKey=" + subStageKey + ", statusKey="
				+ statusKey + ", percentageCompletion=" + percentageCompletion + ", stageDesc=" + stageDesc
				+ ", subStageDesc=" + subStageDesc + ", stageInTime=" + stageInTime + "]";
	}

}
