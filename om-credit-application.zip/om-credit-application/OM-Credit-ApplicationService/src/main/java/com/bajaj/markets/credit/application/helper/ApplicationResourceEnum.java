package com.bajaj.markets.credit.application.helper;

public enum ApplicationResourceEnum {
	APPLICATION("APPLICATION"),
	APP_ATTRIBUTE("APP_ATTRIBUTE"),
	APP_OCCUPATION("APP_OCCUPATION"),
	APP_ADDRESS("APP_ADDRESS"),
	APP_REJECTION_DEVIATION("APP_REJECTION_DEVIATION"),
	APP_OFFER("APP_OFFER"),
	APP_STATUS("APP_STATUS"),
	APP_UTM("APP_UTM"),
	APP_PRINCIPAL_CUST_INFO("APP_PRINCIPAL_CUST_INFO"),
	APP_EMAIL("APP_EMAIL");
	private final String key;

	private ApplicationResourceEnum(String key) {
		this.key = key;
	}

	public String getKey() {
		return key;
	}

}
