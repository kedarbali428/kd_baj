package com.bajaj.markets.credit.application.bean;

public class UwSegOutput {
	
	private String segmentType;

	public String getSegmentType() {
		return segmentType;
	}

	public void setSegmentType(String segmentType) {
		this.segmentType = segmentType;
	}

	@Override
	public String toString() {
		return "UwSegOutput [segmentType=" + segmentType + "]";
	}
}
