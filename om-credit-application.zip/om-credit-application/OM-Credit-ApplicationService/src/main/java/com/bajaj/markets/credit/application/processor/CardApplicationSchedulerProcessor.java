package com.bajaj.markets.credit.application.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.application.bean.PrincipalConsumerRequest;
import com.bajaj.markets.credit.application.bean.SchedulerProduct;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.model.ApplicationAttribute;
import com.bajaj.markets.credit.application.model.StatusMaster;
import com.bajaj.markets.credit.application.repository.tx.ApplicationAttributeRepository;
import com.bajaj.markets.credit.application.repository.tx.StatusMasterRepository;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.publisher.service.PublisherService;

@Component
public class CardApplicationSchedulerProcessor implements ApplicationSchedulerProcessor {

	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private ApplicationAttributeRepository applicationAttributeRepository;
	
	@Autowired
	private StatusMasterRepository statusMasterRepository;
	
	@Autowired 
	private CustomDefaultHeaders customDefaultHeaders;
	
	@Autowired
	PublisherService publisherService;
	
	@Value("${aws.publisher.principal.topic.arn}")
	private String topicArn;
	
	@Value("#{${scheduler.product.map}}")
	private Map<String, List<String>> productMap;
	
	@Value("#{${scheduler.principle.map}}")
	private Map<String, String> principalMap;
	
	@Value("${scheduler.application.status}")
	private String applicationStatus;
	
	@Value("${scheduler.application.days}")
	private String applicationDays;
	
	@Value("${scheduler.application.percentage}")
	private String applicationPercent;
	
	private static final String CLASS_NAME = CardApplicationSchedulerProcessor.class.getCanonicalName();
	
	
	@Override
	public void callToGetApplicationsAndPushToEvent(SchedulerProduct request, HttpHeaders headers) {
		String l2ProdCode = request.getL2ProdCode();
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start callToGetApplicationsAndPushToEvent method wiht L2ProductCode: "+l2ProdCode);
		List<String> principles = null;
		try {
			if(!CollectionUtils.isEmpty(productMap.get(l2ProdCode))) {
				principles = productMap.get(l2ProdCode); 
			}
			if(!CollectionUtils.isEmpty(principles)) { 
				principles.forEach(obj -> {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Scheduler for--"+obj+"--started at: "+Calendar.getInstance().getTime());
			
					if(null != principalMap.get(obj)) {
						Long principleKey = Long.valueOf(principalMap.get(obj));
						List<ApplicationAttribute> appList = filterCriteria(principleKey);
						
						if(!CollectionUtils.isEmpty(appList)) {
							appList.forEach(appattrb -> {
								try {
									Long applicationKey = appattrb.getApplication().getApplicationkey();
									
									Map<String, String> params = new HashMap<String, String>();
									params.put("mobile", String.valueOf(appattrb.getMobile()));
									params.put("principalKey", String.valueOf(principleKey));
									
									pushApplicationsToEvent(params, String.valueOf(applicationKey), headers);
								} catch (Exception e) {
									logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while getting attribute details with L2ProductCode: "+l2ProdCode, e);
								}
							});
						}
						logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Scheduler for--"+obj+"--completed for count: " +appList.size());
					}
				});
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Technical exception occured in scheduler with L2ProductCode: "+l2ProdCode ,e);
		}
	}
	
	private List<ApplicationAttribute> filterCriteria(Long principleKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start  filterCriteria for principalKey: "+principleKey);
		List<ApplicationAttribute> appList = null;
		try {
			Integer intAppDays = Integer.parseInt(applicationDays);
			Integer intPercent = Integer.parseInt(applicationPercent);
			
			List<String> appStatus = new ArrayList<>();
			appStatus = Arrays.asList(applicationStatus.split(","));
			List<Integer> intStatus = new ArrayList<>();
			appStatus.forEach(o -> {
				StatusMaster statusMaster = statusMasterRepository.findByStatusdescAndIsactive(o, ApplicationConstants.IS_ACTIVE);
				intStatus.add(statusMaster.getStatuskey().intValue());
			});
			
			Calendar cal2 = Calendar.getInstance();
			cal2.add(Calendar.DAY_OF_MONTH, -intAppDays);
			Date filterDate = cal2.getTime();
			
			Calendar cal1 = Calendar.getInstance();
			cal1.add(Calendar.DAY_OF_MONTH, 1);
			cal1.add(Calendar.HOUR, -1);
			
			Date currentDate = cal1.getTime();
			
			appList = applicationAttributeRepository.findMobileforSchedulerforCards(intPercent, principleKey, currentDate, filterDate, intStatus);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Technical exception occured in filterCriteria for principleKey: "+principleKey , e);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Application count after filter: "+appList.size()+" for principleKey: "+principleKey);
		return appList;
	}
	
	private void pushApplicationsToEvent(Map<String, String> params, String applicationKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start pushApplicationsToEvent method for application: "+applicationKey);
		try {
			PrincipalConsumerRequest consumerRequest = new PrincipalConsumerRequest();
			consumerRequest.setMobileNumber(params.get("mobile"));
			consumerRequest.setApplicationKey(applicationKey);
			consumerRequest.setPrincipalKey(params.get("principalKey"));
			Map<String, String> messageFilterAttributes = new HashMap<>();
			Map<String, String> header = new HashMap<>();
			header.put(ApplicationConstants.AUTH_TOKEN, headers.get(ApplicationConstants.AUTH_TOKEN).get(0));
			header.put(ApplicationConstants.CMPT_CORR_ID, customDefaultHeaders.getCmptcorrid()); 
			header.put(ApplicationConstants.APPLICATIONID, applicationKey);
			header.put(ApplicationConstants.MOBILE, params.get("mobile"));
			messageFilterAttributes.put("isPrincipalDelayRequired", "NO");
			EventMessage eventMessage = new EventMessage();
			eventMessage.setMessageFilterAttributes(messageFilterAttributes);
			eventMessage.setEventName(ApplicationConstants.PRINCIPAL_STATUS_CHECK);
			eventMessage.setHeaders(header);
			eventMessage.setPayload(consumerRequest);
			publisherService.publish(topicArn, eventMessage);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Successfully pushed status event for applicatin: "+applicationKey);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "pushApplicationsToEvent method failed for application: "+applicationKey, e);
		}
	}
	

}
