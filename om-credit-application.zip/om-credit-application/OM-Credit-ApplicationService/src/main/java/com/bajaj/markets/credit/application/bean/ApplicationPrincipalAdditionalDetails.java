package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.NotBlank;

public class ApplicationPrincipalAdditionalDetails {

	private boolean hasSalaryAccount;
	@NotBlank(message = "appointmentDateTimeFrom is mandatory.")
	private String appointmentDateTimeFrom;
	@NotBlank(message = "appointmentDateTimeTo is mandatory.")
	private String appointmentDateTimeTo;
	private String appointmentAddressTypeCode;


	public boolean isHasSalaryAccount() {
		return hasSalaryAccount;
	}

	public void setHasSalaryAccount(boolean hasSalaryAccount) {
		this.hasSalaryAccount = hasSalaryAccount;
	}

	public String getAppointmentDateTimeFrom() {
		return appointmentDateTimeFrom;
	}

	public void setAppointmentDateTimeFrom(String appointmentDateTimeFrom) {
		this.appointmentDateTimeFrom = appointmentDateTimeFrom;
	}

	public String getAppointmentDateTimeTo() {
		return appointmentDateTimeTo;
	}

	public void setAppointmentDateTimeTo(String appointmentDateTimeTo) {
		this.appointmentDateTimeTo = appointmentDateTimeTo;
	}


	public String getAppointmentAddressTypeCode() {
		return appointmentAddressTypeCode;
	}


	public void setAppointmentAddressTypeCode(String appointmentAddressTypeCode) {
		this.appointmentAddressTypeCode = appointmentAddressTypeCode;
	}


	@Override
	public String toString() {
		return "ApplicationPrincipalAdditionalDetails [hasSalaryAccount=" + hasSalaryAccount
				+ ", appointmentDateTimeFrom=" + appointmentDateTimeFrom + ", appointmentDateTimeTo="
				+ appointmentDateTimeTo + ", appointmentAddressTypeCode=" + appointmentAddressTypeCode + "]";
	}

}
