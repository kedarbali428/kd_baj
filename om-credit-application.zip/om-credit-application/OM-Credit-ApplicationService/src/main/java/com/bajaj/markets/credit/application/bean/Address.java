package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

public class Address implements Serializable {
	private static final long serialVersionUID = 1L;

	private String addressKey;
	@NotBlank(message = "addressTypeKey can not be null")
	private String addressTypeKey;
	private String resiType;
	private String addressLine1;
	private String addressLine2;	
	private String pincode;
	@NotBlank(message = "pincodeKey can not be null")
	private String pincodeKey;
	private String cityKey;
	private String stateKey;
	private String countryKey;
	private Verification verification;
	private String addressSource;
	private String localitykey;
	private Integer numberOfMonths;
	private Boolean preferredFlag;
	private String documentName;
	private String documentValue;
	private String documentCategory;
	public String getAddressKey() {
		return addressKey;
	}

	public void setAddressKey(String addressKey) {
		this.addressKey = addressKey;
	}

	public String getAddressTypeKey() {
		return addressTypeKey;
	}

	public void setAddressTypeKey(String addressTypeKey) {
		this.addressTypeKey = addressTypeKey;
	}

	public String getResiType() {
		return resiType;
	}

	public void setResiType(String resiType) {
		this.resiType = resiType;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(String pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public String getCityKey() {
		return cityKey;
	}

	public void setCityKey(String cityKey) {
		this.cityKey = cityKey;
	}

	public String getStateKey() {
		return stateKey;
	}

	public void setStateKey(String stateKey) {
		this.stateKey = stateKey;
	}

	public String getCountryKey() {
		return countryKey;
	}

	public void setCountryKey(String countryKey) {
		this.countryKey = countryKey;
	}

	public Verification getVerification() {
		return verification;
	}

	public void setVerification(Verification verification) {
		this.verification = verification;
	}

	public String getAddressSource() {
		return addressSource;
	}

	public void setAddressSource(String addressSource) {
		this.addressSource = addressSource;
	}
	
	public String getLocalitykey() {
		return localitykey;
	}
	public void setLocalitykey(String localitykey) {
		this.localitykey = localitykey;
	}

	public Integer getNumberOfMonths() {
		return numberOfMonths;
	}

	public void setNumberOfMonths(Integer numberOfMonths) {
		this.numberOfMonths = numberOfMonths;
	}

	public Boolean getPreferredFlag() {
		return preferredFlag;
	}

	public void setPreferredFlag(Boolean preferredFlag) {
		this.preferredFlag = preferredFlag;
	}
    
	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentValue() {
		return documentValue;
	}

	public void setDocumentValue(String documentValue) {
		this.documentValue = documentValue;
	}

	public String getDocumentCategory() {
		return documentCategory;
	}

	public void setDocumentCategory(String documentCategory) {
		this.documentCategory = documentCategory;
	}

	@Override
	public String toString() {
		return "Address [addressKey=" + addressKey + ", addressTypeKey=" + addressTypeKey + ", resiType=" + resiType
				+ ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + ", pincode=" + pincode
				+ ", pincodeKey=" + pincodeKey + ", cityKey=" + cityKey + ", stateKey=" + stateKey + ", countryKey="
				+ countryKey + ", verification=" + verification + ", addressSource=" + addressSource + ", localitykey="
				+ localitykey + ", numberOfMonths=" + numberOfMonths + ", preferredFlag=" + preferredFlag
				+ ", documentName=" + documentName + ", documentValue=" + documentValue + ", documentCategory="
				+ documentCategory + "]";
	}
}