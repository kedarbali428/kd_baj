package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="app_eligibility_status",schema = "dmcredit")
public class AppEligibilityStatus {

	@Id
	@SequenceGenerator(name="app_eligibility_status_appeligibilitystskey_generator", sequenceName="dmcredit.seq_pk_app_eligibility_status",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_eligibility_status_appeligibilitystskey_generator")
	private Long appeligibilitystskey;
	
    private Long applicationkey;
    
    private Long prodkey;
    
    private String iseligible;
    
    private String source;
	
	private Integer isactive;
	
	private Long lstupdateby;
	
	private Timestamp lstupdatedt;

	public Long getAppeligibilitystskey() {
		return appeligibilitystskey;
	}

	public void setAppeligibilitystskey(Long appeligibilitystskey) {
		this.appeligibilitystskey = appeligibilitystskey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getIseligible() {
		return iseligible;
	}

	public void setIseligible(String iseligible) {
		this.iseligible = iseligible;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
}
