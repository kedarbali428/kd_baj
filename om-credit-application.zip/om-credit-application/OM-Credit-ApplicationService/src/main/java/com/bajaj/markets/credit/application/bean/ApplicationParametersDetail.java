package com.bajaj.markets.credit.application.bean;

public class ApplicationParametersDetail {
private String applicationParameterName;
private String applicationParameterValue;
public String getApplicationParameterName() {
	return applicationParameterName;
}
public void setApplicationParameterName(String applicationParameterName) {
	this.applicationParameterName = applicationParameterName;
}
public String getApplicationParameterValue() {
	return applicationParameterValue;
}
public void setApplicationParameterValue(String applicationParameterValue) {
	this.applicationParameterValue = applicationParameterValue;
}
@Override
public String toString() {
	return "ApplicationParametersDetail [applicationParameterName=" + applicationParameterName
			+ ", applicationParameterValue=" + applicationParameterValue + "]";
}

}
