package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Pattern;

public class NameVerificationDet {

	@Pattern(regexp="^[A-Za-z]*$",message = "Invalid Input firstName")
	private String firstName;
	@Pattern(regexp="^[A-Za-z]*$",message = "Invalid Input middleName")
	private String middleName;
	@Pattern(regexp="^[A-Za-z]*$",message = "Invalid Input lastName")
	private String lastName;
	private String salutation;
	private boolean isVerified;
	private Verification verification;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSalutation() {
		return salutation;
	}
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}
	public boolean isVerified() {
		return isVerified;
	}
	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}
	public Verification getVerification() {
		return verification;
	}
	public void setVerification(Verification verification) {
		this.verification = verification;
	}
	
	
	
}
