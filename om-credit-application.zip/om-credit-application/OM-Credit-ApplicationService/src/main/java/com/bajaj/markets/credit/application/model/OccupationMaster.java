package com.bajaj.markets.credit.application.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="occupation_master", schema="dmmaster")
public class OccupationMaster implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="occupationkey")
	private Long occupationKey; 
	
	@Column(name="occupationcode")
	private String occupationCode;

	@Column(name="occupationname")
	private String occupationValue;
		
	@Column(name="isactive")
	private Integer isactive;

	public Long getOccupationKey() {
		return occupationKey;
	}

	public void setOccupationKey(Long occupationKey) {
		this.occupationKey = occupationKey;
	}

	public String getOccupationCode() {
		return occupationCode;
	}

	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}

	public String getOccupationValue() {
		return occupationValue;
	}

	public void setOccupationValue(String occupationValue) {
		this.occupationValue = occupationValue;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	
}
