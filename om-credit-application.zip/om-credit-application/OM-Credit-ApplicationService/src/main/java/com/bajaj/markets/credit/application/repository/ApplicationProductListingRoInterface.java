package com.bajaj.markets.credit.application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bajaj.markets.credit.application.model.AppProductListing;

public interface ApplicationProductListingRoInterface extends ReadInterface<AppProductListing, Long> {

	List<AppProductListing> findByApplicationkeyAndIsactive(Long applicationkey, Integer isActive);

	AppProductListing findByApplicationkeyAndIsactiveAndProdkey(Long applicationkey, Integer isActive, Long prodkey);

	AppProductListing findByApplicationkeyAndIsactiveAndProdkeyAndProdtypekey(Long applicationkey, Integer isActive,
			Long prodkey, Long prodtypekey);

	AppProductListing findByAppprodlistkey(Long appprodlistkey);

	AppProductListing findByApplicationkeyAndIsactiveAndRiskoffertype(Long valueOf, Integer isActive,
			String productOffer);

	AppProductListing findByApplicationkeyAndIsactiveAndProdkeyAndProdtypekeyAndRiskoffertype(Long applicationkey,
			Integer isActive, Long prodkey, Long prodtypekey, String riskoffertype);

	@Query("select a from AppProductListing a where a.applicationkey=:applicationkey  AND a.isactive=1  AND a.iseligible=1 AND a.prodkey=:prodkey AND a.riskoffertype=:riskoffertype AND prodtypekey IS NOT NULL ")
	List<AppProductListing> findByApplicationkeyAndIsactiveAndIseligibleAndProdkeyAndRiskoffertypeAndProdtypekey(
			Long applicationkey, Long prodkey, String riskoffertype);

	@Query("select a from AppProductListing a where a.applicationkey=:applicationkey  AND a.isactive=1  AND a.iseligible=1 AND a.prodkey=:prodkey  AND prodtypekey IS NOT NULL ")
	List<AppProductListing> findByApplicationkeyAndIsactiveAndIseligibleAndProdkeyAndProdtypekey(Long applicationkey,
			Long prodkey);

	AppProductListing findByAppprodlistkeyAndIsactive(Long appprodlistkey, Integer isActive);

	AppProductListing findByApplicationkeyAndIsactiveAndIsdisplayflgAndProdkeyAndProdtypekey(Long applicationkey,
			Integer isActive, Integer isDisplay, Long prodkey, Long prodtypekey);

	AppProductListing findByApplicationkeyAndIsactiveAndRiskoffertypeAndProdkeyAndProdtypekey(Long applicationkey,
			Integer isActive, String riskoffertype, Long prodkey, Long prodtypekey);

	@Query("select a from AppProductListing a where a.applicationkey=:applicationkey  AND a.isactive=1  AND a.iseligible=1 AND a.prodkey=:prodkey AND a.prodtypekey =:prodtypekey")
	List<AppProductListing> findByApplicationkeyAndIsactiveAndIseligibleAndProdkeyAndProdtypekey(Long applicationkey,
			Long prodkey, Long prodtypekey);

	List<AppProductListing> getEligibleProductsOnly(@Param("applicationkey") Long applicationkey);
}
