package com.bajaj.markets.credit.application.bean;

public class CreateCollateralDisbDetails {

	// ExtendedFields 
	private SPDCDetails spdcDetails;

	public SPDCDetails getSpdcDetails() {
		return spdcDetails;
	}

	public void setSpdcDetails(SPDCDetails spdcDetails) {
		this.spdcDetails = spdcDetails;
	}

}
