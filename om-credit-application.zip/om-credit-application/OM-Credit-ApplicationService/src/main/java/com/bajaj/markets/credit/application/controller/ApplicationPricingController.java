package com.bajaj.markets.credit.application.controller;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.AppBundleDetails;
import com.bajaj.markets.credit.application.bean.PricingDetail;
import com.bajaj.markets.credit.application.bean.PricingStatus;
import com.bajaj.markets.credit.application.bean.UpdateApplication;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.BundleNotSelected;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.BundleSelected;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationPricingService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationPricingController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	ApplicationPricingService applicationPricingService;

	@Autowired
	private Validator validator;

	private static final String CLASSNAME = ApplicationPricingController.class.getName();

	@Secured(value = {Role.SYSTEM,Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch pricing details.", notes = "Fetch pricing details on the basis of applicationKey.", httpMethod = "GET")
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Fetching pricing details successfully.", response = PricingDetail.class,responseContainer = "List"),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
		@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "${api.omcreditapplicationservice.loan.pricing.GET.uri}")
	@CrossOrigin
	public ResponseEntity<Object> getPricingDetail(
			@PathVariable("applicationKey") @Digits(fraction = 0, integer = 20, message = "applicationKey can not be other than digits") String applicationKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Fetching pricing details started:" + applicationKey);
		List<PricingDetail> pricingDetail = null;
		pricingDetail = applicationPricingService.getPricingDetail(applicationKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Fetching pricing details completed successfully:" + pricingDetail.toString());
		return new ResponseEntity<>(pricingDetail, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update pricing details", notes = "Update pricing details", httpMethod = "PUT")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Pricing detail updated successfully.", response = PricingDetail.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)})
	@PutMapping(value = "${api.omcreditapplicationservice.loan.pricing.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> updatePricingDetail(@Valid @RequestBody PricingDetail pricingDetail, BindingResult bindingResult,
			@PathVariable(name = "applicationKey", required = true) String applicationKey, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updatePricingDetail method for applicationId :"
				+ applicationKey + ", pricingDetail :" + pricingDetail);
		PricingDetail response = applicationPricingService.updatePricingDetail(pricingDetail, applicationKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"updatePricingDetail method for pricingDetails completed suceessfully");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update pricing approval status", notes = "Update pricing approval status", httpMethod = "PUT")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Pricing approval status updated successfully.", response = PricingStatus.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.pricing.status.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> updateApprovalStatus(@Valid @RequestBody PricingStatus pricingStatus, BindingResult bindingResult,
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null/empty") @Digits(fraction = 0, integer = 20, message = "applicationid can not be other than digits") String applicationKey,
			@PathVariable("pricingkey") @NotBlank(message = "pricingkey can not be null/empty") @Digits(fraction = 0, integer = 20, message = "pricingkey can not be other than digits") String pricingKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateApprovalStatus method for applicationId :" + applicationKey + ", pricingStatus :" + pricingStatus);
		PricingStatus response = null;
		response = applicationPricingService.updatePricingStatus(pricingStatus, pricingKey, applicationKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "updateApprovalStatus method for pricingStatus completed suceessfully");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Recalculate pricing and update", notes = "Recalculate pricing and update", httpMethod = "PUT")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Pricing approval status updated successfully.", response = PricingDetail.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.pricing.calculations.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> recalculatePricing(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null/empty") @Digits(fraction = 0, integer = 20, message = "applicationid can not be other than digits") String applicationKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside recalculatePricing method for applicationId :" + applicationKey);
		PricingDetail pricingDetail = applicationPricingService.recalculatePricing(applicationKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Method recalculatePricing - Recalculation pricing and update completed suceessfully");
		return new ResponseEntity<>(pricingDetail, HttpStatus.OK);
	}

	//PUT Endpoint for mapping FPP application from vas domain to credit domain : LEN-966
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update mapping of FPP application details in credit domain", notes = "mapping FPP application from vas domain to credit domain", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "FPP application details mapped successfully in credit domain.", response = AppBundleDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.bundle.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> putBundleDetails(@Valid @RequestBody AppBundleDetails appBundleDetails, BindingResult bindingResult,
			@PathVariable(name = "applicationid", required = true) String applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside putBundleDetails method for applicationId :" + applicationId + ", appBundleDetails :" + appBundleDetails);
		Class validationObject = getValidationClass(appBundleDetails);
		Set<ConstraintViolation<AppBundleDetails>> validationErrors = validator.validate(appBundleDetails, validationObject);
		if (!CollectionUtils.isEmpty(validationErrors)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside putBundleDetails method  - resource validation failed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_20", validationErrors.stream().findFirst().get().getMessage()));
		}
		applicationPricingService.putBundleDetails(appBundleDetails, applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "FPP application details mapped successfully in credit domain. Method putBundleDetails - End");
		return new ResponseEntity<>(appBundleDetails, HttpStatus.OK);
	}

	//GET Endpoint to get mapped FPP application details in credit domain : LEN-966
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL})
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch mapped FPP application details in credit domain.", notes = "Fetch mapped FPP application details in credit domain on the basis of applicationKey of credit domain - parentApplicationKey.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched mapped FPP application details in credit domain.", response = AppBundleDetails.class,responseContainer = "List"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "${api.omcreditapplicationservice.bundle.GET.uri}")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> getBundleDetails(
			@PathVariable("applicationid") @Digits(fraction = 0, integer = 20, message = "applicationId can not be other than digits") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Fetching mapped FPP application details started:" + applicationId);
		List<AppBundleDetails> appBundleDetails = applicationPricingService.getBundleDetails(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Fetching mapped FPP application details completed successfully:" + appBundleDetails.toString());
		return new ResponseEntity<>(appBundleDetails, HttpStatus.OK);
	}

	private Class getValidationClass(AppBundleDetails req) {
		if (null != req.getBundleSelected() && req.getBundleSelected()) {
			return BundleSelected.class;
		}
		return BundleNotSelected.class;
	}
	
	@Secured(value = { Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL, Role.PSEUDO_CUSTOMER,
			Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update Loan Details", notes = "Update Loan Details", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application Updated successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.loandetails.PUT.uri}")
	@CrossOrigin
	public ResponseEntity<Object> updateLoanDetails(
			@PathVariable("applicationKey") @NotBlank(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationKey should be numeric & should not exceeds size") String applicationId,
			@RequestBody UpdateApplication updateApplication, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"updateLoanDetails : Start with " + applicationId + " for " + updateApplication.toString());
		applicationPricingService.updateLoanDetails(applicationId, updateApplication);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "updateLoanDetails :Update loan application completed.");
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Save pricing revision details", notes =" Save pricing revision details", httpMethod = "POST")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Pricing detail updated successfully.", response = PricingDetail.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)})
	@PostMapping(value = "${api.omcreditapplicationservice.loan.pricing.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> savePricingRevisionDetail(@Valid @RequestBody PricingDetail pricingDetail, BindingResult bindingResult,
			@PathVariable(name = "applicationKey", required = true) String applicationKey, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside savePricingRevisionDetail method for applicationId :"
				+ applicationKey + ", pricingDetail :" + pricingDetail);
		PricingDetail response = applicationPricingService.savePricingRevisionDetail(pricingDetail, applicationKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"savePricingRevisionDetail method for pricingDetails completed suceessfully");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	//POST Endpoint for mapping FPP application from vas domain to credit domain : BFSDCC-1101
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Save mapping of FPP/FPPLITE application details in credit domain", notes = "mapping FPP application from vas domain to credit domain", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "FPP application details mapped successfully in credit domain.", response = AppBundleDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "${api.omcreditapplicationservice.bundle.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> saveApplicationBundleDetails(@Valid @RequestBody AppBundleDetails appBundleDetails, BindingResult bindingResult,
			@PathVariable(name = "applicationid", required = true) String applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside saveApplicationBundleDetails method for applicationId :" + applicationId + ", appBundleDetails :" + appBundleDetails);
		Class validationObject = getValidationClass(appBundleDetails);
		Set<ConstraintViolation<AppBundleDetails>> validationErrors = validator.validate(appBundleDetails, validationObject);
		if (!CollectionUtils.isEmpty(validationErrors)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveApplicationBundleDetails method  - resource validation failed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_20", validationErrors.stream().findFirst().get().getMessage()));
		}
		appBundleDetails = applicationPricingService.saveApplicationBundleDetails(appBundleDetails, applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "FPP application details mapped successfully in credit domain. Method saveApplicationBundleDetails - End");
		return new ResponseEntity<>(appBundleDetails, HttpStatus.OK);
	}
}