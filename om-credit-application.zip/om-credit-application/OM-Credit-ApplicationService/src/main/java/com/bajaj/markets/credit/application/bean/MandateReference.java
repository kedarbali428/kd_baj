package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

public class MandateReference {
	@NotNull(message = "applicationId can not be null/empty")
	@Digits(fraction = 0, integer = 20, message = "applicationId can not be other than digits")
	private Long applicationId;
	
	private long finalMandatekey;

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public long getFinalMandatekey() {
		return finalMandatekey;
	}

	public void setFinalMandatekey(long finalMandatekey) {
		this.finalMandatekey = finalMandatekey;
	}
	
}


