package com.bajaj.markets.credit.application.bean;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class ProductDetails {

	@NotNull(message = "Invalid Request")
	@Valid
	private OpenArcRejectionOutput openArcRejectionOutput;
	private String rejectionSrc;
	private String rejectionSystem;

	public OpenArcRejectionOutput getOpenArcRejectionOutput() {
		return openArcRejectionOutput;
	}

	public void setOpenArcRejectionOutput(OpenArcRejectionOutput openArcRejectionOutput) {
		this.openArcRejectionOutput = openArcRejectionOutput;
	}

	public String getRejectionSrc() {
		return rejectionSrc;
	}

	public void setRejectionSrc(String rejectionSrc) {
		this.rejectionSrc = rejectionSrc;
	}

	public String getRejectionSystem() {
		return rejectionSystem;
	}

	public void setRejectionSystem(String rejectionSystem) {
		this.rejectionSystem = rejectionSystem;
	}

	@Override
	public String toString() {
		return "ProductDetails [openArcRejectionOutput=" + openArcRejectionOutput + ", rejectionSrc=" + rejectionSrc
				+ ", rejectionSystem=" + rejectionSystem + "]";
	}

}
