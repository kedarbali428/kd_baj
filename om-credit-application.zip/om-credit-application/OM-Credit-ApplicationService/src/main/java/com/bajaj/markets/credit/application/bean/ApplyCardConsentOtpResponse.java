package com.bajaj.markets.credit.application.bean;

public class ApplyCardConsentOtpResponse {

	private Boolean consentRequired;
	private String consentType;
	private Boolean isOTPGenerated;
	private String otpReferenceId;

	public Boolean isConsentRequired() {
		return consentRequired;
	}

	public void setConsentRequired(Boolean consentRequired) {
		this.consentRequired = consentRequired;
	}

	public String getConsentType() {
		return consentType;
	}

	public void setConsentType(String consentType) {
		this.consentType = consentType;
	}

	public Boolean getIsOTPGenerated() {
		return isOTPGenerated;
	}

	public void setIsOTPGenerated(Boolean isOTPGenerated) {
		this.isOTPGenerated = isOTPGenerated;
	}

	public String getOtpReferenceId() {
		return otpReferenceId;
	}

	public void setOtpReferenceId(String otpReferenceId) {
		this.otpReferenceId = otpReferenceId;
	}

	@Override
	public String toString() {
		return "ApplyCardConsentOtpResponse [consentRequired=" + consentRequired + ", consentType=" + consentType
				+ ", isOTPGenerated=" + isOTPGenerated + ", otpReferenceId=" + otpReferenceId + "]";
	}

}
