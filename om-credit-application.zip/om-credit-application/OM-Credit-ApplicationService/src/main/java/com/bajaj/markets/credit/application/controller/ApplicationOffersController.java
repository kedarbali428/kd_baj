package com.bajaj.markets.credit.application.controller;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.AppOfferDetBean;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.DeactivateOffers;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.UpdateOffers;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationOffersService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller for updating product specific offers based on application & principal
 */
@RestController
@Validated
public class ApplicationOffersController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private ApplicationOffersService offersService;
	
	@Autowired
	private Validator validator;
	
	private static final String CLASSNAME = ApplicationOffersController.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update product specific offers at application level", notes = "Update product specific offers at application level", httpMethod = "PUT")
	@ApiResponses(value = {
			 	@ApiResponse(code = 200, message = "Offer updated successfully.", response = AppOfferDetBean.class),
			 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			 	@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
		        @ApiResponse(code = 404, message = "ApplicationId not found",response = ErrorBean.class),
			 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/offers", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> updateOffers(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@Valid @RequestBody AppOfferDetBean appOfferDetBean, BindingResult result, @RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateOffers method controller - applicationId: " + applicationId);
		Class validationObject = getValidationClass(appOfferDetBean.isDeactivateOffers());
		Set<ConstraintViolation<AppOfferDetBean>> validationErrors = validator.validate(appOfferDetBean, validationObject);
		if(!CollectionUtils.isEmpty(validationErrors)){
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateOccupation method controller - resource validation failed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCA_005", validationErrors.stream().findFirst().get().getMessage()));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Input updateOffers, applicationId: "+ applicationId );
		return new ResponseEntity<>(offersService.updateOffers(applicationId, appOfferDetBean), HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.SYSTEM})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch Offers from AppOfferDet", notes = "Fetch Offers from AppOfferDet", httpMethod = "GET")
	@ApiResponses(value = {
			 	@ApiResponse(code = 200, message = "Offer fetched successfully.", response = AppOfferDetBean.class,responseContainer = "List"),
			 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			 	@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
		        @ApiResponse(code = 404, message = "OfferDetails not found for given application",response = ErrorBean.class),
			 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "${api.omcreditapplicationservice.application.offers.GET.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> getOffers(@PathVariable("applicationid")@NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestParam(name = "productCode",required = false)String productCode,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside getOffers method controller -applicationId "+ applicationId
				+ " ProductCode: " + productCode);

		return new ResponseEntity<>(offersService.getOffers(applicationId,productCode), HttpStatus.OK);
	}
	
	private Class getValidationClass(boolean deactivateOffers){
		if (deactivateOffers) {
			return DeactivateOffers.class;
		}else {
			return UpdateOffers.class;
		}
	}
}