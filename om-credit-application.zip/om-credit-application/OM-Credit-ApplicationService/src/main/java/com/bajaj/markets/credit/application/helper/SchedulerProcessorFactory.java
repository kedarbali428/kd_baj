package com.bajaj.markets.credit.application.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.markets.credit.application.processor.ApplicationSchedulerProcessor;
import com.bajaj.markets.credit.application.processor.CardApplicationSchedulerProcessor;
import com.bajaj.markets.credit.application.processor.CommonApplicationSchedulerProcessor;
import com.bajaj.markets.credit.application.processor.LoanApplicationSchedulerProcessor;

@Component
public class SchedulerProcessorFactory {

	@Autowired
	private CardApplicationSchedulerProcessor cardSchedulerProcessor;

	@Autowired
	private LoanApplicationSchedulerProcessor loanSchedulerProcessor;
	
	@Autowired
	private CommonApplicationSchedulerProcessor commonSchedulerProcessor;
	
	public ApplicationSchedulerProcessor getApplicationSchedulerProcessor(String l2ProductCode) {
		switch (l2ProductCode) {
		case ApplicationConstants.CC:
			return cardSchedulerProcessor;
		case ApplicationConstants.OMPL:
			return loanSchedulerProcessor;
		default:
			return commonSchedulerProcessor;
		}
		
	}
	
	
}
