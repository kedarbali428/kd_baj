package com.bajaj.markets.credit.application.bean;

public class SalaryDetail {
	
	private String salarySource;
	
	private int salary;

	public String getSalarySource() {
		return salarySource;
	}

	public void setSalarySource(String salarySource) {
		this.salarySource = salarySource;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "SalaryDetail [salarySource=" + salarySource + ", salary=" + salary + "]";
	}
}
