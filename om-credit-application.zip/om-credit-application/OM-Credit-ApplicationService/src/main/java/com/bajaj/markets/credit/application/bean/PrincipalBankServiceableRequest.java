package com.bajaj.markets.credit.application.bean;

public class PrincipalBankServiceableRequest {

	private String partnerBankId;
	private String partnerBankCode;
	private String partnerBankName;
	private Long principalKey;
	public String getPartnerBankId() {
		return partnerBankId;
	}
	public void setPartnerBankId(String partnerBankId) {
		this.partnerBankId = partnerBankId;
	}
	public String getPartnerBankCode() {
		return partnerBankCode;
	}
	public void setPartnerBankCode(String partnerBankCode) {
		this.partnerBankCode = partnerBankCode;
	}
	public String getPartnerBankName() {
		return partnerBankName;
	}
	public void setPartnerBankName(String partnerBankName) {
		this.partnerBankName = partnerBankName;
	}
	public Long getPrincipalKey() {
		return principalKey;
	}
	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}
	@Override
	public String toString() {
		return "PrincipalBankServiceableRequest [partnerBankId=" + partnerBankId + ", partnerBankCode="
				+ partnerBankCode + ", partnerBankName=" + partnerBankName + ", principalKey=" + principalKey + "]";
	}
	
}
