package com.bajaj.markets.credit.application.finegrain;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.AuthenticatedUser;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.Application;
import com.bajaj.markets.credit.application.repository.tx.ApplicationRepository;

/**
 * @author Abhishek
 * 
 *         Perform finegrain check on requested object.
 *
 */
@Aspect
@Configuration
public class FineGrainAuthCheck {
	@Value("${openmarket.isfinegrain.validation.required}")
	private boolean isFineGrainRequired;
	@Autowired
	private ApplicationRepository applicationRepo;

	@Value("#{'${applicationservice.finegrain.skip.roles}'.split(',')}")
	private List<String> skipFineGrainRoles;

	@Autowired
	BFLLoggerUtilExt logger;
	private static final String CLASSNAME = FineGrainAuthCheck.class.getName();

	/**
	 * Perform fingrain check on application key.
	 * 
	 * @param joinPoint
	 */
	@Before("@annotation(com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck)")
	public void fineGrainCheck(JoinPoint joinPoint) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "fineGrainCheck Started.");
		AuthenticatedUser authenticatedUser = (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();
		if (isFineGrainRequired && !skipFineGrainRoles.contains(authenticatedUser.getRole())) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "check started");
			if (null != authenticatedUser && null != authenticatedUser.getAdditionalInfo()) {
				String requestedApplicationKey = null;
				Object[] inputArgArray = joinPoint.getArgs();
				String methodName = joinPoint.getSignature().getName();
				// Extract the application id received in request param or path variable or
				// directly in method arguments.
				// Compare the method name available in requested controller and extract the
				// application key by comparing the argument of that method.
				Method[] methods = joinPoint.getTarget().getClass().getDeclaredMethods();
				for (Method method : methods) {
					if (StringUtils.equals(methodName, method.getName())) {
						Parameter[] parameters = method.getParameters();
						for (int i = 0; i < parameters.length; i++) {
							if (parameters[i].isNamePresent()) {
								String paramName = parameters[i].getName();
								if (ApplicationConstants.getApplicationKeyFieldName().contains(paramName)) {
									requestedApplicationKey = String.valueOf(inputArgArray[i]);
									// break inner loop once application key is found.
									break;
								}
							}

						}
						// break the outer loop once we find the requested method from all the
						// method available in particular class.
						break;
					}
				}
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
						"Application Key after method arg check : " + requestedApplicationKey);
				// If application key doesn't found directly in method argument then it will
				// look for it in request object of particular class type.
				if (!StringUtils.isNumeric(requestedApplicationKey)) {
					for (Object inputArg : inputArgArray) {
						// check application key in object except String and header as there is no
						// chance of getting application key in these object.
						if (!(inputArg instanceof String || inputArg instanceof HttpHeaders)) {
							try {
								Field declaredField;
								try {
									declaredField = inputArg.getClass().getDeclaredField("applicationKey");
								} catch (Exception e) {
									declaredField = inputArg.getClass().getDeclaredField("applicationId");
								}
								declaredField.setAccessible(true);
								requestedApplicationKey = String.valueOf(declaredField.get(inputArg));
								// break the iteration once application key is found in iterated object.
								if (!StringUtils.isEmpty(requestedApplicationKey))
									break;
							} catch (Exception e) {
								logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
										"No application key found in request : " + e);
							}
						}
					}
				}

				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
						"Application Id in Request : " + requestedApplicationKey);
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
						"Application Id in context : " + authenticatedUser.getAdditionalInfo().getApplicationKey());


				if (!StringUtils.isNumeric(requestedApplicationKey) || requestedApplicationKey.length() > 19) {
					logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
							ApplicationConstants.FINEGRAIN_VALIDATION_FAILED);
					throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
							new ErrorBean(ApplicationConstants.CAS_1023, "Resource Not Found."));
				}

				// Compares the requested applicationKey and application key available in
				// context and if it doesn;t match then access will be rstricted to particular
				// api.
				boolean isfineGrainFailed = false;
				boolean isChildCheckRequired = checkForFineGrain(authenticatedUser, requestedApplicationKey);
				if (isChildCheckRequired) {
					Application application = applicationRepo
							.findByApplicationkeyAndIsactive(Long.valueOf(requestedApplicationKey), 1);
					if (null != application && null != application.getParentapplicationkey()) {
						requestedApplicationKey = String.valueOf(application.getParentapplicationkey());
					}
					isfineGrainFailed = checkForFineGrain(authenticatedUser, requestedApplicationKey);
				}
				if (isfineGrainFailed) {
					// throw exception in case application id don't match.
					throwFineGrainException();
				}
			} else {
				// throw exception when token don't have additional info
				throwFineGrainException();
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "fineGrainCheck End.");
	}

	/**
	 * 
	 */
	private void throwFineGrainException() {
		logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
				ApplicationConstants.FINEGRAIN_VALIDATION_FAILED);
		throw new CreditApplicationServiceException(HttpStatus.FORBIDDEN,
				new ErrorBean(ApplicationConstants.CAS_1023, ApplicationConstants.FORBIDDEN));
	}

	/**
	 * @param authenticatedUser
	 * @param requestedApplicationKey
	 * @return
	 */
	private boolean checkForFineGrain(AuthenticatedUser authenticatedUser, String requestedApplicationKey) {
		boolean isChildCheckRequired = false;
		if (null == authenticatedUser.getAdditionalInfo().getApplicationKey() || !authenticatedUser.getAdditionalInfo()
				.getApplicationKey().equals(Long.valueOf(requestedApplicationKey))) {
			isChildCheckRequired = true;
		}
		return isChildCheckRequired;
	}

}