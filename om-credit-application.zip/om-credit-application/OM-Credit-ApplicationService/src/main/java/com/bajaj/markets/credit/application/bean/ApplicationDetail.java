package com.bajaj.markets.credit.application.bean;

public class ApplicationDetail {

	private String applicationKey;

	private String parentApplicationKey;

	private String mobile;

	private String dateofbirth;

	private String applicantKey;

	private Long l2ProductKey;

	private String l2ProductCode;

	private Long l3ProductKey;

	private String l3ProductCode;

	private Long l4ProductKey;

	private String l4ProductCode;

	private Long principalKey;

	private boolean isInProcessing;

	private Integer applicationStatus;

	private String riskoffertype;

	private LoanPurposeBean loanPurpose;

	private Reference occupationType;

	private String l2ProductDesc;

	private String l3ProductDesc;

	private String l4ProductDesc;

	private String hlProductIntent;
		
	private Long cityKey;
	
	private Integer bflBranchKey;
	
	private Long pincodekey;
	
	private String productRefNo;
	
	private String appDate;

	public String getAppDate() {
		return appDate;
	}

	public void setAppDate(String appDate) {
		this.appDate = appDate;
	}
	private String appProcessIdentifier;


	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getParentApplicationKey() {
		return parentApplicationKey;
	}

	public void setParentApplicationKey(String parentApplicationKey) {
		this.parentApplicationKey = parentApplicationKey;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getL2ProductKey() {
		return l2ProductKey;
	}

	public void setL2ProductKey(Long l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}

	public Long getL3ProductKey() {
		return l3ProductKey;
	}

	public void setL3ProductKey(Long l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}

	public String getL2ProductCode() {
		return l2ProductCode;
	}

	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public Long getL4ProductKey() {
		return l4ProductKey;
	}

	public void setL4ProductKey(Long l4ProductKey) {
		this.l4ProductKey = l4ProductKey;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public boolean isInProcessing() {
		return isInProcessing;
	}

	public void setInProcessing(boolean isInProcessing) {
		this.isInProcessing = isInProcessing;
	}

	public Integer getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(Integer applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	public LoanPurposeBean getLoanPurpose() {
		return loanPurpose;
	}

	public void setLoanPurpose(LoanPurposeBean loanPurpose) {
		this.loanPurpose = loanPurpose;
	}

	public Reference getOccupationType() {
		return occupationType;
	}

	public void setOccupationType(Reference occupationType) {
		this.occupationType = occupationType;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public String getL2ProductDesc() {
		return l2ProductDesc;
	}

	public void setL2ProductDesc(String l2ProductDesc) {
		this.l2ProductDesc = l2ProductDesc;
	}

	public String getL3ProductDesc() {
		return l3ProductDesc;
	}

	public void setL3ProductDesc(String l3ProductDesc) {
		this.l3ProductDesc = l3ProductDesc;
	}

	public String getL4ProductDesc() {
		return l4ProductDesc;
	}

	public void setL4ProductDesc(String l4ProductDesc) {
		this.l4ProductDesc = l4ProductDesc;
	}

	public Long getCityKey() {
		return cityKey;
	}

	public void setCityKey(Long cityKey) {
		this.cityKey = cityKey;
	}
	
	public Integer getBflBranchKey() {
		return bflBranchKey;
	}

	public void setBflBranchKey(Integer bflBranchKey) {
		this.bflBranchKey = bflBranchKey;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public String getProductRefNo() {
		return productRefNo;
	}

	public void setProductRefNo(String productRefNo) {
		this.productRefNo = productRefNo;
	}

	public String getAppProcessIdentifier() {
		return appProcessIdentifier;
	}

	public void setAppProcessIdentifier(String appProcessIdentifier) {
		this.appProcessIdentifier = appProcessIdentifier;
	}

	@Override
	public String toString() {
		return "ApplicationDetail [applicationKey=" + applicationKey + ", parentApplicationKey=" + parentApplicationKey
				+ ", mobile=" + mobile + ", dateofbirth=" + dateofbirth + ", applicantKey=" + applicantKey
				+ ", l2ProductKey=" + l2ProductKey + ", l2ProductCode=" + l2ProductCode + ", l3ProductKey="
				+ l3ProductKey + ", l3ProductCode=" + l3ProductCode + ", l4ProductKey=" + l4ProductKey
				+ ", l4ProductCode=" + l4ProductCode + ", principalKey=" + principalKey + ", isInProcessing="
				+ isInProcessing + ", applicationStatus=" + applicationStatus + ", riskoffertype=" + riskoffertype
				+ ", loanPurpose=" + loanPurpose + ", occupationType=" + occupationType + ", l2ProductDesc="
				+ l2ProductDesc + ", l3ProductDesc=" + l3ProductDesc + ", l4ProductDesc=" + l4ProductDesc
				+ ", hlProductIntent=" + hlProductIntent + ", cityKey=" + cityKey + ", bflBranchKey=" + bflBranchKey
				+ ", pincodekey=" + pincodekey + ", productRefNo=" + productRefNo + ", appDate=" + appDate
				+ ", appProcessIdentifier=" + appProcessIdentifier + "]";
	}

}