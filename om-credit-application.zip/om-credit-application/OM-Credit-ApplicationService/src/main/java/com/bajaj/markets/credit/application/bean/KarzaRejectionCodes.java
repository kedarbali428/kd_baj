package com.bajaj.markets.credit.application.bean;

public class KarzaRejectionCodes {

	private String rejectCode;
	private Long coolingPeriod;

	public Long getCoolingPeriod() {
		return coolingPeriod;
	}

	public void setCoolingPeriod(Long coolingPeriod) {
		this.coolingPeriod = coolingPeriod;
	}

	public String getRejectCode() {
		return rejectCode;
	}

	public void setRejectCode(String rejectCode) {
		this.rejectCode = rejectCode;
	}

	@Override
	public String toString() {
		return "[rejectCode:" + rejectCode + ", coolingPeriod:" + coolingPeriod + "]";
	}

}
