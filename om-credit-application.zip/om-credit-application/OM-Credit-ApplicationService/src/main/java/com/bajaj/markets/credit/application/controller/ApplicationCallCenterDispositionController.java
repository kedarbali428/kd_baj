package com.bajaj.markets.credit.application.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.ApplicationDispositionDetails;
import com.bajaj.markets.credit.application.bean.ApplicationDispositionResponse;
import com.bajaj.markets.credit.application.bean.DispositionDetails;
import com.bajaj.markets.credit.application.bean.DocumentDetails;
import com.bajaj.markets.credit.application.bean.MasterDataBean;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationCallCenterDispositionService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationCallCenterDispositionController 
{

	@Autowired
	private ApplicationCallCenterDispositionService applicationCallCenterDispositonService;
	
	@Autowired
	CustomDefaultHeaders customDefaultHeaders;
	
	@Autowired
	BFLLoggerUtilExt logger;
	private static final String CLASSNAME = ApplicationAddressController.class.getName();
	
	@Secured(value = {Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER})
	@ApiOperation(value = "Application address endpoint", notes = "This resource will be used to update address on application", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Address updated successfully.", response = DocumentDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)})
	@PutMapping(value = "/v1/creditapplication/credit/applications/{applicationid}/sections/{sectionId}/subsections/{subsectionId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveDispositionDetails(@Valid @RequestBody DispositionDetails dispositionDetails, 
			@PathVariable(name = "applicationid", required = true) String applicationId,			
			@PathVariable(name = "subsectionId", required = true) String subsectionId, 
			@PathVariable(name = "sectionId", required = true) String sectionId, 
			
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside saveCallCenterDispositon method for applicationId :"+applicationId+",  subsectionId"+subsectionId
				+", callCenterDisposition :" +dispositionDetails);
		dispositionDetails.setDispositionAddedBy(String.valueOf(customDefaultHeaders.getUserKey()));
		DispositionDetails response = applicationCallCenterDispositonService.
				saveDispositionDetails(dispositionDetails, applicationId, subsectionId);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Completed update method for dispositionDetails ");
			return new ResponseEntity<>(response, HttpStatus.CREATED);
	}
	
	@Secured(value = {Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER})
	@ApiOperation(value = "Get Disposition", notes = "Get Disposition", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching Dispositon Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v2/creditapplication/subdisposition/{dispositionkey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getSubDisposition(@PathVariable("dispositionkey") String dispositionkey){
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "START: getSubDisposition ");
		
		List<MasterDataBean> subDispositionDetails = applicationCallCenterDispositonService.getSubDisposition(dispositionkey);
		
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getSubDisposition:" +subDispositionDetails );
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "END: getSubDisposition method ");
		
		return new ResponseEntity<>(subDispositionDetails, HttpStatus.OK);
		
	}
	
	@Secured(value = {Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER, Role.B2BPARTNER})
	@ApiOperation(value = "update Disposition", notes = "update Disposition", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching Dispositon Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplications/dialer/disposition", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateDispositionDetails(@RequestBody ApplicationDispositionDetails applicationDispositionDetails, @RequestHeader HttpHeaders headers){
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "START: updateDispositionDetails ");
		
		ApplicationDispositionResponse appDispositionResponse = applicationCallCenterDispositonService.updateDispositionDetails(applicationDispositionDetails, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "updateDispositionDetails:" +applicationDispositionDetails );
		
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "END: updateDispositionDetails method ");
		
		return new ResponseEntity<>(appDispositionResponse, HttpStatus.OK);
		
	}
	
}
