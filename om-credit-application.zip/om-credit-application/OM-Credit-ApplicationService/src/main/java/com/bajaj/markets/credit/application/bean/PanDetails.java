package com.bajaj.markets.credit.application.bean;

public class PanDetails {
	private String nameMatch;
	private Integer matchScore;
	private String panType;

	public Integer getMatchScore() {
		return matchScore;
	}

	public void setMatchScore(Integer matchScore) {
		this.matchScore = matchScore;
	}

	public String getPanType() {
		return panType;
	}

	public void setPanType(String panType) {
		this.panType = panType;
	}

	public String getNameMatch() {
		return nameMatch;
	}

	public void setNameMatch(String nameMatch) {
		this.nameMatch = nameMatch;
	}

	@Override
	public String toString() {
		return "PanDetails [nameMatch=" + nameMatch + ", matchScore=" + matchScore + ", panType=" + panType + "]";
	}

}
