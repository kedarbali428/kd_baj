package com.bajaj.markets.credit.application.bean;

public class LoanPurposeApplication {

	private Long applicationKey;
	private Long applicantKey;
	private Long parrentApplicationKey;
	private String mobile;
	private String dateofbirth;
	private Long l3ProductKey;
	private Long l2ProductKey;
	private LoanPurposeBean purposeofLoan;
	
	public LoanPurposeApplication(Long applicationKey) {
		super();
		this.applicationKey = applicationKey;
	}
	
	public LoanPurposeApplication() {
		//constructor
	}

	public Long getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}
	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}
	public Long getParrentApplicationKey() {
		return parrentApplicationKey;
	}
	public void setParrentApplicationKey(Long parrentApplicationKey) {
		this.parrentApplicationKey = parrentApplicationKey;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public Long getL3ProductKey() {
		return l3ProductKey;
	}
	public void setL3ProductKey(Long l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}
	public Long getL2ProductKey() {
		return l2ProductKey;
	}
	public void setL2ProductKey(Long l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}
	public LoanPurposeBean getPurposeofLoan() {
		return purposeofLoan;
	}
	public void setPurposeofLoan(LoanPurposeBean purposeofLoan) {
		this.purposeofLoan = purposeofLoan;
	}
	@Override
	public String toString() {
		return "LoanPurposeApplication [applicationKey=" + applicationKey + ", applicantKey=" + applicantKey
				+ ", parrentApplicationKey=" + parrentApplicationKey + ", mobile=" + mobile + ", dateofbirth="
				+ dateofbirth + ", l3ProductKey=" + l3ProductKey + ", l2ProductKey=" + l2ProductKey + ", purposeofLoan="
				+ purposeofLoan + "]";
	}

	
}