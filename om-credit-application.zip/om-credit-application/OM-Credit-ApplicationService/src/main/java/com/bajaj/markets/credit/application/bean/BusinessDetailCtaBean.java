package com.bajaj.markets.credit.application.bean;

public class BusinessDetailCtaBean {

	private String gstNumber;
	private Reference subindumastkey;

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public Reference getSubindumastkey() {
		return subindumastkey;
	}

	public void setSubindumastkey(Reference subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

}
