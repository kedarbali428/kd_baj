package com.bajaj.markets.credit.application.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.AppDocumentTrackingBean;
import com.bajaj.markets.credit.application.bean.CreditDocumentTypeBean;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationDocumentPushService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationDocumentPushController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CustomDefaultHeaders customDefaultHeaders;

	@Autowired
	ApplicationDocumentPushService applicationDocumentPushService;

	private static final String CLASSNAME = ApplicationDocumentPushController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.SYSTEM })
	@ApiOperation(value = "Fetch document details from transaction", notes = "Fetch document details from transaction", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = AppDocumentTrackingBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Not Found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/document/push/status", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getDocument(
			@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In getDocument method for applicationId :" + applicationId);
		// String userKey = String.valueOf(customDefaultHeaders.getUserKey());
		List<AppDocumentTrackingBean> applicationDocumentPushResponseBean = applicationDocumentPushService
				.getDocument(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out getDocument method");
		return new ResponseEntity<>(applicationDocumentPushResponseBean, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.SYSTEM })
	@ApiOperation(value = "Fetch Document details from master", notes = "Fetch Document details from master", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = CreditDocumentTypeBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Not Found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/{principalkey}/document/details", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getDocumentFromMaster(@PathVariable("principalkey") Long principalKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In getDocument method for principal :" + principalKey);
		List<CreditDocumentTypeBean> creditDocumentTypeBeanList = applicationDocumentPushService
				.getDocumentFromMaster(principalKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out getDocument method");
		return new ResponseEntity<>(creditDocumentTypeBeanList, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiOperation(value = "Update document in transaction", notes = "Update document in transaction", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Documents updated successfully.", response = AppDocumentTrackingBean[].class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/document/push/status", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveDocumentDetails(
			@Valid @RequestBody List<AppDocumentTrackingBean> appDocumentTrackingBeanList, BindingResult result,
			@PathVariable(name = "applicationid") @NotNull(message = "applicationId can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestParam(name = "updatestatusflag") Boolean updateStatusFlag, @RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside ApplicationDocumentPushController :: saveDocumentDetails method controller -resource :"
						+ appDocumentTrackingBeanList);
		String userKey = String.valueOf(customDefaultHeaders.getUserKey());

		if (result.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Inside saveDocumentDetails method - invalid parameters passed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_011", result.getFieldErrors().get(0).getDefaultMessage()));
		} else {
			List<AppDocumentTrackingBean> response = applicationDocumentPushService
					.saveDocumentDetails(appDocumentTrackingBeanList, applicationId, updateStatusFlag, userKey);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Completed ApplicationDocumentPushController :: saveDocumentDetails method");
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
	}
}
