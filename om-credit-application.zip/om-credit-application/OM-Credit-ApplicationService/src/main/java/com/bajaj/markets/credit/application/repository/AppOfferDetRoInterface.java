package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.AppOfferDet;

public interface AppOfferDetRoInterface extends ReadInterface<AppOfferDet, Long> {

	List<AppOfferDet> findByApplicationkeyAndIsactive(Long applicationkey, Integer isActive);

	public AppOfferDet findByApplicationkeyAndProdkeyAndIsactive(Long applicationkey, Long prodkey, Integer isactive);

	List<AppOfferDet> findByApplicationkeyAndRiskoffertypeAndIsactive(Long applicationkey, String riskoffertype,
			Integer isActive);

	public AppOfferDet findByApplicationkeyAndProdkeyAndRiskoffertypeAndIsactive(Long applicationkey, Long prodkey,
			String riskoffertype, Integer isactive);

	public List<AppOfferDet> findByApplicationkeyAndOffersrckeyAndIsactive(Long applicationkey, Long offersrckey,
			Integer isactive);
}
