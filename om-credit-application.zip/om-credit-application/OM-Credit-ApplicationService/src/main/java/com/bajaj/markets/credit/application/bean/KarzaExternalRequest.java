package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class KarzaExternalRequest implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private KarzaVerificationInput karzaVerificationInput;
	private AppUtmParam additionalParameterDetail;

	public void setKarzaVerificationInput(KarzaVerificationInput karzaVerificationInput) {
		this.karzaVerificationInput = karzaVerificationInput;
	}

	public void setAdditionalParameterDetail(AppUtmParam additionalParameterDetail) {
		this.additionalParameterDetail = additionalParameterDetail;
	}

	@Override
	public String toString() {
		return "KarzaExternalRequest [karzaVerificationInput=" + karzaVerificationInput + ", additionalParameterDetail="
				+ additionalParameterDetail + "]";
	}

}
