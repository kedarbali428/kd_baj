package com.bajaj.markets.credit.application.bean;

public class UwSegBreResponse {
	
	private UwSegOutput uwSegOutput;
	
	private String action;

	public UwSegOutput getUwSegOutput() {
		return uwSegOutput;
	}

	public void setUwSegOutput(UwSegOutput uwSegOutput) {
		this.uwSegOutput = uwSegOutput;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "UwSegBreResponse [uwSegOutput=" + uwSegOutput + ", action=" + action + "]";
	}
	
	

}
