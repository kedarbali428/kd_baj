package com.bajaj.markets.credit.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.SchedulerProduct;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationSchedulerService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationSchedulerController {
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private ApplicationSchedulerService applicationSchedulerService;
	
	private static final String CLASSNAME = ApplicationSchedulerController.class.getName();
	
	@Secured(value = {Role.B2BPARTNER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "status check scheduler for applications", notes = "status check scheduler for applications", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Status api scheduler successful"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.status.scheduler.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> statusApiScheduler(@RequestBody SchedulerProduct request, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Input controller: statusApiScheduler: "+request);
		applicationSchedulerService.statusApiScheduler(request, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Exit controller: statusApiScheduler.");
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
	
}
