package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "app_deviation_detail", schema = "dmcredit")
public class AppDeviationDetail implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Long appdeviationkey;

	private Long applicationkey;

	private Integer devaitioncodekey;

	private Long createdby;

	private Timestamp createdtm;

	private String deviationauthority;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long prodkey;

	public AppDeviationDetail() {
	}

	public Long getAppdeviationkey() {
		return appdeviationkey;
	}

	public void setAppdeviationkey(Long appdeviationkey) {
		this.appdeviationkey = appdeviationkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getDevaitioncodekey() {
		return devaitioncodekey;
	}

	public void setDevaitioncodekey(Integer devaitioncodekey) {
		this.devaitioncodekey = devaitioncodekey;
	}

	public Long getCreatedby() {
		return createdby;
	}

	public void setCreatedby(Long createdby) {
		this.createdby = createdby;
	}

	public Timestamp getCreatedtm() {
		return createdtm;
	}

	public void setCreatedtm(Timestamp createdtm) {
		this.createdtm = createdtm;
	}

	public String getDeviationauthority() {
		return deviationauthority;
	}

	public void setDeviationauthority(String deviationauthority) {
		this.deviationauthority = deviationauthority;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

}
