
package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_pricing_consent", schema = "dmcredit")
public class AppPricingConsent implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_pricing_consent_generator", sequenceName = "dmcredit.seq_pk_app_pricing_consent", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_pricing_consent_generator")
	private Long appconsentkey;

	private Long apploanpricingkey;
	private String consentmechanism;
	private Integer consentcapturedflg;
	private Integer consentsentflg;
	private String personalemail;
	private String officialemail;
	private Long mobile;
	private String consentpasscode;
	private String consentstatus;
	private Integer employeecatureflg;
	private String consentsource;
	private Long employeeuserkey;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Timestamp consentsentdt;
	private Timestamp consentaccepteddt;

	public Long getAppconsentkey() {
		return appconsentkey;
	}

	public void setAppconsentkey(Long appconsentkey) {
		this.appconsentkey = appconsentkey;
	}

	public Long getApploanpricingkey() {
		return apploanpricingkey;
	}

	public void setApploanpricingkey(Long apploanpricingkey) {
		this.apploanpricingkey = apploanpricingkey;
	}

	public String getConsentmechanism() {
		return consentmechanism;
	}

	public void setConsentmechanism(String consentmechanism) {
		this.consentmechanism = consentmechanism;
	}

	public Integer getConsentcapturedflg() {
		return consentcapturedflg;
	}

	public void setConsentcapturedflg(Integer consentcapturedflg) {
		this.consentcapturedflg = consentcapturedflg;
	}

	public Integer getConsentsentflg() {
		return consentsentflg;
	}

	public void setConsentsentflg(Integer consentsentflg) {
		this.consentsentflg = consentsentflg;
	}

	public String getPersonalemail() {
		return personalemail;
	}

	public void setPersonalemail(String personalemail) {
		this.personalemail = personalemail;
	}

	public String getOfficialemail() {
		return officialemail;
	}

	public void setOfficialemail(String officialemail) {
		this.officialemail = officialemail;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getConsentpasscode() {
		return consentpasscode;
	}

	public void setConsentpasscode(String consentpasscode) {
		this.consentpasscode = consentpasscode;
	}

	public String getConsentstatus() {
		return consentstatus;
	}

	public void setConsentstatus(String consentstatus) {
		this.consentstatus = consentstatus;
	}

	public Integer getEmployeecatureflg() {
		return employeecatureflg;
	}

	public void setEmployeecatureflg(Integer employeecatureflg) {
		this.employeecatureflg = employeecatureflg;
	}

	public String getConsentsource() {
		return consentsource;
	}

	public void setConsentsource(String consentsource) {
		this.consentsource = consentsource;
	}

	public Long getEmployeeuserkey() {
		return employeeuserkey;
	}

	public void setEmployeeuserkey(Long employeeuserkey) {
		this.employeeuserkey = employeeuserkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	@Override
	public String toString() {
		return "AppPricingConsent [appconsentkey=" + appconsentkey + ", apploanpricingkey=" + apploanpricingkey
				+ ", consentmechanism=" + consentmechanism + ", consentcapturedflg=" + consentcapturedflg
				+ ", consentsentflg=" + consentsentflg + ", personalemail=" + personalemail + ", officialemail="
				+ officialemail + ", mobile=" + mobile + ", consentpasscode=" + consentpasscode + ", consentstatus="
				+ consentstatus + ", employeecatureflg=" + employeecatureflg + ", consentsource=" + consentsource
				+ ", employeeuserkey=" + employeeuserkey + ", isactive=" + isactive + ", lstupdateby=" + lstupdateby
				+ ", lstupdatedt=" + lstupdatedt + ", consentsentdt=" + consentsentdt + ", consentaccepteddt="
				+ consentaccepteddt + "]";
	}

	public Timestamp getConsentsentdt() {
		return consentsentdt;
	}

	public void setConsentsentdt(Timestamp consentsentdt) {
		this.consentsentdt = consentsentdt;
	}

	public Timestamp getConsentaccepteddt() {
		return consentaccepteddt;
	}

	public void setConsentaccepteddt(Timestamp consentaccepteddt) {
		this.consentaccepteddt = consentaccepteddt;
	}

}