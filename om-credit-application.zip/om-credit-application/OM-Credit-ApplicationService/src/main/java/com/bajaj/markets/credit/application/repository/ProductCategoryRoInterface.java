package com.bajaj.markets.credit.application.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bajaj.markets.credit.application.model.ProductCategory;

public interface ProductCategoryRoInterface extends ReadInterface<ProductCategory, Long> {

	ProductCategory findByProdcatkey(Long prodcatkey);

	public ProductCategory findByProdcatkeyAndIsactive(Long prodcatkey, Integer isActive);

	@Query("select p.prodcatkey from ProductCategory p where p.prodcatcode=:prodCatCode")
	Long findProdcatkeyByProdcatcode(@Param("prodCatCode") String prodCatCode);

	@Query("select p.prodcatcode from ProductCategory p where p.prodcatkey=:prodcatkey AND p.isactive=1")
	public String findProdcatcodeByProdcatkeyAndIsactive(Long prodcatkey);

}
