package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.AppLoanPricingFees;

public interface AppLoanPricingFeesRoInterface extends ReadInterface<AppLoanPricingFees, Long> {

	List<AppLoanPricingFees> findByApploanpricingkeyAndIsactive(Long apploanpricingkey, Integer isActive);

}
