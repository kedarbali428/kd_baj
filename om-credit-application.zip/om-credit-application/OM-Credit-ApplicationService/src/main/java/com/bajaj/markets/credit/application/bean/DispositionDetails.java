package com.bajaj.markets.credit.application.bean;

import java.sql.Timestamp;

/**
 * Application Disposition Details resource 
 * @author Mahesh Nandure
 * 
 */
public class DispositionDetails {
	
	private String dispositionStatus;
	private String dispositionSubStatus;
	private String followUpDate;
	private String followUpTime;
	private String dispositionTimestamp;
	private String dispositionAddedBy;
	/**
	 * @return the dispositionStatus
	 */
	public String getDispositionStatus() {
		return dispositionStatus;
	}
	/**
	 * @param dispositionStatus the dispositionStatus to set
	 */
	public void setDispositionStatus(String dispositionStatus) {
		this.dispositionStatus = dispositionStatus;
	}
	/**
	 * @return the dispositionSubStatus
	 */
	public String getDispositionSubStatus() {
		return dispositionSubStatus;
	}
	/**
	 * @param dispositionSubStatus the dispositionSubStatus to set
	 */
	public void setDispositionSubStatus(String dispositionSubStatus) {
		this.dispositionSubStatus = dispositionSubStatus;
	}
	
	/**
	 * @return the dispositionTimestamp
	 */
	public String getDispositionTimestamp() {
		return dispositionTimestamp;
	}
	/**
	 * @param dispositionTimestamp the dispositionTimestamp to set
	 */
	public void setDispositionTimestamp(String dispositionTimestamp) {
		this.dispositionTimestamp = dispositionTimestamp;
	}
	/**
	 * @return the dispositionAddedBy
	 */
	public String getDispositionAddedBy() {
		return dispositionAddedBy;
	}
	/**
	 * @param dispositionAddedBy the dispositionAddedBy to set
	 */
	public void setDispositionAddedBy(String dispositionAddedBy) {
		this.dispositionAddedBy = dispositionAddedBy;
	}
	@Override
	public String toString() {
		return "DispositionDetails [dispositionStatus=" + dispositionStatus + ", dispositionSubStatus="
				+ dispositionSubStatus + ", parentFollowUpDate=" + followUpDate + ", parentFollowUpTime="
				+ followUpTime + ", dispositionTimestamp=" + dispositionTimestamp + ", dispositionAddedBy="
				+ dispositionAddedBy + "]";
	}
	/**
	 * @return the followUpDate
	 */
	public String getFollowUpDate() {
		return followUpDate;
	}
	/**
	 * @param followUpDate the followUpDate to set
	 */
	public void setFollowUpDate(String followUpDate) {
		this.followUpDate = followUpDate;
	}
	/**
	 * @return the followUpTime
	 */
	public String getFollowUpTime() {
		return followUpTime;
	}
	/**
	 * @param followUpTime the followUpTime to set
	 */
	public void setFollowUpTime(String followUpTime) {
		this.followUpTime = followUpTime;
	}
	
}
