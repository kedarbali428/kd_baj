package com.bajaj.markets.credit.application.processor;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;

@Component
public class VasApplicationIssueProcessor {
	@Value("${api.omvasapplicationservice.disbursementeventraise.PUT.url}") 
	private String vasDisbursementEventraiseUrl;
	
	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;

	@Autowired
	private Environment env;
	
	@Autowired
	private BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = VasApplicationIssueProcessor.class.getCanonicalName();

	public String callDisbursementRaiseEventOfVasDomain(String bundleApplicationKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start callDisbursementRaiseEventOfVasDomain for application: "+bundleApplicationKey);
		String vasDisbursementEventRaiseResp = null;
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		try {
			params.put(ApplicationConstants.APPLICATIONKEY, bundleApplicationKey);
			ResponseEntity<Object> vasDisbursementEventRaiseRespObj = creditApplicationServiceUtility
					.excuteRestCall(vasDisbursementEventraiseUrl, HttpMethod.PUT, String.class, params, null, headers);
			if (vasDisbursementEventRaiseRespObj.getStatusCode().equals(HttpStatus.OK)) {
				vasDisbursementEventRaiseResp = vasDisbursementEventRaiseRespObj.getBody().toString();
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in call DisbursementRaiseEvent Of VasDomain for the given application: "+bundleApplicationKey);
				throw new CreditApplicationServiceException(vasDisbursementEventRaiseRespObj.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1044,
								env.getProperty(ApplicationConstants.CAS_1044)));
			}
		} catch (CreditApplicationServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Technical Exception occurred for application: "+bundleApplicationKey ,e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End getApplicationCost for application: " +bundleApplicationKey);
		return vasDisbursementEventRaiseResp;
	}
}