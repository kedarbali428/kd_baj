package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class AddressAuditDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String cityName;
	private String stateName;
	private String localitykey;
	private String localityCd;
	private String documentName;
    private String documentValue;
    private String documentCategory;
    
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getLocalitykey() {
		return localitykey;
	}
	public void setLocalitykey(String localitykey) {
		this.localitykey = localitykey;
	}
	public String getLocalityCd() {
		return localityCd;
	}
	public void setLocalityCd(String localityCd) {
		this.localityCd = localityCd;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentValue() {
		return documentValue;
	}
	public void setDocumentValue(String documentValue) {
		this.documentValue = documentValue;
	}
	public String getDocumentCategory() {
		return documentCategory;
	}
	public void setDocumentCategory(String documentCategory) {
		this.documentCategory = documentCategory;
	}
	
}
