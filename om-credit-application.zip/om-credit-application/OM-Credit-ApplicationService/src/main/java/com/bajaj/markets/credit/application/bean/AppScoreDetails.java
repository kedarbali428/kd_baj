package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class AppScoreDetails {
	
	private BigDecimal finalScore;
	private BigDecimal lrScore;
	private BigDecimal miScore;
	private BigDecimal lrScorev2;
	

	public BigDecimal getLrScorev2() {
		return lrScorev2;
	}
	public void setLrScorev2(BigDecimal lrScorev2) {
		this.lrScorev2 = lrScorev2;
	}
	

	public BigDecimal getFinalScore() {
		return finalScore;
	}
	public void setFinalScore(BigDecimal finalScore) {
		this.finalScore = finalScore;
	}
	public BigDecimal getLrScore() {
		return lrScore;
	}
	public void setLrScore(BigDecimal lrScore) {
		this.lrScore = lrScore;
	}
	public BigDecimal getMiScore() {
		return miScore;
	}
	public void setMiScore(BigDecimal miScore) {
		this.miScore = miScore;
	}
	
	
	
	

}
