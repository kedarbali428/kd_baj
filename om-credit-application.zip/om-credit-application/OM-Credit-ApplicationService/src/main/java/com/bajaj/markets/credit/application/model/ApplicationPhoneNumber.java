package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "application_phone_number", schema = "dmcredit")
public class ApplicationPhoneNumber {

	@Id
	@SequenceGenerator(name = "application_phone_number_appphnumkey_generator", sequenceName = "dmcredit.seq_pk_application_phone_number", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_phone_number_appphnumkey_generator")
	private Long appphnumkey;

	private Long appattrbkey;

	private Long phonetypekey;

	private Long lstupdateby;

	private String countrycode;

	private String areacode;

	private String phonenumber;

	private Integer isactive;

	private Integer ispreferred;

	private Integer isdndactive;

	private Integer isverified;

	private Timestamp verifydt;

	private Timestamp startdt;

	private Timestamp enddt;

	private Timestamp lstupdatedt;

	public Long getAppphnumkey() {
		return appphnumkey;
	}

	public void setAppphnumkey(Long appphnumkey) {
		this.appphnumkey = appphnumkey;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Long getPhonetypekey() {
		return phonetypekey;
	}

	public void setPhonetypekey(Long phonetypekey) {
		this.phonetypekey = phonetypekey;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public String getCountrycode() {
		return countrycode;
	}

	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	public String getAreacode() {
		return areacode;
	}

	public void setAreacode(String areacode) {
		this.areacode = areacode;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Integer getIspreferred() {
		return ispreferred;
	}

	public void setIspreferred(Integer ispreferred) {
		this.ispreferred = ispreferred;
	}

	public Integer getIsdndactive() {
		return isdndactive;
	}

	public void setIsdndactive(Integer isdndactive) {
		this.isdndactive = isdndactive;
	}

	public Integer getIsverified() {
		return isverified;
	}

	public void setIsverified(Integer isverified) {
		this.isverified = isverified;
	}

	public Timestamp getVerifydt() {
		return verifydt;
	}

	public void setVerifydt(Timestamp verifydt) {
		this.verifydt = verifydt;
	}

	public Timestamp getStartdt() {
		return startdt;
	}

	public void setStartdt(Timestamp startdt) {
		this.startdt = startdt;
	}

	public Timestamp getEnddt() {
		return enddt;
	}

	public void setEnddt(Timestamp enddt) {
		this.enddt = enddt;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	
	@Override
	public ApplicationPhoneNumber clone() throws CloneNotSupportedException {
		ApplicationPhoneNumber phone = new ApplicationPhoneNumber();
		phone.setAppattrbkey(this.appattrbkey);
		phone.setAreacode(this.areacode);
		phone.setCountrycode(this.countrycode);
		phone.setEnddt(this.enddt);
		phone.setIsactive(this.isactive);
		phone.setIsverified(this.isverified);
		phone.setLstupdateby(this.getLstupdateby());
		phone.setLstupdatedt(this.lstupdatedt);
		phone.setPhonenumber(this.phonenumber);
		phone.setPhonetypekey(this.phonetypekey);
		phone.setStartdt(this.startdt);
		return phone;
	}

}
