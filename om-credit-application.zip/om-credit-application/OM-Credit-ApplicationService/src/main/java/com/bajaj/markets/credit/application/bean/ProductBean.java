package com.bajaj.markets.credit.application.bean;

public class ProductBean {

	private Long prodkey;

	private String prodcode;

	private String proddesc;

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getProdcode() {
		return prodcode;
	}

	public void setProdcode(String prodcode) {
		this.prodcode = prodcode;
	}

	public String getProddesc() {
		return proddesc;
	}

	public void setProddesc(String proddesc) {
		this.proddesc = proddesc;
	}

}
