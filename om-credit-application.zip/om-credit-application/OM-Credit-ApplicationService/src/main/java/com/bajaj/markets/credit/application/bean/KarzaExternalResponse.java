package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class KarzaExternalResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private KarzaVerificationOutput karzaVerificationOutput;
	private String Action;

	public KarzaVerificationOutput getKarzaVerificationOutput() {
		return karzaVerificationOutput;
	}

	public void setKarzaVerificationOutput(KarzaVerificationOutput karzaVerificationOutput) {
		this.karzaVerificationOutput = karzaVerificationOutput;
	}

	public String getAction() {
		return Action;
	}

	public void setAction(String action) {
		Action = action;
	}

	@Override
	public String toString() {
		return "[karzaVerificationOutput:" + karzaVerificationOutput + ", Action:" + Action + "]";
	}

}
