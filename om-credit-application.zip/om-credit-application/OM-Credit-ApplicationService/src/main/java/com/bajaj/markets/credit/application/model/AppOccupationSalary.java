package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the app_occupation_salary database table.
 *
 */
@Entity
@Table(name = "app_occupation_salary", schema = "dmcredit")
public class AppOccupationSalary implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="app_occupation_salary_appoccupationsalarykey_generator", sequenceName="dmcredit.seq_pk_app_occupation_salary", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_occupation_salary_appoccupationsalarykey_generator")
	private Long appoccupationsalarykey;
	
	private Long appoccupationkey;
	
	private BigDecimal salary;
	
	private String salarysource;
	
	private Integer isactive;
	
	private Long lstupdateby;
	
	private Timestamp lstupdatedt;

	public Long getAppoccupationsalarykey() {
		return appoccupationsalarykey;
	}

	public void setAppoccupationsalarykey(Long appoccupationsalarykey) {
		this.appoccupationsalarykey = appoccupationsalarykey;
	}

	public Long getAppoccupationkey() {
		return appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public String getSalarysource() {
		return salarysource;
	}

	public void setSalarysource(String salarysource) {
		this.salarysource = salarysource;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	
	@Override
	public AppOccupationSalary clone() throws CloneNotSupportedException {
		AppOccupationSalary appOccupationSalary = new AppOccupationSalary();
		appOccupationSalary.setAppoccupationkey(this.appoccupationkey);
		appOccupationSalary.setSalary(this.salary);
		appOccupationSalary.setSalarysource(this.salarysource);
		appOccupationSalary.setIsactive(this.isactive);
		appOccupationSalary.setLstupdatedt(this.lstupdatedt);
		appOccupationSalary.setLstupdateby(this.lstupdateby);
		return appOccupationSalary;
	}
}
