package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class SegmentBreRequest {

	private String emprMastCategory;
	
	private String creditVidyaRiskCategory;
	
	private boolean officialMailVerification;
	
	private String emprMastSubcategory;
	
	private boolean nsdlNameMatchFlag;
	
	private String cibilScore;
	
	private Integer additionalCibilFlag;
	
	private String residenceType;
	
	private String cityLocation;
	
	public String getCityLocation() {
		return cityLocation;
	}

	public void setCityLocation(String cityLocation) {
		this.cityLocation = cityLocation;
	}

	public String getResidenceType() {
		return residenceType;
	}

	public void setResidenceType(String residenceType) {
		this.residenceType = residenceType;
	}

	public String getEmprMastCategory() {
		return emprMastCategory;
	}

	public void setEmprMastCategory(String emprMastCategory) {
		this.emprMastCategory = emprMastCategory;
	}

	public String getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(String cibilScore) {
		this.cibilScore = cibilScore;
	}

	public Integer getAdditionalCibilFlag() {
		return additionalCibilFlag;
	}

	public void setAdditionalCibilFlag(Integer additionalCibilFlag) {
		this.additionalCibilFlag = additionalCibilFlag;
	}

	public String getCreditVidyaRiskCategory() {
		return creditVidyaRiskCategory;
	}

	public void setCreditVidyaRiskCategory(String creditVidyaRiskCategory) {
		this.creditVidyaRiskCategory = creditVidyaRiskCategory;
	}

	public boolean isOfficialMailVerification() {
		return officialMailVerification;
	}

	public void setOfficialMailVerification(boolean officialMailVerification) {
		this.officialMailVerification = officialMailVerification;
	}
 
	public String getEmprMastSubcategory() {
		return emprMastSubcategory;
	}

	public void setEmprMastSubcategory(String emprMastSubcategory) {
		this.emprMastSubcategory = emprMastSubcategory;
	}

	public boolean isNsdlNameMatchFlag() {
		return nsdlNameMatchFlag;
	}

	public void setNsdlNameMatchFlag(boolean nsdlNameMatchFlag) {
		this.nsdlNameMatchFlag = nsdlNameMatchFlag;
	}

	@Override
	public String toString() {
		return "SegmentBreRequest [emprMastCategory=" + emprMastCategory + ", creditVidyaRiskCategory="
				+ creditVidyaRiskCategory + ", officialMailVerification=" + officialMailVerification
				+ ", emprMastSubcategory=" + emprMastSubcategory + ", nsdlNameMatchFlag=" + nsdlNameMatchFlag
				+ ", cibilScore=" + cibilScore + ", additionalCibilFlag=" + additionalCibilFlag + "]";
	}

}
