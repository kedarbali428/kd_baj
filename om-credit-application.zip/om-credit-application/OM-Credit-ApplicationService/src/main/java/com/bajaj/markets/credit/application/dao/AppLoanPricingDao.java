package com.bajaj.markets.credit.application.dao;

import java.util.List;

import com.bajaj.markets.credit.application.model.AppLoanPricing;
import com.bajaj.markets.credit.application.model.AppLoanPricingFees;
import com.bajaj.markets.credit.application.model.AppProductListing;

public interface AppLoanPricingDao {

	/**
	 * 
	 * This method is to create or update app_loan_pricing record bases on applicationkey, productlistingkey
	 * 
	 * @param appLoanPricing
	 * @return
	 * @throws ParseException
	 */
	public AppLoanPricing updateAppLoanPricing(AppLoanPricing appLoanPricing);
	
	/**
	 * 
	 * This method is to create new app_loan_pricing_fee record and inactivate existing record bases apploanpricingkey
	 * 
	 * @param appLoanPricingKey
	 * @param appLoanPricingFees
	 * @return
	 */
	public List<AppLoanPricingFees> updateAppLoanPricingFees(Long appLoanPricingKey, List<AppLoanPricingFees> appLoanPricingFees);
	
	/**
	 * This method is to mark child loan pricing raised from EP as SUSPENDED
	 * @param parentapplicationKey
	 * @return
	 */
	 public AppLoanPricing suspendChildAppEPLoanPricing(String parentapplicationKey, AppProductListing appProductListing);
}
