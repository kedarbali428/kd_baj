package com.bajaj.markets.credit.application.processor;

import java.util.HashMap;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.application.bean.ApplyCardConsentOtpResponse;
import com.bajaj.markets.credit.application.bean.CheckCaseStatusRes;
import com.bajaj.markets.credit.application.bean.CustDemogConsentOtpResponse;
import com.bajaj.markets.credit.application.bean.CustomerDemographics;
import com.bajaj.markets.credit.application.bean.ProcessCardResponse;
import com.bajaj.markets.credit.application.bean.ProcessPrincipalCardRequest;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.ApplicationAttribute;
import com.bajaj.markets.credit.application.model.PrincipleCustomerInfo;
import com.bajaj.markets.credit.application.model.Product;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class ApplicationPrincipleProcessor {
	@Value("${api.omcreditcardprincipleintegration.consent.post.url}")
	private String applyCardConsentUrl;
	@Value("${api.omcreditcardprincipleintegration.processcard.post.url}")
	private String processCardUrl;
	@Value("${api.omcreditcardprincipleintegration.checkcasestatus.put.url}")
	private String checkCaseStatusUrl;
	@Value("${api.omcreditcardprincipleintegration.custdemogconsent.post.url}")
	private String custDemogConsentUrl;
	@Value("${api.omcreditcardprincipleintegration.custdemog.PUT.url}")
	private String custDemogUrl;


	@Autowired
	private BFLLoggerUtilExt logger;
	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;

	@Autowired
	private Environment env;

	private static final String CLASS_NAME = ApplicationPrincipleProcessor.class.getCanonicalName();

	public ApplyCardConsentOtpResponse applyCardConsent(String applicationKey, String mobileNumber, Product product,
			String custType) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start - applyCardConsent method for applicationKey : "+applicationKey);
		ApplyCardConsentOtpResponse applyCardConsentOtpResponse = null;
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		try {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put(ApplicationConstants.MOBILE_NUMBER, mobileNumber);
			jsonObject.put(ApplicationConstants.PROD_KEY, String.valueOf(product.getProdkey()));
			params.put(ApplicationConstants.PRINCIPALKEY, String.valueOf(product.getPrincipalkey()));
			params.put(ApplicationConstants.CUST_TYPE, custType);
			headers.add(ApplicationConstants.APPLICATIONID, applicationKey);
			headers.add(ApplicationConstants.MOBILE, mobileNumber);
			ResponseEntity<Object> applyCOnsentResp = creditApplicationServiceUtility
					.excuteRestCall(applyCardConsentUrl, HttpMethod.POST, String.class, params, jsonObject.toString(),
							headers);
			if (applyCOnsentResp.getStatusCode().equals(HttpStatus.OK)) {
				Gson gson = new Gson();
				applyCardConsentOtpResponse = gson.fromJson(applyCOnsentResp.getBody().toString(),
						ApplyCardConsentOtpResponse.class);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in principle integration service while consent call."
								+ applyCOnsentResp.getBody().toString());
				throw new CreditApplicationServiceException(applyCOnsentResp.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1011,
								env.getProperty(ApplicationConstants.CAS_1011)));
			}
		} catch (CreditApplicationServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred for applicationId : "+applicationKey, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End - applyCardConsent method completed successfully for applicationaId : "+applicationKey +"  response : "+ applyCardConsentOtpResponse.toString());
		return applyCardConsentOtpResponse;
	}

	public ProcessCardResponse processCard(ProcessPrincipalCardRequest principalCardRequest, Long principlekey,
			String custType, String applicationKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start - processCard method for applicationKey :  " +applicationKey);
		ProcessCardResponse processCardResponse = new ProcessCardResponse();
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		try {
			Gson gson = new Gson();
			ObjectMapper mapper = new ObjectMapper();
			String jsonReq = mapper.writeValueAsString(principalCardRequest);
			params.put(ApplicationConstants.PRINCIPALKEY, String.valueOf(principlekey));
			params.put(ApplicationConstants.CUST_TYPE, custType);
			headers.add(ApplicationConstants.APPLICATIONID, applicationKey);
			headers.add(ApplicationConstants.MOBILE,
					String.valueOf(principalCardRequest.getApplicationAttribute().getMobile()));
			ResponseEntity<Object> applyCOnsentResp = creditApplicationServiceUtility.excuteRestCall(
					processCardUrl, HttpMethod.POST, String.class, params, jsonReq, headers);
			if (applyCOnsentResp.getStatusCode().equals(HttpStatus.OK)) {
				processCardResponse = gson.fromJson(applyCOnsentResp.getBody().toString(),
						ProcessCardResponse.class);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in principle integration service." + applyCOnsentResp.getBody().toString());
				throw new CreditApplicationServiceException(applyCOnsentResp.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1011,
								env.getProperty(ApplicationConstants.CAS_1011)));
			}
		} catch (CreditApplicationServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred for applicationId : " +applicationKey , e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "End - processCard method completed successfully for applicationId : " +applicationKey+ " Response : " +processCardResponse.toString());
		return processCardResponse;
	}

	public CheckCaseStatusRes checkStatus(String applicationKey, String mobileNumber, String principalKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start - checkStatus method for applicationKey : "+applicationKey);
		CheckCaseStatusRes checkCaseStatusRes = null;
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		try {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put(ApplicationConstants.MOBILE_NUMBER, mobileNumber);
			params.put(ApplicationConstants.PRINCIPALKEY, principalKey);
			headers.add(ApplicationConstants.APPLICATIONID, applicationKey);
			headers.add(ApplicationConstants.MOBILE, mobileNumber);
			ResponseEntity<Object> applyCOnsentResp = creditApplicationServiceUtility.excuteRestCall(checkCaseStatusUrl,
					HttpMethod.PUT, String.class, params, jsonObject.toString(), headers);
			if (applyCOnsentResp.getStatusCode().equals(HttpStatus.OK)) {
				Gson gson = new Gson();
				checkCaseStatusRes = gson.fromJson(applyCOnsentResp.getBody().toString(), CheckCaseStatusRes.class);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in principle integration service while check status call."
								+ applyCOnsentResp.getBody().toString());
				throw new CreditApplicationServiceException(applyCOnsentResp.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1011, env.getProperty(ApplicationConstants.CAS_1011)));
			}
		} catch (CreditApplicationServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred for applicationId : " +applicationKey, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "End - checkStatus method completed successfully for applicationId : " +applicationKey+ " Response : " + checkCaseStatusRes.toString());
		return checkCaseStatusRes;

	}

	public CustDemogConsentOtpResponse custDemogConsent(String applicationKey, String mobileNumber, Product product,
			PrincipleCustomerInfo principleCustInfo) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start - custDemogConsent method for applicationKey : "+applicationKey);
		CustDemogConsentOtpResponse custDemogConsentOtpResponse = new CustDemogConsentOtpResponse();
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		try {

			JSONObject jsonObject = new JSONObject();
			jsonObject.put(ApplicationConstants.CUST_TYPE, principleCustInfo.getPrinciplecusttype());
			jsonObject.put(ApplicationConstants.MOBILE_NUMBER, mobileNumber);
			jsonObject.put(ApplicationConstants.PROD_KEY, String.valueOf(product.getProdkey()));
			params.put(ApplicationConstants.PRINCIPALKEY, String.valueOf(product.getPrincipalkey()));
			headers.add(ApplicationConstants.APPLICATIONID, applicationKey);
			headers.add(ApplicationConstants.MOBILE, mobileNumber);
			ResponseEntity<Object> custDemogConsentResp = creditApplicationServiceUtility.excuteRestCall(
					custDemogConsentUrl, HttpMethod.POST, String.class, params, jsonObject.toString(), headers);
			if (custDemogConsentResp.getStatusCode().equals(HttpStatus.OK)) {
				Gson gson = new Gson();
				custDemogConsentOtpResponse = gson.fromJson(custDemogConsentResp.getBody().toString(),
						CustDemogConsentOtpResponse.class);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in principle integration service while consent call."
								+ custDemogConsentResp.getBody().toString());
				throw new CreditApplicationServiceException(custDemogConsentResp.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1011, env.getProperty(ApplicationConstants.CAS_1011)));
			}

		} catch (CreditApplicationServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred for applicationId : " +applicationKey, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"applyCardConsent end : " + custDemogConsentOtpResponse.toString());
		return custDemogConsentOtpResponse;

	}

	public Boolean custDemogDetails(String applicationKey, String mobileNumber, Product product, String otp,
			PrincipleCustomerInfo principleCustInfo, ApplicationAttribute applicationAttribute) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start custDemogDetails method for applicationKey : "+applicationKey);
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		try {

			JSONObject jsonObject = new JSONObject();
			jsonObject.put(ApplicationConstants.CUST_TYPE, principleCustInfo.getPrinciplecusttype());
			jsonObject.put(ApplicationConstants.MOBILE_NUMBER, mobileNumber);
			jsonObject.put(ApplicationConstants.PROD_KEY, String.valueOf(product.getProdkey()));
			jsonObject.put(ApplicationConstants.OTP, otp);
			jsonObject.put(ApplicationConstants.DATE_OF_BIRTH, String.valueOf(applicationAttribute.getDob()));
			params.put(ApplicationConstants.PRINCIPALKEY, String.valueOf(product.getPrincipalkey()));
			headers.add(ApplicationConstants.APPLICATIONID, applicationKey);
			headers.add(ApplicationConstants.MOBILE, mobileNumber);
			ResponseEntity<Object> custDemogDetailsResp = creditApplicationServiceUtility.excuteRestCall(custDemogUrl,
					HttpMethod.PUT, String.class, params, jsonObject.toString(), headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					" Demog Ext Fetch Response is" + custDemogDetailsResp);
			if (!custDemogDetailsResp.getStatusCode().equals(HttpStatus.OK)) {

				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Exception occurred  while calling PrincipleIntegration demog fetch"
								+ custDemogDetailsResp.getBody().toString());
				throw new CreditApplicationServiceException(custDemogDetailsResp.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1011, env.getProperty(ApplicationConstants.CAS_1011)));
			} else {
				Gson mapper = new Gson();
				CustomerDemographics customerDemographics = mapper.fromJson(custDemogDetailsResp.getBody().toString(),
						CustomerDemographics.class);
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"End custDemogDetails method completed successfully for applicationId : "+applicationKey+ " with response " + customerDemographics);
				return (null != customerDemographics ? customerDemographics.getIsOtpValid() : null);
			}

		} catch (CreditApplicationServiceException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while fetching demog details for applicationId : "+applicationKey, e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while fetching demog details for applicationId : "+applicationKey, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}

	}

}