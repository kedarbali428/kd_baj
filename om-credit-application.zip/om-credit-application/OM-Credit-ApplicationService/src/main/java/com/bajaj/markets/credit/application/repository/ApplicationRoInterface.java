package com.bajaj.markets.credit.application.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bajaj.markets.credit.application.model.Application;
import com.bajaj.markets.credit.application.repository.tx.ApplicationRepository;
import com.sun.xml.bind.v2.model.core.ID;

public interface ApplicationRoInterface extends ReadInterface<Application, Long> {

	Application findByApplicationkeyAndIsactive(Long applicationkey, Integer isActive);

	@Query("select a.applicationkey from Application a where a.parentapplicationkey=:parentApplicationKey AND a.prodcdl3=:prodCodel3 AND a.isactive=1")
	public Long findApplicationkeyByParentapplicationkeyAndProdcdl3(
			@Param("parentApplicationKey") Long parentApplicationKey, @Param("prodCodel3") Long prodCodel3);

	@Query("select a.applicationkey from Application a where a.parentapplicationkey=:parentApplicationKey "
			+ "AND a.prodcdl3=:prodCodel3 AND a.prodtypekey=:prodtypekey AND a.riskoffertype=:riskoffertype AND a.isactive=1")
	public Long findApplicationkeyByParentapplicationkeyAndProdcdl3AndProdtypekeyAndRiskoffertype(
			@Param("parentApplicationKey") Long parentApplicationKey, @Param("prodCodel3") Long prodCodel3,
			@Param("prodtypekey") Long prodtypekey, @Param("riskoffertype") String riskoffertype);

	@Query("select a.applicationkey from Application a where a.parentapplicationkey=:parentApplicationKey "
			+ "AND a.prodcdl3=:prodCodel3 AND a.prodtypekey=:prodtypekey AND a.riskoffertype is null AND a.isactive=1")
	public Long findApplicationkeyByParentapplicationkeyAndProdcdl3AndProdtypekeyAndRiskoffertype(
			@Param("parentApplicationKey") Long parentApplicationKey, @Param("prodCodel3") Long prodCodel3,
			@Param("prodtypekey") Long prodtypekey);

	public List<Application> findByParentapplicationkeyAndIsactive(Long parentApplicationKey, Integer isActive);

	public List<Application> findByParentapplicationkeyAndIsactiveAndInprocessflg(Long parentapplicationkey,
			Integer isActive, BigDecimal inprocessflg);

	@Query("select a.prodcdl2 from Application a where a.applicationkey=:applicationkey AND a.isactive=1")
	public Long findProdcdl2ByApplicationkeyAndIsactive(Long applicationkey);

	public List<Application> findByParentapplicationkeyAndApplicationkeyNotInAndAppstatusNotIn(
			Long parentapplicationkey, List<Long> applicationKeyList, List<Integer> appStatusList);

	public List<Application> findByParentapplicationkeyAndApplicationkeyNotAndIsactive(Long parentapplicationkey,
			Long applicationkey, Integer isactive);

	Application findByParentapplicationkeyAndProdcdl3AndIsactive(Long applicationKey, Long prodCdL3, Integer isActive);

	@Query("select a.prodcdl3 from Application a where a.applicationkey=:applicationkey AND a.isactive=1")
	public Long findProdcdl3ByApplicationkeyAndIsactive(Long applicationkey);

	public List<Application> findByParentapplicationkeyAndApplicationkeyAndIsactive(Long parentapplicationkey,
			Long applicationkey, Integer isactive);

}
