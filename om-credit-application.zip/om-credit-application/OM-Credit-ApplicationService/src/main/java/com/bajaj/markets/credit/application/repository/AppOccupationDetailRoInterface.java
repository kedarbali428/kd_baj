package com.bajaj.markets.credit.application.repository;

import com.bajaj.markets.credit.application.model.AppOccupationDetail;

public interface AppOccupationDetailRoInterface extends ReadInterface<AppOccupationDetail, Long> {

	AppOccupationDetail findByAppattrbkeyAndIsactive(Long appattrbkey, Integer isActive);

}
