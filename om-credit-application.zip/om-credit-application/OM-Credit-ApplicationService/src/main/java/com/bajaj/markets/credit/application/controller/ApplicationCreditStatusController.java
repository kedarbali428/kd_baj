package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.CreditStatus;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationCreditStatusService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationCreditStatusController {

	@Autowired
	private ApplicationCreditStatusService applicationCreditStatusService;

	@Autowired
	BFLLoggerUtilExt logger;
	private static final String CLASSNAME = ApplicationAddressController.class.getName();

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER})
	@ApiOperation(value = "Update application credit status endpoint", notes = "This resource will be used to update credit status of an application", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { 
			@ApiResponse(code = 201, message = "application credit status updated successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/statusupdate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateCreditStatusDetail(@Valid @RequestBody CreditStatus creditStatus,
			@PathVariable(name = "applicationid", required = true) Long applicationId,
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateCreditStatusDetails method for applicationId :" + applicationId);
		CreditStatus creditState = applicationCreditStatusService.updateCreditStatusDetail(creditStatus, applicationId,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Completed updateCreditStatusDetails method successfully - applicationId : " +applicationId);
		return new ResponseEntity<>(creditState, HttpStatus.CREATED);

	}
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER,Role.INTERNAL})
	@ApiOperation(value = "update credit disbursement status endpoint", notes = "This resource will be used to update credit disbursement status of an application", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "update request for application credit disbursement status completed successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationId}/updatecreditstatus", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateCreditDisbursementStatus(@PathVariable(name = "applicationId", required = true) Long applicationId,@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateCreditDisbursementStatus method");
		// Service call
	    applicationCreditStatusService.updateCreditDisbursementStatus(applicationId,headers);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Completed updateCreditDisbursementStatus method successfully");
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
