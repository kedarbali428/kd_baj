package com.bajaj.markets.credit.application.bean;

public class ApplicationDispositionDetails {

	private String applicationId;
	
	private String quoteId;
	
	private String offerId;
	
	private String dispositionCode;
	
	private String subdispositionCode;
	
	private String followUpDate;
	
	private String followUpTime;
	
	private String dispositionDescription;
	
	private String subdispositionDescription;
	
	private Long userId;
	
	private String function;
	
	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getQuoteId() {
		return quoteId;
	}

	public void setQuoteId(String quoteId) {
		this.quoteId = quoteId;
	}

	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public String getDispositionCode() {
		return dispositionCode;
	}

	public void setDispositionCode(String dispositionCode) {
		this.dispositionCode = dispositionCode;
	}

	public String getSubdispositionCode() {
		return subdispositionCode;
	}

	public void setSubdispositionCode(String subdispositionCode) {
		this.subdispositionCode = subdispositionCode;
	}
	
	public String getFollowUpDate() {
		return followUpDate;
	}

	public void setFollowUpDate(String followUpDate) {
		this.followUpDate = followUpDate;
	}

	public String getFollowUpTime() {
		return followUpTime;
	}

	public void setFollowUpTime(String followUpTime) {
		this.followUpTime = followUpTime;
	}

	public String getDispositionDescription() {
		return dispositionDescription;
	}

	public void setDispositionDescription(String dispositionDescription) {
		this.dispositionDescription = dispositionDescription;
	}

	public String getSubdispositionDescription() {
		return subdispositionDescription;
	}

	public void setSubdispositionDescription(String subdispositionDescription) {
		this.subdispositionDescription = subdispositionDescription;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}
}
