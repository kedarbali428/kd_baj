package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.ChildApplication;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.ParentApplication;

/**
 * Application Resource for creating parent & child application
 * @author 738768
 *
 */
public class Application{

	private String applicationKey;
	
	@NotBlank(groups = ChildApplication.class, message = "parentApplicationKey cannot be null or empty")
	private String parentApplicationKey;

	@Pattern(groups = ParentApplication.class,regexp="(0/91)?[6-9][0-9]{9}",message="mobile is not valid") 
	@NotBlank(groups = ParentApplication.class, message = "mobile cannot be null or empty")
	private String mobile;
	@Pattern(groups = ParentApplication.class, regexp = "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", message = "Invalid date")
	@NotBlank(groups = ParentApplication.class, message = "dateOfBirth cannot be null or empty")
	private String dateOfBirth;
	
	private String applicantKey;
	
	private Integer l3ProductKey;
	private String l3ProductCode;
	
	private Integer l2ProductKey;
	private String l2ProductCode;
	
	private Integer l4ProductKey;
	private String  l4ProductCode;
	
	private String productListingKey;   
	private String riskoffertype;	
	
	
	private String  hlProductIntent;
	
	private Boolean tncAccepted = true;

	private Name name;
	
	private String appProcessIdentifier;
		
	public Boolean getTncAccepted() {
		return tncAccepted;
	}
	public void setTncAccepted(Boolean tncAccepted) {
		this.tncAccepted = tncAccepted;
	}
	public String getRiskoffertype() {
		return riskoffertype;
	}
	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}
	public String getProductListingKey() {
		return productListingKey;
	}
	public Integer getL4ProductKey() {
		return l4ProductKey;
	}
	public void setL4ProductKey(Integer l4ProductKey) {
		this.l4ProductKey = l4ProductKey;
	}
	public String getL4ProductCode() {
		return l4ProductCode;
	}
	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}
	public void setProductListingKey(String productListingKey) {
		this.productListingKey = productListingKey;
	}
	
	public String getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	public String getParentApplicationKey() {
		return parentApplicationKey;
	}
	public void setParentApplicationKey(String parentApplicationKey) {
		this.parentApplicationKey = parentApplicationKey;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}
	public Integer getL3ProductKey() {
		return l3ProductKey;
	}
	public void setL3ProductKey(Integer l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}
	public Integer getL2ProductKey() {
		return l2ProductKey;
	}
	public void setL2ProductKey(Integer l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public String getL2ProductCode() {
		return l2ProductCode;
	}

	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}
	
	public String getHlProductIntent() {
		return hlProductIntent;
	}
	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}
	
	public String getAppProcessIdentifier() {
		return appProcessIdentifier;
	}
	public void setAppProcessIdentifier(String appProcessIdentifier) {
		this.appProcessIdentifier = appProcessIdentifier;
	}
	@Override
	public String toString() {
		return "Application [applicationKey=" + applicationKey + ", parentApplicationKey=" + parentApplicationKey
				+ ", mobile=" + mobile + ", dateOfBirth=" + dateOfBirth + ", applicantKey=" + applicantKey
				+ ", l3ProductKey=" + l3ProductKey + ", l3ProductCode=" + l3ProductCode + ", l2ProductKey="
				+ l2ProductKey + ", l2ProductCode=" + l2ProductCode + ", l4ProductKey=" + l4ProductKey
				+ ", l4ProductCode=" + l4ProductCode + ", productListingKey=" + productListingKey + ", riskoffertype="
				+ riskoffertype + ", hlProductIntent=" + hlProductIntent + ", tncAccepted=" + tncAccepted + ", name="
				+ name + ", appProcessIdentifier=" + appProcessIdentifier + "]";
	}
}
