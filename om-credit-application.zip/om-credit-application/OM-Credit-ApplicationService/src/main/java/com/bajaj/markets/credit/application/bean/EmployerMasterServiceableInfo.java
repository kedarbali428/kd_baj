package com.bajaj.markets.credit.application.bean;

public class EmployerMasterServiceableInfo {
	private Integer isactive;
	private Long principalkey;
	private String partneremprname;
	private String partneremprcategory;
	private String partneremprsubcategory;

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getPrincipalkey() {
		return principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

	public String getPartneremprname() {
		return partneremprname;
	}

	public void setPartneremprname(String partneremprname) {
		this.partneremprname = partneremprname;
	}

	public String getPartneremprcategory() {
		return partneremprcategory;
	}

	public void setPartneremprcategory(String partneremprcategory) {
		this.partneremprcategory = partneremprcategory;
	}

	public String getPartneremprsubcategory() {
		return partneremprsubcategory;
	}

	public void setPartneremprsubcategory(String partneremprsubcategory) {
		this.partneremprsubcategory = partneremprsubcategory;
	}

	@Override
	public String toString() {
		return "EmployeeMasterServiceableInfo [isactive=" + isactive + ", principalkey=" + principalkey
				+ ", partneremprname=" + partneremprname + ", partneremprcategory=" + partneremprcategory
				+ ", partneremprsubcategory=" + partneremprsubcategory + "]";
	}
}
