package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class OpenArcFppInput {

	private String customerSegment;
	private Double loanTypeSelectionRate;
	private Integer applicationScore;
	private Boolean perfiosRequiredFlag;
	private String branch;
	private String applicationID;
	private String l3product;
	private String occupationType;
	private String l4product;
	private String principalName;
	private String existingCustomerFlag;
	private Integer subStagePercentage;
	private Long requiredloanamount;
	private Integer CIBILScore;
	private int age;
	private String companyCategory;
	private Integer finalFOIR;
	private Integer eligibilityAmount;
	private List<OfferDetails> offerDetails;
	private List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails;
	private String source;
	private Integer tenor;
	
	public void setCustomerSegment(String customerSegment) {
		this.customerSegment = customerSegment;
	}
	public void setLoanTypeSelectionRate(Double loanTypeSelectionRate) {
		this.loanTypeSelectionRate = loanTypeSelectionRate;
	}
	public void setApplicationScore(Integer applicationScore) {
		this.applicationScore = applicationScore;
	}
	public void setPerfiosRequiredFlag(Boolean perfiosRequiredFlag) {
		this.perfiosRequiredFlag = perfiosRequiredFlag;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(String applicationID) {
		this.applicationID = applicationID;
	}
	public void setL3product(String l3product) {
		this.l3product = l3product;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public void setL4product(String l4product) {
		this.l4product = l4product;
	}
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}
	public void setExistingCustomerFlag(String existingCustomerFlag) {
		this.existingCustomerFlag = existingCustomerFlag;
	}
	public void setSubStagePercentage(Integer subStagePercentage) {
		this.subStagePercentage = subStagePercentage;
	}
	public void setRequiredloanamount(Long requiredloanamount) {
		this.requiredloanamount = requiredloanamount;
	}
	public void setCIBILScore(Integer cIBILScore) {
		CIBILScore = cIBILScore;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setCompanyCategory(String companyCategory) {
		this.companyCategory = companyCategory;
	}
	public void setFinalFOIR(Integer finalFOIR) {
		this.finalFOIR = finalFOIR;
	}
	public void setEligibilityAmount(Integer eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}
	public void setOfferDetails(List<OfferDetails> offerDetails) {
		this.offerDetails = offerDetails;
	}
	public void setEstimatedNetMonthlySalaryDetails(List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails) {
		this.estimatedNetMonthlySalaryDetails = estimatedNetMonthlySalaryDetails;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public void setTenor(Integer tenor) {
		this.tenor = tenor;
	}

	 

}
