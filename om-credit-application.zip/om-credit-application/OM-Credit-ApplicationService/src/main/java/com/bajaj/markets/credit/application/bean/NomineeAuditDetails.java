package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class NomineeAuditDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String nomineeName;

	public String getNomineeName() {
		return nomineeName;
	}

	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}
}
