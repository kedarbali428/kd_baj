package com.bajaj.markets.credit.application.helper;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.application.bean.ChildRejectionInput;
import com.bajaj.markets.credit.application.bean.ChildRejectionParentOutput;
import com.bajaj.markets.credit.application.bean.PrincipalProductRejectionInput;
import com.bajaj.markets.credit.application.bean.Rejection;
import com.bajaj.markets.credit.application.model.AppDeviationDtl;
import com.bajaj.markets.credit.application.model.AppOccupationDetail;
import com.bajaj.markets.credit.application.model.AppProductListing;
import com.bajaj.markets.credit.application.model.AppRejectionDetail;
import com.bajaj.markets.credit.application.model.Application;
import com.bajaj.markets.credit.application.model.ApplicationAttribute;
import com.bajaj.markets.credit.application.model.ApplicationStage;
import com.bajaj.markets.credit.application.model.ApplicationUtmParameter;
import com.bajaj.markets.credit.application.model.OccupationMaster;
import com.bajaj.markets.credit.application.model.PrincipleCustomerInfo;
import com.bajaj.markets.credit.application.model.Product;
import com.bajaj.markets.credit.application.model.ProductCategory;
import com.bajaj.markets.credit.application.model.ProductType;
import com.bajaj.markets.credit.application.model.RejectionCode;
import com.bajaj.markets.credit.application.model.RejectionSystemMaster;
import com.bajaj.markets.credit.application.repository.ApplicationsRejectionDetailRoInterface;
import com.bajaj.markets.credit.application.repository.ReadRepositoryLocator;
import com.bajaj.markets.credit.application.repository.tx.AppDeviationDtlRepository;
import com.bajaj.markets.credit.application.repository.tx.AppOccupationDetailRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationAttributeRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationProductListingRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationStageRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationUtmParameterRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationsRejectionDetailRepository;
import com.bajaj.markets.credit.application.repository.tx.PrincipleCustomerInfoRepository;
import com.bajaj.markets.credit.application.repository.tx.ProductCategoryRepository;
import com.bajaj.markets.credit.application.repository.tx.ProductRepository;
import com.bajaj.markets.credit.application.repository.tx.ProductTypeRepository;
import com.bajaj.markets.credit.application.repository.tx.RejectionCodeRepository;
import com.bajaj.markets.credit.application.repository.tx.RejectionSystemMasterRepository;
import com.bajaj.markets.credit.application.repository.tx.StatusMasterRepository;
import com.bajaj.markets.insurance.remoteapitrackinglib.bean.RemoteApiTrackingBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Component
public class CreditApplicationServiceUtility {
	
	@Value("${credit.parentapp.cooling.period}")
	private Long coolingPeriod;

	@Value("${bre-auth-type}")
	private String authtype;

	@Value("${bre-auth-userName}")
	private String authuserName;

	@Value("${bre-auth-password}")
	private String authpassword;

	@Value("${bre.om.parent.rejection.resource.path}")
	private String parentRejectionBreUrl;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private ApplicationAttributeRepository applicationAttributeRepository;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CustomDefaultHeaders customHeaders;

	@Autowired
	private ProductCategoryRepository productCategoryRepository;

	@Autowired
	private ApplicationUtmParameterRepository applicationUtmParameterRepository;

	@Autowired
	private ApplicationsRejectionDetailRepository applicationsRejectionDetailRepository;
	
	@Autowired
	private List<ApplicationsRejectionDetailRoInterface> applicationsRejectionDetailRoInterfaces;

	@Autowired
	private RejectionSystemMasterRepository rejectionSystemMasterRepository;

	@Autowired
	private RejectionCodeRepository rejectionCodeRepository;

	@Autowired
	private PrincipleCustomerInfoRepository principleCustomerInfoRepository;

	@Autowired
	private StatusMasterRepository statusMasterRepository;

	@Autowired
	private AppDeviationDtlRepository appDeviationDtlRepository;

	@Autowired
	private ApplicationStageRepository applicationStageRepository;

	@Autowired
	private ProductTypeRepository productTypeRepository;

	@Autowired
	private AppOccupationDetailRepository appOccupationDetailRepository;

	@Autowired
	private ApplicationProductListingRepository applicationProductListingRepository;
	
	@Autowired
	KibanaLoggingHelper kibanaLoggingHelper;

	@Value("${api.referencedata.occupationmaster.GET.url}")
	private String getOccupationMasterUrl;

	private final String API_TRACKING_SOURCE_CREDIT = "CREDIT";
	private final String TARGET_CHILDREJECTIONBRE = "CHILDREJECTIONBRE";
	private static final String SALARIED = "Salaried";
	private static final String BUSINESS_OWNER = "Business Owner";

	private static final String CLASSNAME = CreditApplicationServiceUtility.class.getName();
	
	public void validateApplicationAndPrincipalKey(String applicationKey, String principalKey) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside validateApplicationAndPrincipalKey method - applicationKey principalKey validation start for "+applicationKey);
		if (!StringUtils.isEmpty(applicationKey) && !StringUtils.isEmpty(principalKey)) {

			try {
				Application application = applicationRepository.findByApplicationkeyAndIsactive(Long.valueOf(applicationKey), 1);
				Product product = productRepository.findByProdkeyAndIsactive(application.getProdcdl3(), 1);
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "product from DB : " + product);
				if (null != principalKey && null != product && principalKey.equals(product.getPrincipalkey().toString())) {
					logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
							"Inside validateApplicationAndPrincipalKey method validation Successful for applicationId : "+applicationKey+ " principalKey :"+principalKey);
				} else {
					logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateOccupation method controller - resource validation failed for applicationId : "+applicationKey);
					throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
							new ErrorBean("OMCA_010", "Application id & principal key does not match"));
				}

			} catch (CreditApplicationServiceException creditApplicationServiceException) {
				throw creditApplicationServiceException;
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Technical error while validating applicationId : "+applicationKey+ " & principal key : "+principalKey ,e);
				throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("OMCA_010", "Technical error while validating Application id & principal key"));
			}
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside validateApplicationAndPrincipalKey method controller - resource validation failed for applicationId : "+applicationKey);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_010", "Application id & principal key doesnot match"));
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside validateApplicationAndPrincipalKey method validation end for ApplicationId : "+applicationKey+ " & principal key : "+principalKey);
	}

	public void validateApplicationAndApplicationAttribute(String applicationKey, String userattributeKey) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside validateApplicationAndApplicationAttribute method - applicationKey userattributeKey validation start for applicationId : "+applicationKey);
		if (!StringUtils.isEmpty(applicationKey) && !StringUtils.isEmpty(userattributeKey)) {

			try {
				Long applicationId = applicationAttributeRepository.findApplicationkeyByAppattrbkey(Long.valueOf(userattributeKey));
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "ApplicationId from DB : " + applicationId);
				if (null != applicationId && applicationKey.equals(applicationId.toString())) {
					logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
							"Inside validateApplicationAndApplicationAttribute method validation Successful for applicationKey : " +applicationKey+ " & userattributeKey : "+userattributeKey);
				} else {
					logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateOccupation method controller - resource validation failed for applicationId : "+applicationKey);
					throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
							new ErrorBean("OMCA_010", "Application id & user attribute doesnot match"));
				}

			} catch (CreditApplicationServiceException creditApplicationServiceException) {
				logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Exception occured while validating application",creditApplicationServiceException);
				throw creditApplicationServiceException;
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Technical error while validating Application id :" +applicationKey+ " & userattribute : " +userattributeKey ,e);
				throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("OMCA_010", "Technical error while validating Application id & user attribute"));
			}
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateOccupation method controller - resource validation failed for applicationId : "+applicationKey);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_010", "Application id & user attribute doesnot match"));
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside validateApplicationAndApplicationAttribute method - applicationKey userattributeKey validation end for applicationId : "+applicationKey);
	}
	
	public ResponseEntity<Object> excuteRestCall(String url, HttpMethod httpMethod, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Start excuteRestCall");
		updateHttpHeaders(headers);
		HttpEntity<Object> entity = null;
		String jsonRes = null;
		ResponseEntity<?> responseEntity = null;
		try {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Method  : " + httpMethod+"\n URL  : " + url);
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "RequestJson  : " + requestJson + "\n Params  : " + params);
			entity = new HttpEntity<>(requestJson, headers);
			if (params != null) {
				responseEntity = restTemplate.exchange(url, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplate.exchange(url, httpMethod, entity, responseType);
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "End excuteRestCall, Response  : " + responseEntity);
            if(null != responseEntity.getBody()){
			jsonRes = responseEntity.getBody().toString();
            }
			return new ResponseEntity<>(jsonRes, responseEntity.getStatusCode());

		} catch (HttpClientErrorException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					" HttpClientErrorException during call of " + httpMethod.name() +", Endpoint URL  : " + url
					+"\n Request Json  : " + requestJson + "\n Params  : " + params
					+ "\n ResponseBodyAsString : "+ e.getResponseBodyAsString(), e);
			throw new CreditApplicationServiceException(e.getStatusCode(), new ErrorBean("CPS-1016", e.getResponseBodyAsString()));
		} catch (HttpStatusCodeException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					" HttpStatusCodeException during call of " + httpMethod.name() +", Endpoint URL  : " + url
					+"\n Request Json  : " + requestJson + "\n Params  : " + params
					+ "\n ResponseBodyAsString : "+ e.getResponseBodyAsString(), e);
			throw new CreditApplicationServiceException(e.getStatusCode(), new ErrorBean("CPS-1015", e.getResponseBodyAsString()));
		} catch (RestClientException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					" RestClientException during call of " + httpMethod.name() +", URL  : " + url
					+"\n RequestJson  : " + requestJson + "\n Params  : " + params, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CPS-1017", "RestClientException while calling service."));
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					" Super Exception during call of " + httpMethod.name() +", URL  : " + url
					+"\n RequestJson  : " + requestJson + "\n Params  : " + params, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CPS-1018", "Exception occurred."));
		}
	}

	/**
	 * Utility for parent & child application status update
	 * 1. If applicationId is parent application id then parent application status will be updated.
	 * 2. If applicationId is child application id then child & parent both application status will be updated.
	 * @param applicationId
	 * @param status
	 */
	public void updateApplicationStatus(Long applicationId, Integer status) {
		if (null != applicationId && null != status) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
					"Input updateApplicationStatus method, applicationId: " + applicationId + " & status: " + status);
			try {
				if (checkApplicationIsParent(applicationId)) {
					updateStatus(applicationId, status);
				} else {
					updateChildAndParentStatus(applicationId, status);
				}
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside updateApplicationStatus method - exception occurred : applicationId: "+ applicationId, e);
				throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCA_00003", e.getMessage()));
			}
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside updateApplicationStatus method - applicationId or status is null : applicationId: "+applicationId);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCA_00001", "applicationId or status is null"));
		}
	}

	private Boolean checkApplicationIsParent(Long applicationId) {
		Application application = applicationRepository.findByApplicationkeyAndIsactive(applicationId, 1);
		if (null != application && null != application.getParentapplicationkey() && applicationId.equals(application.getParentapplicationkey())) {
			return true;
		} else if (null != application && null != application.getParentapplicationkey() && !applicationId.equals(application.getParentapplicationkey())) {
			return false;
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside checkApplicationIsParent method - details not found fpr application : "+applicationId);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCA_00002", "application details not found"));
		}
	}

	private Application updateStatus(Long applicationId, Integer status) {
		Application application = applicationRepository.findByApplicationkeyAndIsactive(applicationId, 1);
		application.setAppstatus(status);
		application.setLstupdateby(customHeaders.getUserKey());
		application.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));

		markChildsSuspended(applicationId, application);

		application = applicationRepository.save(application);
		return application;
	}

	/**
	 * Method to mark all child applications (having their status expect Approval, Rejected, Disbursed & Closed) status as Suspended
	 * 
	 * @param applicationId
	 * @param application entity
	 */
	private void markChildsSuspended(Long applicationId, Application application) {
		if (application != null && application.getParentapplicationkey() != null
				&& !(Long.compare(applicationId, application.getParentapplicationkey()) == 0)) {
			List<Integer> appStatusList = new ArrayList<>();
			appStatusList.add(ApplicationStatusEnum.APPROVAL.getKey());
			appStatusList.add(ApplicationStatusEnum.REJECTED.getKey());
			appStatusList.add(ApplicationStatusEnum.CLOSED.getKey());
			appStatusList.add(ApplicationStatusEnum.DISBURSED.getKey());
			appStatusList.add(ApplicationStatusEnum.SENTTOBANK.getKey());
			appStatusList.add(ApplicationStatusEnum.CARDCREATED.getKey());

			List<Long> appIds = new ArrayList<>();
			appIds.add(applicationId);
			appIds.add(application.getParentapplicationkey());

			List<Application> childApplications = applicationRepository
					.findByParentapplicationkeyAndApplicationkeyNotInAndAppstatusNotIn(application.getParentapplicationkey(), appIds, appStatusList);
			if (!CollectionUtils.isEmpty(childApplications)) {
				childApplications.forEach(app -> app.setAppstatus(ApplicationStatusEnum.SUSPENDED.getKey()));
				applicationRepository.saveAll(childApplications);
			}
		}
	}

	private void updateChildAndParentStatus(Long applicationId, Integer status) {
		Application application = applicationRepository.findByApplicationkeyAndIsactive(applicationId, 1);
		ProductCategory productCategory = productCategoryRepository.findByProdcatkeyAndIsactive(application.getProdcdl2(), 1);
		String l2Code = null != productCategory ? productCategory.getProdcatcode() : null;
		String l2CodeDescription = null != productCategory ? productCategory.getProdcatdesc() : null;
		String childStatus = statusMasterRepository.findByStatuskeyAndIsactive(status.longValue(), 1).getStatusdesc();
		Integer parentStatus = null;
		if (null != l2Code && CreditApplicationConstant.l2CODE_CC.equalsIgnoreCase(l2Code)) {
			if (CreditApplicationConstant.REJECTED_STATUS.equalsIgnoreCase(childStatus)) {
				try {
					parentStatus = callBreAndFetchParentStatus(application, childStatus, l2CodeDescription);
				} catch (Exception e) {
					logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside updateChildAndParentStatus method , childApplicationId :" + applicationId
							+ " Exception occurred while calling BRE for parent status ", e);
				}
			} else {
				parentStatus = Arrays.stream(CreditCardParentChildStatusEnum.values()).filter(e -> e.getChildStatus().equals(status)).findFirst().get()
						.getParentStatus();
			}
		} else if (null != l2Code && CreditApplicationConstant.l2CODE_OMPL.equalsIgnoreCase(l2Code)) {
			try {
				parentStatus = callBreAndFetchParentStatus(application, childStatus, l2CodeDescription);
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside updateChildAndParentStatus method , childApplicationId :" + applicationId
						+ " Exception occurred while calling BRE for parent status ", e);
			}
		} else if (null != l2Code && CreditApplicationConstant.l2CODE_OMSL.equalsIgnoreCase(l2Code)) {
			if (CreditApplicationConstant.REJECTED_STATUS.equalsIgnoreCase(childStatus)) {
				try {
					parentStatus = callBreAndFetchParentStatus(application, childStatus, l2CodeDescription);
				} catch (Exception e) {
					logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
							"Inside updateChildAndParentStatus method , childApplicationId :" + applicationId
									+ " Exception occurred while calling BRE for parent status ",
							e);
				}
			} else {
				parentStatus = Arrays.stream(CreditLoansParentChildStatusEnum.values())
						.filter(e -> e.getChildStatus().equals(status)).findFirst().get().getParentStatus();
			}
		}
		if (null != parentStatus) {
			updateStatus(applicationId, status);
			updateStatus(application.getParentapplicationkey(), parentStatus);
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"Inside updateChildAndParentStatus method , childApplicationId :" + applicationId + "- parent status not found");
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCA_00002", "parent status not found"));
		}
	}

	/**
	 * This method gets childApplication and status as input then calls childRejectionBre to fetch corresponding status of parent.
	 * Updates both parent and child statuses.
	 * 
	 * @param childApplication
	 * @param childStatus
	 * @param l2CodeDescription
	 * @return
	 * @throws JsonProcessingException 
	 * @throws JsonMappingException 
	 */
	public Integer callBreAndFetchParentStatus(Application childApplication, String childStatus, String l2CodeDescription) throws JsonMappingException, JsonProcessingException {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Start - callBreAndFetchParentStatus method for applicationId : "+childApplication.getApplicationkey());
		ChildRejectionParentOutput childRejectionParentOutput = null;
		Long parentApplicationKey = childApplication.getParentapplicationkey();
		ChildRejectionInput childRejectionInput = new ChildRejectionInput();
		childRejectionInput.setApplicationId(parentApplicationKey.toString());
		childRejectionInput.setProduct(l2CodeDescription);
		childRejectionInput.setRejectionType("1");
		ApplicationStage applicationStage = applicationStageRepository.findByApplicationkeyAndIsactive(Long.valueOf(parentApplicationKey), 1);
		childRejectionInput.setSubStagePercentage(null != applicationStage ? applicationStage.getAppstagecompletionper().floatValue() : null);
		ApplicationAttribute appAttr = applicationAttributeRepository.findByApplication_ApplicationkeyAndApplicanttypeAndIsactive(parentApplicationKey, 1L, 1);
		 HttpHeaders httpHeader = new HttpHeaders();
	        httpHeader.add("Content-Type", "application/json");
			ResponseEntity<Object> excuteRestCall = excuteRestCall(getOccupationMasterUrl, HttpMethod.GET, String.class, null, null,httpHeader );
			List<OccupationMaster> occupationMaster = null;
			if (HttpStatus.OK.equals(excuteRestCall.getStatusCode())) {
				occupationMaster = new ObjectMapper().readValue(excuteRestCall.getBody().toString(),
						new TypeReference<List<OccupationMaster>>() {
						});
			}
			if(!CollectionUtils.isEmpty(occupationMaster)) {
				for (OccupationMaster occMaster : occupationMaster) {
				if(appAttr != null) {
					AppOccupationDetail appOcc = appOccupationDetailRepository.findByAppattrbkeyAndIsactive(appAttr.getAppattrbkey(), 1);
					if(occMaster.getOccupationKey().equals( appOcc.getOccupationtype())) {
						childRejectionInput.setOccupationType(occMaster.getOccupationValue());
					}
				}
			}
			}
		if ((CreditApplicationConstant.REJECTED_STATUS.equalsIgnoreCase(childStatus)|| CreditApplicationConstant.CREDIT_REJECTED_STATUS.equalsIgnoreCase(childStatus))
				&& null!=appAttr) {
			List<PrincipleCustomerInfo> principleCustomerInfo = principleCustomerInfoRepository.findByIsactiveAndApplicationkeyAndAppattrbkey(1, parentApplicationKey,appAttr.getAppattrbkey());
			Map<Long, List<Object>> principalInfoMap = new HashMap<>();
			principleCustomerInfo.forEach(info -> {
				List<Object> list = new ArrayList<>();
				Boolean existingCustomerType = info.getIsetb().equals("0") ? Boolean.FALSE : Boolean.TRUE;
				list.add(existingCustomerType);
				list.add(info.getPrinciplecusttype());
				principalInfoMap.put(info.getPrincipalkey(), list);
			});

			List<PrincipalProductRejectionInput> principleProductDetails = getChildRejectionBreProductList(parentApplicationKey, principalInfoMap,childApplication, childStatus);
			childRejectionInput.setPrincipleProductDetails(principleProductDetails);
			childRejectionParentOutput = callParentRejectionBre(childRejectionInput, null);
			if (null != childRejectionParentOutput && null != childRejectionParentOutput.getChildRejectionOutput()
					&& !CollectionUtils.isEmpty(childRejectionParentOutput.getChildRejectionOutput().getPrincipleProductDetails())) {
				RejectionSystemMaster rejectionSystemMaster = rejectionSystemMasterRepository.findByRejectionsystemcodeIgnoreCaseAndIsactive("CHLDREJBRE1", 1);
				childRejectionParentOutput.getChildRejectionOutput().getPrincipleProductDetails().forEach(dtl -> {
					Product product = productRepository.findByProdcodeAndIsactive(dtl.getPrincipleProductCode(), 1);
					Long prodTypeKey = null;
					if (dtl.getL4ProductCode() != null) {
						ProductType prodType = productTypeRepository.findByProdtypecodeAndIsactive(dtl.getL4ProductCode(), 1);
						if(null != prodType ) {
						prodTypeKey = prodType.getProdtypekey();
						}
					}

					AppProductListing appProductListing = applicationProductListingRepository
							.findByApplicationkeyAndIsactiveAndProdkeyAndProdtypekeyAndRiskoffertype(parentApplicationKey, 1, product.getProdkey(), prodTypeKey,
									dtl.getRiskOfferType());
					if(null != appProductListing) {
						appProductListing.setIseligible(null != dtl.getIsEligible() && dtl.getIsEligible() ? BigDecimal.ONE : BigDecimal.ZERO);
						appProductListing.setIsdisplayflg(null != dtl.getIsDisplay() && dtl.getIsDisplay() ? 1 : 0);
						appProductListing.setLstupdateby(customHeaders.getUserKey());
						appProductListing.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
	
					}
					
					updateRejectionDetails(parentApplicationKey.toString(), dtl.getRejectCodeList(), product.getProdkey(), rejectionSystemMaster, prodTypeKey,
							dtl.getRiskOfferType());
				});
				
				if(!StringUtils.isEmpty(childRejectionParentOutput.getChildRejectionOutput().getParentApplicationStagePercentage()) && !childRejectionParentOutput.getChildRejectionOutput().getParentApplicationStagePercentage().equals("0.0")) {
					UpdateApplicationStagePercentage(parentApplicationKey,childRejectionParentOutput.getChildRejectionOutput().getParentApplicationStagePercentage());
				}
			}

		} else {
			//Prepare BRE data for other than rejection status
			List<PrincipalProductRejectionInput> principleProductDetails = new ArrayList<>();
			PrincipalProductRejectionInput principalProductRejectionInput = new PrincipalProductRejectionInput();
			principalProductRejectionInput.setChildApplicationStatus(childStatus);
			if (childApplication.getProdcdl3() != null) {
				Product l3Product = productRepository.findByProdkeyAndIsactive(childApplication.getProdcdl3(), 1);
				principalProductRejectionInput.setPrincipleProductCode(l3Product != null ? l3Product.getProdcode() : null);
			}
			if (childApplication.getProdtypekey() != null) {
				ProductType l4Product = productTypeRepository.findByProdtypekeyAndIsactive(childApplication.getProdtypekey(), 1);
				principalProductRejectionInput.setL4ProductCode(l4Product != null ? l4Product.getProdtypecode() : null);
			}
			principalProductRejectionInput.setRiskOfferType(childApplication.getRiskoffertype());
			principleProductDetails.add(principalProductRejectionInput);
			childRejectionInput.setPrincipleProductDetails(principleProductDetails);
			//Call BRE
			childRejectionParentOutput = callParentRejectionBre(childRejectionInput, null);
		}
		//Return parent status
		if (null != childRejectionParentOutput && null != childRejectionParentOutput.getChildRejectionOutput()
				&& !StringUtils.isEmpty(childRejectionParentOutput.getChildRejectionOutput().getParentStatus())) {
			Integer parentStatus = statusMasterRepository.findByStatusdescIgnoreCaseAndIsactive(childRejectionParentOutput.getChildRejectionOutput().getParentStatus(), 1)
					.getStatuskey().intValue();
			return parentStatus;
		}
		return null;
	}

	private void UpdateApplicationStagePercentage(Long parentApplicationKey, String stagePercent) {
		ApplicationStage applicationStage = applicationStageRepository.findByApplicationkeyAndIsactive(Long.valueOf(parentApplicationKey), 1);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Start - UpdateApplicationStagePercentage for applicationId: " + parentApplicationKey);
		try {
			if (null != applicationStage) {
				Double stagePercentage=Double.valueOf(stagePercent);
				applicationStage.setAppstagecompletionper(stagePercentage.intValue());
				applicationStageRepository.save(applicationStage);
			} else{
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside UpdateApplicationStagePercentage,Resource not found for given applicationId :" + parentApplicationKey);
				throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND, new ErrorBean("OMCA_1021", "Resource not found for given applicationId."));
			}
		}catch (CreditApplicationServiceException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside callParentRejectionBre, appplicationId :" + parentApplicationKey + " CreditApplicationServiceException : ", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Technical exception while saving stage percentage for application: "+ parentApplicationKey, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OMCA_1022", "Technical exception while saving stage percentage"));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,"End - UpdateApplicationStagePercentage for applicationId: " + parentApplicationKey);
	}
	
	private List<String> getDeviations(Long applicationKey, Long l3ProductKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Start :: getDeviations() for application : "+ applicationKey + "  & L3 Key " + l3ProductKey);
		List<AppDeviationDtl> appDeviationDtls= appDeviationDtlRepository.findByApplicationkeyAndProdkeyAndIsactive(applicationKey, l3ProductKey, 1);
				if(!CollectionUtils.isEmpty(appDeviationDtls)){
					List<String> deviationCodes = new ArrayList<>();
					appDeviationDtls.forEach(dtl -> {
						deviationCodes.add(dtl.getAppDeviationCode().getDeviationcd());
					});
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Finished :: getDeviations() for application: "+applicationKey);
			return deviationCodes;
				}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Finished :: getDeviations() for application: "+applicationKey);
		return null;
	}

	private List<Rejection> getRejectionCodes(String rejectionSystemCode, Set<String> rejectCodes, PrincipalProductRejectionInput input) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Start - getRejectionCodes method ");
		List<Rejection> rejList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(input.getRejectionList())) {
			rejList = input.getRejectionList();
		}
		Rejection rej = rejList.stream().filter(r -> rejectionSystemCode.equals(r.getRejectionSource())).findFirst().orElse(new Rejection());
		rej.setRejectionSource(rejectionSystemCode);
		if (!CollectionUtils.isEmpty(rej.getRejectCodeList())) {
			rejectCodes = rej.getRejectCodeList();
		}
		rej.setRejectCodeList(!CollectionUtils.isEmpty(rejectCodes) ? rejectCodes.stream().distinct().collect(Collectors.toSet()) : null);
		rejList.add(rej);
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "End - getRejectionCodes method ");
		return rejList;
	}

	public ChildRejectionParentOutput callParentRejectionBre(ChildRejectionInput childRejectionInput, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside callParentRejectionBre, appplicationId :" + childRejectionInput.getApplicationId());
		ChildRejectionParentOutput childRejectionParentOutput = null;
		String source = API_TRACKING_SOURCE_CREDIT;
		String target = TARGET_CHILDREJECTIONBRE;
		String errorMessage=null;
	    String status=CreditApplicationConstant.STATUS_FAILURE;
		Gson g = new GsonBuilder().disableHtmlEscaping().serializeNulls().create();
		if (headers == null)
			headers = new HttpHeaders();
		headers.add(HttpHeaders.AUTHORIZATION, getAuthDetails());
		RemoteApiTrackingBean apiTrackingBean = new RemoteApiTrackingBean();
		ResponseEntity<?> breResponse =null;
		try {
			String jsonRequest = g.toJson(childRejectionInput);
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside callParentRejectionBre, parent rejection bre URL " + parentRejectionBreUrl);
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside callParentRejectionBre, parent rejection bre External request " + jsonRequest);
	
			apiTrackingBean = kibanaLoggingHelper.apiTrackingBeanCreation(childRejectionInput.getApplicationId(),
					childRejectionInput.getApplicationId(), jsonRequest, parentRejectionBreUrl, source, target);

			breResponse = excuteRestCall(parentRejectionBreUrl, HttpMethod.POST, String.class, null, jsonRequest, headers);
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside callParentRejectionBre, Response from BRE : " + breResponse);
			if (null != breResponse && HttpStatus.CREATED.equals(breResponse.getStatusCode()) && null != breResponse.getBody()) {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside callParentRejectionBre, Response Body : " + breResponse.getBody());
				childRejectionParentOutput = g.fromJson(breResponse.getBody().toString(), ChildRejectionParentOutput.class);
				status = CreditApplicationConstant.STATUS_SUCCESS;
				apiTrackingBean.setStatus(status);
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
						"Inside callParentRejectionBre, appplicationId :" + childRejectionInput.getApplicationId() + " Null or Invalid response from BRE");

				errorMessage=" Null or Invalid response from BRE";
				throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCA_102", "Null or Invalid response from BRE"));
			}
		} catch (CreditApplicationServiceException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside callParentRejectionBre, appplicationId :"
					+ childRejectionInput.getApplicationId() + " CreditApplicationServiceException : ", e);

			errorMessage = "Exception while parsing in ChildRejectionBre response." + e;
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"Inside callParentRejectionBre, appplicationId :" + childRejectionInput.getApplicationId(), e);
			errorMessage = e.toString();
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OMCA_102", "Technical exception occured inside callParentRejectionBre()"));
		} finally {
			apiTrackingBean.setResponsePayload(breResponse != null ? breResponse.toString() : null);
			apiTrackingBean.setResponseTimeStamp(new Timestamp(System.currentTimeMillis()).toString());
			apiTrackingBean.setStatus(status);
			apiTrackingBean.setError(errorMessage);
			kibanaLoggingHelper.save(apiTrackingBean);

		}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "End callParentRejectionBre method, appplicationId : " + childRejectionInput.getApplicationId());
		return childRejectionParentOutput;
	}

	private String getAuthDetails() {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside getAuthDetails method - Start");
		String auth;
		String userNamePwd = authuserName + ":" + authpassword;
		auth = Base64.getEncoder().encodeToString(userNamePwd.getBytes());
		auth = authtype + " " + auth;
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "End getAuthDetails method - End");
		return auth;
	}

	/**
	 * Form the customer full name by joining first , middle and last name.
	 * 
	 * @param applicationAttribute
	 * @return
	 */
	public String formFullName(ApplicationAttribute applicationAttribute) {
		StringBuilder fullname = new StringBuilder();
		if (!StringUtils.isBlank(applicationAttribute.getFirstname())) {
			fullname.append(applicationAttribute.getFirstname());
			if (!StringUtils.isBlank(applicationAttribute.getMiddlename())) {
				fullname.append(" ").append(applicationAttribute.getMiddlename());
			}
			if (!StringUtils.isBlank(applicationAttribute.getLastname())) {
				fullname.append(" ").append(applicationAttribute.getLastname());
			}
			return fullname.toString();
		} else {
			return null;
		}
	}

	/**
	 * Extract the eligibility amount available in message received from Axis.
	 * 
	 * @param axisStatusMessage
	 * @return
	 */
	public String checkForCardLimit(String axisStatusMessage) {
		String creditLimit = null;
		if (axisStatusMessage.contains(ApplicationConstants.LIMIT_KEY_WORD)) {
			int limitIndex = axisStatusMessage.lastIndexOf(ApplicationConstants.LIMIT_KEY_WORD);
			creditLimit = axisStatusMessage.substring(limitIndex + 6, axisStatusMessage.length());
		}
		return creditLimit;
	}

	public void saveUTMParameter(HttpHeaders headers, String event, Long applicationId) {
		try {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside saveUTMParameter for application : "+applicationId + ", headers : " + headers);
			ApplicationUtmParameter applicationUtmParameter = extractUTMFromHeader(headers);
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside saveUTMParameter for application : "+applicationId + ", applicationUtmParameter : " + applicationUtmParameter.toString());
			applicationUtmParameter.setApplicationkey(applicationId);
			ApplicationUtmParameter applicationUtmParam = applicationUtmParameterRepository.findByApplicationkeyAndEventAndIsactive(applicationId,
					ApplicationConstants.PARENT_CREATED, 1);
			if (StringUtils.equalsIgnoreCase(event, ApplicationConstants.PARENT_CREATED) && null == applicationUtmParam) {
				// save UTM in case of Parent application.
				saveUTM(event, applicationUtmParameter);
			} else if (!StringUtils.equalsIgnoreCase(event, ApplicationConstants.PARENT_CREATED)) {
				if (null == applicationUtmParam) {
					// create parent created entry if there is no entry of parent created.
					saveUTM(ApplicationConstants.PARENT_CREATED, applicationUtmParameter);
				} else {
					ApplicationUtmParameter appUtmParam = applicationUtmParameterRepository.findByApplicationkeyAndEventAndIsactive(applicationId,
							ApplicationConstants.RESUME, 1);
					// disable previous entry in application utm param table
					if (null != appUtmParam) {
						appUtmParam.setIsactive(0);
						applicationUtmParameterRepository.save(appUtmParam);
					}
					// Create new entry Application Utm param table.
					saveUTM(event, applicationUtmParameter);
				}
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occured while saving UTM for application : "+applicationId , e);
		}

	}

	private void saveUTM(String event, ApplicationUtmParameter applicationUtmParameter) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside saveUTM method start");
		applicationUtmParameter.setEvent(event);
		applicationUtmParameter.setIsactive(1);
		applicationUtmParameter.setCreatedt(new Timestamp(System.currentTimeMillis()));
		applicationUtmParameterRepository.save(applicationUtmParameter);
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside saveUTM method end");
	}

	/**
	 * Extract the UTM Parameters from header and map it to Applicatin_UTM_Parameter
	 * to store in DB.
	 * 
	 * @param headers
	 * @return
	 */
	private ApplicationUtmParameter extractUTMFromHeader(HttpHeaders headers) {
		ApplicationUtmParameter applicationUtmParameter = new ApplicationUtmParameter();
		applicationUtmParameter
				.setUtmterm(CollectionUtils.isEmpty(headers.get(ApplicationConstants.UTM_TERM)) ? null : headers.get(ApplicationConstants.UTM_TERM).get(0));
		applicationUtmParameter.setUtmsource(
				CollectionUtils.isEmpty(headers.get(ApplicationConstants.UTM_SOURCE)) ? null : headers.get(ApplicationConstants.UTM_SOURCE).get(0));
		applicationUtmParameter.setUtmreferralcode(
				CollectionUtils.isEmpty(headers.get(ApplicationConstants.UTM_REFERRAL)) ? null : headers.get(ApplicationConstants.UTM_REFERRAL).get(0));
		applicationUtmParameter.setUtmmedium(
				CollectionUtils.isEmpty(headers.get(ApplicationConstants.UTM_MEDIUM)) ? null : headers.get(ApplicationConstants.UTM_MEDIUM).get(0));
		applicationUtmParameter.setUtmcontent(
				CollectionUtils.isEmpty(headers.get(ApplicationConstants.UTM_CONTENT)) ? null : headers.get(ApplicationConstants.UTM_CONTENT).get(0));
		applicationUtmParameter.setUtmcampaign(
				CollectionUtils.isEmpty(headers.get(ApplicationConstants.UTM_CAMPAIGN)) ? null : headers.get(ApplicationConstants.UTM_CAMPAIGN).get(0));
		applicationUtmParameter.setSourcingchannel(
				CollectionUtils.isEmpty(headers.get(ApplicationConstants.SOURCING_CHANNEL)) ? null : headers.get(ApplicationConstants.SOURCING_CHANNEL).get(0));
		applicationUtmParameter
				.setGclid(CollectionUtils.isEmpty(headers.get(ApplicationConstants.GCLID)) ? null : headers.get(ApplicationConstants.GCLID).get(0));
		applicationUtmParameter.setRecversion(1);
		applicationUtmParameter.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		applicationUtmParameter.setLstupdateby(123l);
		return applicationUtmParameter;
	}

	/**
	 * Check validity(cooling period) of the parent app
	 * @param application
	 */
	public Boolean checkApplicationValidity(Application application) {
		Boolean valid = null;
		if (null != application && null != application.getAppdate()) {
			Long timeDifference = Math.abs(Calendar.getInstance().getTime().getTime() - application.getAppdate().getTime());
			long diff = TimeUnit.DAYS.convert(timeDifference, TimeUnit.MILLISECONDS);
			if (diff > coolingPeriod)
				valid = false;
			else
				valid = true;
		}
		return valid;
	}

	public String createProductListString(List<String> productList) {

		String productListString = "";
		int count = 1;
		if (productList.size() > 1) {
			for (String product : productList) {
				productListString = productListString.concat(String.valueOf(count).concat(".").concat(product).concat(". "));
				count++;
			}
		} else {
			productListString = productList.get(0);
		}
		return productListString.trim();

	}

	public void updateHttpHeaders(HttpHeaders headers) {
		if (headers != null) {
			headers.remove("host");
			headers.set("Content-Type", "application/json");
			if (null != customHeaders) {
				headers.set(CustomDefaultHeaders.AUTH_TOKEN, customHeaders.getAuthtoken());
				headers.set(CustomDefaultHeaders.CMPTCORR_ID, customHeaders.getCmptcorrid());
				if (!StringUtils.isEmpty(customHeaders.getPlatform()))
					headers.set(CustomDefaultHeaders.PLATFORM, customHeaders.getPlatform());
			}
		}
	}

	public void updateRejectionDetails(String applicationKey, List<String> rejectCodeList, Long productKey,
			RejectionSystemMaster rejectionSystemMaster,Long prodTypeKey,String riskOfferType) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside updateRejectionDetails method Start : " + "\n rejectCodeList : " + rejectCodeList
				+ ", productKey : " + productKey + ", rejectionSystemMasterCode : " + rejectionSystemMaster.getRejectionsystemcode() + " applicationKey: "+applicationKey);
		Long parentApplicationId = getParentApplicationId(Long.valueOf(applicationKey));
		Timestamp timestamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		List<AppRejectionDetail> appRejectionDetailsList = applicationsRejectionDetailRepository
				.findByApplicationkeyAndProdkeyAndProdtypekeyAndRiskoffertypeAndRejectionSystemMasterAndIsactive(
						parentApplicationId, productKey, prodTypeKey, riskOfferType, rejectionSystemMaster, 1);
		if (!CollectionUtils.isEmpty(appRejectionDetailsList)) {
			for (AppRejectionDetail appRejectionDetail : appRejectionDetailsList) {
				appRejectionDetail.setLstupdateby(customHeaders.getUserKey());
				appRejectionDetail.setLstupdatedt(timestamp);
				appRejectionDetail.setIsactive(0);
			}
		}
		if (!CollectionUtils.isEmpty(rejectCodeList)) {
			rejectCodeList  =  rejectCodeList.stream().distinct().collect(Collectors.toList());
			for (String rejectCode : rejectCodeList) {
				AppRejectionDetail appRejectionDetail = new AppRejectionDetail();
				RejectionCode rejectCodeMaster = rejectionCodeRepository.findByRejectcodeAndIsactive(rejectCode, 1);
				if (null == rejectCodeMaster) {
					throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
							new ErrorBean("OMCA_10012", "rejectCodeMaster not found for rejectCode : "+rejectCode));
				}
				appRejectionDetail.setRejectionCode(rejectCodeMaster);
				appRejectionDetail.setRiskoffertype(riskOfferType);
				appRejectionDetail.setProdtypekey(prodTypeKey);
				appRejectionDetail.setApplicationkey(parentApplicationId);
				appRejectionDetail.setProdkey(productKey);
				appRejectionDetail.setLstupdateby(customHeaders.getUserKey());
				appRejectionDetail.setLstupdatedt(timestamp);
				appRejectionDetail.setIsactive(1);
				appRejectionDetail.setRejectionsrc(rejectionSystemMaster.getRejectionsystemcode());
				appRejectionDetail.setRejectionSystemMaster(rejectionSystemMaster);
				appRejectionDetail.setRejectiondt(timestamp);
				Calendar cal = Calendar.getInstance();
				if(null!=rejectCodeMaster.getCoolprdapplicableflg() && rejectCodeMaster.getCoolprdapplicableflg()==1){
					cal.add(Calendar.DATE, rejectCodeMaster.getCoolperioddays().intValue());
					appRejectionDetail.setRejectcoolprdenddt(new Timestamp(cal.getTime().getTime()));
				}else{
					cal.add(Calendar.DATE, -1); // set to previous day so that the user is allowed always. 'NEVER' case
					appRejectionDetail.setRejectcoolprdenddt(new Timestamp(cal.getTime().getTime()));
				}
				appRejectionDetail.setRejectedbyuserkey(customHeaders.getUserKey());
				appRejectionDetailsList.add(appRejectionDetail);
			}
		}
		if(!CollectionUtils.isEmpty(appRejectionDetailsList)) {
			applicationsRejectionDetailRepository.saveAll(appRejectionDetailsList);
		}
		
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Successfully updated apprejectiondetails.");
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside updateRejectionDetails method End");
	}

	public RejectionSystemMaster validateRejectionSystem(List<String> rejectCodeList, String rejectionSystem) {
		RejectionSystemMaster rejectionSystemMaster = null;
		if (!StringUtils.isBlank(rejectionSystem)) {
			rejectionSystemMaster = rejectionSystemMasterRepository.findByRejectionsystemcodeIgnoreCaseAndIsactive(rejectionSystem, 1);
			if (null == rejectionSystemMaster) {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
						"Please provide a valid rejection system. Column 'rejectionsystemcode' from 'dmcredit.rejection_system_master'");
				throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("CAS-1042", "Please provide a valid rejection system"));
			}
		} else {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
					"Please provide a valid rejection system. Column 'rejectionsystemcode' from 'dmcredit.rejection_system_master'");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1042", "Please provide a valid rejection system"));
		}
		return rejectionSystemMaster;
	}

	private Long getParentApplicationId(Long applicationId) {
		Application application = applicationRepository.findByApplicationkeyAndIsactive(applicationId, 1);
		if (null != application) {
			return application.getParentapplicationkey();
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside getParentApplicationId method - application details not found");
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCA_00002", "application details not found"));
		}
	}
	
	public void validateApplication(String applicationKey, String applicationAttributeTypeKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
				"Inside validateApplication method - validation start for applicationKey:" + applicationKey);
		ApplicationAttribute applicationAttribute = applicationAttributeRepository
				.findByApplication_ApplicationkeyAndApplicanttypeAndIsactive(Long.valueOf(applicationKey),
						Long.valueOf(applicationAttributeTypeKey), ApplicationConstants.IS_ACTIVE);
		if (null != applicationAttribute) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"Application attribute is already present with given application id: " + applicationKey
							+ " and applicantType:" + applicationAttributeTypeKey);
			throw new CreditApplicationServiceException(HttpStatus.CONFLICT, new ErrorBean("OMCA_152",
					"ApplicationAttribute already exist for given applicationkey and applicantType"));
		} else {
			Application application = applicationRepository
					.findByApplicationkeyAndIsactive(Long.valueOf(applicationKey), ApplicationConstants.IS_ACTIVE);
			if (null != application) {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
						"Inside validateApplication method - resource validation successfull for applicationKey:"
								+ applicationKey);
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
						"Inside validateApplication method - application not found");
				throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
						new ErrorBean("OMCA_00002", "application details not found"));
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
				"Inside validateApplication method - validation end for applicationKey: " + applicationKey);
	}

	private List<PrincipalProductRejectionInput> getChildRejectionBreProductList(Long applicationKey, Map<Long, List<Object>> principalInfoMap,
			Application childApplication, String childStatus) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, " into getChildRejectionBreProductList() method ");
		List<PrincipalProductRejectionInput> principleProductList = new ArrayList<PrincipalProductRejectionInput>();
		List<AppProductListing> productListing = new ArrayList<AppProductListing>();
		productListing = applicationProductListingRepository.findByApplicationkeyAndIsactive(applicationKey, 1);
		if (!CollectionUtils.isEmpty(productListing)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
					" Preparing childRejectionBre product list from AppProductListing, Records found in listing =  "+ productListing.size());
			PrincipalProductRejectionInput principalProductRejectionInputBean = null;
			for (AppProductListing list : productListing) {
				principalProductRejectionInputBean = new PrincipalProductRejectionInput();
				if (null != list.getProdtypekey()) {
					ProductType l4Product = productTypeRepository.findByProdtypekeyAndIsactive(list.getProdtypekey(), 1);
					principalProductRejectionInputBean.setL4ProductCode(l4Product != null ? l4Product.getProdtypecode() : null);
				}
				principalProductRejectionInputBean.setRiskOfferType(list.getRiskoffertype());
				Product l3Product = productRepository.findByProdkeyAndIsactive(list.getProdkey(), 1);
				if (l3Product != null) {
					principalProductRejectionInputBean.setPrincipleProductCode(l3Product.getProdcode());
					if (principalInfoMap != null && principalInfoMap.containsKey(l3Product.getPrincipalkey())) {
						principalProductRejectionInputBean.setExistingCustomerType((Boolean) principalInfoMap.get(l3Product.getPrincipalkey()).get(0));
						principalProductRejectionInputBean.setPrincipleCustType((String) principalInfoMap.get(l3Product.getPrincipalkey()).get(1));
					}
				}
				// Only L3 present
				if (childApplication.getProdtypekey() == null && childApplication.getRiskoffertype() == null) {
					if (list.getProdkey().equals(childApplication.getProdcdl3()) && list.getProdtypekey() == null && list.getRiskoffertype() == null) {
						principalProductRejectionInputBean.setChildApplicationStatus(childStatus);
					}
					// L4 present but riskOffer not present
				} else if (childApplication.getProdtypekey() != null && childApplication.getRiskoffertype() == null) {
					if (list.getProdkey().equals(childApplication.getProdcdl3()) && childApplication.getProdtypekey().equals(list.getProdtypekey())
							&& list.getRiskoffertype() == null) {
						principalProductRejectionInputBean.setChildApplicationStatus(childStatus);
					}
					//L4 present & riskOffer both present
				} else if (childApplication.getProdtypekey() != null && childApplication.getRiskoffertype() != null) {
					if (list.getProdkey().equals(childApplication.getProdcdl3()) && childApplication.getProdtypekey().equals(list.getProdtypekey())
							&& childApplication.getRiskoffertype().equals(list.getRiskoffertype())) {
						principalProductRejectionInputBean.setChildApplicationStatus(childStatus);
					}
				}
				principalProductRejectionInputBean.setDeviationCodes(getDeviations(applicationKey, list.getProdkey()));
				principalProductRejectionInputBean
						.setRejectionList(getRejectionBeanList(list.getApplicationkey(), list.getProdkey(), list.getProdtypekey(), list.getRiskoffertype()));
				principleProductList.add(principalProductRejectionInputBean);
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, " Completed  getChildRejectionBreProductList()  ");
		return principleProductList;
	}
	
	/**
	 * Method to get Rejection bean list on the basis of L3 + L4 + RiskOfferType
	 *  
	 * @param appId
	 * @param l3Key
	 * @param l4Key
	 * @param riskOffer
	 * @return Rejection bean List
	 */	
	public List<Rejection> getRejectionBeanList(Long appId, Long l3Key, Long l4Key, String riskOffer) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "into  :: getRejectionBeanList() for application " + appId + "  & L3 Key " + l3Key + "  & L4 Key " + l4Key+ "  & riskOffer " + riskOffer);
		List<AppRejectionDetail> appRejectionDetailList = applicationsRejectionDetailRepository
				.findByApplicationkeyAndProdkeyAndProdtypekeyAndRiskoffertypeAndIsactive(appId, l3Key, l4Key, riskOffer, 1);
		List<Rejection> rejList = prepareRejectionBeanList(appRejectionDetailList);
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "getRejectionBeanList() completed ");
		return rejList;
	}
	
	/**
	 * Method to get Rejection bean list only on the basis of L3 Product
	 * @param appId
	 * @param l3Key
	 * @return Rejection bean List
	 */
	public List<Rejection> getRejectionBeanListByL3Only(Long appId, Long l3Key) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "into  :: getRejectionBeanListByL3Only() for application " + appId + "  & L3 Key " + l3Key );
		List<AppRejectionDetail> appRejectionDetailList = ReadRepositoryLocator
				.getReadOnlyInstance(applicationsRejectionDetailRoInterfaces)
				.findByApplicationkeyAndProdkeyAndIsactive(appId, l3Key, 1);
		List<Rejection> rejList = prepareRejectionBeanList(appRejectionDetailList);
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "getRejectionBeanListByL3Only() completed ");
		return rejList;
	}

	private List<Rejection> prepareRejectionBeanList(List<AppRejectionDetail> appRejectionDetailList) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "prepareRejectionBeanList() started");
		Map<String, Rejection> srcAndRejectionMap = new HashMap<>();
		if (!CollectionUtils.isEmpty(appRejectionDetailList)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Total Rejection found == "+ appRejectionDetailList.size());
			Rejection rejection = null;
			for (AppRejectionDetail appRejectionDetail : appRejectionDetailList) {
				String rejectionSrc = appRejectionDetail.getRejectionSystemMaster()!=null ? appRejectionDetail.getRejectionSystemMaster().getRejectionsystemcode() :null;
				if(srcAndRejectionMap.containsKey(rejectionSrc)) {
					rejection = srcAndRejectionMap.get(rejectionSrc);
				}else {
					rejection = new Rejection();
					rejection.setRejectionSource(rejectionSrc);
				}
				Set<String> rejectCodeSet =  CollectionUtils.isEmpty(rejection.getRejectCodeList()) ? new HashSet<>() : rejection.getRejectCodeList() ;
				rejectCodeSet.add(appRejectionDetail.getRejectionCode().getRejectcode());
				rejection.setRejectCodeList(rejectCodeSet);
				srcAndRejectionMap.put(rejectionSrc, rejection);
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "prepareRejectionBeanList() completed");
		return srcAndRejectionMap.isEmpty() ? null : new ArrayList<>(srcAndRejectionMap.values());
	}

}
