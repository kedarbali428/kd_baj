package com.bajaj.markets.credit.application.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BflEdwDemogData {

	@JsonProperty("company_type")
	private String companyType;

	@JsonProperty("mask_panno")
    private String maskedPan;

	@JsonProperty("employment_type")
    private String employmentType;

    private String gender;

    @JsonProperty("indiv_corp_flag")
    private String individualCorpFlag;

    private String panno;

    private String statedesc;

    private String uid;

    @JsonProperty("phon_e2")
    private String phoneE2;

    @JsonProperty("phon_e1")
    private String phoneE1;

    @JsonProperty("comp_name")
    private String companyName;

    private String addresstype;

    @JsonProperty("contact_person_name")
    private String contactPersonName;

    @JsonProperty("formatted_dob")
    private String formattedDob;

    private String landmark;

    @JsonProperty("first_name")
    private String firstName;

    private String email;

    @JsonProperty("addres_s1")
    private String addresS1;

    @JsonProperty("addres_s2")
    private String addresS2;

    @JsonProperty("annual_income")
    private String annualIncome;

    private String area;

    @JsonProperty("addres_s3")
    private String addresS3;

    private String tan;

    private String fname;

    private String cityname;

    private String mobile;

    @JsonProperty("last_name")
    private String lastName;

    @JsonProperty("city_desc")
    private String cityDesc;

    private String addressid;

    private String zipcode;

    private String dob;

    @JsonProperty("emi_card_no")
    private String emiCard;

    private String stdisd;

    private String doi;
    
    private String customerId;

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getMaskedPan() {
		return maskedPan;
	}

	public void setMaskedPan(String maskedPan) {
		this.maskedPan = maskedPan;
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIndividualCorpFlag() {
		return individualCorpFlag;
	}

	public void setIndividualCorpFlag(String individualCorpFlag) {
		this.individualCorpFlag = individualCorpFlag;
	}

	public String getPanno() {
		return panno;
	}

	public void setPanno(String panno) {
		this.panno = panno;
	}

	public String getStatedesc() {
		return statedesc;
	}

	public void setStatedesc(String statedesc) {
		this.statedesc = statedesc;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getPhoneE2() {
		return phoneE2;
	}

	public void setPhoneE2(String phoneE2) {
		this.phoneE2 = phoneE2;
	}

	public String getPhoneE1() {
		return phoneE1;
	}

	public void setPhoneE1(String phoneE1) {
		this.phoneE1 = phoneE1;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getAddresstype() {
		return addresstype;
	}

	public void setAddresstype(String addresstype) {
		this.addresstype = addresstype;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getFormattedDob() {
		return formattedDob;
	}

	public void setFormattedDob(String formattedDob) {
		this.formattedDob = formattedDob;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddresS1() {
		return addresS1;
	}

	public void setAddresS1(String addresS1) {
		this.addresS1 = addresS1;
	}

	public String getAddresS2() {
		return addresS2;
	}

	public void setAddresS2(String addresS2) {
		this.addresS2 = addresS2;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getAddresS3() {
		return addresS3;
	}

	public void setAddresS3(String addresS3) {
		this.addresS3 = addresS3;
	}

	public String getTan() {
		return tan;
	}

	public void setTan(String tan) {
		this.tan = tan;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCityDesc() {
		return cityDesc;
	}

	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}

	public String getAddressid() {
		return addressid;
	}

	public void setAddressid(String addressid) {
		this.addressid = addressid;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmiCard() {
		return emiCard;
	}

	public void setEmiCard(String emiCard) {
		this.emiCard = emiCard;
	}

	public String getStdisd() {
		return stdisd;
	}

	public void setStdisd(String stdisd) {
		this.stdisd = stdisd;
	}

	public String getDoi() {
		return doi;
	}

	public void setDoi(String doi) {
		this.doi = doi;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "BflEdwDemogData [companyType=" + companyType + ", maskedPan=" + maskedPan + ", employmentType="
				+ employmentType + ", gender=" + gender + ", individualCorpFlag=" + individualCorpFlag + ", panno="
				+ panno + ", statedesc=" + statedesc + ", uid=" + uid + ", phoneE2=" + phoneE2 + ", phoneE1=" + phoneE1
				+ ", companyName=" + companyName + ", addresstype=" + addresstype + ", contactPersonName="
				+ contactPersonName + ", formattedDob=" + formattedDob + ", landmark=" + landmark + ", firstName="
				+ firstName + ", email=" + email + ", addresS1=" + addresS1 + ", addresS2=" + addresS2
				+ ", annualIncome=" + annualIncome + ", area=" + area + ", addresS3=" + addresS3 + ", tan=" + tan
				+ ", fname=" + fname + ", cityname=" + cityname + ", mobile=" + mobile + ", lastName=" + lastName
				+ ", cityDesc=" + cityDesc + ", addressid=" + addressid + ", zipcode=" + zipcode + ", dob=" + dob
				+ ", emiCard=" + emiCard + ", stdisd=" + stdisd + ", doi=" + doi + ", customerId=" + customerId + "]";
	}
	
}
