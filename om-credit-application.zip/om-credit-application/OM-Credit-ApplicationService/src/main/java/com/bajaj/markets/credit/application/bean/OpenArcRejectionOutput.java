package com.bajaj.markets.credit.application.bean;

import java.util.List;

import javax.validation.constraints.NotNull;

public class OpenArcRejectionOutput {
	@NotNull(message = "Invalid Request: PrincipleProductDetails is null")
	private List<PrincipleProductDetails> principleProductDetails;
	private Boolean cibilRequired;
	private String leadQualifiesBflFlag;
	private List<String> creditReviewReasonCode;
	private Boolean pltbFlag;
	private String pefiosRequiredFlag;
	private Boolean nonStpFlag;

	private Boolean cvRequired;
	private String degreeCategory;
	private Integer finalExperience;
	
	public Boolean getCvRequired() {
		return cvRequired;
	}

	public void setCvRequired(Boolean cvRequired) {
		this.cvRequired = cvRequired;
	}

	public String getLeadQualifiesBflFlag() {
		return leadQualifiesBflFlag;
	}

	public void setLeadQualifiesBflFlag(String leadQualifiesBflFlag) {
		this.leadQualifiesBflFlag = leadQualifiesBflFlag;
	}

	public List<String> getCreditReviewReasonCode() {
		return creditReviewReasonCode;
	}

	public void setCreditReviewReasonCode(List<String> creditReviewReasonCode) {
		this.creditReviewReasonCode = creditReviewReasonCode;
	}

	public Boolean getPltbFlag() {
		return pltbFlag;
	}

	public void setPltbFlag(Boolean pltbFlag) {
		this.pltbFlag = pltbFlag;
	}

	public String getPefiosRequiredFlag() {
		return pefiosRequiredFlag;
	}

	public void setPefiosRequiredFlag(String pefiosRequiredFlag) {
		this.pefiosRequiredFlag = pefiosRequiredFlag;
	}

	public Boolean getNonStpFlag() {
		return nonStpFlag;
	}

	public void setNonStpFlag(Boolean nonStpFlag) {
		this.nonStpFlag = nonStpFlag;
	}

	public List<PrincipleProductDetails> getPrincipleProductDetails() {
		return principleProductDetails;
	}

	public void setPrincipleProductDetails(List<PrincipleProductDetails> principleProductDetails) {
		this.principleProductDetails = principleProductDetails;
	}

	/**
	 * @return the cibilRequired
	 */
	public Boolean getCibilRequired() {
		return cibilRequired;
	}

	/**
	 * @param cibilRequired the cibilRequired to set
	 */
	public void setCibilRequired(Boolean cibilRequired) {
		this.cibilRequired = cibilRequired;
	}

	public String getDegreeCategory() {
		return degreeCategory;
	}

	public void setDegreeCategory(String degreeCategory) {
		this.degreeCategory = degreeCategory;
	}
	
	public Integer getFinalExperience() {
		return finalExperience;
	}

	public void setFinalExperience(Integer finalExperience) {
		this.finalExperience = finalExperience;
	}

	@Override
	public String toString() {
		return "OpenArcRejectionOutput [principleProductDetails=" + principleProductDetails + ", cibilRequired="
				+ cibilRequired + ", leadQualifiesBflFlag=" + leadQualifiesBflFlag + ", creditReviewReasonCode="
				+ creditReviewReasonCode + ", pltbFlag=" + pltbFlag + ", pefiosRequiredFlag=" + pefiosRequiredFlag
				+ ", nonStpFlag=" + nonStpFlag + ", cvRequired=" + cvRequired + ", degreeCategory=" + degreeCategory
				+ ", finalExperience=" + finalExperience + "]";
	}
	
}
