package com.bajaj.markets.credit.application.bean;

public class LoanRevisionBean {

	private String l3productCode;
	private String productOffer;
	private String l4productVariant;
	private Integer revisedEligibilityAmmount;
	private Integer revisedEligibilityTenure;
	private Integer revisedLoanRequirement;
	private Integer revisedLoanTenure;
	private Long prodkey;
	private Long prodtypekey;

	public String getL3productCode() {
		return l3productCode;
	}

	public void setL3productCode(String l3productCode) {
		this.l3productCode = l3productCode;
	}

	public String getProductOffer() {
		return productOffer;
	}

	public void setProductOffer(String productOffer) {
		this.productOffer = productOffer;
	}

	public String getL4productVariant() {
		return l4productVariant;
	}

	public void setL4productVariant(String l4productVariant) {
		this.l4productVariant = l4productVariant;
	}

	public Integer getRevisedEligibilityAmmount() {
		return revisedEligibilityAmmount;
	}

	public void setRevisedEligibilityAmmount(Integer revisedEligibilityAmmount) {
		this.revisedEligibilityAmmount = revisedEligibilityAmmount;
	}

	public Integer getRevisedEligibilityTenure() {
		return revisedEligibilityTenure;
	}

	public void setRevisedEligibilityTenure(Integer revisedEligibilityTenure) {
		this.revisedEligibilityTenure = revisedEligibilityTenure;
	}

	public Integer getRevisedLoanRequirement() {
		return revisedLoanRequirement;
	}

	public void setRevisedLoanRequirement(Integer revisedLoanRequirement) {
		this.revisedLoanRequirement = revisedLoanRequirement;
	}

	public Integer getRevisedLoanTenure() {
		return revisedLoanTenure;
	}

	public void setRevisedLoanTenure(Integer revisedLoanTenure) {
		this.revisedLoanTenure = revisedLoanTenure;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	@Override
	public String toString() {
		return "LoanRevisionBean [l3productCode=" + l3productCode + ", productOffer=" + productOffer
				+ ", l4productVariant=" + l4productVariant + ", revisedEligibilityAmmount=" + revisedEligibilityAmmount
				+ ", revisedEligibilityTenure=" + revisedEligibilityTenure + ", revisedLoanRequirement="
				+ revisedLoanRequirement + ", revisedLoanTenure=" + revisedLoanTenure + ", prodkey=" + prodkey
				+ ", prodtypekey=" + prodtypekey + "]";
	}

}