package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.bajaj.markets.credit.application.helper.UpperCaseConverter;

@Entity
@Table(name = "app_occupation_detail", schema = "dmcredit")
public class AppBusinessDetail implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_occupation_detail_appoccupationkey_generator", sequenceName = "dmcredit.seq_pk_app_occupation_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_occupation_detail_appoccupationkey_generator")
	private Long appoccupationkey;

	@Convert(converter = UpperCaseConverter.class)
	private String businessname;

	@Convert(converter = UpperCaseConverter.class)
    private String businesspan;

	private Long businesskey;

	private Integer businessvintage;

	private String industryother;

	private String annualturnover;

	private Long declaredincome;

    @Convert(converter = UpperCaseConverter.class)
	private String gstnumber;

	private Long occupationtype;
	private Long nobkey;
	private BigDecimal netmthincome;

	private Long custindmastkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal profitaftertax;

	private BigDecimal avgbankbalance;

	private Long appattrbkey;

	private Integer presentbusinessvintage;

	private String officetype;

	private String cif;

	private Long subindumastkey;
	
	private Long qlfymastkey;
	
	private Long spclmastkey;
	
	private String spclforoth;
	
	private BigDecimal graduationyear;
	
	private BigDecimal postgraduationyear;
	
	private Long rcmastkey;
	
	private Long hospitalkey;
	
	private String hospitalnameother;
	
	private String practicetype;
	
	private String medicalregistrationnumber;
	
	private String caregistrationnumber;
	
	private Integer certificateofpractice;
    private String shopstatus;
	
	private String corporatelinkagetype;

	private Long businessnaturekey;

	public String getShopstatus() {
		return shopstatus;
	}

	public void setShopstatus(String shopstatus) {
		this.shopstatus = shopstatus;
	}

	public String getCorporatelinkagetype() {
		return corporatelinkagetype;
	}

	public void setCorporatelinkagetype(String corporatelinkagetype) {
		this.corporatelinkagetype = corporatelinkagetype;
	}

	public BigDecimal getProfitaftertax() {
		return profitaftertax;
	}

	public void setProfitaftertax(BigDecimal profitaftertax) {
		this.profitaftertax = profitaftertax;
	}

	public BigDecimal getAvgbankbalance() {
		return avgbankbalance;
	}

	public void setAvgbankbalance(BigDecimal avgbankbalance) {
		this.avgbankbalance = avgbankbalance;
	}

	public Long getAppoccupationkey() {
		return appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public String getBusinesspan() {
		return businesspan;
	}

	public void setBusinesspan(String businesspan) {
		this.businesspan = businesspan;
	}

	public Integer getBusinessvintage() {
		return businessvintage;
	}

	public Long getBusinesskey() {
		return businesskey;
	}

	public void setBusinesskey(Long businesskey) {
		this.businesskey = businesskey;
	}

	public void setBusinessvintage(Integer businessvintage) {
		this.businessvintage = businessvintage;
	}

	public String getIndustryother() {
		return industryother;
	}

	public void setIndustryother(String industryother) {
		this.industryother = industryother;
	}

	public String getAnnualturnover() {
		return annualturnover;
	}

	public void setAnnualturnover(String annualturnover) {
		this.annualturnover = annualturnover;
	}

	public Long getDeclaredincome() {
		return declaredincome;
	}

	public void setDeclaredincome(Long declaredincome) {
		this.declaredincome = declaredincome;
	}

	public String getGstnumber() {
		return gstnumber;
	}

	public void setGstnumber(String gstnumber) {
		this.gstnumber = gstnumber;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getOccupationtype() {
		return occupationtype;
	}

	public void setOccupationtype(Long occupationtype) {
		this.occupationtype = occupationtype;
	}

	public Long getNobkey() {
		return nobkey;
	}

	public void setNobkey(Long nobkey) {
		this.nobkey = nobkey;
	}

	public Long getCustindmastkey() {
		return custindmastkey;
	}

	public void setCustindmastkey(Long custindmastkey) {
		this.custindmastkey = custindmastkey;
	}

	public BigDecimal getNetmthincome() {
		return netmthincome;
	}

	public void setNetmthincome(BigDecimal netmthincome) {
		this.netmthincome = netmthincome;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	@Override
	public AppBusinessDetail clone() throws CloneNotSupportedException {
		AppBusinessDetail detail = new AppBusinessDetail();
		detail.setBusinessname(this.businessname);
		detail.setBusinesspan(this.businesspan);
		detail.setBusinesskey(this.businesskey);
		detail.setBusinessvintage(this.businessvintage);
		detail.setIndustryother(this.industryother);
		detail.setAnnualturnover(this.annualturnover);
		detail.setDeclaredincome(this.declaredincome);
		detail.setGstnumber(this.gstnumber);
		detail.setOccupationtype(this.occupationtype);
		detail.setNobkey(this.nobkey);
		detail.setNetmthincome(this.netmthincome);
		detail.setCustindmastkey(this.custindmastkey);
		detail.setIsactive(this.isactive);
		detail.setLstupdateby(this.lstupdateby);
		detail.setLstupdatedt(this.lstupdatedt);
		detail.setProfitaftertax(this.profitaftertax);
		detail.setAvgbankbalance(this.avgbankbalance);
		detail.setAppattrbkey(this.appattrbkey);
		detail.setPresentbusinessvintage(this.presentbusinessvintage);
		detail.setOfficetype(this.officetype);
		detail.setCif(this.cif);
		detail.setCaregistrationnumber(this.caregistrationnumber);
		detail.setCertificateofpractice(this.certificateofpractice);
		return detail;
	}

	public Integer getPresentbusinessvintage() {
		return presentbusinessvintage;
	}

	public void setPresentbusinessvintage(Integer presentbusinessvintage) {
		this.presentbusinessvintage = presentbusinessvintage;
	}

	public String getOfficetype() {
		return officetype;
	}

	public void setOfficetype(String officetype) {
		this.officetype = officetype;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public Long getSubindumastkey() {
		return subindumastkey;
	}

	public void setSubindumastkey(Long subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

	public Long getQlfymastkey() {
		return qlfymastkey;
	}

	public void setQlfymastkey(Long qlfymastkey) {
		this.qlfymastkey = qlfymastkey;
	}

	public Long getSpclmastkey() {
		return spclmastkey;
	}

	public void setSpclmastkey(Long spclmastkey) {
		this.spclmastkey = spclmastkey;
	}

	public String getSpclforoth() {
		return spclforoth;
	}

	public void setSpclforoth(String spclforoth) {
		this.spclforoth = spclforoth;
	}

	public BigDecimal getGraduationyear() {
		return graduationyear;
	}

	public void setGraduationyear(BigDecimal graduationyear) {
		this.graduationyear = graduationyear;
	}

	public BigDecimal getPostgraduationyear() {
		return postgraduationyear;
	}

	public void setPostgraduationyear(BigDecimal postgraduationyear) {
		this.postgraduationyear = postgraduationyear;
	}

	public Long getRcmastkey() {
		return rcmastkey;
	}

	public void setRcmastkey(Long rcmastkey) {
		this.rcmastkey = rcmastkey;
	}

	public Long getHospitalkey() {
		return hospitalkey;
	}

	public void setHospitalkey(Long hospitalkey) {
		this.hospitalkey = hospitalkey;
	}

	public String getHospitalnameother() {
		return hospitalnameother;
	}

	public void setHospitalnameother(String hospitalnameother) {
		this.hospitalnameother = hospitalnameother;
	}

	public String getPracticetype() {
		return practicetype;
	}

	public void setPracticetype(String practicetype) {
		this.practicetype = practicetype;
	}

	public String getMedicalregistrationnumber() {
		return medicalregistrationnumber;
	}

	public void setMedicalregistrationnumber(String medicalregistrationnumber) {
		this.medicalregistrationnumber = medicalregistrationnumber;
	}

	public String getCaregistrationnumber() {
		return caregistrationnumber;
	}

	public void setCaregistrationnumber(String caregistrationnumber) {
		this.caregistrationnumber = caregistrationnumber;
	}

	public Integer getCertificateofpractice() {
		return certificateofpractice;
	}

	public void setCertificateofpractice(Integer certificateofpractice) {
		this.certificateofpractice = certificateofpractice;
	}

	public Long getBusinessnaturekey() {
		return businessnaturekey;
	}

	public void setBusinessnaturekey(Long businessnaturekey) {
		this.businessnaturekey = businessnaturekey;
	}

}
