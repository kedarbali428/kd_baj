package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.NotBlank;

public class HLProductIntentBean {
	
	@NotBlank(message = "hlProductIntent cannot be null or empty")
	private String hlProductIntent;

	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	@Override
	public String toString() {
		return "HLProductIntentBean [hlProductIntent=" + hlProductIntent + "]";
	}
	
	

}
