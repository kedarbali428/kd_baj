package com.bajaj.markets.credit.application.bean;

import java.util.Set;

public class Rejection {

	private String rejectionSource;
	private Set<String> rejectCodeList;
	
	public String getRejectionSource() {
		return rejectionSource;
	}
	public void setRejectionSource(String rejectionSource) {
		this.rejectionSource = rejectionSource;
	}
	public Set<String> getRejectCodeList() {
		return rejectCodeList;
	}
	public void setRejectCodeList(Set<String> rejectCodeList) {
		this.rejectCodeList = rejectCodeList;
	}
	
	@Override
	public String toString() {
		return "Rejection [rejectionSource=" + rejectionSource + ", rejectCodeList=" + rejectCodeList + "]";
	}
}
