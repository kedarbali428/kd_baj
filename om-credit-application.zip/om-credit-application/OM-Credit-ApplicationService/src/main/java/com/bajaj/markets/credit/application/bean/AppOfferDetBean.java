package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.NotBlank;

import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.UpdateOffers;

/**
 * 
 * @author 738768
 * Bean for updating the product specific offers in app_offer_det_table.
 *
 */
public class AppOfferDetBean {

	private Long appOfferDetKey;
	private Long applicationKey;
	private Long appattrbkey;
	private Long principalKey;
	
	@NotBlank(groups = { UpdateOffers.class },message = "productCode cannot be null or empty")
	private String productCode;
	private Boolean isOfferAvailable;
	private String offerId;
	private String partnerOfferId;
	private Integer offerType;
	private String offerCustomerId;
	private BigDecimal offerAmt;
	private Integer offerTenure;
	
	private BigDecimal offerRoi;
	private BigDecimal offerProcessingFees;
	private Date offerStartDt;
	private Date offerExpiryDt;
	private Date offerAppliedDt;
	
	private Boolean lineAvailedFlg;
	private Integer offerAcceptsts;
	private Date offerAcceptDt;
	private String offerTypeCode;
	private String riskSegment;
	
	private Long offerSrcKey;
	private String prospectId;
	private String riskOfferType;
	private String generationRule;
	private String offerGenerationSource;
	
	private String riskClassification;
	private BigDecimal tlBaseRate;
	private BigDecimal isBaseRate;
	private String offerProgramCode;
	private String isCardHolder;
	private boolean deactivateOffers;
	private Integer offerPriority;
	
	private String source;
	private BigDecimal cibilScore;
	private String subSource;
	private BigDecimal appsScore;
	private String custSegment;
	private BigDecimal obligations;
	private BigDecimal isEmiAmount;
	private String offerStatus;

	public Long getAppOfferDetKey() {
		return appOfferDetKey;
	}

	public void setAppOfferDetKey(Long appOfferDetKey) {
		this.appOfferDetKey = appOfferDetKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Boolean getIsOfferAvailable() {
		return isOfferAvailable;
	}

	public void setIsOfferAvailable(Boolean isOfferAvailable) {
		this.isOfferAvailable = isOfferAvailable;
	}

	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public String getPartnerOfferId() {
		return partnerOfferId;
	}

	public void setPartnerOfferId(String partnerOfferId) {
		this.partnerOfferId = partnerOfferId;
	}

	public Integer getOfferType() {
		return offerType;
	}

	public void setOfferType(Integer offerType) {
		this.offerType = offerType;
	}

	public String getOfferCustomerId() {
		return offerCustomerId;
	}

	public void setOfferCustomerId(String offerCustomerId) {
		this.offerCustomerId = offerCustomerId;
	}
	
	public Integer getOfferTenure() {
		return offerTenure;
	}

	public void setOfferTenure(Integer offerTenure) {
		this.offerTenure = offerTenure;
	}

	public Date getOfferStartDt() {
		return offerStartDt;
	}

	public void setOfferStartDt(Date offerStartDt) {
		this.offerStartDt = offerStartDt;
	}

	public Date getOfferExpiryDt() {
		return offerExpiryDt;
	}

	public void setOfferExpiryDt(Date offerExpiryDt) {
		this.offerExpiryDt = offerExpiryDt;
	}

	public Date getOfferAppliedDt() {
		return offerAppliedDt;
	}

	public void setOfferAppliedDt(Date offerAppliedDt) {
		this.offerAppliedDt = offerAppliedDt;
	}

	public Boolean getLineAvailedFlg() {
		return lineAvailedFlg;
	}

	public void setLineAvailedFlg(Boolean lineAvailedFlg) {
		this.lineAvailedFlg = lineAvailedFlg;
	}

	public Integer getOfferAcceptsts() {
		return offerAcceptsts;
	}

	public void setOfferAcceptsts(Integer offerAcceptsts) {
		this.offerAcceptsts = offerAcceptsts;
	}

	public Date getOfferAcceptDt() {
		return offerAcceptDt;
	}

	public void setOfferAcceptDt(Date offerAcceptDt) {
		this.offerAcceptDt = offerAcceptDt;
	}

	public String getOfferTypeCode() {
		return offerTypeCode;
	}

	public void setOfferTypeCode(String offerTypeCode) {
		this.offerTypeCode = offerTypeCode;
	}

	public String getRiskSegment() {
		return riskSegment;
	}

	public void setRiskSegment(String riskSegment) {
		this.riskSegment = riskSegment;
	}

	public Long getOfferSrcKey() {
		return offerSrcKey;
	}

	public void setOfferSrcKey(Long offerSrcKey) {
		this.offerSrcKey = offerSrcKey;
	}

	public String getProspectId() {
		return prospectId;
	}

	public void setProspectId(String prospectId) {
		this.prospectId = prospectId;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public String getGenerationRule() {
		return generationRule;
	}

	public void setGenerationRule(String generationRule) {
		this.generationRule = generationRule;
	}

	public String getOfferGenerationSource() {
		return offerGenerationSource;
	}

	public void setOfferGenerationSource(String offerGenerationSource) {
		this.offerGenerationSource = offerGenerationSource;
	}

	public String getRiskClassification() {
		return riskClassification;
	}

	public void setRiskClassification(String riskClassification) {
		this.riskClassification = riskClassification;
	}

	public String getOfferProgramCode() {
		return offerProgramCode;
	}

	public void setOfferProgramCode(String offerProgramCode) {
		this.offerProgramCode = offerProgramCode;
	}

	public BigDecimal getOfferAmt() {
		return offerAmt;
	}

	public void setOfferAmt(BigDecimal offerAmt) {
		this.offerAmt = offerAmt;
	}

	public BigDecimal getOfferRoi() {
		return offerRoi;
	}

	public void setOfferRoi(BigDecimal offerRoi) {
		this.offerRoi = offerRoi;
	}

	public BigDecimal getOfferProcessingFees() {
		return offerProcessingFees;
	}

	public void setOfferProcessingFees(BigDecimal offerProcessingFees) {
		this.offerProcessingFees = offerProcessingFees;
	}

	public BigDecimal getTlBaseRate() {
		return tlBaseRate;
	}

	public void setTlBaseRate(BigDecimal tlBaseRate) {
		this.tlBaseRate = tlBaseRate;
	}

	public BigDecimal getIsBaseRate() {
		return isBaseRate;
	}

	public void setIsBaseRate(BigDecimal isBaseRate) {
		this.isBaseRate = isBaseRate;
	}
	
	public String getIsCardHolder() {
		return isCardHolder;
	}
	
	public void setIsCardHolder(String isCardHolder) {
		this.isCardHolder = isCardHolder;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public boolean isDeactivateOffers() {
		return deactivateOffers;
	}

	public void setDeactivateOffers(boolean deactivateOffers) {
		this.deactivateOffers = deactivateOffers;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Integer getOfferPriority() {
		return offerPriority;
	}

	public void setOfferPriority(Integer offerPriority) {
		this.offerPriority = offerPriority;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public BigDecimal getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(BigDecimal cibilScore) {
		this.cibilScore = cibilScore;
	}

	public String getSubSource() {
		return subSource;
	}

	public void setSubSource(String subSource) {
		this.subSource = subSource;
	}

	public BigDecimal getAppsScore() {
		return appsScore;
	}

	public void setAppsScore(BigDecimal appsScore) {
		this.appsScore = appsScore;
	}

	public String getCustSegment() {
		return custSegment;
	}

	public void setCustSegment(String custSegment) {
		this.custSegment = custSegment;
	}

	public BigDecimal getObligations() {
		return obligations;
	}

	public void setObligations(BigDecimal obligations) {
		this.obligations = obligations;
	}

	public BigDecimal getIsEmiAmount() {
		return isEmiAmount;
	}

	public void setIsEmiAmount(BigDecimal isEmiAmount) {
		this.isEmiAmount = isEmiAmount;
	}

	public String getOfferStatus() {
		return offerStatus;
	}

	public void setOfferStatus(String offerStatus) {
		this.offerStatus = offerStatus;
	}

	@Override
	public String toString() {
		return "AppOfferDetBean [appOfferDetKey=" + appOfferDetKey + ", applicationKey=" + applicationKey
				+ ", appattrbkey=" + appattrbkey + ", principalKey=" + principalKey + ", productCode=" + productCode
				+ ", isOfferAvailable=" + isOfferAvailable + ", offerId=" + offerId + ", partnerOfferId="
				+ partnerOfferId + ", offerType=" + offerType + ", offerCustomerId=" + offerCustomerId + ", offerAmt="
				+ offerAmt + ", offerTenure=" + offerTenure + ", offerRoi=" + offerRoi + ", offerProcessingFees="
				+ offerProcessingFees + ", offerStartDt=" + offerStartDt + ", offerExpiryDt=" + offerExpiryDt
				+ ", offerAppliedDt=" + offerAppliedDt + ", lineAvailedFlg=" + lineAvailedFlg + ", offerAcceptsts="
				+ offerAcceptsts + ", offerAcceptDt=" + offerAcceptDt + ", offerTypeCode=" + offerTypeCode
				+ ", riskSegment=" + riskSegment + ", offerSrcKey=" + offerSrcKey + ", prospectId=" + prospectId
				+ ", riskOfferType=" + riskOfferType + ", generationRule=" + generationRule + ", offerGenerationSource="
				+ offerGenerationSource + ", riskClassification=" + riskClassification + ", tlBaseRate=" + tlBaseRate
				+ ", isBaseRate=" + isBaseRate + ", offerProgramCode=" + offerProgramCode + ", isCardHolder="
				+ isCardHolder + ", deactivateOffers=" + deactivateOffers + ", offerPriority=" + offerPriority
				+ ", source=" + source + ", cibilScore=" + cibilScore + ", subSource=" + subSource + ", appsScore="
				+ appsScore + ", custSegment=" + custSegment + ", obligations=" + obligations + ", isEmiAmount="
				+ isEmiAmount + ", offerStatus=" + offerStatus + "]";
	}

	
}
