package com.bajaj.markets.credit.application.helper;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@Component
public class EncryptionDecryptionUtil {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private Environment env;

	private SecretKeySpec secretKey;
	private byte[] key;
	
	@Value("${IV_ENCRYPTION_KEY}")
	private String ivKey;
	
	@Value("${ENCRYPTION_KEY}")
	private String encryptionKey;

	private byte[] ivKeySecret;

	public static final String CIPHER_PADDING = "AES/GCM/NoPadding";

	private static final String CLASS_NAME = EncryptionDecryptionUtil.class.getCanonicalName();

	public void setKey(String myKey) {
		MessageDigest sha = null;
		try {
			key = myKey.getBytes("UTF-8");
			sha = MessageDigest.getInstance("SHA-1");
			key = sha.digest(key);
			key = Arrays.copyOf(key, 16);
			secretKey = new SecretKeySpec(key, "AES");

			byte[] ivKeyByte = ivKey.getBytes("UTF-8");
			ivKeyByte = sha.digest(ivKeyByte);
			ivKeySecret = Arrays.copyOf(ivKeyByte, 16);
		} catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Encryption Algorithm exception in setKey method : " + e);
			throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean(ApplicationConstants.CAS_1048, env.getProperty(ApplicationConstants.CAS_1048)));
		}

	}

	public String encrypt(String strToEncrypt) {
		try {
			setKey(encryptionKey);
			Cipher cipher = Cipher.getInstance(CIPHER_PADDING);
			GCMParameterSpec ivSpec = new GCMParameterSpec(cipher.getBlockSize() * 8, ivKeySecret);
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
			return Base64.getUrlEncoder()
					.encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8.displayName())));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Exception Occured while encrypting verification mail link : " + e);
			throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean(ApplicationConstants.CAS_1049, env.getProperty(ApplicationConstants.CAS_1049)));
		}
	}

	public String decrypt(String strToDecrypt) {
		try {
			setKey(encryptionKey);
			Cipher cipher = Cipher.getInstance(CIPHER_PADDING);
			GCMParameterSpec ivSpec = new GCMParameterSpec(cipher.getBlockSize() * 8, ivKeySecret);
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
			return new String(cipher.doFinal(Base64.getUrlDecoder().decode(strToDecrypt)));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"GenerateTokenUtility :- Exception Occured while decrypting verification mail link :" + e);
			throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean(ApplicationConstants.CAS_1050, env.getProperty(ApplicationConstants.CAS_1050)));
		}
	}
}