package com.bajaj.markets.credit.application.controller;

import javax.validation.constraints.Digits;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.PricingConsentCaptureRequest;
import com.bajaj.markets.credit.application.bean.PricingConsentRequest;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.AppPricingConsent;
import com.bajaj.markets.credit.application.service.ApplicationPricingConsentService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationPricingConsentController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	ApplicationPricingConsentService applicationPricingConsentService;

	private static final String CLASSNAME = ApplicationPricingConsentController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Save pricing  consent details", notes = "Save pricing consent details", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Pricing consent detail updated successfully.", response = AppPricingConsent.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/creditapplication/applications/{applicationKey}/pricingconsent", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> savePricingConsentDetail(@PathVariable("applicationKey") @Digits(fraction = 0, integer = 20, message = "applicationKey can not be other than digits") String applicationKey,
			@RequestBody PricingConsentRequest pricingConsentRequest,
			BindingResult bindingResult, @RequestHeader HttpHeaders headers) {

		AppPricingConsent response;
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updatePricingConsentDetail method :" + applicationKey);
		response = applicationPricingConsentService.savePricingConsentDetail(Long.valueOf(applicationKey),pricingConsentRequest);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"updatePricingConsentDetail method for pricingConsentDetails completed suceessfully");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.SYSTEM, Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch pricing consent details.", notes = "Fetch pricing consent details on the basis of consentRef.", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching pricing consent details successfully.", response = AppPricingConsent.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(path = "/v1/creditapplication/applications/{applicationKey}/pricingconsent/{consentref}")
	@CrossOrigin
	public ResponseEntity<Object> updatePricingConsentDetail(@RequestBody PricingConsentCaptureRequest pricingConsentCaptureRequest,
			@PathVariable("applicationKey") @Digits(fraction = 0, integer = 20, message = "applicationKey can not be other than digits") String applicationKey,
			@PathVariable("consentref") String consentRef,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Fetching getPricingConsentDetail started:" + consentRef);
		AppPricingConsent appPricingConsent;
		appPricingConsent = applicationPricingConsentService.updatePricingConsentDetail(Long.valueOf(applicationKey),pricingConsentCaptureRequest,consentRef);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Fetching getPricingConsentDetail completed successfully:" + applicationKey);
		return new ResponseEntity<>(appPricingConsent, HttpStatus.OK);
	}

}
