package com.bajaj.markets.credit.application.config;

import java.util.HashMap;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.HikariPoolMXBean;

@Configuration
@Component
@EnableJpaRepositories(basePackages = {
		"com.bajaj.markets.credit.application.repository.tx" }, entityManagerFactoryRef = "txEntityManager", transactionManagerRef = "txTransactionManager")
public class TxDataSourceConfig {

	@Autowired
	private Environment env;

	@Bean(name = "txHikariConfig")
	@ConfigurationProperties(prefix = "spring.txdatasource.hikari")
	public HikariConfig txHikariConfig() {
		return new HikariConfig();
	}

	@Bean(name = "txDataSource")
	@Primary
	public DataSource txDataSource(@Autowired @Qualifier("txHikariConfig") HikariConfig hikariConfig) {
		return new HikariDataSource(hikariConfig);
	}

	@Bean("txEntityManager")
	@Primary
	public LocalContainerEntityManagerFactoryBean txEntityManager(
			@Autowired @Qualifier("txDataSource") DataSource dataSource) {

		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dataSource);
		em.setPackagesToScan(new String[] { "com.bajaj.markets.credit.application.model" });
		em.setPersistenceUnitName("txPersistenceUnit");
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		HashMap<String, Object> properties = new HashMap<String, Object>();
		properties.put("hibernate.hbm2ddl.auto", env.getProperty("spring.jpa.hibernate.ddl-auto"));
		properties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
		properties.put("hibernate.naming.physical-strategy",
				env.getProperty("spring.jpa.hibernate.naming.physical-strategy"));
		em.setJpaPropertyMap(properties);
		return em;
	}

	@Bean(name = "txTransactionManager")
	@Primary
	public PlatformTransactionManager txTransactionManager(
			@Autowired @Qualifier("txEntityManager") EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}

	@Bean
	public HikariPoolMXBean txDataSourcePool(@Autowired @Qualifier("txDataSource") HikariDataSource hikariDataSource) {

		return hikariDataSource.getHikariPoolMXBean();
	}

}