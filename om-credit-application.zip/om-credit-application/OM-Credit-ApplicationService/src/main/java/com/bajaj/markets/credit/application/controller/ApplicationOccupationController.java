package com.bajaj.markets.credit.application.controller;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.BusinessOwnerDetails;
import com.bajaj.markets.credit.application.bean.Occupation;
import com.bajaj.markets.credit.application.bean.SalarySource;
import com.bajaj.markets.credit.application.bean.SalarySourceDetails;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.Business;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.OccupationType;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.Salaried;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationOccupationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller for updating & fetching Occupation detail resource
 * @author bflrdpuser1
 *
 */
@RestController
@Validated
public class ApplicationOccupationController {

	@Autowired
	private Validator validator;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private ApplicationOccupationService applicationOccupationService;
	
	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;
	
	private static final String CLASSNAME = ApplicationOccupationController.class.getName();
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Create & update Occupation Detail", notes = "Create & update Occupational Detail at application level", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Occupation detail added Successfully.", response = Occupation.class),
			@ApiResponse(code = 201, message = "Occupation type added Successfully.", response = Occupation.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application occupation detail not found",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 409, message = "Existing Occupation type can not be changed.",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PutMapping(value = "${api.omcreditapplicationservice.application.userprofiles.occupation.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateOccupation(@PathVariable("applicationid") String applicationId, @PathVariable("userattributekey") String userattributeKey, @RequestBody Occupation occupation,
			@RequestHeader HttpHeaders headers){
	if (StringUtils.isNumeric(applicationId) && StringUtils.isNumeric(userattributeKey)) {
		
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateOccupation method controller - applicationId: "+ applicationId + " userattributeKey: " + userattributeKey);
		Class validationObject = getValidationClass(occupation);
		Set<ConstraintViolation<Occupation>> validationErrors = validator.validate(occupation, validationObject);
		if(!CollectionUtils.isEmpty(validationErrors)){
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateOccupation method controller - resource validation failed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCA_005", validationErrors.stream().findFirst().get().getMessage()));
		}else {
			creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userattributeKey);
			Occupation response = applicationOccupationService.updateOccupationDetail(occupation,userattributeKey, applicationId);
			return new ResponseEntity<>(response, validationObject.equals(OccupationType.class)? HttpStatus.CREATED : HttpStatus.OK);
			}
		}
	else {
		logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
		throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
		new ErrorBean("OMCA_033", "ApplicationId & Userattributekey should be number."));
	}
	}
	
	private Class getValidationClass(Occupation occupation){
		
		if (null != occupation.getBusinessOwnerDetails()) {
			return Business.class;
		}else if(null != occupation.getSalariedDetail()){
			return Salaried.class;
		}else {
			return OccupationType.class;
		}
	}
	
	@Secured(value = {Role.INTERNAL,Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.SYSTEM,
			Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch Occupation Detail", notes = "Fetch occupation details on the basis of user attribute", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Occupation Detail found for the user attribute", response = Occupation.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Occupation Detail not found for the user attribute",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "${api.omcreditapplicationservice.application.userprofiles.occupation.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getOccupation(@PathVariable("applicationid") String applicationId , @PathVariable("userattributekey") String userattributeKey,
			@RequestHeader HttpHeaders headers){
	logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getOccupation method controller - applicationId: "+ applicationId + " userattributeKey: " + userattributeKey);
	if (StringUtils.isNumeric(applicationId) && StringUtils.isNumeric(userattributeKey)) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getOccupation method controller - applicationId: "+ applicationId + " userattributeKey: " + userattributeKey);
		creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userattributeKey);
		return new ResponseEntity<>(applicationOccupationService.getOccupationDetail(userattributeKey),HttpStatus.OK);
	}
	else {
	logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
	throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
	new ErrorBean("OMCA_033", "ApplicationId & Userattributekey should be number."));
	}
}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update salary details", notes = "update salary details for particular application coming from different source", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Application salary details updated successfully"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Salary details not found for the given applicationId or user attribute", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occured", response = ErrorBean.class)
	})
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/salary", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateSalary(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10,message = "userattributekey should be numeric & should not exceeds size") @PathVariable("userattributekey") String userAttributeKey, 
			@Valid @RequestBody SalarySourceDetails salarySourceDetails, BindingResult bindingResult,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Input updateSalary method Controller - applicationId: "+applicationId+", userattributeKey: "+userAttributeKey);
		
		applicationOccupationService.updateSalary(applicationId, userAttributeKey, salarySourceDetails);
		return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get salary details", notes = "Get salary details for particular application coming from different source", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Salary Detail found", response = SalarySource.class, responseContainer = "List"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Salary Detail not found",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/salary", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getSalaryDetails(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10,message = "userattributekey should be numeric & should not exceeds size") @PathVariable("userattributekey") String userAttributeKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside Controller : getSalaryDetails method start- applicationId: "+applicationId+", userattributeKey: "+userAttributeKey);
		List<SalarySource> response=applicationOccupationService.getSalaryDetails(applicationId, userAttributeKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside Controller : getSalaryDetails method end - applicationId : "+applicationId);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.SYSTEM,
			Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Deactivate Occupation Detail", notes = "Deactivate occupation details on the basis of userAttributeKey", httpMethod = "DELETE")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Deactivate occupation Detail found for the userAttributeKey"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Occupation Detail not found for the user attribute", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class)})
	@DeleteMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/occupation", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> deactivateOccupation(@PathVariable("applicationid") String applicationId,
			@PathVariable("userattributekey") String userattributeKey, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside deactivateOccupation method controller - applicationId: " + applicationId
						+ " userattributeKey: " + userattributeKey);
		if (StringUtils.isNumeric(applicationId) && StringUtils.isNumeric(userattributeKey)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Inside deactivateOccupation method controller - applicationId: " + applicationId
							+ " userattributeKey: " + userattributeKey);
			creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userattributeKey);
			applicationOccupationService.deactivateOccupationDetails(userattributeKey);
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_033", "ApplicationId & Userattributekey should be number."));
		}
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Create & update Occupation Detail", notes = "Create & update Occupational Detail at application level", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Occupation detail added Successfully.", response = Occupation.class),
			@ApiResponse(code = 201, message = "Occupation type added Successfully.", response = Occupation.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application occupation detail not found",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 409, message = "Existing Occupation type can not be changed.",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/businessdetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateBusinessDetails(@PathVariable("applicationid") String applicationId, @PathVariable("userattributekey") String userattributeKey, @RequestBody BusinessOwnerDetails businessOwnerDetails ,
			@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateBusinessDetails method controller - applicationId: " + applicationId
						+ " userattributeKey: " + userattributeKey);
		BusinessOwnerDetails response = new BusinessOwnerDetails();
		try {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Start Business Name updation for application : " + applicationId);
			 response = applicationOccupationService.updateBusinessDetails(businessOwnerDetails,applicationId,userattributeKey);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Name updation Successful for application : " + applicationId);
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Technical Exception occured while updating Business Name for application : "+applicationId , exception);
			throw exception;
		} 
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
