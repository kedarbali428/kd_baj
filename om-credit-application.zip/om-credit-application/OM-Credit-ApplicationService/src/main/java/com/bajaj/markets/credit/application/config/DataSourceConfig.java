package com.bajaj.markets.credit.application.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.HikariPoolMXBean;

@Configuration
public class DataSourceConfig {

	@Bean
	public HikariPoolMXBean databaseConnectionPool(@Autowired HikariDataSource hikariDataSource) {

		return hikariDataSource.getHikariPoolMXBean();
	}
}