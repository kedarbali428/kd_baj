package com.bajaj.markets.credit.application.controller;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.Digits;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.PropertyDetails;
import com.bajaj.markets.credit.application.bean.ServiceRequestDetails;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ServiceRequestServiceImpl;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ServiceRequestController {
	private static final String CLASSNAME = ApplicationPropertyController.class.getName();

	@Autowired
	private BFLLoggerUtil logger;

	@Autowired
	private ServiceRequestServiceImpl serviceRequestServiceImpl;
	
	@Secured(value = {  Role.CUSTOMER, Role.EMPLOYEE })
	@ApiOperation(value = "Fetch Sercie Request Details", notes = "This resource will be used to fetch service request details", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Service request details found for applicantKey successfully.", response = ServiceRequestDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),	
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/applicants/{applicantkey}/applicationinfo", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getServiceRequestDetails(
			@PathVariable(name="applicantkey",required = true) Long applicantkey,
	        @RequestParam(name = "mobile",required=false) @Digits(fraction = 0, integer = 10, message = "mobile number should be numeric & should not exceeds size") Long mobile,
            @RequestParam(name = "dob",required=false) @DateTimeFormat(pattern="yyyy-MM-dd") Date dob,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In getServiceRequestDetails controller method for applicantKey :" + applicantkey +",mobile : "+mobile+" and dob : "+dob);
		List<ServiceRequestDetails> serviceRequestList = serviceRequestServiceImpl.getServiceRequestDetails(applicantkey,mobile,dob);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Out getServiceRequestDetails controller method , service request details fetch completed successfully with response : "+serviceRequestList);
		return new ResponseEntity<>(serviceRequestList,HttpStatus.OK);
	}

}
