package com.bajaj.markets.credit.application.helper;

public class CreditApplicationConstant {

	public interface ParentApplication{}
	public interface ChildApplication{}
	public interface Salaried{}
	public interface Business{}
	public interface Doctor{}
	public interface CA{}
	public interface OccupationType{}
	public interface Qualification{}
	public interface UserProfileAttribute{}
	public interface BundleSelected{}
	public interface BundleNotSelected{}
	public interface ObligationAmount{}
	public interface Verificationdetail{}
	public interface DeactivateOffers{}
	public interface UpdateOffers{}
	public interface CreateUserProfileAttribute{}

	public interface Residence {
	}	
	
	public static final String CARDLIMIT = "cardLimit";
	public static final String PRODUCT_REF_NO = "productrefno";

	public static final String STATUS_API_COUNT = "statusApiCount"; 
	public static final String APPLICATION_CREATED_BY = "applicationCreatedBy"; 
	
	public static final String REQUESTED_CREDIT_AMOUNT = "requestedCreditAmount"; 
	public static final String REQUESTED_TENURE_MONTHS = "requestedTenureMonths";
	public static final String FPP_SELECTED_BY_USER="fppselectedbyuser";
	
	//Error Code
	public static final String CAS_13012 = "CAS-13012";
	public static final String CAS_13014 = "CAS-13014";
	public static final String l2CODE_OMSL = "OMSL";
	public static final String REJECTED_STATUS = "Rejected";
	public static final String CREDIT_REJECTED_STATUS = "Credit Rejected";
	public static final String l2CODE_CC = "CC";
	public static final String l2CODE_OMPL = "OMPL";
	
	public static final String FPPBRE_SOURCE ="CREDIT";
	public static final String FPPBRE_TARGET ="FPPBRE";
	
	public static final String MANDATEBRE_SOURCE = "CREDIT";
	public static final String MANDATEBRE_TARGET = "MANDATEBRE";
	
	public static final String STATUS_SUCCESS ="SUCCESS";
	public static final String STATUS_FAILURE ="FAILURE";
	
}
