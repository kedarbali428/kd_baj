package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class RejectionCodeBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long rejectcodekey;

	private String rejectcode;

	private String rejectcodedesc;

	private Long coolingPeriod;

	public RejectionCodeBean() {
	}

	public Long getRejectcodekey() {
		return this.rejectcodekey;
	}

	public void setRejectcodekey(Long rejectcodekey) {
		this.rejectcodekey = rejectcodekey;
	}

	public String getRejectcode() {
		return this.rejectcode;
	}

	public void setRejectcode(String rejectcode) {
		this.rejectcode = rejectcode;
	}

	public String getRejectcodedesc() {
		return this.rejectcodedesc;
	}

	public void setRejectcodedesc(String rejectcodedesc) {
		this.rejectcodedesc = rejectcodedesc;
	}

	public Long getCoolingPeriod() {
		return coolingPeriod;
	}

	public void setCoolingPeriod(Long coolingPeriod) {
		this.coolingPeriod = coolingPeriod;
	}

	@Override
	public String toString() {
		return "RejectionCodeBean [rejectcodekey=" + rejectcodekey + ", rejectcode=" + rejectcode + ", rejectcodedesc=" + rejectcodedesc + ", coolingPeriod="
				+ coolingPeriod + "]";
	}

}