package com.bajaj.markets.credit.application.helper;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.apache.commons.lang3.StringUtils;

@Converter()
public class UpperCaseConverter implements AttributeConverter<String, String> {

	@Override
	public String convertToDatabaseColumn(String attribute) {
		if (StringUtils.isEmpty(attribute)) {
			return null;
		} else {
			return attribute.toUpperCase();
		}
	}

	@Override
	public String convertToEntityAttribute(String dbData) {
		if (StringUtils.isEmpty(dbData)) {
			return null;
		} else {
			return dbData.toUpperCase();
		}
	}
}
