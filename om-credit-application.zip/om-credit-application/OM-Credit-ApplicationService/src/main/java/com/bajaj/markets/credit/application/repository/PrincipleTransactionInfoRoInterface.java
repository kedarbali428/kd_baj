package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.PrincipleTransactionInfo;

public interface PrincipleTransactionInfoRoInterface extends ReadInterface<PrincipleTransactionInfo, Long> {

	List<PrincipleTransactionInfo> findByApplicationkeyAndIsactive(Long applicationId, Integer isActive);

}
