package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the app_bundle database table.
 * 
 */
@Entity
@Table(name="app_bundle", schema = "dmcredit")

public class AppBundle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="APP_BUNDLE_APPBUNDLEKEY_GENERATOR", sequenceName="DMCREDIT.SEQ_PK_APP_BUNDLE", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="APP_BUNDLE_APPBUNDLEKEY_GENERATOR")
	private Long appbundlekey;

	private Long applicationkey;

	private Long bundleapplicationkey;

	private Integer bundleplankey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String source;
	
	private Long apploanpricingkey;
	
	private Integer bundlerevision;
	
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Long getApploanpricingkey() {
		return apploanpricingkey;
	}

	public void setApploanpricingkey(Long apploanpricingkey) {
		this.apploanpricingkey = apploanpricingkey;
	}

	public Integer getBundlerevision() {
		return bundlerevision;
	}

	public void setBundlerevision(Integer bundlerevision) {
		this.bundlerevision = bundlerevision;
	}

	public AppBundle() {
	}

	public Long getAppbundlekey() {
		return this.appbundlekey;
	}

	public void setAppbundlekey(Long appbundlekey) {
		this.appbundlekey = appbundlekey;
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getBundleapplicationkey() {
		return this.bundleapplicationkey;
	}

	public void setBundleapplicationkey(Long bundleapplicationkey) {
		this.bundleapplicationkey = bundleapplicationkey;
	}

	public Integer getBundleplankey() {
		return this.bundleplankey;
	}

	public void setBundleplankey(Integer bundleplankey) {
		this.bundleplankey = bundleplankey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}