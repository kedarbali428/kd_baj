package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class PrincipleProductDetailsOutputBean {

	private String loanTypeRecommendation;
	private String principleProductCode;
	private String riskOfferType;
	private List<FeesList> feesList;
	private BigDecimal finalLoanAmount;
	private BigDecimal netDisbursementAmount;
    private boolean vasAddedFlag;

	public String getLoanTypeRecommendation() {
		return loanTypeRecommendation;
	}

	public void setLoanTypeRecommendation(String loanTypeRecommendation) {
		this.loanTypeRecommendation = loanTypeRecommendation;
	}

	public String getPrincipleProductCode() {
		return principleProductCode;
	}

	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public List<FeesList> getFeesList() {
		return feesList;
	}

	public void setFeesList(List<FeesList> feesList) {
		this.feesList = feesList;
	}


	public BigDecimal getFinalLoanAmount() {
		return finalLoanAmount;
	}

	public void setFinalLoanAmount(BigDecimal finalLoanAmount) {
		this.finalLoanAmount = finalLoanAmount;
	}
	

	public BigDecimal getNetDisbursementAmount() {
		return netDisbursementAmount;
	}

	public void setNetDisbursementAmount(BigDecimal netDisbursementAmount) {
		this.netDisbursementAmount = netDisbursementAmount;
	}

	public boolean isVasAddedFlag() {
		return vasAddedFlag;
	}

	public void setVasAddedFlag(boolean vasAddedFlag) {
		this.vasAddedFlag = vasAddedFlag;
	}

	@Override
	public String toString() {
		return "PrincipleProductDetailsOutputBean [loanTypeRecommendation=" + loanTypeRecommendation
				+ ", principleProductCode=" + principleProductCode + ", riskOfferType=" + riskOfferType + ", feesList="
				+ feesList + ", finalLoanAmount=" + finalLoanAmount + ", netDisbursementAmount=" + netDisbursementAmount
				+ ", vasAddedFlag=" + vasAddedFlag + "]";
	}

}
