package com.bajaj.markets.credit.application.processor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.application.bean.LocationResponseBean;
import com.bajaj.markets.credit.application.bean.Notification;
import com.bajaj.markets.credit.application.bean.OccupationMasterBean;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class ApplicationProcessor {

	@Value("${api.notifications.sendnotifications.POST.url}")
	private String notificationUrl;

	@Value("${api.bitly.url.GET.url}")
	private String bitlyUrl;
	
	@Value("${ref.data.base.occupation.url}")
	private String refDataOccupationBaseUrl;
  
    @Value("${mobile.app.url}")
	private String appLink;
	
    @Value("${api.referencedata.pincode.GET.url}")
	private String refDataLocationUrl;
    
    @Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;
	
	private static final String CLASS_NAME = ApplicationProcessor.class.getCanonicalName();

	/**
	 * Call notification service to trigger the the notification.
	 * 
	 * @param notification
	 * @param notificationCode
	 */
	public String sendNotification(String notficationReqJson) {
		String payLoad = null;
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "sendNotification Start : "+notficationReqJson);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			
			ResponseEntity<Object> sendNotificationRes = creditApplicationServiceUtility
					.excuteRestCall(notificationUrl, HttpMethod.POST, String.class, null, notficationReqJson,
							headers);
			if (sendNotificationRes.getStatusCodeValue() == HttpStatus.OK.value()) {
				Object responseObject = sendNotificationRes.getBody();
				JSONObject responseJson = new JSONObject(responseObject.toString());
				payLoad = responseJson.get("payload").toString();
				if (!StringUtils.equalsIgnoreCase("null", payLoad)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Success Response from notification service : " + sendNotificationRes.getBody());
				} else {
					logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
							"sendEmailNSms - unable to send mail and sms - " + sendNotificationRes);
				}
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"sendEmailNSms - unable to send mail and sms - " + sendNotificationRes);
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "sendNotification End ");
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Exception while send notification : " + e);
		}
		return payLoad;
	}

	/**
	 * Prepare Request for notification. These parameters will be used in
	 * notification template to show the value of dynamic information in
	 * notification.
	 * 
	 * @param notification
	 * @param notificationCode
	 * @return
	 */
	public String prepareNotficReqJson(Notification notification) {
		String applicationId = notification.getApplicationId();
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "prepareNotficReqJson Start for applicationId : "+applicationId);
		JSONObject notificationJson = new JSONObject();
		notificationJson.put(ApplicationConstants.NOTIFICATION_TYPE_CODE, notification.getNotificationCode());
		JSONObject templatedata = new JSONObject();
		templatedata.put(ApplicationConstants.APPLICATIONKEY, notification.getApplicationId());
		templatedata.put(ApplicationConstants.CUSTOMER_NAME, notification.getCustomerName());
		templatedata.put(ApplicationConstants.PRODUCT, notification.getProduct());
		templatedata.put(ApplicationConstants.PRODUCT_LIST, notification.getProductList());
		templatedata.put(ApplicationConstants.PHONE_NUMBER, notification.getMobileNumber());
		templatedata.put(ApplicationConstants.PERSONAL_EMAIL, notification.getPersonalEmailId());
		templatedata.put(ApplicationConstants.LINK, notification.getLink());
		templatedata.put(ApplicationConstants.APPLINK, appLink);
		templatedata.put(ApplicationConstants.PRODUCT_COUNT, notification.getProductCount());
		templatedata.put(ApplicationConstants.PRODUCT_NAME, notification.getProductName());
		templatedata.put(ApplicationConstants.PRODUCT_MAX_ELIGIBILITY, notification.getMaxeligibility());
		boolean isBol = false;
		if(null != notification.getOccupationTypeCode() && "SEMP".equalsIgnoreCase(notification.getOccupationTypeCode())) {
			isBol = true;
		}
		templatedata.put("isBol", isBol);
		notificationJson.put(ApplicationConstants.TEMPLATE_DATA_MAP, templatedata);
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "prepareNotficReqJson End for applicationId : "+applicationId);
		return notificationJson.toString();
	}
	/**
	 * Call shorten url service to generate short url for communication.
	 * 
	 * @param actualUrl
	 * @param headers
	 * @return
	 */
	public String getShortUrl(String actualUrl, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getShortUrl - started");
		try {
			Map<String, String> queryParam = new HashMap<>();
			queryParam.put("url", actualUrl);
			ResponseEntity<Object> bitlyResponse = creditApplicationServiceUtility.excuteRestCall(bitlyUrl,
					HttpMethod.GET, String.class, queryParam, null, headers);
			if (bitlyResponse != null && bitlyResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
					Object responseObject = bitlyResponse.getBody();
					JSONObject responseJson = new JSONObject(responseObject.toString());
				String payLoad = responseJson.get("payload").toString();
				responseJson = new JSONObject(payLoad);
				return responseJson.get("shortURL").toString();
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Invalid status received while calling bitly URL - " + bitlyResponse);
				return actualUrl;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Exception occurred while calling bitly URL - " + e);
			return actualUrl;
		}
	}
	
	/**
	 * Call to get OccupationMaster from Reference domain.
	 * 
	 * @param occupationKey
	 * @return OccupationMasterBean
	 */
	public OccupationMasterBean getOccupationMaster(Long occupationKey) {
		OccupationMasterBean occupationMasterBean = null;
		try {
			ResponseEntity<Object> genderResp = creditApplicationServiceUtility.excuteRestCall(refDataOccupationBaseUrl,
					HttpMethod.GET, String.class, null, null, new HttpHeaders());
			List<OccupationMasterBean> occupationMasterBeanList = null;
			if (HttpStatus.OK.equals(genderResp.getStatusCode())) {
				occupationMasterBeanList = new ObjectMapper().readValue(genderResp.getBody().toString(),
						new TypeReference<List<OccupationMasterBean>>() {
						});
			}
			occupationMasterBeanList = occupationMasterBeanList.stream()
					.filter(item -> item.getOccupationKey() == occupationKey).collect(Collectors.toList());
			occupationMasterBean = null != occupationMasterBeanList ? occupationMasterBeanList.get(0) : null;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error in fetching occupation master ", e);
			throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean("OMCA_031", "Error in fetching occupation master"));
		}
		return occupationMasterBean;
	}

	public LocationResponseBean getLocationDetails(Long pincode) {
		LocationResponseBean locationResponseBean = null;
		Map<String, String> param = new HashMap<>();
		param.put("pincodeKey", pincode.toString());
		Gson g = new Gson();
		try {
			ResponseEntity<Object> excuteRestCall = creditApplicationServiceUtility.excuteRestCall(refDataLocationUrl,
					HttpMethod.GET, String.class, param, null, new HttpHeaders());
		
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				locationResponseBean = g.fromJson(excuteRestCall.getBody().toString(), LocationResponseBean.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error in fetching locationResponse ", e);
			throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean("OMCA_031", "Error in fetching locationResponse "));
		}
		return locationResponseBean;
	}
}

