package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the loan_purpose database table.
 * 
 */
@Entity
@Table(name="loan_purpose", schema = "dmcredit")
public class LoanPurpose implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long loanpurposekey;

	private Integer isactive;

	private String loanpurposecode;

	private String loanpurposedesc;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to Application
	@OneToMany(mappedBy="loanPurpose")
	private Set<Application> applications;

	public LoanPurpose() {
	}

	public Long getLoanpurposekey() {
		return this.loanpurposekey;
	}

	public void setLoanpurposekey(Long loanpurposekey) {
		this.loanpurposekey = loanpurposekey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public String getLoanpurposecode() {
		return this.loanpurposecode;
	}

	public void setLoanpurposecode(String loanpurposecode) {
		this.loanpurposecode = loanpurposecode;
	}

	public String getLoanpurposedesc() {
		return this.loanpurposedesc;
	}

	public void setLoanpurposedesc(String loanpurposedesc) {
		this.loanpurposedesc = loanpurposedesc;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Set<Application> getApplications() {
		return this.applications;
	}

	public void setApplications(Set<Application> applications) {
		this.applications = applications;
	}

	public Application addApplication(Application application) {
		getApplications().add(application);
		application.setLoanPurpose(this);

		return application;
	}

	public Application removeApplication(Application application) {
		getApplications().remove(application);
		application.setLoanPurpose(null);

		return application;
	}

}