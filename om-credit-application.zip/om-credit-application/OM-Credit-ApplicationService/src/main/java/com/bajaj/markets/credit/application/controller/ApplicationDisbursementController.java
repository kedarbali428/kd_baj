package com.bajaj.markets.credit.application.controller;

import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.BFLRefCodeDetailsRequest;
import com.bajaj.markets.credit.application.bean.BflRefSysCodeDetails;
import com.bajaj.markets.credit.application.bean.CreateCollateralDisbDetails;
import com.bajaj.markets.credit.application.bean.CustomerDisbDetails;
import com.bajaj.markets.credit.application.bean.DisbursementRecordsBean;
import com.bajaj.markets.credit.application.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.application.bean.ProductTypeBean;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationDisbursementService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationDisbursementController {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	ApplicationDisbursementService applicationDisbursementService;

	private static final String CLASSNAME = ApplicationDisbursementController.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch create customer details.", notes = "Fetch create customer details on the basis of applicationKey.", httpMethod = "GET")
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Fetching create customer details successfully.", response = CustomerDisbDetails.class,responseContainer = "List"),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
		@ApiResponse(code = 404, message = "Create customer details not found", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping("/v1/creditapplication/applications/{applicationkey}/customerdetails")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<CustomerDisbDetails> processCreateCustomerDetail(
			@PathVariable("applicationkey") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationKey can not be other than digits") Long applicationKey,
			@RequestParam(value = "userattrkey", required = false)@Digits(fraction = 0, integer = 10,message = "userattributekey should be numeric & should not exceeds size") Long userAttrKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Fetching create customer details started:" + applicationKey);
		CustomerDisbDetails createCustomerDisbDetails = applicationDisbursementService.processCreateCustomerDetails(applicationKey,userAttrKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Fetching create customer details completed successfully:" + createCustomerDisbDetails.toString());
		return new ResponseEntity<>(createCustomerDisbDetails, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch create collateral details.", notes = "Fetch create collateral details on the basis of applicationKey.", httpMethod = "GET")
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Fetching create Collateral details successfully.", response = CreateCollateralDisbDetails.class,responseContainer = "List"),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping("/v1/creditapplication/applications/{applicationkey}/collateraldetails")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> processCreateCollateralDetails(
			@PathVariable("applicationkey") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Fetching create Collateral details started:" + applicationKey);
		CreateCollateralDisbDetails createCollateralDisbDetails = applicationDisbursementService.processCreateCollateralDetails(applicationKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Fetching create Collateral details completed successfully:" + createCollateralDisbDetails.toString());
		return new ResponseEntity<>(createCollateralDisbDetails, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get Bfl Pennat Sys codes", notes = "Get Bfl Pennat Sys codes.", httpMethod = "POST")
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Get Bfl Pennat Sys codes successfull.", response = BflRefSysCodeDetails.class),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
		@ApiResponse(code = 404, message = "Bfl Pennat sys code not found", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping("/v1/creditapplication/bflrefcode")
	@CrossOrigin 
	public ResponseEntity<Object> getBflBankBranchCode(@RequestBody BFLRefCodeDetailsRequest omRefCodeRequest,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getBflRefSysCode details started:");
		BflRefSysCodeDetails response = applicationDisbursementService.getBflRefSysCode(omRefCodeRequest);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"getBflRefSysCode details completed successfully:");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	@Secured(value = {Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Add Disbursement Transactions", notes = "Tracks Disbursement failures", httpMethod = "POST")
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Disbursement Transactions added successfully.", response = DisbursementTrackerBean.class),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping("/v1/creditapplication/applications/disbursement/{tranchKey}/errors")
	@CrossOrigin 
	public ResponseEntity<Object> saveDisbursementErrors(@PathVariable("tranchKey")Long tranchKey ,@RequestBody DisbursementTrackerBean disbursementTrackerBean,
			@RequestHeader HttpHeaders headers) {
		disbursementTrackerBean.setApptranchedetkey(tranchKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "saveDisbursementErrors details started for Application: "+disbursementTrackerBean.getApplicationId()+" with Tranch: "+disbursementTrackerBean.getApptranchedetkey());
		DisbursementTrackerBean response = applicationDisbursementService.saveDisbursementErrors(disbursementTrackerBean);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"saveDisbursementErrors details completed for Application: "+disbursementTrackerBean.getApplicationId()+" with Tranch: "+disbursementTrackerBean.getApptranchedetkey());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER, Role.EMPLOYEE,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch Disbursement Errors", notes = "Fetch Disbursement Errors", httpMethod = "POST")
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Disbursement Transactions added successfully.", response = DisbursementTrackerBean.class),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping("/v1/creditapplication/applications/disbursement/{tranchKey}/errors")
	@CrossOrigin 
	public ResponseEntity<Object> getDisbursementErrors(@PathVariable("tranchKey") @NotBlank(message = "tranchKey cannot be null or empty") Long tranchKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getDisbursementErrors details started for tranchKey: "+tranchKey);
		List <DisbursementTrackerBean> response = applicationDisbursementService.getDisbursementErrors(tranchKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"getDisbursementErrors details completed for tranchKey: "+tranchKey);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch Disbursement Records", notes = "Fetch Disbursement Records", httpMethod = "GET")
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Disbursement records fetched successfully.", response = DisbursementRecordsBean.class),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping("/v1/creditapplication/applications/{applicationkey}/disbursement/reports")
	@CrossOrigin 
	public ResponseEntity<Object> getDisbursementRecords(@PathVariable("applicationkey") @NotBlank(message = "applicationkey cannot be null or empty") Long applicationkey,
			@RequestParam(name = "source", required = true) String source,@RequestParam(name = "target", required = true) String target,@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getDisbursementRecords started for applicationkey: "+applicationkey);
		List<DisbursementRecordsBean> response = applicationDisbursementService.getDisbursementRecords(applicationkey,source,target,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"getDisbursementRecords completed for applicationkey: "+applicationkey);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch ProductTypeDetails", notes = "Fetch ProductTypeDetails", httpMethod = "GET")
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "ProductTypeDetails fetched successfully.", response = ProductTypeBean.class),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping("/v1/creditapplication/applications/{applicationkey}/producttype")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> getProductTypeDetails(
			@PathVariable("applicationkey") @NotBlank(message = "applicationkey cannot be null or empty") Long applicationkey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"getProductTypeDetails started for applicationkey: " + applicationkey);
		ProductTypeBean response = applicationDisbursementService.getProductTypeDetails(applicationkey, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"getProductTypeDetails completed for applicationkey: " + applicationkey);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}