package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class PrincipalProductRejectionInput {

	private List<String> deviationCodes;
	private List<Rejection> rejectionList;
	private String principleProductCode;
	private Boolean existingCustomerType;
	private String principleCustType;
	private String childApplicationStatus;
	private String l4ProductCode;
	private String riskOfferType;
	
	public List<String> getDeviationCodes() {
		return deviationCodes;
	}
	public void setDeviationCodes(List<String> deviationCodes) {
		this.deviationCodes = deviationCodes;
	}
	public String getPrincipleProductCode() {
		return principleProductCode;
	}
	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}
	public Boolean getExistingCustomerType() {
		return existingCustomerType;
	}
	public void setExistingCustomerType(Boolean existingCustomerType) {
		this.existingCustomerType = existingCustomerType;
	}
	public String getPrincipleCustType() {
		return principleCustType;
	}
	public void setPrincipleCustType(String principleCustType) {
		this.principleCustType = principleCustType;
	}
	public String getChildApplicationStatus() {
		return childApplicationStatus;
	}
	public void setChildApplicationStatus(String childApplicationStatus) {
		this.childApplicationStatus = childApplicationStatus;
	}
	public List<Rejection> getRejectionList() {
		return rejectionList;
	}
	public void setRejectionList(List<Rejection> rejectionList) {
		this.rejectionList = rejectionList;
	}
	 
	public String getL4ProductCode() {
		return l4ProductCode;
	}
	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}
	public String getRiskOfferType() {
		return riskOfferType;
	}
	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}
	@Override
	public String toString() {
		return "PrincipalProductRejectionInput [deviationCodes=" + deviationCodes + ", rejectionList=" + rejectionList + ", principleProductCode="
				+ principleProductCode + ", existingCustomerType=" + existingCustomerType + ", principleCustType=" + principleCustType
				+ ", childApplicationStatus=" + childApplicationStatus + ", l4ProductCode=" + l4ProductCode + ", riskOfferType=" + riskOfferType + "]";
	}
}
