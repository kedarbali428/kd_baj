package com.bajaj.markets.credit.application.config;

import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

	@Value("${omcreditapplicationservice.httpclient.maxConnectionsPerRoute}")
	private int maxConnectionsPerRoute;

	@Value("${omcreditapplicationservice.httpclient.maxConnections}")
	private int maxConnections;

	@Value("${omcreditapplicationservice.httpclient.connectTimeoutMilliseconds:10000}")
	private int connectTimeout;

	@Value("${omcreditapplicationservice.httpclient.readTimeoutMilliseconds:180000}")
	private int readTimeout;

	@Bean
	public HttpClientConnectionManager httpClientConnectionManager() {
		PoolingHttpClientConnectionManager poolingConnectionManager = new PoolingHttpClientConnectionManager();
		poolingConnectionManager.setDefaultMaxPerRoute(maxConnectionsPerRoute);
		poolingConnectionManager.setMaxTotal(maxConnections);
		return poolingConnectionManager;
	}

	/*
	 * For proxy, below property needs to added by creating a file -
	 * om-credit-applicationservice-java.env in ENVIRONMENT repository
	 * JDK_JAVA_OPTIONS=-Dhttps.proxyHost=proxy.mgmt.bfsgodirect.com
	 * -Dhttps.proxyPort=3128
	 */
	@Bean
	@Primary
	public RestTemplate restTemplate(@Autowired HttpClientConnectionManager httpClientConnectionManager) {
		CloseableHttpClient httpClient = HttpClients.custom().useSystemProperties()
				.setConnectionManager(httpClientConnectionManager).disableCookieManagement().build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		requestFactory.setConnectionRequestTimeout(connectTimeout);
		requestFactory.setConnectTimeout(connectTimeout);
		requestFactory.setReadTimeout(readTimeout);
		return new RestTemplate(requestFactory);
	}

	@Bean
	public HttpConnectionPoolMXBean httpConnectionPool(
			@Autowired PoolingHttpClientConnectionManager httpClientConnectionManager) {
		return new HttpConnectionPoolMXBean(httpClientConnectionManager);
	}

	@ManagedResource
	public static class HttpConnectionPoolMXBean {

		private PoolingHttpClientConnectionManager poolingConnectionManager;

		public HttpConnectionPoolMXBean(PoolingHttpClientConnectionManager poolingConnectionManager) {
			this.poolingConnectionManager = poolingConnectionManager;
		}

		@ManagedAttribute
		public int getActiveHttpConnections() {
			return this.poolingConnectionManager.getTotalStats().getLeased();
		}

		@ManagedAttribute
		public int getThreadsAwaitingHttpConnections() {
			return this.poolingConnectionManager.getTotalStats().getPending();
		}

		@ManagedAttribute
		public int getIdleHttpConnections() {
			return this.poolingConnectionManager.getTotalStats().getAvailable();
		}

		@ManagedAttribute
		public int getTotalHttpConnectionsPerRoute() {
			return this.poolingConnectionManager.getDefaultMaxPerRoute();
		}

		@ManagedAttribute
		public int getTotalHttpConnections() {
			return this.poolingConnectionManager.getMaxTotal();
		}

		@ManagedOperation
		public void setTotalHttpConnectionsPerRoute(int maxPerRoute) {
			this.poolingConnectionManager.setDefaultMaxPerRoute(maxPerRoute);
		}

		@ManagedOperation
		public void setTotalHttpConnections(int maxTotal) {
			this.poolingConnectionManager.setMaxTotal(maxTotal);
		}
	}

}
