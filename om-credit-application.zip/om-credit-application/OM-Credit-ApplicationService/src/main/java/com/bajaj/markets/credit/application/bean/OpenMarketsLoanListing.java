package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class OpenMarketsLoanListing {

	private String eligibilityType;
	private Long maxEligibility;
	private Integer maxTenor;
	private Integer requiredLoanAmount;
	private Integer requiredTenor;
	private List<PrincialSelectedbyCustomer> principalProductDetails;
	private List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails;
	private String takeBacktoListingPage;
	private String customerSegment;
	private Boolean existingCustomerFlag;
	private List<BolProgramCodeList> bolProgramCodeList;
	private List<OfferDetailsListing> offerDetails;
	private Boolean segmentReRunFlag;
	
	public Boolean getSegmentReRunFlag() {
		return segmentReRunFlag;
	}

	public void setSegmentReRunFlag(Boolean segmentReRunFlag) {
		this.segmentReRunFlag = segmentReRunFlag;
	}

	public String getCustomerSegment() {
		return customerSegment;
	}

	public void setCustomerSegment(String customerSegment) {
		this.customerSegment = customerSegment;
	}

	public List<EstimatedNetMonthlySalaryDetails> getEstimatedNetMonthlySalaryDetails() {
		return estimatedNetMonthlySalaryDetails;
	}

	public void setEstimatedNetMonthlySalaryDetails(
			List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails) {
		this.estimatedNetMonthlySalaryDetails = estimatedNetMonthlySalaryDetails;
	}

	public String getTakeBacktoListingPage() {
		return takeBacktoListingPage;
	}

	public void setTakeBacktoListingPage(String takeBacktoListingPage) {
		this.takeBacktoListingPage = takeBacktoListingPage;
	}

	public List<PrincialSelectedbyCustomer> getPrincipalProductDetails() {
		return principalProductDetails;
	}

	public void setPrincipalProductDetails(List<PrincialSelectedbyCustomer> principalProductDetails) {
		this.principalProductDetails = principalProductDetails;
	}

	public Integer getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(Integer requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public Integer getRequiredTenor() {
		return requiredTenor;
	}

	public void setRequiredTenor(Integer requiredTenor) {
		this.requiredTenor = requiredTenor;
	}

	public String getEligibilityType() {
		return eligibilityType;
	}

	public void setEligibilityType(String eligibilityType) {
		this.eligibilityType = eligibilityType;
	}

	public Long getMaxEligibility() {
		return maxEligibility;
	}

	public void setMaxEligibility(Long maxEligibility) {
		this.maxEligibility = maxEligibility;
	}

	public Integer getMaxTenor() {
		return maxTenor;
	}

	public void setMaxTenor(Integer maxTenor) {
		this.maxTenor = maxTenor;
	}

	public List<BolProgramCodeList> getBolProgramCodeList() {
		return bolProgramCodeList;
	}

	public void setBolProgramCodeList(List<BolProgramCodeList> bolProgramCodeList) {
		this.bolProgramCodeList = bolProgramCodeList;
	}

	public Boolean getExistingCustomerFlag() {
		return existingCustomerFlag;
	}

	public void setExistingCustomerFlag(Boolean existingCustomerFlag) {
		this.existingCustomerFlag = existingCustomerFlag;
	}

	public List<OfferDetailsListing> getOfferDetails() {
		return offerDetails;
	}

	public void setOfferDetails(List<OfferDetailsListing> offerDetails) {
		this.offerDetails = offerDetails;
	}
	
}
