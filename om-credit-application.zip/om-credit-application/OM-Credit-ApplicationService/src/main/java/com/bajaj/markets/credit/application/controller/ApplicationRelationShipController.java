package com.bajaj.markets.credit.application.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.ApplicationRelationShipDetails;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationRelationShipService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationRelationShipController {

	@Autowired
	private ApplicationRelationShipService applicationRelationShipService;

	@Autowired
	private BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = ApplicationRelationShipController.class.getCanonicalName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Save Application Relationship endpoint", notes = "This api will be used to update relationship on application", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "RelationShip updated successfully.", response = ApplicationRelationShipDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/relation", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<ApplicationRelationShipDetails> saveRelationShip(
			@PathVariable(name = "applicationid", required = true) @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@Valid @RequestBody ApplicationRelationShipDetails applicationRelationShipDetails,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "saveRelationShip start for app id " + applicationId
				+ " for " + applicationRelationShipDetails.toString());
		ApplicationRelationShipDetails applicationRelationShipDetailsRes = applicationRelationShipService
				.saveRelationShip(applicationId, applicationRelationShipDetails);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "saveRelationShip End for app id " + applicationId
				+ " with " + applicationRelationShipDetailsRes.toString());
		return new ResponseEntity<>(applicationRelationShipDetailsRes, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Get Application Relationship endpoint", notes = "This api will be used to get relationship of application", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "RelationShip fetched successfully.", response = ApplicationRelationShipDetails.class, responseContainer = "List"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/relation", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<List<ApplicationRelationShipDetails>> getRelationShip(
			@PathVariable(name = "applicationid", required = true) @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestParam(required = false, name = "relationcodemasterkey") String relationCodeMasterKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getRelationShip Start for app id " + applicationId);
		List<ApplicationRelationShipDetails> applicationRelationShipDetails = applicationRelationShipService
				.getRelationShip(applicationId, relationCodeMasterKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getRelationShip End for app id " + applicationId
				+ " with " + applicationRelationShipDetails.toString());
		return new ResponseEntity<>(applicationRelationShipDetails, HttpStatus.OK);
	}

}
