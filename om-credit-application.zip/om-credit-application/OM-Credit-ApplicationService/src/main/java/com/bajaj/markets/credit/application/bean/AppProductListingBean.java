package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class AppProductListingBean{
	private BigDecimal annualFee;
	private BigDecimal isEligible;
	private String eligibilityType;
	private BigDecimal requiredLoanAmount;
	private Integer tenure;
	private String loanTypeRecommendation;
	private Integer preApproved;
	private String riskOfferType;
	
	public BigDecimal getAnnualFee() {
		return annualFee;
	}
	public void setAnnualFee(BigDecimal annualFee) {
		this.annualFee = annualFee;
	}
	public BigDecimal getIsEligible() {
		return isEligible;
	}
	public void setIsEligible(BigDecimal isEligible) {
		this.isEligible = isEligible;
	}
	public String getEligibilityType() {
		return eligibilityType;
	}
	public void setEligibilityType(String eligibilityType) {
		this.eligibilityType = eligibilityType;
	}
	public BigDecimal getRequiredLoanAmount() {
		return requiredLoanAmount;
	}
	public void setRequiredLoanAmount(BigDecimal requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}
	public Integer getTenure() {
		return tenure;
	}
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}
	public String getLoanTypeRecommendation() {
		return loanTypeRecommendation;
	}
	public void setLoanTypeRecommendation(String loanTypeRecommendation) {
		this.loanTypeRecommendation = loanTypeRecommendation;
	}
	public Integer getPreApproved() {
		return preApproved;
	}
	public void setPreApproved(Integer preApproved) {
		this.preApproved = preApproved;
	}
	public String getRiskOfferType() {
		return riskOfferType;
	}
	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}
	@Override
	public String toString() {
		return "AppProductListingBean [annualFee=" + annualFee + ", isEligible=" + isEligible + ", eligibilityType="
				+ eligibilityType + ", requiredLoanAmount=" + requiredLoanAmount + ", tenure=" + tenure
				+ ", loanTypeRecommendation=" + loanTypeRecommendation + ", preApproved=" + preApproved
				+ ", riskOfferType=" + riskOfferType + "]";
	}
}
