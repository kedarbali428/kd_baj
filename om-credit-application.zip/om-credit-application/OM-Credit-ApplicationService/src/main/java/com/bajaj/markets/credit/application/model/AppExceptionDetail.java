package com.bajaj.markets.credit.application.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "app_exception_detail", schema = "dmcredit")
public class AppExceptionDetail {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long appexceptiondtlkey;

	private Long applicationkey;

	private Integer substagekey;

	private Integer appcompletionper;

	private Long raisedby;

	private String status;

	private Integer isactive;

	private Date raiseddt;

	private Long lstupdateby;

	private Date lstupdatedt;	
	
	private Long exceptionraisedto;

	public Long getAppexceptiondtlkey() {
		return appexceptiondtlkey;
	}

	public void setAppexceptiondtlkey(Long appexceptiondtlkey) {
		this.appexceptiondtlkey = appexceptiondtlkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getSubstagekey() {
		return substagekey;
	}

	public void setSubstagekey(Integer substagekey) {
		this.substagekey = substagekey;
	}

	public Integer getAppcompletionper() {
		return appcompletionper;
	}

	public void setAppcompletionper(Integer appcompletionper) {
		this.appcompletionper = appcompletionper;
	}

	public Long getRaisedby() {
		return raisedby;
	}

	public void setRaisedby(Long raisedby) {
		this.raisedby = raisedby;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getRaiseddt() {
		return raiseddt;
	}

	public void setRaiseddt(Date raiseddt) {
		this.raiseddt = raiseddt;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Date getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Date lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getExceptionraisedto() {
		return exceptionraisedto;
	}

	public void setExceptionraisedto(Long exceptionraisedto) {
		this.exceptionraisedto = exceptionraisedto;
	}
	
	

}
