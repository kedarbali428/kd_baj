package com.bajaj.markets.credit.application.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bajaj.markets.credit.application.model.AppVerificationDetail;

public interface AppVerificationDetailRoInterface extends ReadInterface<AppVerificationDetail, Long> {

	AppVerificationDetail findByApplicationkeyAndIsactiveAndVerificationattrb(Long applicationkey, Integer isActive,
			String verificationAttr);

	AppVerificationDetail findByApplicationkeyAndIsactiveAndVerificationsrc(Long valueOf, Integer isactive, String src);

	AppVerificationDetail findByApplicationkeyAndVerificationsrcAndVerificationattrbAndIsactive(Long valueOf,
			String src, String attr, Integer isactive);

	Set<AppVerificationDetail> findByApplicationkeyAndIsactive(Long applicationkey, Integer isactive);

	@Query("select avd from AppVerificationDetail avd where applicationkey = :applicationkey AND "
			+ "verificationattrb IN (:verificationattrbs) AND isactive = 1")
	List<AppVerificationDetail> findByApplicationKeyAndVerificationattrbAndIsactive(
			@Param("applicationkey") Long applicationKey, @Param("verificationattrbs") List<String> verificationAttrbs);

	@Query("select avd from AppVerificationDetail avd where applicationkey = ?1 AND "
			+ "verificationattrb = ?2 AND isactive = 1 ORDER BY verificationdt DESC")
	List<AppVerificationDetail> findByApplicationkeyAndVerificationattrb(@Param("applicationkey") Long applicationkey,
			@Param("verificationAttr") String verificationAttr);

}
