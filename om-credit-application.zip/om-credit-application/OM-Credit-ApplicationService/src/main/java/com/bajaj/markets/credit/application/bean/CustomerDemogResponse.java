package com.bajaj.markets.credit.application.bean;

public class CustomerDemogResponse {

	private Boolean isOTPValid;

	public Boolean getIsOTPValid() {
		return isOTPValid;
	}

	public void setIsOTPValid(Boolean isOTPValid) {
		this.isOTPValid = isOTPValid;
	}
}
