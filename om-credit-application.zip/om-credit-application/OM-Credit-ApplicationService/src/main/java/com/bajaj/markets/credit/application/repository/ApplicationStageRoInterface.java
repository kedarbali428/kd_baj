package com.bajaj.markets.credit.application.repository;

import com.bajaj.markets.credit.application.model.ApplicationStage;

public interface ApplicationStageRoInterface extends ReadInterface<ApplicationStage, Long> {

	ApplicationStage findByApplicationkeyAndIsactive(Long applicationKey, Integer isActive);
}
