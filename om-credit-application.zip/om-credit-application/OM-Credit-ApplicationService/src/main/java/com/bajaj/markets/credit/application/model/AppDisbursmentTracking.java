package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the app_bundle database table.
 * 
 */
@Entity
@Table(name="app_disbursment_tracking", schema = "dmcredit")

public class AppDisbursmentTracking  {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long appdisbursmenttrackkey;
	
	private Long apptranchedetkey;
	
	private String status;
	
	private String disbursmentstage;
	
	private String error;
	
	private Long errorretryable;
	
	private String errorreason;
	
	private Long isActive;
	
	private Long lstupdateby;
	
	private Timestamp lstupdatedt;

	public Long getAppdisbursmenttrackkey() {
		return appdisbursmenttrackkey;
	}

	public void setAppdisbursmenttrackkey(Long appdisbursmenttrackkey) {
		this.appdisbursmenttrackkey = appdisbursmenttrackkey;
	}

	public Long getApptranchedetkey() {
		return apptranchedetkey;
	}

	public void setApptranchedetkey(Long apptranchedetkey) {
		this.apptranchedetkey = apptranchedetkey;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDisbursmentstage() {
		return disbursmentstage;
	}

	public void setDisbursmentstage(String disbursmentstage) {
		this.disbursmentstage = disbursmentstage;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getErrorreason() {
		return errorreason;
	}

	public void setErrorreason(String errorreason) {
		this.errorreason = errorreason;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getErrorretryable() {
		return errorretryable;
	}

	public void setErrorretryable(Long errorretryable) {
		this.errorretryable = errorretryable;
	}

	public Long getIsActive() {
		return isActive;
	}

	public void setIsActive(Long isActive) {
		this.isActive = isActive;
	}
	
	
	

}