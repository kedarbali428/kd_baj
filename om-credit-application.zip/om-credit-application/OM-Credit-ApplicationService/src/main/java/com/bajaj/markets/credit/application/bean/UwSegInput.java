package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class UwSegInput {
	
	private String applicationId;
	
	private String loanType;
	
	private String employerMasterCategory;
	
	private String employmentVerificationByKarza;
	
	private String officialMailVerification;
	
	private String creditVidyaRiskCategory;
	
	private String employerSubCategory;
	
	private String cityLocation;                
	
	private Integer cibilScore;
	
	private Integer appsScore;
	
	private Integer loanTicketSize;           
	
	private Integer foir;
	
	private boolean additionalCibilFlag;
	
	private boolean nsdlNameMatchFlag;
	
	private boolean isETB;
	
	private List<SalaryDetail> salaryDetail;
	
	private String pan;
	
	private String dob;
	
	private String segmentation;
	
	private String residenceType;
	
	public String getSegmentation() {
		return segmentation;
	}

	public void setSegmentation(String segmentation) {
		this.segmentation = segmentation;
	}

	public String getResidenceType() {
		return residenceType;
	}

	public void setResidenceType(String residenceType) {
		this.residenceType = residenceType;
	}

	public String getEmploymentVerificationByKarza() {
		return employmentVerificationByKarza;
	}

	public void setEmploymentVerificationByKarza(String employmentVerificationByKarza) {
		this.employmentVerificationByKarza = employmentVerificationByKarza;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getEmployerMasterCategory() {
		return employerMasterCategory;
	}

	public void setEmployerMasterCategory(String employerMasterCategory) {
		this.employerMasterCategory = employerMasterCategory;
	}

	public String getOfficialMailVerification() {
		return officialMailVerification;
	}

	public void setOfficialMailVerification(String officialMailVerification) {
		this.officialMailVerification = officialMailVerification;
	}

	public String getCreditVidyaRiskCategory() {
		return creditVidyaRiskCategory;
	}

	public void setCreditVidyaRiskCategory(String creditVidyaRiskCategory) {
		this.creditVidyaRiskCategory = creditVidyaRiskCategory;
	}

	public String getEmployerSubCategory() {
		return employerSubCategory;
	}

	public void setEmployerSubCategory(String employerSubCategory) {
		this.employerSubCategory = employerSubCategory;
	}

	public String getCityLocation() {
		return cityLocation;
	}

	public void setCityLocation(String cityLocation) {
		this.cityLocation = cityLocation;
	}

	public Integer getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(Integer cibilScore) {
		this.cibilScore = cibilScore;
	}

	public Integer getAppsScore() {
		return appsScore;
	}

	public void setAppsScore(Integer appsScore) {
		this.appsScore = appsScore;
	}

	public Integer getLoanTicketSize() {
		return loanTicketSize;
	}

	public void setLoanTicketSize(Integer loanTicketSize) {
		this.loanTicketSize = loanTicketSize;
	}

	public Integer getFoir() {
		return foir;
	}

	public void setFoir(Integer foir) {
		this.foir = foir;
	}

	public boolean isAdditionalCibilFlag() {
		return additionalCibilFlag;
	}

	public void setAdditionalCibilFlag(boolean additionalCibilFlag) {
		this.additionalCibilFlag = additionalCibilFlag;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public boolean isNsdlNameMatchFlag() {
		return nsdlNameMatchFlag;
	}

	public void setNsdlNameMatchFlag(boolean nsdlNameMatchFlag) {
		this.nsdlNameMatchFlag = nsdlNameMatchFlag;
	}

	public boolean isETB() {
		return isETB;
	}

	public void setETB(boolean isETB) {
		this.isETB = isETB;
	}

	public List<SalaryDetail> getSalaryDetails() {
		return salaryDetail;
	}

	public void setSalaryDetails(List<SalaryDetail> salaryDetail) {
		this.salaryDetail = salaryDetail;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "UwSegInput [applicationId=" + applicationId + ", loanType=" + loanType + ", employerMasterCategory="
				+ employerMasterCategory + ", employmentVerificationByKarza=" + employmentVerificationByKarza
				+ ", officialMailVerification=" + officialMailVerification + ", creditVidyaRiskCategory="
				+ creditVidyaRiskCategory + ", employerSubCategory=" + employerSubCategory + ", cityLocation="
				+ cityLocation + ", cibilScore=" + cibilScore + ", appsScore=" + appsScore + ", loanTicketSize="
				+ loanTicketSize + ", foir=" + foir + ", additionalCibilFlag=" + additionalCibilFlag
				+ ", nsdlNameMatchFlag=" + nsdlNameMatchFlag + ", isETB=" + isETB + ", salaryDetails=" + salaryDetail
				+ ", pan=" + pan + ", dob=" + dob + "]";
	}
	
}
