package com.bajaj.markets.credit.application.bean;

public class FppExternalRequest {

	private OpenArcFppInput openArcFppInput;
	private AdditionalParameterDetail additionalParameterDetail;
	
	public OpenArcFppInput getOpenArcFppInput() {
		return openArcFppInput;
	}

	public AdditionalParameterDetail getAdditionalParameterDetail() {
		return additionalParameterDetail;
	}

	public void setOpenArcFppInput(OpenArcFppInput openArcFppInput) {
		this.openArcFppInput = openArcFppInput;
	}

	public void setAdditionalParameterDetail(AdditionalParameterDetail additionalParameterDetail) {
		this.additionalParameterDetail = additionalParameterDetail;
	}

}
