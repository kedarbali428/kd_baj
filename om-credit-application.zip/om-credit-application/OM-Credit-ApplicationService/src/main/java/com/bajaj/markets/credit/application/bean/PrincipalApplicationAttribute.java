package com.bajaj.markets.credit.application.bean;

import java.util.Date;

public class PrincipalApplicationAttribute {

	private Long appattrbkey;

	private Date dob;

	private Long mobile;

	private String firstname;

	private String middlename;

	private String lastname;

	private Long salutationkey;

	private Long maritalstatuskey;

	private Long genderkey;

	private Long residencetypekey;

	private Long applicantkey;

	private String pan;

	private Long applicanttype;

	private String qualification;

	private String mothername;

	private String fathername;

	private String nametobeprintedoncard;

	private String spousename;

	private Long relationcodemastkey;

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Long getSalutationkey() {
		return salutationkey;
	}

	public void setSalutationkey(Long salutationkey) {
		this.salutationkey = salutationkey;
	}

	public Long getMaritalstatuskey() {
		return maritalstatuskey;
	}

	public void setMaritalstatuskey(Long maritalstatuskey) {
		this.maritalstatuskey = maritalstatuskey;
	}

	public Long getGenderkey() {
		return genderkey;
	}

	public void setGenderkey(Long genderkey) {
		this.genderkey = genderkey;
	}

	public Long getResidencetypekey() {
		return residencetypekey;
	}

	public void setResidencetypekey(Long residencetypekey) {
		this.residencetypekey = residencetypekey;
	}

	public Long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public Long getApplicanttype() {
		return applicanttype;
	}

	public void setApplicanttype(Long applicanttype) {
		this.applicanttype = applicanttype;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getMothername() {
		return mothername;
	}

	public void setMothername(String mothername) {
		this.mothername = mothername;
	}

	public String getFathername() {
		return fathername;
	}

	public void setFathername(String fathername) {
		this.fathername = fathername;
	}

	public String getNametobeprintedoncard() {
		return nametobeprintedoncard;
	}

	public void setNametobeprintedoncard(String nametobeprintedoncard) {
		this.nametobeprintedoncard = nametobeprintedoncard;
	}

	public String getSpousename() {
		return spousename;
	}

	public void setSpousename(String spousename) {
		this.spousename = spousename;
	}

	public Long getRelationcodemastkey() {
		return relationcodemastkey;
	}

	public void setRelationcodemastkey(Long relationcodemastkey) {
		this.relationcodemastkey = relationcodemastkey;
	}

	@Override
	public String toString() {
		return "PrincipalApplicationAttribute [appattrbkey=" + appattrbkey + ", dob=" + dob + ", mobile=" + mobile
				+ ", firstname=" + firstname + ", middlename=" + middlename + ", lastname=" + lastname
				+ ", salutationkey=" + salutationkey + ", maritalstatuskey=" + maritalstatuskey + ", genderkey="
				+ genderkey + ", residencetypekey=" + residencetypekey + ", applicantkey=" + applicantkey + ", pan="
				+ pan + ", applicanttype=" + applicanttype + ", qualification=" + qualification + ", mothername="
				+ mothername + ", fathername=" + fathername + ", nametobeprintedoncard=" + nametobeprintedoncard
				+ ", spousename=" + spousename + ", relationcodemastkey=" + relationcodemastkey + "]";
	}

}
