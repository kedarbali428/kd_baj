package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.DeactivatedOffer;

public interface DeactivatedOfferRoInterface extends ReadInterface<DeactivatedOffer, Long> {

	public List<DeactivatedOffer> findByMobileAndIsactive(String mobile, Integer isactive);

}
