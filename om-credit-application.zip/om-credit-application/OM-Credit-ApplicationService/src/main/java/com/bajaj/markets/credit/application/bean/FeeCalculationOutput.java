package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class FeeCalculationOutput {
	private List<PrincipleProductDetailsOutputBean> principleProductDetails;

	public List<PrincipleProductDetailsOutputBean> getPrincipleProductDetails() {
		return principleProductDetails;
	}

	public void setPrincipleProductDetails(List<PrincipleProductDetailsOutputBean> principleProductDetails) {
		this.principleProductDetails = principleProductDetails;
	}

	@Override
	public String toString() {
		return "FeeCalculationOutput [principleProductDetails=" + principleProductDetails + "]";
	}

}
