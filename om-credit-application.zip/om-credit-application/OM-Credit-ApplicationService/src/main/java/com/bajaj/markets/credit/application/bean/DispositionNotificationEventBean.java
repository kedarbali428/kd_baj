package com.bajaj.markets.credit.application.bean;

import java.util.Map;

import com.bajaj.markets.credit.bean.EventSchema;

public class DispositionNotificationEventBean {

	private String eventName;
	private String eventType;
	private EventSchema eventSchema;
	private Object payload;
	private Map<String, String> messageFilterAttributes;
	private Map<String, String> headers;
	
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public EventSchema getEventSchema() {
		return eventSchema;
	}
	public void setEventSchema(EventSchema eventSchema) {
		this.eventSchema = eventSchema;
	}
	public Object getPayload() {
		return payload;
	}
	public void setPayload(Object payload) {
		this.payload = payload;
	}
	public Map<String, String> getMessageFilterAttributes() {
		return messageFilterAttributes;
	}
	public void setMessageFilterAttributes(Map<String, String> messageFilterAttributes) {
		this.messageFilterAttributes = messageFilterAttributes;
	}
	public Map<String, String> getHeaders() {
		return headers;
	}
	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}
}
