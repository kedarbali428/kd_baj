package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

public class CoapplicantRequest {

	@Pattern(regexp="^[A-Za-z]*$",message = "Invalid Input middleName")
	private String middleName;
	
	private String gender;
	
	@Pattern(regexp="^[a-zA-Z\\s]*$",message = "Invalid Input fatherName")
	private String fatherName;
	
	@Pattern(regexp="^[a-zA-Z\\s]*$",message = "Invalid Input motherName")
	private String motherName;
	
	@Pattern(regexp="^[A-Za-z]*$",message = "Invalid Input maritalStatus")
	private String maritalStatus;
	
	@Pattern(regexp="^[a-zA-Z0-9]*$",message = "Invalid Input relation")
	private String relation;
	
	@Pattern(regexp="^[a-zA-Z0-9]*$",message = "Invalid Input occupation")
	private String occupation;
	
	private String address1;
	private String address2;
	
	@Digits(fraction = 0, integer = 6, message = "pincode can not be other than digits")
	private Long pincode;
	
	private String email;
	
	@Digits(fraction = 0, integer = 10, message = "applicantKey can not be other than digits")
	private Long applicantKey;
	
	
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public Long getPincode() {
		return pincode;
	}
	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}
	
}
