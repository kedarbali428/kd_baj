package com.bajaj.markets.credit.application.repository;

import java.util.Optional;

import com.bajaj.markets.credit.application.model.AppCreditReviewStatus;

public interface ApplicationCreditStatusRoInterface extends ReadInterface<AppCreditReviewStatus, Long> {

	Optional<AppCreditReviewStatus> findByApplicationkeyAndIsactive(Long applicationkey, Integer isactive);

}
