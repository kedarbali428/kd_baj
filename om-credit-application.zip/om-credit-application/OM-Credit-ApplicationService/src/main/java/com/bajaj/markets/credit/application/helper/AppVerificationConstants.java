package com.bajaj.markets.credit.application.helper;

/**
 * Enum containing all application verification's attribute and source enums 
 * 
 * @author 764504
 *
 */
public class AppVerificationConstants {

	public enum Source {
		KARZABRE("KARZABRE");

		private String value;

		Source(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}

	public enum Attribute {
		EMPLOYER("EMPLOYER");

		private String value;

		Attribute(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}

}
