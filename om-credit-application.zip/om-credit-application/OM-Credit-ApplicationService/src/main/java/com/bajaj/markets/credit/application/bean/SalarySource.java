package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class SalarySource {

	@NotBlank(message = "salary source cannot be null or empty")
	private String salarySource;

	@NotNull(message = "salary value cannot be null or empty")
	@Digits(message = "salary should be numeric & should not exceeds size", fraction = 0, integer = 8)
	private Integer salary;

	public String getSalarySource() {
		return salarySource;
	}

	public void setSalarySource(String salarySource) {
		this.salarySource = salarySource;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "salarySource : [ salarySource=" + salarySource + ",salary" + salary + "]";
	}

}
