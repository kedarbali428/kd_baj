package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class OfferDetailsListing {
    private Boolean isOfferAvailable;
    private String riskOfferType;
    private String offerType;
    private BigDecimal offerAmount;

    // Adding Additional parameter as part of JIRAID Len-535
    private String offerSource;
    private String offerAcceptedStatus;
    private String offerID;
    private String riskClassification;
    private BigDecimal offerROI;
    private String offerGenerationRule;
    private String offerProgramCode;
    private String offerExpiryDate;
    private String prospectSource;
    private BigDecimal offerCibilScore;
    private String offerSubsource;
    private BigDecimal offerAppScore;
    private BigDecimal offerObligation;
    private String offerCustomerSegmentation;   
    private Integer offerPriority;
    private String principleProductCode;
    public BigDecimal getOfferROI() {
        return offerROI;
    }

    public void setOfferROI(BigDecimal offerROI) {
        this.offerROI = offerROI;
    }

    public String getOfferGenerationRule() {
        return offerGenerationRule;
    }

    public void setOfferGenerationRule(String offerGenerationRule) {
        this.offerGenerationRule = offerGenerationRule;
    }

    public String getOfferProgramCode() {
        return offerProgramCode;
    }

    public void setOfferProgramCode(String offerProgramCode) {
        this.offerProgramCode = offerProgramCode;
    }

    public Boolean getIsOfferAvailable() {
        return isOfferAvailable;
    }

    public void setIsOfferAvailable(Boolean isOfferAvailable) {
        this.isOfferAvailable = isOfferAvailable;
    }

    public String getRiskOfferType() {
        return riskOfferType;
    }

    public void setRiskOfferType(String riskOfferType) {
        this.riskOfferType = riskOfferType;
    }

    public String getOfferType() {
        return offerType;
    }

    public void setOfferType(String offerType) {
        this.offerType = offerType;
    }

    public BigDecimal getOfferAmount() {
        return offerAmount;
    }

    public void setOfferAmount(BigDecimal offerAmount) {
        this.offerAmount = offerAmount;
    }

    public String getOfferSource() {
        return offerSource;
    }

    public void setOfferSource(String offerSource) {
        this.offerSource = offerSource;
    }

    public String getOfferAcceptedStatus() {
        return offerAcceptedStatus;
    }

    public void setOfferAcceptedStatus(String offerAcceptedStatus) {
        this.offerAcceptedStatus = offerAcceptedStatus;
    }

    public String getOfferID() {
        return offerID;
    }

    public void setOfferID(String offerID) {
        this.offerID = offerID;
    }

    public String getRiskClassification() {
        return riskClassification;
    }

    public void setRiskClassification(String riskClassification) {
        this.riskClassification = riskClassification;
    }

    public String getOfferExpiryDate() {
        return offerExpiryDate;
    }

    public void setOfferExpiryDate(String offerExpiryDate) {
        this.offerExpiryDate = offerExpiryDate;
    }

    public String getProspectSource() {
        return prospectSource;
    }

    public void setProspectSource(String prospectSource) {
        this.prospectSource = prospectSource;
    }

    public BigDecimal getOfferCibilScore() {
        return offerCibilScore;
    }

    public void setOfferCibilScore(BigDecimal offerCibilScore) {
        this.offerCibilScore = offerCibilScore;
    }

    public String getOfferSubsource() {
        return offerSubsource;
    }

    public void setOfferSubsource(String offerSubsource) {
        this.offerSubsource = offerSubsource;
    }

    public BigDecimal getOfferAppScore() {
        return offerAppScore;
    }

    public void setOfferAppScore(BigDecimal offerAppScore) {
        this.offerAppScore = offerAppScore;
    }

    public BigDecimal getOfferObligation() {
        return offerObligation;
    }

    public void setOfferObligation(BigDecimal offerObligation) {
        this.offerObligation = offerObligation;
    }

    public String getOfferCustomerSegmentation() {
        return offerCustomerSegmentation;
    }

    public void setOfferCustomerSegmentation(String offerCustomerSegmentation) {
        this.offerCustomerSegmentation = offerCustomerSegmentation;
    }

    public Integer getOfferPriority() {
        return offerPriority;
    }

    public void setOfferPriority(Integer offerPriority) {
        this.offerPriority = offerPriority;
    }
    

    public String getPrincipleProductCode() {
        return principleProductCode;
    }

    public void setPrincipleProductCode(String principleProductCode) {
        this.principleProductCode = principleProductCode;
    }

    @Override
    public String toString() {
        return "OfferDetailsListing [isOfferAvailable=" + isOfferAvailable + ", riskOfferType=" + riskOfferType
                + ", offerType=" + offerType + ", offerAmount=" + offerAmount + ", offerSource=" + offerSource
                + ", offerAcceptedStatus=" + offerAcceptedStatus + ", offerID=" + offerID + ", riskClassification="
                + riskClassification + ", offerROI=" + offerROI + ", offerGenerationRule=" + offerGenerationRule
                + ", offerProgramCode=" + offerProgramCode + ", offerExpiryDate=" + offerExpiryDate
                + ", prospectSource=" + prospectSource + ", offerCibilScore=" + offerCibilScore + ", offerSubsource="
                + offerSubsource + ", offerAppScore=" + offerAppScore + ", offerObligation=" + offerObligation
                + ", offerCustomerSegmentation=" + offerCustomerSegmentation + ", offerPriority=" + offerPriority
                + ", principleProductCode=" + principleProductCode + "]";
    }

    

}
