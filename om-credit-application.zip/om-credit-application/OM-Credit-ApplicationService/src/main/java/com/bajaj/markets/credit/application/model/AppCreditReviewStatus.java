package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="app_credit_review_status",schema = "dmcredit")
public class AppCreditReviewStatus implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long appcreditreviewkey;
	
	private Long applicationkey;
	private Integer eligibilitycreditreviewsts;
	private Integer disbursementcreditreviewsts;
	private String crediteligibilityapprovedby;
	private String creditdisbursementapprovedby;
	private Timestamp eligibilitycreditreviewdt;
	private Timestamp disbursementcreditreviewdt;
	private Integer isactive;
	private Integer lstupdateby;
	private Timestamp lstupdatedt;
	private String opsreviewstatus;
	private Timestamp opsreviewdt;
	private Long opsreviewapprovedby;
	private String individualcoapplicantrequired;
	private Timestamp individualcoapplicantdt;
	private Long individualcoapplicantaddedby;
	private String entitycoapplicantrequired;
	private Timestamp entitycoapplicantdt;
	private Long entitycoapplicantaddedby;
	public Long getAppcreditreviewkey() {
		return appcreditreviewkey;
	}
	public void setAppcreditreviewkey(Long appcreditreviewkey) {
		this.appcreditreviewkey = appcreditreviewkey;
	}
	public Long getApplicationkey() {
		return applicationkey;
	}
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}
	public Integer getEligibilitycreditreviewsts() {
		return eligibilitycreditreviewsts;
	}
	public void setEligibilitycreditreviewsts(Integer eligibilitycreditreviewsts) {
		this.eligibilitycreditreviewsts = eligibilitycreditreviewsts;
	}
	public Integer getDisbursementcreditreviewsts() {
		return disbursementcreditreviewsts;
	}
	public void setDisbursementcreditreviewsts(Integer disbursementcreditreviewsts) {
		this.disbursementcreditreviewsts = disbursementcreditreviewsts;
	}
	public String getCrediteligibilityapprovedby() {
		return crediteligibilityapprovedby;
	}
	public void setCrediteligibilityapprovedby(String crediteligibilityapprovedby) {
		this.crediteligibilityapprovedby = crediteligibilityapprovedby;
	}
	public String getCreditdisbursementapprovedby() {
		return creditdisbursementapprovedby;
	}
	public void setCreditdisbursementapprovedby(String creditdisbursementapprovedby) {
		this.creditdisbursementapprovedby = creditdisbursementapprovedby;
	}
	public Timestamp getEligibilitycreditreviewdt() {
		return eligibilitycreditreviewdt;
	}
	public void setEligibilitycreditreviewdt(Timestamp eligibilitycreditreviewdt) {
		this.eligibilitycreditreviewdt = eligibilitycreditreviewdt;
	}
	public Timestamp getDisbursementcreditreviewdt() {
		return disbursementcreditreviewdt;
	}
	public void setDisbursementcreditreviewdt(Timestamp disbursementcreditreviewdt) {
		this.disbursementcreditreviewdt = disbursementcreditreviewdt;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	public Integer getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(Integer lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	public String getOpsreviewstatus() {
		return opsreviewstatus;
	}
	public void setOpsreviewstatus(String opsreviewstatus) {
		this.opsreviewstatus = opsreviewstatus;
	}
	public Timestamp getOpsreviewdt() {
		return opsreviewdt;
	}
	public void setOpsreviewdt(Timestamp opsreviewdt) {
		this.opsreviewdt = opsreviewdt;
	}
	public Long getOpsreviewapprovedby() {
		return opsreviewapprovedby;
	}
	public void setOpsreviewapprovedby(Long opsreviewapprovedby) {
		this.opsreviewapprovedby = opsreviewapprovedby;
	}
	public String getIndividualcoapplicantrequired() {
		return individualcoapplicantrequired;
	}
	public void setIndividualcoapplicantrequired(String individualcoapplicantrequired) {
		this.individualcoapplicantrequired = individualcoapplicantrequired;
	}
	public Timestamp getIndividualcoapplicantdt() {
		return individualcoapplicantdt;
	}
	public void setIndividualcoapplicantdt(Timestamp individualcoapplicantdt) {
		this.individualcoapplicantdt = individualcoapplicantdt;
	}
	public Long getIndividualcoapplicantaddedby() {
		return individualcoapplicantaddedby;
	}
	public void setIndividualcoapplicantaddedby(Long individualcoapplicantaddedby) {
		this.individualcoapplicantaddedby = individualcoapplicantaddedby;
	}
	public String getEntitycoapplicantrequired() {
		return entitycoapplicantrequired;
	}
	public void setEntitycoapplicantrequired(String entitycoapplicantrequired) {
		this.entitycoapplicantrequired = entitycoapplicantrequired;
	}
	public Timestamp getEntitycoapplicantdt() {
		return entitycoapplicantdt;
	}
	public void setEntitycoapplicantdt(Timestamp entitycoapplicantdt) {
		this.entitycoapplicantdt = entitycoapplicantdt;
	}
	public Long getEntitycoapplicantaddedby() {
		return entitycoapplicantaddedby;
	}
	public void setEntitycoapplicantaddedby(Long entitycoapplicantaddedby) {
		this.entitycoapplicantaddedby = entitycoapplicantaddedby;
	}	
}
