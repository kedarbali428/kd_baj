package com.bajaj.markets.credit.application.bean;

public class BtBankReponse {
	private Integer bankMasterKey;
	private String sourceName;
	private String bankAccountCatCode;

	public Integer getBankMasterKey() {
		return bankMasterKey;
	}

	public void setBankMasterKey(Integer bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}

	public String getSourceName() {
		return sourceName;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	public String getBankAccountCatCode() {
		return bankAccountCatCode;
	}

	public void setBankAccountCatCode(String bankAccountCatCode) {
		this.bankAccountCatCode = bankAccountCatCode;
	}

	@Override
	public String toString() {
		return "BtBankReponse [bankMasterKey=" + bankMasterKey + ", sourceName=" + sourceName + ", bankAccountCatCode=" + bankAccountCatCode + "]";
	}

}
