/**
 * 
 */
package com.bajaj.markets.credit.application.controller;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.Email;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationEmailService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author deepak.ray
 * Controller for persisting email id's based on user input
 */
@RestController
@Validated
public class ApplicationEmailController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private ApplicationEmailService applicationEmailService;
	
	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;
	
	private static final String CLASSNAME = ApplicationEmailService.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "Update email id", notes = "Update email for user profile", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			 	@ApiResponse(code = 200, message = "Email updated successfully.", response = Email.class),
			 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			 	@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
		        @ApiResponse(code = 404, message = "ApplicationId not found",response = ErrorBean.class),
			 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PutMapping(value = "v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/email", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateEmail(@PathVariable(name = "applicationid", required = true) @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@PathVariable(name = "userattributekey", required = true) @NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10,message = "userattributekey should be numeric & should not exceeds size") String userAttributeKey, @Valid @RequestBody Email email,
			 BindingResult result,
			 @RequestHeader HttpHeaders headers){

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateEmail method controller for applicationId : " +applicationId+ " and userAttributeKey : " +userAttributeKey);
		if(result.hasFieldErrors()){
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateEmail method controller - resource validation failed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCA_001", result.getFieldErrors().get(0).getDefaultMessage()));
		}else {
			creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userAttributeKey);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Exiting updateEmail method controller - applicationId: "+ applicationId );
			return new ResponseEntity<>(applicationEmailService.updateEmail(applicationId,userAttributeKey, email), HttpStatus.CREATED);
		}
	}
	

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL,Role.SYSTEM ,Role.INTERNAL})
	@ApiOperation(value = "Fetch Email Detail", notes = "Fetch Email details on the basis of user attribute", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Email Detail found for the user attribute", response = Email.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Email Detail not found for the user attribute",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/email", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getEmail(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable("userattributekey") @NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10,message = "userattributekey should be numeric & should not exceeds size") String userAttributeKey,
			@RequestParam  @NotBlank(message = "typeKey can not be null or empty") @Digits(fraction = 0, integer = 10,message = "typeKey should be numeric & should not exceeds size") String typeKey,
			@RequestHeader HttpHeaders headers){

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getEmail method controller - applicationId : "+ applicationId + " and userattributeKey : " + userAttributeKey);

		creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userAttributeKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Exiting getEmail method controller - applicationId: "+ applicationId );
		return new ResponseEntity<>(applicationEmailService.getEmailDetail(Long.valueOf(applicationId), Long.valueOf(userAttributeKey), Long.valueOf(typeKey)),HttpStatus.OK);
	}
	
}
