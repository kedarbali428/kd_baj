package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author 586941
 * Bean for holding data during Vas application disbursement precheck
 *
 */
public class VasPricingCheckBean {

	private Long applicationKey;
	private String pennantLanNo;
	private Date applicationLastUpdateDate;
	private String l2ProductCategoryCode;
	private String l3ProductCode;
	private String l4ProductTypeCode;
	private Boolean bundleSelectedFlag;
	private Long bundleApplicationKey;
	private String bundleApplicationPlanCode;
	private String bundleApplicationPlanName;
	private Long appLoanPricingKey;
	private BigDecimal loanAmount;
	private BigDecimal loanAmountWithBundle;
	private BigDecimal finalLoanAmount;
	private BigDecimal netDisbursementAmt;
	private BigDecimal roi;
	private BigDecimal finalRoi;
	private Integer tenureIs;
	private Integer tenureDropline;
	private String emiIs;
	private BigDecimal emiDropline;
	private BigDecimal emiAmount;
	private Integer emiCycleDay;
	private Date firstEmiDueDate;
	private String source;
	private String status;
	private List<FeeDetails> feesList;
	private String l3ProductTypeDesc;
	private String l4ProductTypeDesc;

	
	
	public String getL3ProductTypeDesc() {
		return l3ProductTypeDesc;
	}
	public void setL3ProductTypeDesc(String l3ProductTypeDesc) {
		this.l3ProductTypeDesc = l3ProductTypeDesc;
	}
	public String getL4ProductTypeDesc() {
		return l4ProductTypeDesc;
	}
	public void setL4ProductTypeDesc(String l4ProductTypeDesc) {
		this.l4ProductTypeDesc = l4ProductTypeDesc;
	}
	public Long getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}
	public Long getBundleApplicationKey() {
		return bundleApplicationKey;
	}
	public void setBundleApplicationKey(Long bundleApplicationKey) {
		this.bundleApplicationKey = bundleApplicationKey;
	}
	public Long getAppLoanPricingKey() {
		return appLoanPricingKey;
	}
	public void setAppLoanPricingKey(Long appLoanPricingKey) {
		this.appLoanPricingKey = appLoanPricingKey;
	}
	public BigDecimal getFinalLoanAmount() {
		return finalLoanAmount;
	}
	public void setFinalLoanAmount(BigDecimal finalLoanAmount) {
		this.finalLoanAmount = finalLoanAmount;
	}
	public BigDecimal getFinalRoi() {
		return finalRoi;
	}
	public void setFinalRoi(BigDecimal finalRoi) {
		this.finalRoi = finalRoi;
	}
	public Integer getTenureIs() {
		return tenureIs;
	}
	public void setTenureIs(Integer tenureIs) {
		this.tenureIs = tenureIs;
	}
	public Integer getTenureDropline() {
		return tenureDropline;
	}
	public void setTenureDropline(Integer tenureDropline) {
		this.tenureDropline = tenureDropline;
	}
	public String getEmiIs() {
		return emiIs;
	}
	public void setEmiIs(String emiIs) {
		this.emiIs = emiIs;
	}
	public BigDecimal getEmiDropline() {
		return emiDropline;
	}
	public void setEmiDropline(BigDecimal emiDropline) {
		this.emiDropline = emiDropline;
	}
	public BigDecimal getEmiAmount() {
		return emiAmount;
	}
	public void setEmiAmount(BigDecimal emiAmount) {
		this.emiAmount = emiAmount;
	}
	public Integer getEmiCycleDay() {
		return emiCycleDay;
	}
	public void setEmiCycleDay(Integer emiCycleDay) {
		this.emiCycleDay = emiCycleDay;
	}
	public Date getFirstEmiDueDate() {
		return firstEmiDueDate;
	}
	public void setFirstEmiDueDate(Date firstEmiDueDate) {
		this.firstEmiDueDate = firstEmiDueDate;
	}
	@Override
	public String toString() {
		return "VasPricingCheckBean [applicationKey=" + applicationKey + ", pennantLanNo=" + pennantLanNo
				+ ", applicationLastUpdateDate=" + applicationLastUpdateDate + ", l2ProductCategoryCode="
				+ l2ProductCategoryCode + ", l3ProductCode=" + l3ProductCode + ", l4ProductTypeCode="
				+ l4ProductTypeCode + ", bundleSelectedFlag=" + bundleSelectedFlag + ", bundleApplicationKey="
				+ bundleApplicationKey + ", bundleApplicationPlanCode=" + bundleApplicationPlanCode
				+ ", bundleApplicationPlanName=" + bundleApplicationPlanName + ", appLoanPricingKey="
				+ appLoanPricingKey + ", loanAmount=" + loanAmount + ", loanAmountWithBundle=" + loanAmountWithBundle
				+ ", finalLoanAmount=" + finalLoanAmount + ", netDisbursementAmt=" + netDisbursementAmt + ", roi=" + roi
				+ ", finalRoi=" + finalRoi + ", tenureIs=" + tenureIs + ", tenureDropline=" + tenureDropline
				+ ", emiIs=" + emiIs + ", emiDropline=" + emiDropline + ", emiAmount=" + emiAmount + ", emiCycleDay="
				+ emiCycleDay + ", firstEmiDueDate=" + firstEmiDueDate + ", source=" + source + ", status=" + status
				+ ", feesList=" + feesList + ", l3ProductTypeDesc=" + l3ProductTypeDesc + ", l4ProductTypeDesc="
				+ l4ProductTypeDesc + "]";
	}
	public BigDecimal getRoi() {
		return roi;
	}
	public void setRoi(BigDecimal roi) {
		this.roi = roi;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getL2ProductCategoryCode() {
		return l2ProductCategoryCode;
	}
	public void setL2ProductCategoryCode(String l2ProductCategoryCode) {
		this.l2ProductCategoryCode = l2ProductCategoryCode;
	}
	public String getL3ProductCode() {
		return l3ProductCode;
	}
	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}
	public String getL4ProductTypeCode() {
		return l4ProductTypeCode;
	}
	public void setL4ProductTypeCode(String l4ProductTypeCode) {
		this.l4ProductTypeCode = l4ProductTypeCode;
	}
	public BigDecimal getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}
	public List<FeeDetails> getFeesList() {
		return feesList;
	}
	public void setFeesList(List<FeeDetails> feesList) {
		this.feesList = feesList;
	}
	public BigDecimal getNetDisbursementAmt() {
		return netDisbursementAmt;
	}
	public void setNetDisbursementAmt(BigDecimal netDisbursementAmt) {
		this.netDisbursementAmt = netDisbursementAmt;
	}
	public BigDecimal getLoanAmountWithBundle() {
		return loanAmountWithBundle;
	}
	public void setLoanAmountWithBundle(BigDecimal loanAmountWithBundle) {
		this.loanAmountWithBundle = loanAmountWithBundle;
	}
	public String getBundleApplicationPlanCode() {
		return bundleApplicationPlanCode;
	}
	public void setBundleApplicationPlanCode(String bundleApplicationPlanCode) {
		this.bundleApplicationPlanCode = bundleApplicationPlanCode;
	}
	public String getBundleApplicationPlanName() {
		return bundleApplicationPlanName;
	}
	public void setBundleApplicationPlanName(String bundleApplicationPlanName) {
		this.bundleApplicationPlanName = bundleApplicationPlanName;
	}
	public Boolean getBundleSelectedFlag() {
		return bundleSelectedFlag;
	}
	public void setBundleSelectedFlag(Boolean bundleSelectedFlag) {
		this.bundleSelectedFlag = bundleSelectedFlag;
	}
	public String getPennantLanNo() {
		return pennantLanNo;
	}
	public void setPennantLanNo(String pennantLanNo) {
		this.pennantLanNo = pennantLanNo;
	}
	public Date getApplicationLastUpdateDate() {
		return applicationLastUpdateDate;
	}
	public void setApplicationLastUpdateDate(Date applicationLastUpdateDate) {
		this.applicationLastUpdateDate = applicationLastUpdateDate;
	}
}