package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.BtBankReponse;
import com.bajaj.markets.credit.application.bean.BtBankRequest;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.helper.ResponseBean;
import com.bajaj.markets.credit.application.service.ApplicationBtBankService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author sujit.lole
 *
 *         Jul 19, 2020
 *
 */
@RestController
@Validated
public class ApplicationBtBankController {

	private static final String CLASS_NAME = ApplicationBtBankController.class.getCanonicalName();

	@Autowired
	private ApplicationBtBankService btBankService;

	@Autowired
	private BFLLoggerUtilExt logger;

	/**
	 * @param btBankRequest
	 * @param bindingResult
	 * @param applicationId
	 * @param userAttributeKey
	 * @param headers
	 * @return
	 */
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiOperation(value = "Btbank details endpoint", notes = "Save btBank details", httpMethod = "PUT")
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), @ApiImplicitParam(name = "applicationKey", required = true, dataType = "string", paramType = "path"),
			@ApiImplicitParam(name = "userattributekey", required = true, dataType = "string", paramType = "path") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Bank details created successfully.", response = BtBankReponse.class), @ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class), @ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.btBank.details.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<ResponseBean> updateBankDetails(@Valid @RequestBody BtBankRequest btBankRequest, BindingResult bindingResult,
			@PathVariable(name = "applicationKey") @NotNull(message = "Application id can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") Long applicationId,
			@PathVariable(name = "userattributekey") @NotNull(message = "User Attribute Key can not be null or empty") @Digits(fraction = 0, integer = 20, message = "userattributekey should be numeric & should not exceeds size") Long userAttributeKey,
			@RequestHeader HttpHeaders headers) {
		long startTime = System.currentTimeMillis();
		if (btBankRequest != null)
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside updateBankDetails controller - applicationKey : "+ applicationId + " and userattributeKey : " +userAttributeKey);

		if (bindingResult.hasFieldErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside updateBankDetails method - Invalid parameters passed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1022", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}
		BtBankReponse btBankResponse = btBankService.updateBtBankDetails(applicationId, userAttributeKey, btBankRequest);
		long endTime = System.currentTimeMillis() - startTime;
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "updateBankDetails API Completed successfully - applicationId : " +applicationId);
		return new ResponseEntity<ResponseBean>(new ResponseBean(btBankResponse), HttpStatus.CREATED);
	}

	/**
	 * @param applicationId
	 * @param userAttributeKey
	 * @param bankAccountCatCode
	 * @param headers
	 * @return
	 */
	@ApiOperation(value = "Btbank details endpoint", notes = "Fetch bt bank details", httpMethod = "GET")
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), @ApiImplicitParam(name = "applicationKey", required = true, dataType = "string", paramType = "path"),
			@ApiImplicitParam(name = "userattributekey", required = true, dataType = "string", paramType = "path") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Fetch bank details", response = BtBankReponse.class), @ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class), @ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.btBank.details.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<BtBankReponse> getBtBankDetails(
			@PathVariable(name = "applicationKey") @NotNull(message = "Application id can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") Long applicationId,
			@PathVariable(name = "userattributekey") @NotNull(message = "User Attribute Key can not be null or empty") @Digits(fraction = 0, integer = 20, message = "userattributekey should be numeric & should not exceeds size") Long userAttributeKey,
			@RequestParam(value = "bankAccountCatCode", required = false) String bankAccountCatCode, @RequestHeader HttpHeaders headers) {
		long startTime = System.currentTimeMillis();
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside getBtBankDetails controller - applicationKey : "+applicationId + " and userattributeKey : " +userAttributeKey);
		BtBankReponse btBankResponse = btBankService.fetchBtBankDetails(applicationId, userAttributeKey, bankAccountCatCode.toUpperCase());
		long endTime = System.currentTimeMillis() - startTime;
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getBtBankDetails API completed successfully - applicationId : " +applicationId);
		return new ResponseEntity<BtBankReponse>(btBankResponse, HttpStatus.OK);
	}
}
