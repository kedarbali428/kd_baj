package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the app_apps_score database table.
 * 
 */
@Entity
@Table(name = "app_apps_score", schema="dmcredit")
public class AppAppsScore implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="app_apps_score_appsscorekey_generator", sequenceName="dmcredit.seq_pk_app_apps_score",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_apps_score_appsscorekey_generator")
	private Long appsscorekey;

	private BigDecimal finalscore;

	private Integer isactive;

	private BigDecimal lrscore;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal miscore;

	private Long applicationkey;
	
	private BigDecimal lrscorev2;

	public AppAppsScore() {
	}

	public Long getAppsscorekey() {
		return this.appsscorekey;
	}

	public void setAppsscorekey(Long appsscorekey) {
		this.appsscorekey = appsscorekey;
	}

	public BigDecimal getFinalscore() {
		return this.finalscore;
	}

	public void setFinalscore(BigDecimal finalscore) {
		this.finalscore = finalscore;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public BigDecimal getLrscore() {
		return this.lrscore;
	}

	public void setLrscore(BigDecimal lrscore) {
		this.lrscore = lrscore;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getMiscore() {
		return this.miscore;
	}

	public void setMiscore(BigDecimal miscore) {
		this.miscore = miscore;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public BigDecimal getLrscorev2() {
		return lrscorev2;
	}

	public void setLrscorev2(BigDecimal lrscorev2) {
		this.lrscorev2 = lrscorev2;
	}
	
}