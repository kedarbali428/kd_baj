package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the app_disposition_status database table.
 * 
 */
@Entity
@Table(name = "app_disposition_status", schema = "dmcredit")
public class AppDispositionStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_disposition_status_appdisposstskey_generator", sequenceName = "dmcredit.seq_pk_app_disposition_status", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_disposition_status_appdisposstskey_generator")
	private Long appdisposstskey;

	private Long applicationkey;

	private Integer appstatus;

	private Long applsubstagekey;

	private Date followupdt;

	private String followuptime;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Integer isactive;
	
	//private Long subdispositonkey;
	
	private Integer functionKey;
	
	private Timestamp createdt;
	
	private Long createbyuserrolekey;
	
	private Long subdispostionkey;
	
	private Integer appstagecompletionper;

	public AppDispositionStatus() {
	}

	/**
	 * @return the appdisposstskey
	 */
	public Long getAppdisposstskey() {
		return appdisposstskey;
	}

	/**
	 * @param appdisposstskey the appdisposstskey to set
	 */
	public void setAppdisposstskey(Long appdisposstskey) {
		this.appdisposstskey = appdisposstskey;
	}

	/**
	 * @return the applicationkey
	 */
	public Long getApplicationkey() {
		return applicationkey;
	}

	/**
	 * @param applicationkey the applicationkey to set
	 */
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	/**
	 * @return the appstatus
	 */
	public Integer getAppstatus() {
		return appstatus;
	}

	/**
	 * @param appstatus the appstatus to set
	 */
	public void setAppstatus(Integer appstatus) {
		this.appstatus = appstatus;
	}

	/**
	 * @return the applsubstagekey
	 */
	public Long getApplsubstagekey() {
		return applsubstagekey;
	}

	/**
	 * @param applsubstagekey the applsubstagekey to set
	 */
	public void setApplsubstagekey(Long applsubstagekey) {
		this.applsubstagekey = applsubstagekey;
	}

	/**
	 * @return the followupdt
	 */
	public Date getFollowupdt() {
		return followupdt;
	}

	/**
	 * @param followupdt the followupdt to set
	 */
	public void setFollowupdt(Date followupdt) {
		this.followupdt = followupdt;
	}

	/**
	 * @return the followuptime
	 */
	public String getFollowuptime() {
		return followuptime;
	}

	/**
	 * @param followuptime the followuptime to set
	 */
	public void setFollowuptime(String followuptime) {
		this.followuptime = followuptime;
	}

	/**
	 * @return the lstupdateby
	 */
	public Long getLstupdateby() {
		return lstupdateby;
	}

	/**
	 * @param lstupdateby the lstupdateby to set
	 */
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	/**
	 * @return the lstupdatedt
	 */
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	/**
	 * @param lstupdatedt the lstupdatedt to set
	 */
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	
	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}

	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	/*
	 * public Long getSubdispositonkey() { return subdispositonkey; }
	 * 
	 * public void setSubdispositonkey(Long subdispositonkey) {
	 * this.subdispositonkey = subdispositonkey; }
	 */

	public Integer getFunctionKey() {
		return functionKey;
	}

	public void setFunctionKey(Integer functionKey) {
		this.functionKey = functionKey;
	}

	public Timestamp getCreatedt() {
		return createdt;
	}

	public void setCreatedt(Timestamp createdt) {
		this.createdt = createdt;
	}

	public Long getCreatebyuserrolekey() {
		return createbyuserrolekey;
	}

	public void setCreatebyuserrolekey(Long createbyuserrolekey) {
		this.createbyuserrolekey = createbyuserrolekey;
	}

	public Long getSubdispostionkey() {
		return subdispostionkey;
	}

	public void setSubdispostionkey(Long subdispostionkey) {
		this.subdispostionkey = subdispostionkey;
	}

	public Integer getCompletionper() {
		return appstagecompletionper;
	}

	public void setCompletionper(Integer appstagecompletionper) {
		this.appstagecompletionper = appstagecompletionper;
	}

	
	

}