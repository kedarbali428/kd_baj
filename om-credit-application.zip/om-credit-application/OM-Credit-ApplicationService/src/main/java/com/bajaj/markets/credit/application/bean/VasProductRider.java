package com.bajaj.markets.credit.application.bean;

public class VasProductRider {
	private String riderCode;
	private String riderDescription;
	private String riderUserFriendlyName;

	public String getRiderCode() {
		return riderCode;
	}

	public String getRiderDescription() {
		return riderDescription;
	}

	public String getRiderUserFriendlyName() {
		return riderUserFriendlyName;
	}

}
