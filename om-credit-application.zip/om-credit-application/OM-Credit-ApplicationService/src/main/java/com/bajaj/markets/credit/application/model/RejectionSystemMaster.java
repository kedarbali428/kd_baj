package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the rejection_system_master database table.
 * 
 */
@Entity
@Table(name="rejection_system_master", schema="dmcredit")
public class RejectionSystemMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer rejectionsystemmastkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String rejectionsystemcode;

	private String rejectionsystemdesc;

	private String rejectionsystemtype;

	//bi-directional many-to-one association to AppRejectionDetail
	@OneToMany(mappedBy="rejectionSystemMaster")
	private Set<AppRejectionDetail> appRejectionDetails;

	public RejectionSystemMaster() {
	}

	public Integer getRejectionsystemmastkey() {
		return this.rejectionsystemmastkey;
	}

	public void setRejectionsystemmastkey(Integer rejectionsystemmastkey) {
		this.rejectionsystemmastkey = rejectionsystemmastkey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getRejectionsystemcode() {
		return this.rejectionsystemcode;
	}

	public void setRejectionsystemcode(String rejectionsystemcode) {
		this.rejectionsystemcode = rejectionsystemcode;
	}

	public String getRejectionsystemdesc() {
		return this.rejectionsystemdesc;
	}

	public void setRejectionsystemdesc(String rejectionsystemdesc) {
		this.rejectionsystemdesc = rejectionsystemdesc;
	}

	public String getRejectionsystemtype() {
		return this.rejectionsystemtype;
	}

	public void setRejectionsystemtype(String rejectionsystemtype) {
		this.rejectionsystemtype = rejectionsystemtype;
	}

	public Set<AppRejectionDetail> getAppRejectionDetails() {
		return this.appRejectionDetails;
	}

	public void setAppRejectionDetails(Set<AppRejectionDetail> appRejectionDetails) {
		this.appRejectionDetails = appRejectionDetails;
	}

	public AppRejectionDetail addAppRejectionDetail(AppRejectionDetail appRejectionDetail) {
		getAppRejectionDetails().add(appRejectionDetail);
		appRejectionDetail.setRejectionSystemMaster(this);

		return appRejectionDetail;
	}

	public AppRejectionDetail removeAppRejectionDetail(AppRejectionDetail appRejectionDetail) {
		getAppRejectionDetails().remove(appRejectionDetail);
		appRejectionDetail.setRejectionSystemMaster(null);

		return appRejectionDetail;
	}

}