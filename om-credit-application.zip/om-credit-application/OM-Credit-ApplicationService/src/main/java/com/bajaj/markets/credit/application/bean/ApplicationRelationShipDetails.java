package com.bajaj.markets.credit.application.bean;

public class ApplicationRelationShipDetails {

	private Long relationCodeMasterKey;
	private Long salutationKey;
	private String name;

	public Long getRelationCodeMasterKey() {
		return relationCodeMasterKey;
	}

	public void setRelationCodeMasterKey(Long relationCodeMasterKey) {
		this.relationCodeMasterKey = relationCodeMasterKey;
	}

	public Long getSalutationKey() {
		return salutationKey;
	}

	public void setSalutationKey(Long salutationKey) {
		this.salutationKey = salutationKey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "ApplicationRelationShipDetails [relationCodeMasterKey=" + relationCodeMasterKey + ", salutationKey="
				+ salutationKey + ", name=" + name + "]";
	}


}
