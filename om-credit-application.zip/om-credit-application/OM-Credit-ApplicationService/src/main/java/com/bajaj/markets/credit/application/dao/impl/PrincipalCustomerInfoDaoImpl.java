package com.bajaj.markets.credit.application.dao.impl;

import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.Calendar;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.application.bean.PrincipalCustomer;
import com.bajaj.markets.credit.application.dao.PrincipalCustomerInfoDao;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.model.PrincipleCustomerInfo;
import com.bajaj.markets.credit.application.repository.tx.PrincipleCustomerInfoRepository;

@Component
public class PrincipalCustomerInfoDaoImpl implements PrincipalCustomerInfoDao {
	
	private static final String CLASS_NAME = PrincipalCustomerInfoDaoImpl.class.getCanonicalName();
	
	@Autowired
	private PrincipleCustomerInfoRepository custInfoRepository;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CustomDefaultHeaders customHeaders;

	@Transactional
	@Override
	public void fetchExistingCustomerInfoAndSave(String applicationId, String principalkey, PrincipalCustomer customer) {
		PrincipleCustomerInfo existingPrincipleCustomerInfo = custInfoRepository.findByApplicationkeyAndAppattrbkeyAndPrincipalkeyAndIsactive(Long.valueOf(applicationId), customer.getAppattrbkey(),Long.valueOf(principalkey), 1);
		if(null == existingPrincipleCustomerInfo) {
			existingPrincipleCustomerInfo = new PrincipleCustomerInfo();
			existingPrincipleCustomerInfo.setApplicationkey(Long.valueOf(applicationId));
			existingPrincipleCustomerInfo.setPrincipalkey(Long.valueOf(principalkey));
		}
		existingPrincipleCustomerInfo.setAppattrbkey(customer.getAppattrbkey());
		this.populateAndSaveCustomer(existingPrincipleCustomerInfo, customer);
	}
	
	private void populateAndSaveCustomer(PrincipleCustomerInfo customerInfo, PrincipalCustomer customer) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "START - populateAndSaveCustomer,"
				+ "\n , PrincipleCustomerInfo : " + customerInfo + ", PrincipalCustomer" + customer.toString()
				+ "for Applicationkey" + customerInfo.getApplicationkey());
		try {
			if (!"1".equalsIgnoreCase(customerInfo.getIsetb())) {
				if (null != customer.getPrincipleCustType() && "B".equalsIgnoreCase(customer.getPrincipleCustType())) {
					customerInfo.setIsetb(ApplicationConstants.ETB_Y);
					customerInfo.setEtbsrc(customer.getPrincipleCustRefSrc());
				} else {
					customerInfo.setIsetb(ApplicationConstants.ETB_N);
				}
			}
			if (!"1".equalsIgnoreCase(customerInfo.getIsetb()) && null != customer.getIsEtb() && customer.getIsEtb().booleanValue()) {
				customerInfo.setIsetb(ApplicationConstants.ETB_Y);
				customerInfo.setEtbsrc(customer.getPrincipleCustRefSrc());
			}
			if (null != customer.getLivepos())
				customerInfo.setLivepos(customer.getLivepos().setScale(2, RoundingMode.HALF_EVEN));
			if (null != customer.getPrincipleCustRefId())
				customerInfo.setPrinciplecustrefid(customer.getPrincipleCustRefId());
			if (null != customer.getPrincipleCustRefSrc())
				customerInfo.setPrinciplecustrefsrc(customer.getPrincipleCustRefSrc());
			if (null != customer.getPrincipleCustSegment())
				customerInfo.setPrinciplecustsegment(customer.getPrincipleCustSegment());
			if (null != customer.getPrincipleCustType())
				customerInfo.setPrinciplecusttype(customer.getPrincipleCustType());
			if (null != customer.getBtsSegment())
				customerInfo.setBtssegment(customer.getBtsSegment());
			customerInfo.setIsactive(1);
			if (null != customer.getWipFlag())
				customerInfo.setWipflag(customer.getWipFlag());
			if (null != customer.getApprovedFlag()) {
				if(ApplicationConstants.BMR_APPROVEDFLAG_UNDEFINED == customer.getApprovedFlag())
					customerInfo.setApprovedflag(customer.getApprovedFlag());
				if(null == customerInfo.getApprovedflag() || 
						(null != customerInfo.getApprovedflag() && ApplicationConstants.BMR_APPROVEDFLAG_TRUE == customerInfo.getApprovedflag()))
					customerInfo.setApprovedflag(customer.getApprovedFlag());
			}
				
			if (null != customer.getRejectFlag())
				customerInfo.setRejectflag(customer.getRejectFlag());
			if (null != customer.getFraudFlag())
				customerInfo.setFraudflag(customer.getFraudFlag());
			if (null != customer.getBmrOneApprovedFlag())
				customerInfo.setBmr1approvedflag(customer.getBmrOneApprovedFlag());
			if (null != customer.getBmrTwoApprovedFlag())
				customerInfo.setBmr2approvedflag(customer.getBmrTwoApprovedFlag());
			if (null != customer.getBmrTwoBadFlag())
				customerInfo.setBmr2badflag(customer.getBmrTwoBadFlag());
			if (null != customer.getBmrTwoDisbursedFlag())
				customerInfo.setBmr2disbflag(customer.getBmrTwoDisbursedFlag());
			if (null != customer.getBmrTwoRejectFlag())
				customerInfo.setBmr2rejectflag(customer.getBmrTwoRejectFlag());
			if (StringUtils.isNotEmpty(customer.getEdwStatus())) {
				customerInfo.setEdwstatus(customer.getEdwStatus());
			}
			if(null!=customer.getFinnoneId()) {
				customerInfo.setFinnoneid(customer.getFinnoneId());
			}
			customerInfo.setLstupdateby(customHeaders.getUserKey());
			customerInfo.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
			PrincipleCustomerInfo customerInfoUpdatedEntity = custInfoRepository.save(customerInfo);
			customer.setPrincipleCustKey(customerInfoUpdatedEntity.getPrinciplecustkey());
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception in while saving the principal cust info data for: "
							+ customerInfo.getApplicationkey() + " and principleKey: " + customerInfo.getPrincipalkey(), e);
		} 
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exiting - populateAndSaveCustomer," + "for Applicationkey" + customerInfo.getApplicationkey());
	}

}
