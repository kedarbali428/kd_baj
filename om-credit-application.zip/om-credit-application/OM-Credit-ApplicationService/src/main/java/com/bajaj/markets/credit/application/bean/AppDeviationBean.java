package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class AppDeviationBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
    
	private Integer deviationcodeKey;
	
	private Long prodKey;

	public Integer getDeviationcodeKey() {
		return deviationcodeKey;
	}

	public void setDeviationcodeKey(Integer deviationcodeKey) {
		this.deviationcodeKey = deviationcodeKey;
	}

	public Long getProdKey() {
		return prodKey;
	}

	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}

	@Override
	public String toString() {
		return "AppDeviationBean [deviationcodeKey=" + deviationcodeKey + ", prodKey=" + prodKey + "]";
	}
}
