package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class PrincipleProductDetails {
	private String principleProductCode;
	private List<String> rejectCodeList;
	private Boolean isEligible;
	private Integer priority;
	private Float bScore;
	private String cibilType;
	private String cardTag;
	private String approvalChances;
	private String ctaName;
	private List<String> creditReviewCodes;

	public Float getbScore() {
		return bScore;
	}

	public void setbScore(Float bScore) {
		this.bScore = bScore;
	}

	public String getCibilType() {
		return cibilType;
	}

	public void setCibilType(String cibilType) {
		this.cibilType = cibilType;
	}

	public String getPrincipleProductCode() {
		return principleProductCode;
	}

	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}

	public List<String> getRejectCodeList() {
		return rejectCodeList;
	}

	public void setRejectCodeList(List<String> rejectCodeList) {
		this.rejectCodeList = rejectCodeList;
	}

	public Boolean getIsEligible() {
		return isEligible;
	}

	public void setIsEligible(Boolean isEligible) {
		this.isEligible = isEligible;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getCardTag() {
		return cardTag;
	}

	public void setCardTag(String cardTag) {
		this.cardTag = cardTag;
	}

	public String getApprovalChances() {
		return approvalChances;
	}

	public void setApprovalChances(String approvalChances) {
		this.approvalChances = approvalChances;
	}

	public String getCtaName() {
		return ctaName;
	}

	public void setCtaName(String ctaName) {
		this.ctaName = ctaName;
	}

	public List<String> getCreditReviewCodes() {
		return creditReviewCodes;
	}

	public void setCreditReviewCodes(List<String> creditReviewCodes) {
		this.creditReviewCodes = creditReviewCodes;
	}

	@Override
	public String toString() {
		return "PrincipleProductDetails [principleProductCode=" + principleProductCode + ", rejectCodeList="
				+ rejectCodeList + ", isEligible=" + isEligible + ", priority=" + priority + ", bScore=" + bScore
				+ ", cibilType=" + cibilType + ", cardTag=" + cardTag + ", approvalChances=" + approvalChances
				+ ", ctaName=" + ctaName + ", creditReviewCodes=" + creditReviewCodes + "]";
	}

}
