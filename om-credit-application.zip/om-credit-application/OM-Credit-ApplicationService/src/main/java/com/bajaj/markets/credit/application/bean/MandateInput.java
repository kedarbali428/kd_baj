package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class MandateInput {

	private String applicationID;
	private BigDecimal tlEmi;
	private BigDecimal isEmi;
	private BigDecimal firstEmi;
	private BigDecimal requiredLoanAmount;
	private String impsStatus;
	private String impsErrorCode;
	private String impsResponse;
	private String impsNameMatch;
	private String product;
	private String l3Product;
	private String occupationType;
	private String l4Product;
	private Boolean existingCustomerFlag;
	private Integer isTenor;
	private Integer droplineTenor;
	private String breCallType;
	private List<OfferDetails> offerDetails;
	private List<MandateDetails> mandateDetails;
	private List<BankDetails> bankDetails;

	/**
	 * @return the mandateDetails
	 */
	public List<MandateDetails> getMandateDetails() {
		return mandateDetails;
	}

	/**
	 * @param mandateDetails the mandateDetails to set
	 */
	public void setMandateDetails(List<MandateDetails> mandateDetails) {
		this.mandateDetails = mandateDetails;
	}

	/**
	 * @return the offerDetails
	 */
	public List<OfferDetails> getOfferDetails() {
		return offerDetails;
	}

	/**
	 * @param offerDetails the offerDetails to set
	 */
	public void setOfferDetails(List<OfferDetails> offerDetails) {
		this.offerDetails = offerDetails;
	}

	/**
	 * @return the applicationID
	 */
	public String getApplicationID() {
		return applicationID;
	}

	/**
	 * @param applicationID the applicationID to set
	 */
	public void setApplicationID(String applicationID) {
		this.applicationID = applicationID;
	}

	/**
	 * @return the tlEmi
	 */
	public BigDecimal getTlEmi() {
		return tlEmi;
	}

	/**
	 * @param tlEmi the tlEmi to set
	 */
	public void setTlEmi(BigDecimal tlEmi) {
		this.tlEmi = tlEmi;
	}

	/**
	 * @return the isEmi
	 */
	public BigDecimal getIsEmi() {
		return isEmi;
	}

	/**
	 * @param isEmi the isEmi to set
	 */
	public void setIsEmi(BigDecimal isEmi) {
		this.isEmi = isEmi;
	}

	/**
	 * @return the firstEmi
	 */
	public BigDecimal getFirstEmi() {
		return firstEmi;
	}

	/**
	 * @param firstEmi the firstEmi to set
	 */
	public void setFirstEmi(BigDecimal firstEmi) {
		this.firstEmi = firstEmi;
	}

	/**
	 * @return the requiredLoanAmount
	 */
	public BigDecimal getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	/**
	 * @param requiredLoanAmount the requiredLoanAmount to set
	 */
	public void setRequiredLoanAmount(BigDecimal requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	/**
	 * @return the impsStatus
	 */
	public String getImpsStatus() {
		return impsStatus;
	}

	/**
	 * @param impsStatus the impsStatus to set
	 */
	public void setImpsStatus(String impsStatus) {
		this.impsStatus = impsStatus;
	}

	/**
	 * @return the impsErrorCode
	 */
	public String getImpsErrorCode() {
		return impsErrorCode;
	}

	/**
	 * @param impsErrorCode the impsErrorCode to set
	 */
	public void setImpsErrorCode(String impsErrorCode) {
		this.impsErrorCode = impsErrorCode;
	}

	/**
	 * @return the impsResponse
	 */
	public String getImpsResponse() {
		return impsResponse;
	}

	/**
	 * @param impsResponse the impsResponse to set
	 */
	public void setImpsResponse(String impsResponse) {
		this.impsResponse = impsResponse;
	}

	/**
	 * @return the impsNameMatch
	 */
	public String getImpsNameMatch() {
		return impsNameMatch;
	}

	/**
	 * @param impsNameMatch the impsNameMatch to set
	 */
	public void setImpsNameMatch(String impsNameMatch) {
		this.impsNameMatch = impsNameMatch;
	}

	/**
	 * @return the product
	 */
	public String getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(String product) {
		this.product = product;
	}

	/**
	 * @return the l3Product
	 */
	public String getL3Product() {
		return l3Product;
	}

	/**
	 * @param l3Product the l3Product to set
	 */
	public void setL3Product(String l3Product) {
		this.l3Product = l3Product;
	}

	/**
	 * @return the occupationType
	 */
	public String getOccupationType() {
		return occupationType;
	}

	/**
	 * @param occupationType the occupationType to set
	 */
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}

	/**
	 * @return the l4Product
	 */
	public String getL4Product() {
		return l4Product;
	}

	/**
	 * @param l4Product the l4Product to set
	 */
	public void setL4Product(String l4Product) {
		this.l4Product = l4Product;
	}

	/**
	 * @return the existingCustomerFlag
	 */
	public Boolean getExistingCustomerFlag() {
		return existingCustomerFlag;
	}

	/**
	 * @param existingCustomerFlag the existingCustomerFlag to set
	 */
	public void setExistingCustomerFlag(Boolean existingCustomerFlag) {
		this.existingCustomerFlag = existingCustomerFlag;
	}

	/**
	 * @return the bankDetails
	 */
	public List<BankDetails> getBankDetails() {
		return bankDetails;
	}

	/**
	 * @param bankDetails the bankDetails to set
	 */
	public void setBankDetails(List<BankDetails> bankDetails) {
		this.bankDetails = bankDetails;
	}

	public Integer getIsTenor() {
		return isTenor;
	}

	public void setIsTenor(Integer isTenor) {
		this.isTenor = isTenor;
	}

	public Integer getDroplineTenor() {
		return droplineTenor;
	}

	public void setDroplineTenor(Integer droplineTenor) {
		this.droplineTenor = droplineTenor;
	}

	public String getBreCallType() {
		return breCallType;
	}

	public void setBreCallType(String breCallType) {
		this.breCallType = breCallType;
	}

	@Override
	public String toString() {
		return "MandateInput [applicationID=" + applicationID + ", tlEmi=" + tlEmi + ", isEmi=" + isEmi + ", firstEmi="
				+ firstEmi + ", requiredLoanAmount=" + requiredLoanAmount + ", impsStatus=" + impsStatus
				+ ", impsErrorCode=" + impsErrorCode + ", impsResponse=" + impsResponse + ", impsNameMatch="
				+ impsNameMatch + ", product=" + product + ", l3Product=" + l3Product + ", occupationType="
				+ occupationType + ", l4Product=" + l4Product + ", existingCustomerFlag=" + existingCustomerFlag
				+ ", isTenor=" + isTenor + ", droplineTenor=" + droplineTenor + ", breCallType=" + breCallType
				+ ", offerDetails=" + offerDetails + ", mandateDetails=" + mandateDetails + ", bankDetails="
				+ bankDetails + "]";
	}
	
}
