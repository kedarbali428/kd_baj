package com.bajaj.markets.credit.application.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.AppLoanPricing;
import com.bajaj.markets.credit.application.model.AppProductListing;
import com.bajaj.markets.credit.application.service.ApplicationLoanPricingService;
import com.bajaj.markets.credit.application.service.ApplicationsProductListService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationLoanPricingController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	ApplicationLoanPricingService applicationLoanPricingService;

	@Autowired
	ApplicationsProductListService appProductListService;

	private static final String CLASSNAME = ApplicationLoanPricingController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE,
			Role.SYSTEMPARTNER })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Create AppLoanPricing record", notes = "Create AppLoanPricing record on the basis of tenure,amount,rate ", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "AppLoanPricing record created Successfully.", response = AppLoanPricing.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 409, message = "conflict AppLoanPricing record already exists.", response = AppLoanPricing.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/applications/{applicationid}/loanpricing", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> createAppLoanPricingRecord(
			@PathVariable("applicationid") @NotBlank(message = "applicationid cannot be null or empty") Long applicationid,
			@RequestParam Integer tenure, @RequestParam BigDecimal amount, @RequestParam BigDecimal rate,
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside createApplicationRecord method controller - application resource :" + applicationid);
		String msg = "Records inserted successfully!!!";

		List<AppProductListing> appProdListings = appProductListService.getAppProductListingRecords(applicationid, 1);
		if (appProdListings.isEmpty()) {
			msg = "Failed because no App Product Listing record found!!!";
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Inside createAppLoanPricingRecord method controller - record insertion failed because App Product Listing record does not exist!");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_001", msg));
		} else {
			List<AppLoanPricing> appLoanPricingRecords = new ArrayList<>();
			for (AppProductListing appProdList : appProdListings) {
				AppLoanPricing pricing = applicationLoanPricingService
						.getAppLoanPricingRecordByApplicationKey(applicationid, 1, appProdList.getAppprodlistkey());
				AppLoanPricing pricingResponse = applicationLoanPricingService.insertOrUpdateAppLoanPricingRecord(
						pricing, applicationid, tenure, amount, rate, appProdList.getAppprodlistkey());
				appLoanPricingRecords.add(pricingResponse);
			}
			if (appLoanPricingRecords.isEmpty()) {
				msg = "Failed to insert records!!!";
				logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
						"Inside createAppLoanPricingRecord method controller - record insertion failed!");
				throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("OMCA_001", msg));
			}
		}
		return new ResponseEntity<>(msg, HttpStatus.CREATED);
	}

}