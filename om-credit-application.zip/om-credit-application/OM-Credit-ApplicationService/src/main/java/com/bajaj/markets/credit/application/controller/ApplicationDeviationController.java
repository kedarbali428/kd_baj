package com.bajaj.markets.credit.application.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.AppDeviationBean;
import com.bajaj.markets.credit.application.bean.AppDeviationResponse;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationDeviationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationDeviationController {
	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private ApplicationDeviationService applicationDeviationService;

	@Autowired
	CustomDefaultHeaders customDefaultHeaders;

	private static final String CLASSNAME = ApplicationDeviationController.class.getName();

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL,Role.CUSTOMER})
	@ApiOperation(value = "Add deviation details for applicationId", notes = "Add deviation details for applicationId", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Deviation details added successfully.", response = AppDeviationBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/creditapplication/applications/{applicationid}/deviation", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<AppDeviationResponse> saveDeviationDetails(
			@Valid @RequestBody AppDeviationBean appDeviationBean, BindingResult result,
			@PathVariable(name = "applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In saveDeviationDetails method with request :" + appDeviationBean);
		String userKey = String.valueOf(customDefaultHeaders.getUserKey());
		AppDeviationResponse response = applicationDeviationService.saveDeviationDetails(appDeviationBean,
					applicationId, userKey);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out saveDeviationDetails method");
			return new ResponseEntity<>(response, HttpStatus.CREATED);
		}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL,Role.CUSTOMER})
	@ApiOperation(value = "Update deviation details for applicationId", notes = "Update deviation details for applicationId", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Deviation details updated successfully.", response = AppDeviationBean[].class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/deviation/{devaitioncodekey}/products/{prodkey}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateDeviationDetails(
			@PathVariable(name = "applicationid") Long applicationid,
			@PathVariable(name = "devaitioncodekey") Integer devaitioncodekey,
			@PathVariable(name = "prodkey") Long prodkey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In updateDeviationDetails method with applicationid "+applicationid+" devaitioncodekey: "+devaitioncodekey+" prodkey "+prodkey);
		String userKey = String.valueOf(customDefaultHeaders.getUserKey());
		List<AppDeviationResponse> response = applicationDeviationService.updateDeviationDetails(applicationid,devaitioncodekey,prodkey, userKey);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateDeviationDetails method");
			return new ResponseEntity<>(response, HttpStatus.CREATED);
		}

	}



