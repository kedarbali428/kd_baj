package com.bajaj.markets.credit.application.helper;

public class ApplicationDisbursementConstant {

	public static final String CUSTOMER_CATEGORY_RETAIL = "RETAIL";
	public static final String BASE_CURRENCY = "INR";
	public static final String PRIMARY_RELATION_OFFICER = "DEFAULT";
	public static final long APPLICANT_TYPE_MAIN_APPLICANT = 1;
	public static final String INCOME_EXPENSES = "INCOME";
	public static final String INCOME_INFO_CAT_SALARIED = "SALARIED";
	public static final String CUST_INCOME_TYPE_BS = "BS";
	public static final String DOC_ISSUE_DATE = "2019-11-11T00:00:00";  
	public static final String DOC_EXP_DATE = "2030-11-11T00:00:00";
	public static final Integer IS_ACTIVE = 1;
	
	public static final String BANK_MASTER = "bank master";
	public static final String BRANCH_MASTER = "branch master";
	public static final String STATUS_CREATED = "CREATED";
	
	public static final String ADDRESS_TYPE_OFFICE_KEY = "46";
	public static final String ADDRESS_TYPE_CURRENT_KEY = "50";
	public static final String ADDRESS_TYPE_PERMANENT_KEY = "48";
	
}