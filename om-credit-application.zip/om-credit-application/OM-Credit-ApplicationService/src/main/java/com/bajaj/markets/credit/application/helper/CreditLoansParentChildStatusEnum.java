package com.bajaj.markets.credit.application.helper;

/**
 * Enum containing mapping of child status with corresponding parent status for Loans
 * 
 * @author 764504
 *
 */
public enum CreditLoansParentChildStatusEnum {
	
	INPROGRESS_AIP(1,2),
	REJECTED(3,5),
	APPROVED(4,4),
	SENTTOBANK(5,5);

	private final Integer childStatus;
	private final Integer parentStatus;
	
	private CreditLoansParentChildStatusEnum(Integer childStatus, Integer parentStatus) {
		this.childStatus = childStatus;
		this.parentStatus = parentStatus;
	}

	public Integer getChildStatus() {
		return childStatus;
	}
	
	public Integer getParentStatus() {
		return parentStatus;
	}
}
