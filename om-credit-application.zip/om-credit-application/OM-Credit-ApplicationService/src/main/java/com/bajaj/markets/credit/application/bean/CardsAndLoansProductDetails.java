package com.bajaj.markets.credit.application.bean;

public class CardsAndLoansProductDetails {
	
	private OpenArcCardListingOutput openArcCardListingOutput;
	private Boolean action;
	private String rejectionSystem;
	private boolean sendNotification;
	
	public OpenArcCardListingOutput getOpenArcCardListingOutput() {
		return openArcCardListingOutput;
	}

	public void setOpenArcCardListingOutput(OpenArcCardListingOutput openArcCardListingOutput) {
		this.openArcCardListingOutput = openArcCardListingOutput;
	}

	public Boolean getAction() {
		return action;
	}

	public void setAction(Boolean action) {
		this.action = action;
	}

	public String getRejectionSystem() {
		return rejectionSystem;
	}

	public void setRejectionSystem(String rejectionSystem) {
		this.rejectionSystem = rejectionSystem;
	}

	public boolean isSendNotification() {
		return sendNotification;
	}

	public void setSendNotification(boolean sendNotification) {
		this.sendNotification = sendNotification;
	}

	@Override
	public String toString() {
		return "CardsAndLoansProductDetails [openArcCardListingOutput=" + openArcCardListingOutput + ", action="
				+ action + ", rejectionSystem=" + rejectionSystem + ", sendNotification=" + sendNotification + "]";
	}		
}
