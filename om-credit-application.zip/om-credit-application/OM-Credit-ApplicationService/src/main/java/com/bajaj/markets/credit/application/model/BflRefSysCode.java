package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bfl_ref_sys_code", schema = "dmcredit")
public class BflRefSysCode implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	private Long bflrefsyscodekey;
	private Long systemkey;
	private String omlable;
	private String omcode;
	private String refcode;
	private Integer isactive;
	public Long getBflrefsyscodekey() {
		return bflrefsyscodekey;
	}
	public void setBflrefsyscodekey(Long bflrefsyscodekey) {
		this.bflrefsyscodekey = bflrefsyscodekey;
	}
	public Long getSystemkey() {
		return systemkey;
	}
	public void setSystemkey(Long systemkey) {
		this.systemkey = systemkey;
	}
	public String getOmlable() {
		return omlable;
	}
	public void setOmlable(String omlable) {
		this.omlable = omlable;
	}
	public String getOmcode() {
		return omcode;
	}
	public void setOmcode(String omcode) {
		this.omcode = omcode;
	}
	public String getRefcode() {
		return refcode;
	}
	public void setRefcode(String refcode) {
		this.refcode = refcode;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	
}
