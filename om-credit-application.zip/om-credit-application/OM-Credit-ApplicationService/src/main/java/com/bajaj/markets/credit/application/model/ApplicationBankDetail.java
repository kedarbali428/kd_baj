package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "application_bank_detail", schema = "dmcredit")
public class ApplicationBankDetail implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -734346019354546968L;
	@Id
	@SequenceGenerator(name = "application_bank_detail_generator", sequenceName = "dmcredit.seq_pk_application_bank_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_bank_detail_generator")
	private Long applicationbankdetkey;
	private Long appattrbkey;
	private Integer acctypkey;
	private Integer branchkey;
	private String accnum;
	private String holdername;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Long impskey;
	private String impsstatus;
	private Integer isimpsverificationrequired;
	private Integer impsnamematch;
	private String source;
	private Long finalmandatekey;
	private Long sysselectedmandatekey;
	private Integer bankacctcatkey;
	private Integer beneficiarytypekey;
	private String beneficiarynames;
	private Integer preferedbank;
	private Integer bankmastkey;
	private String mandateaddedby;
	private Integer mandatereqdflg;
	private Integer mandatecollectedflg;
	private String paymentmode;
	
	@OneToMany(mappedBy = "applicationBankDetail", cascade = CascadeType.ALL)
	private List<AppTrancheDetails> appTranchDetails;
	
	public Long getApplicationbankdetkey() {
		return applicationbankdetkey;
	}
	public void setApplicationbankdetkey(Long applicationbankdetkey) {
		this.applicationbankdetkey = applicationbankdetkey;
	}
	public Long getAppattrbkey() {
		return appattrbkey;
	}
	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}
	public Integer getAcctypkey() {
		return acctypkey;
	}
	public void setAcctypkey(Integer acctypkey) {
		this.acctypkey = acctypkey;
	}
	public Integer getBranchkey() {
		return branchkey;
	}
	public void setBranchkey(Integer branchkey) {
		this.branchkey = branchkey;
	}
	public String getAccnum() {
		return accnum;
	}
	public void setAccnum(String accnum) {
		this.accnum = accnum;
	}
	public String getHoldername() {
		return holdername;
	}
	public void setHoldername(String holdername) {
		this.holdername = holdername;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	public Long getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	public Long getImpskey() {
		return impskey;
	}
	public void setImpskey(Long impskey) {
		this.impskey = impskey;
	}
	public String getImpsstatus() {
		return impsstatus;
	}
	public void setImpsstatus(String impsstatus) {
		this.impsstatus = impsstatus;
	}
	public Integer getIsimpsverificationrequired() {
		return isimpsverificationrequired;
	}
	public void setIsimpsverificationrequired(Integer isimpsverificationrequired) {
		this.isimpsverificationrequired = isimpsverificationrequired;
	}
	public Integer getImpsnamematch() {
		return impsnamematch;
	}
	public void setImpsnamematch(Integer impsnamematch) {
		this.impsnamematch = impsnamematch;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public Long getFinalmandatekey() {
		return finalmandatekey;
	}
	public void setFinalmandatekey(Long finalmandatekey) {
		this.finalmandatekey = finalmandatekey;
	}
	public Long getSysselectedmandatekey() {
		return sysselectedmandatekey;
	}
	public void setSysselectedmandatekey(Long sysselectedmandatekey) {
		this.sysselectedmandatekey = sysselectedmandatekey;
	}
	public Integer getBankacctcatkey() {
		return bankacctcatkey;
	}
	public void setBankacctcatkey(Integer bankacctcatkey) {
		this.bankacctcatkey = bankacctcatkey;
	}
	public Integer getBeneficiarytypekey() {
		return beneficiarytypekey;
	}
	public void setBeneficiarytypekey(Integer beneficiarytypekey) {
		this.beneficiarytypekey = beneficiarytypekey;
	}
	public String getBeneficiarynames() {
		return beneficiarynames;
	}
	public void setBeneficiarynames(String beneficiarynames) {
		this.beneficiarynames = beneficiarynames;
	}
	public Integer getPreferedbank() {
		return preferedbank;
	}
	public void setPreferedbank(Integer preferedbank) {
		this.preferedbank = preferedbank;
	}
	public Integer getBankmastkey() {
		return bankmastkey;
	}
	public void setBankmastkey(Integer bankmastkey) {
		this.bankmastkey = bankmastkey;
	}
	public String getMandateaddedby() {
		return mandateaddedby;
	}
	public void setMandateaddedby(String mandateaddedby) {
		this.mandateaddedby = mandateaddedby;
	}
	public Integer getMandatecollectedflg() {
		return mandatecollectedflg;
	}
	public void setMandatecollectedflg(Integer mandatecollectedflg) {
		this.mandatecollectedflg = mandatecollectedflg;
	}
	public Integer getMandatereqdflg() {
		return mandatereqdflg;
	}
	public void setMandatereqdflg(Integer mandatereqdflg) {
		this.mandatereqdflg = mandatereqdflg;
	}
	public String getPaymentmode() {
		return paymentmode;
	}
	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}
	
	public List<AppTrancheDetails> getAppTranchDetails() {
		return appTranchDetails;
	}
	public void setAppTranchDetails(List<AppTrancheDetails> appTranchDetails) {
		this.appTranchDetails = appTranchDetails;
	}
	@Override
	public ApplicationBankDetail clone() throws CloneNotSupportedException {
		ApplicationBankDetail app = new ApplicationBankDetail();
		app.setAccnum(this.accnum);
		app.setAcctypkey(this.acctypkey);
		app.setAppattrbkey(this.appattrbkey);
		app.setBankacctcatkey(this.bankacctcatkey);
		app.setBeneficiarynames(this.beneficiarynames);
		app.setBeneficiarytypekey(this.beneficiarytypekey);
		app.setBranchkey(this.branchkey);
		app.setFinalmandatekey(this.finalmandatekey);
		app.setHoldername(this.holdername);
		app.setImpskey(this.impskey);
		app.setImpsnamematch(this.impsnamematch);
		app.setImpsstatus(this.impsstatus);
		app.setIsactive(this.isactive);
		app.setIsimpsverificationrequired(this.isimpsverificationrequired);
		app.setLstupdateby(this.lstupdateby);
		app.setLstupdatedt(this.lstupdatedt);
		app.setPreferedbank(this.preferedbank);
		app.setSource(this.source);
		app.setSysselectedmandatekey(this.sysselectedmandatekey);
		app.setBankmastkey(this.bankmastkey);
		app.setMandateaddedby(this.mandateaddedby);
		app.setMandatereqdflg(this.mandatereqdflg);
		app.setMandatecollectedflg(this.mandatecollectedflg);
		app.setPaymentmode(this.paymentmode);
		return app;
	}
}
