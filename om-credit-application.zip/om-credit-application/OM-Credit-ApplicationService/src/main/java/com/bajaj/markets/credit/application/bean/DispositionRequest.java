package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class DispositionRequest implements Serializable{
	
	private String mobileNumber;

	private String agentId;

	private String callbackDate;

	private String dispositionCode;

	private String subDispositionCode;
	
	private String productCode;
	
	private String dispositionDescription;
	
	private String subDispositionDescription;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getCallbackDate() {
		return callbackDate;
	}

	public void setCallbackDate(String callbackDate) {
		this.callbackDate = callbackDate;
	}

	public String getDispositionCode() {
		return dispositionCode;
	}

	public void setDispositionCode(String dispositionCode) {
		this.dispositionCode = dispositionCode;
	}

	public String getSubDispositionCode() {
		return subDispositionCode;
	}

	public void setSubDispositionCode(String subDispositionCode) {
		this.subDispositionCode = subDispositionCode;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getDispositionDescription() {
		return dispositionDescription;
	}

	public void setDispositionDescription(String dispositionDescription) {
		this.dispositionDescription = dispositionDescription;
	}

	public String getSubDispositionDescription() {
		return subDispositionDescription;
	}

	public void setSubDispositionDescription(String subDispositionDescription) {
		this.subDispositionDescription = subDispositionDescription;
	}
}
