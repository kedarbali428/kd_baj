package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class MandateBreRequest {
	    private Long applicationId;
	    private BigDecimal tlEMI; 
        private BigDecimal  isEMI; 
        private BigDecimal  firstEMI;
        private BigDecimal requiredloanAmount;
        private String   impsStatus;
        private String impsErrorCode;
        private String impsResponse;
        private String impsNameMatch;
        private Long   mandateBRECallType;
        private String product;
        private String l3product;
        private String occupationType;
        private String  l4product;
        private Integer isTenor;
    	private Integer droplineTenor;
    	private String breCallType;
    	private String source;
        private AdditionalParameterDetail additionalParameterDetail;
		@JsonIgnore
        private List<OfferDetails> offerDetails;
        private List<MandateDetails> mandateDetails;
        private List<BankDetails> bankDetails;
		public void setTlEMI(BigDecimal tlEMI) {
			this.tlEMI = tlEMI;
		}
		public void setIsEMI(BigDecimal isEMI) {
			this.isEMI = isEMI;
		}
		public void setFirstEMI(BigDecimal firstEMI) {
			this.firstEMI = firstEMI;
		}
		public void setRequiredloanAmount(BigDecimal requiredloanAmount) {
			this.requiredloanAmount = requiredloanAmount;
		}
		public void setImpsStatus(String impsStatus) {
			this.impsStatus = impsStatus;
		}
		public void setImpsErrorCode(String impsErrorCode) {
			this.impsErrorCode = impsErrorCode;
		}
		public void setImpsResponse(String impsResponse) {
			this.impsResponse = impsResponse;
		}
		public void setImpsNameMatch(String impsNameMatch) {
			this.impsNameMatch = impsNameMatch;
		}
		public void setMandateBRECallType(Long mandateBRECallType) {
			this.mandateBRECallType = mandateBRECallType;
		}
		
		public void setL3product(String l3product) {
			this.l3product = l3product;
		}
		public void setOccupationType(String occupationType) {
			this.occupationType = occupationType;
		}
		public void setL4product(String l4product) {
			this.l4product = l4product;
		}
		
		public AdditionalParameterDetail getAdditionalParameterDetail() {
			return additionalParameterDetail;
		}
	
		public void setAdditionalParameterDetail(AdditionalParameterDetail additionalParameterDetail) {
			this.additionalParameterDetail = additionalParameterDetail;
		}
		public List<OfferDetails> getOfferDetails() {
			return offerDetails;
		}
		public void setOfferDetails(List<OfferDetails> offerDetails) {
			this.offerDetails = offerDetails;
		}
		public List<MandateDetails> getMandateDetails() {
			return mandateDetails;
		}
		public void setMandateDetails(List<MandateDetails> mandateDetails) {
			this.mandateDetails = mandateDetails;
		}
		public List<BankDetails> getBankDetails() {
			return bankDetails;
		}
		public void setBankDetails(List<BankDetails> bankDetails) {
			this.bankDetails = bankDetails;
		}
		public Long getApplicationId() {
			return applicationId;
		}
		public void setApplicationId(Long applicationId) {
			this.applicationId = applicationId;
		}
		public void setProduct(String product) {
			this.product = product;
		}
		/**
		 * @return the tlEMI
		 */
		public BigDecimal getTlEMI() {
			return tlEMI;
		}
		/**
		 * @return the isEMI
		 */
		public BigDecimal getIsEMI() {
			return isEMI;
		}
		/**
		 * @return the firstEMI
		 */
		public BigDecimal getFirstEMI() {
			return firstEMI;
		}
		/**
		 * @return the requiredloanAmount
		 */
		public BigDecimal getRequiredloanAmount() {
			return requiredloanAmount;
		}
		/**
		 * @return the impsStatus
		 */
		public String getImpsStatus() {
			return impsStatus;
		}
		/**
		 * @return the impsErrorCode
		 */
		public String getImpsErrorCode() {
			return impsErrorCode;
		}
		/**
		 * @return the impsResponse
		 */
		public String getImpsResponse() {
			return impsResponse;
		}
		/**
		 * @return the impsNameMatch
		 */
		public String getImpsNameMatch() {
			return impsNameMatch;
		}
		/**
		 * @return the mandateBRECallType
		 */
		public Long getMandateBRECallType() {
			return mandateBRECallType;
		}
		/**
		 * @return the product
		 */
		public String getProduct() {
			return product;
		}
		/**
		 * @return the l3product
		 */
		public String getL3product() {
			return l3product;
		}
		/**
		 * @return the occupationType
		 */
		public String getOccupationType() {
			return occupationType;
		}
		/**
		 * @return the l4product
		 */
		public String getL4product() {
			return l4product;
		}
		public Integer getIsTenor() {
			return isTenor;
		}
		public void setIsTenor(Integer isTenor) {
			this.isTenor = isTenor;
		}
		public Integer getDroplineTenor() {
			return droplineTenor;
		}
		public void setDroplineTenor(Integer droplineTenor) {
			this.droplineTenor = droplineTenor;
		}
		public String getBreCallType() {
			return breCallType;
		}
		public void setBreCallType(String breCallType) {
			this.breCallType = breCallType;
		}
		public String getSource() {
			return source;
		}
		public void setSource(String source) {
			this.source = source;
		}
		@Override
		public String toString() {
			return "MandateBreRequest [applicationId=" + applicationId + ", tlEMI=" + tlEMI + ", isEMI=" + isEMI
					+ ", firstEMI=" + firstEMI + ", requiredloanAmount=" + requiredloanAmount + ", impsStatus="
					+ impsStatus + ", impsErrorCode=" + impsErrorCode + ", impsResponse=" + impsResponse
					+ ", impsNameMatch=" + impsNameMatch + ", mandateBRECallType=" + mandateBRECallType + ", product="
					+ product + ", l3product=" + l3product + ", occupationType=" + occupationType + ", l4product="
					+ l4product + ", isTenor=" + isTenor + ", droplineTenor=" + droplineTenor + ", breCallType="
					+ breCallType + ", source=" + source + ", additionalParameterDetail=" + additionalParameterDetail
					+ ", offerDetails=" + offerDetails + ", mandateDetails=" + mandateDetails + ", bankDetails="
					+ bankDetails + "]";
		}
		
}
