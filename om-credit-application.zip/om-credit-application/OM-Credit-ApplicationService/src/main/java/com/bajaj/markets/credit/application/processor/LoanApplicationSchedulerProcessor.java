package com.bajaj.markets.credit.application.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.application.bean.PrincipalConsumerRequest;
import com.bajaj.markets.credit.application.bean.SchedulerProduct;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.model.ApplicationAttribute;
import com.bajaj.markets.credit.application.model.StatusMaster;
import com.bajaj.markets.credit.application.repository.tx.ApplicationAttributeRepository;
import com.bajaj.markets.credit.application.repository.tx.StatusMasterRepository;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.publisher.service.PublisherService;

@Component
public class LoanApplicationSchedulerProcessor implements ApplicationSchedulerProcessor {

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private ApplicationAttributeRepository applicationAttributeRepository;

	@Autowired
	private StatusMasterRepository statusMasterRepository;

	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;

	@Autowired
	PublisherService publisherService;
 
	@Value("${aws.publisher.principal.topic.arn}")
	private String topicArn;

	@Value("#{${loan.scheduler.completionPercent.map}}")
	private Map<String,String> completionPercentMap;

	@Value("${loan.scheduler.application.status}")
	private String applicationStatus;

	@Value("${loan.scheduler.application.days}")
	private String applicationDays;

	private static final String CLASS_NAME = LoanApplicationSchedulerProcessor.class.getCanonicalName();

	@Override
	public void callToGetApplicationsAndPushToEvent(SchedulerProduct request, HttpHeaders headers) {
		String principalCode=request.getPrincipalCode();
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Strat loanApplicationSchedulerProcessor -callToGetApplicationsAndPushToEvent for principalCode: " + principalCode);
		try {

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Status API Scheduler for--"
					+ principalCode + "--started at: " + Calendar.getInstance().getTime());
			Long principleKey = Long.valueOf(request.getPrincipalCode());
			Integer completionPercent = Integer.valueOf(completionPercentMap.get(request.getPrincipalCode()));
			List<ApplicationAttribute> appList = filterCriteria(principleKey,completionPercent);
			if (!CollectionUtils.isEmpty(appList)) {
				appList.forEach(appattrb -> {
					try {
						Long applicationKey = appattrb.getApplication().getApplicationkey();
						Map<String, String> params = new HashMap<>();
						params.put(ApplicationConstants.MOBILE_NO, String.valueOf(appattrb.getMobile()));
						params.put("principalKey", String.valueOf(principleKey));

						pushApplicationsToEvent(params, String.valueOf(applicationKey), headers);
					} catch (Exception e) {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
								"Exception occured while getting attribute details with principleKey: "+principleKey, e);
					}
				});
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Scheduler for--" + principalCode + "--completed for count: " + appList.size());
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured in scheduler for principalCode: " + principalCode, e);
		}
	}

	private List<ApplicationAttribute> filterCriteria(Long principleKey,Integer completionPercent) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start filterCriteria for principleKey: " + principleKey);
		List<ApplicationAttribute> appList = null;
		try {
			Integer intAppDays = Integer.parseInt(applicationDays);

			List<String> appStatus = Arrays.asList(applicationStatus.split(","));
			List<Integer> intStatus = new ArrayList<>();
			appStatus.forEach(o -> {
				StatusMaster statusMaster = statusMasterRepository.findByStatusdescAndIsactive(o,
						ApplicationConstants.IS_ACTIVE);
				intStatus.add(statusMaster.getStatuskey().intValue());
			});

			Calendar cal2 = Calendar.getInstance();
			cal2.add(Calendar.DAY_OF_MONTH, -intAppDays);
			Date filterDate = cal2.getTime();

			Calendar cal1 = Calendar.getInstance();
			cal1.add(Calendar.DAY_OF_MONTH, 1);
			Date currentDate = cal1.getTime();

			appList = applicationAttributeRepository.findApplicationsForLoansStatusApi(completionPercent, principleKey,
					currentDate, filterDate, intStatus);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Application count after filter: " + appList.size());
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Technical exception occured in filterCriteria for principleKey: " + principleKey ,e);
		}
		return appList;
	}

	private void pushApplicationsToEvent(Map<String, String> params, String applicationKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start pushApplicationsToEvent for application: " + applicationKey);
		try {
			PrincipalConsumerRequest consumerRequest = new PrincipalConsumerRequest();
			consumerRequest.setMobileNumber(params.get(ApplicationConstants.MOBILE_NO));
			consumerRequest.setApplicationKey(applicationKey);
			consumerRequest.setPrincipalKey(params.get("principalKey"));
			Map<String, String> messageFilterAttributes = new HashMap<>();
			Map<String, String> header = new HashMap<>();
			header.put(ApplicationConstants.AUTH_TOKEN, headers.get(ApplicationConstants.AUTH_TOKEN).get(0));
			header.put(ApplicationConstants.CMPT_CORR_ID, customDefaultHeaders.getCmptcorrid());
			header.put(ApplicationConstants.APPLICATIONID, applicationKey);
			header.put(ApplicationConstants.MOBILE, params.get(ApplicationConstants.MOBILE_NO));
			messageFilterAttributes.put("isPrincipalDelayRequired", "NO");
			EventMessage eventMessage = new EventMessage();
			eventMessage.setMessageFilterAttributes(messageFilterAttributes);
			eventMessage.setEventName(ApplicationConstants.PRINCIPAL_STATUS_CHECK);
			eventMessage.setHeaders(header); 
			eventMessage.setPayload(consumerRequest);
			publisherService.publish(topicArn, eventMessage);

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Successfully pushed status event for application: "+applicationKey);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Status api scheduler failed for application: " + applicationKey);
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, e.getLocalizedMessage());
		}
	}

}
