package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

public class ApplicationStatus {
	@Digits(fraction = 0, integer = 2, message = "Invalid status Key.")
	private Integer statusKey;
	@Pattern(regexp = "^\\w+( \\w+)*$", message = "Invalid status value.")
	private String statusValue;
	private RejectionBean rejectionBean;

	public Integer getStatusKey() {
		return statusKey;
	}

	public void setStatusKey(Integer statusKey) {
		this.statusKey = statusKey;
	}

	public String getStatusValue() {
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

	public RejectionBean getRejectionBean() {
		return rejectionBean;
	}

	public void setRejectionBean(RejectionBean rejectionBean) {
		this.rejectionBean = rejectionBean;
	}

	@Override
	public String toString() {
		return "ApplicationStatus [statusKey=" + statusKey + ", statusValue=" + statusValue + ", rejectionBean="
				+ rejectionBean + "]";
	}

}
