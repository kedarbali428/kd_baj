package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.PrincipleCustomerInfo;

public interface PrincipleCustomerInfoRoInterface extends ReadInterface<PrincipleCustomerInfo, Long> {
	PrincipleCustomerInfo findByApplicationkeyAndAppattrbkeyAndIsactive(Long applicationkey, Long appattrbkey,
			Integer isActive);

	PrincipleCustomerInfo findByApplicationkeyAndAppattrbkeyAndPrincipalkeyAndIsactive(Long applicationkey,
			Long appattrbkey, Long principalkey, Integer isActive);

	List<PrincipleCustomerInfo> findByIsactiveAndApplicationkeyAndAppattrbkey(Integer isActive, Long applicationkey,
			Long appattrbkey);

	List<PrincipleCustomerInfo> findByIsactiveAndApplicationkey(Integer isActive, Long applicationkey);

	PrincipleCustomerInfo findByApplicationkeyAndAppattrbkeyAndPrinciplecustrefsrcAndIsactive(Long applicationkey,
			Long appattrbkey, String source, Integer isActive);

	PrincipleCustomerInfo findByApplicationkeyAndPrincipalkeyAndIsactive(Long applicationkey, Long principalkey,
			Integer isActive);
}
