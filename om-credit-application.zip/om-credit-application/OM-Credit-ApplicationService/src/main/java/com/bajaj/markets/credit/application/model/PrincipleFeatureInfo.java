package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the principle_feature_info database table.
 * 
 */
@Entity
@Table(name = "principle_feature_info", schema = "dmcredit")
public class PrincipleFeatureInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "seq_pk_principle_feature_info", sequenceName = "dmcredit.seq_pk_principle_feature_info", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_pk_principle_feature_info")
	private Long principlefeatureinfokey;

	private Long applicationkey;

	private Integer contactless;

	private Integer ecom;

	private Integer international;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long prodkey;

	public PrincipleFeatureInfo() {
	}

	public Long getPrinciplefeatureinfokey() {
		return this.principlefeatureinfokey;
	}

	public void setPrinciplefeatureinfokey(Long principlefeatureinfokey) {
		this.principlefeatureinfokey = principlefeatureinfokey;
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getContactless() {
		return this.contactless;
	}

	public void setContactless(Integer contactless) {
		this.contactless = contactless;
	}

	public Integer getEcom() {
		return this.ecom;
	}

	public void setEcom(Integer ecom) {
		this.ecom = ecom;
	}

	public Integer getInternational() {
		return this.international;
	}

	public void setInternational(Integer international) {
		this.international = international;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdkey() {
		return this.prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

}