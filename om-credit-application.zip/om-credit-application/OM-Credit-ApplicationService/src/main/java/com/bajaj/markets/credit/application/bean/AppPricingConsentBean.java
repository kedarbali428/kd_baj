package com.bajaj.markets.credit.application.bean;

public class AppPricingConsentBean {

	private Long apploanpricingkey;
	private String consentMechanism;
	private Integer consentsentflg;
	private Integer consentcapturedflg;
	private Integer employeecatureflg;
	private Long employeeuserkey;

	public Long getApploanpricingkey() {
		return apploanpricingkey;
	}

	public void setApploanpricingkey(Long apploanpricingkey) {
		this.apploanpricingkey = apploanpricingkey;
	}

	public String getConsentMechanism() {
		return consentMechanism;
	}

	public void setConsentMechanism(String consentMechanism) {
		this.consentMechanism = consentMechanism;
	}

	public Integer getConsentsentflg() {
		return consentsentflg;
	}

	public void setConsentsentflg(Integer consentsentflg) {
		this.consentsentflg = consentsentflg;
	}

	public Integer getConsentcapturedflg() {
		return consentcapturedflg;
	}

	public void setConsentcapturedflg(Integer consentcapturedflg) {
		this.consentcapturedflg = consentcapturedflg;
	}

	public Integer getEmployeecatureflg() {
		return employeecatureflg;
	}

	public void setEmployeecatureflg(Integer employeecatureflg) {
		this.employeecatureflg = employeecatureflg;
	}

	public Long getEmployeeuserkey() {
		return employeeuserkey;
	}

	public void setEmployeeuserkey(Long employeeuserkey) {
		this.employeeuserkey = employeeuserkey;
	}

	@Override
	public String toString() {
		return "AppPricingConsentBean [apploanpricingkey=" + apploanpricingkey + ", consentMechanism="
				+ consentMechanism + ", consentsentflg=" + consentsentflg + ", consentcapturedflg=" + consentcapturedflg
				+ ", employeecatureflg=" + employeecatureflg + ", employeeuserkey=" + employeeuserkey + "]";
	}

}