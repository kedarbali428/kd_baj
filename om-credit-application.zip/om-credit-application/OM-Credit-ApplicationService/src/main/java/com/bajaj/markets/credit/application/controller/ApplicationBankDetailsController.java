package com.bajaj.markets.credit.application.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.BankDetailsReponse;
import com.bajaj.markets.credit.application.bean.BankDetailsRequest;
import com.bajaj.markets.credit.application.bean.FinalMandateResponse;
import com.bajaj.markets.credit.application.bean.ImpsRequestBean;
import com.bajaj.markets.credit.application.bean.ImpsResponseMetadata;
import com.bajaj.markets.credit.application.bean.MandateReference;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationBankDetailsService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationBankDetailsController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	ApplicationBankDetailsService applicationBankDetailsService;

	private static final String CLASSNAME = ApplicationBankDetailsController.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "Applications bank details endpoint", notes = "Save user bank details", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Bank details added successfully.", response = BankDetailsReponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 409, message = "Conflict", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "${api.omcreditapplicationservice.savebankdetails.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> saveBankDetails(@Valid @RequestBody BankDetailsRequest bankDetails,
			@PathVariable(name = "applicationKey") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") String applicationId,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside ApplicationBankDetailsController :: saveBankDetails method started - applicationKey :" + applicationId);
		BankDetailsReponse response = applicationBankDetailsService.saveBankDetails(bankDetails,applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Completed ApplicationBankDetailsController :: saveBankDetails method and response :"+response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.INTERNAL,Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.SYSTEM})
	@ApiOperation(value = "Fetch bank details.", notes = "Fetch bank details on the basis of applicationKey.", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Fetching bank details successfully.", response = BankDetailsReponse.class ,responseContainer = "List"),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "${api.omcreditapplicationservice.getbankdetails.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	//@EnableFineGrainCheck
	public ResponseEntity<Object> getBankDetails(@PathVariable(name ="applicationKey") @NotBlank(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") String applicationId, 
			@RequestParam(name = "isPreferedForRepayment", required = false) Boolean isPreferedForRepayment,@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside ApplicationBankDetailsController :: getBankDetails method started - applicationKey :" + applicationId);
		List<BankDetailsReponse> response=applicationBankDetailsService.getBankDetails(applicationId, isPreferedForRepayment);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside ApplicationBankDetailsController :: getBankDetails method completed successfully:" + response );
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER,Role.EMPLOYEE})
	@ApiOperation(value = "Applications bank details endpoint", notes = "Update user bank details", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Bank details added successfully.", response = BankDetailsReponse.class),
			@ApiResponse(code = 200, message = "Bank details updated sucessfully", response = BankDetailsReponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value ="${api.omcreditapplicationservice.updatebankdetails.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateBankDetails(@Valid @RequestBody BankDetailsRequest bankDetails, BindingResult result,
			@PathVariable(name = "applicationKey") @NotNull(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") String applicationId,
			@PathVariable(name = "bankdetailskey") @NotNull(message = "bankdetailskey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "bankdetailskey should be numeric & should not exceeds size") String bankdetailsKey,@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside ApplicationBankDetailsController :: updateBankDetails method started - applicationKey :" + applicationId);
		BankDetailsReponse response = applicationBankDetailsService.updateBankDetails(bankDetails, applicationId,bankdetailsKey);;
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Completed ApplicationBankDetailsController :: updateBankDetails method " + response);
		return new ResponseEntity<>(response, HttpStatus.OK);
		
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER,Role.EMPLOYEE,Role.INTERNAL})
	@ApiOperation(value = "Fetch bank details.", notes = "Fetch bank details on the basis of applicationKey and bankdetailskey.", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Fetching bank details successfully.", response = BankDetailsReponse.class),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "${api.omcreditapplicationservice.fetchbankdetails.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> fetchBankDetails(@PathVariable("applicationKey") @NotBlank(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") String applicationId, 
			@PathVariable("bankdetailskey") @NotBlank(message = "bankdetailskey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "bankdetailskey should be numeric") String bankdetailsKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside ApplicationBankDetailsController :: fetchBankDetails method started - applicationKey :" + applicationId);
		BankDetailsReponse response=applicationBankDetailsService.fetchBankDetails(applicationId,bankdetailsKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside ApplicationBankDetailsController :: fetchBankDetails method completed successfully:" + response );
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Save final mandate in repayment bank details", notes = "Save final mandatekey in repayment bank details", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Final mandate updated Successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/creditapplication/applications/{applicationid}/updatemandate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveFinalMandate(@Valid @RequestBody MandateReference mandateReference,
			@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In saveFinalMandate method with applicationId: " + applicationId);
        //service call
		FinalMandateResponse mandateResponse = applicationBankDetailsService.saveFinalMandate(mandateReference, applicationId);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out saveFinalMandate method with response : "+mandateResponse);
		return new ResponseEntity<>(mandateResponse,HttpStatus.CREATED);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "Fetch imps details.", notes = "Fetch imps details on the basis of applicationKey.", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Fetching imps details successfully.", response = ImpsRequestBean.class ,responseContainer = "List"),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/creditapplication/applications/{applicationid}/imps", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> getImpsDetails(@PathVariable(name ="applicationid")@NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId, 
			@RequestParam(name = "bankAcctcatKey") Integer bankAcctcatKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside ApplicationBankDetailsController :: getImpsDetails method started - applicationKey :" + applicationId);
		ImpsRequestBean response=applicationBankDetailsService.getImpsDetails(applicationId,bankAcctcatKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside ApplicationBankDetailsController :: getImpsDetails method completed successfully:" + response );
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Save Imps details for application", notes = "Save imps details for application", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Imps details saved successfully"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid Input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)	})
	@PutMapping(path = "/v1/creditapplication/applications/{applicationid}/imps", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> saveImpsDetails(@Valid @RequestBody ImpsResponseMetadata impsResponse,@PathVariable(name ="applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size")String applicationId, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside ApplicationBankDetailsController :: saveImpsDetails method started - applicationKey :" + applicationId);
		applicationBankDetailsService.saveImpsDetails(applicationId,impsResponse);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside ApplicationBankDetailsController :: saveImpsDetails method completed successfully:" );
		return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
	}
	
	
	
}
