package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "deviation_code", schema = "dmcredit")
public class DeviationCode implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer devaitioncodekey;
	
	private Integer deviationcatkey;
	
	private String deviationcd;
	
	private String deviationdscr;
	
	private Integer isactive;
	
	private Long lstupdateby;
	
	private Timestamp lstupdatedt;
	
	private String approverauthority;
	
	private Long prodcatkey;
	
	private Long prodkey;

	public Integer getDevaitioncodekey() {
		return devaitioncodekey;
	}

	public void setDevaitioncodekey(Integer devaitioncodekey) {
		this.devaitioncodekey = devaitioncodekey;
	}

	public Integer getDeviationcatkey() {
		return deviationcatkey;
	}

	public void setDeviationcatkey(Integer deviationcatkey) {
		this.deviationcatkey = deviationcatkey;
	}

	public String getDeviationcd() {
		return deviationcd;
	}

	public void setDeviationcd(String deviationcd) {
		this.deviationcd = deviationcd;
	}

	public String getDeviationdscr() {
		return deviationdscr;
	}

	public void setDeviationdscr(String deviationdscr) {
		this.deviationdscr = deviationdscr;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getApproverauthority() {
		return approverauthority;
	}

	public void setApproverauthority(String approverauthority) {
		this.approverauthority = approverauthority;
	}

	public Long getProdcatkey() {
		return prodcatkey;
	}

	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}
	
}

