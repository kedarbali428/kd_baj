package com.bajaj.markets.credit.application.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.application.bean.AppPlanDetCostBean;
import com.bajaj.markets.credit.application.bean.BranchDetails;
import com.bajaj.markets.credit.application.bean.BundleApplicationDetail;
import com.bajaj.markets.credit.application.bean.CityResponseBean;
import com.bajaj.markets.credit.application.bean.EmandateRegistrationBean;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class ApplicationPricingProcessor {
	@Value("${api.omvasapplicationservice.applicationcost.GET.url}")
	private String getApplicationCostUrl;
	
	@Value("${api.omvasapplicationservice.application.GET.url}")
	private String getApplicationDetailsUrl;

	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;

	@Autowired
	private Environment env;
	
	@Value("${api.payment.GET.url}")
	private String getEmandatePaymentUrl;
	
	@Value("${api.citycode.GET.uri}")
	private String getCityCodeUrl;
	@Value("${api.referencedata.banks.GET.uri}")
	private String getImpsIfscCodeUrl;
	
	@Autowired
	private BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = ApplicationPricingProcessor.class.getCanonicalName();

	public List<AppPlanDetCostBean> getApplicationCost(String applicationKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start - getApplicationCost method for applicationId : " +applicationKey);
		List<AppPlanDetCostBean> listAppPlanDetCostBean = null;
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		ObjectMapper mapper = new ObjectMapper();
		try {
			params.put(ApplicationConstants.APPLICATIONKEY, applicationKey);
			ResponseEntity<Object> getApplicationCostResp = creditApplicationServiceUtility
					.excuteRestCall(getApplicationCostUrl, HttpMethod.GET, String.class, params, null, headers);
			if (getApplicationCostResp.getStatusCode().equals(HttpStatus.OK)) {
				listAppPlanDetCostBean = mapper.readValue(getApplicationCostResp.getBody().toString(),
						new TypeReference<List<AppPlanDetCostBean>>(){});
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in getApplicationCost service call while getting cost of FPP Application."
								+ getApplicationCostResp.getBody().toString());
				throw new CreditApplicationServiceException(getApplicationCostResp.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1032,
								env.getProperty(ApplicationConstants.CAS_1032)));
			}
		} catch (CreditApplicationServiceException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while getting cost for applicationId : "+applicationKey ,e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while getting cost for applicationId : "+applicationKey ,e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End - getApplicationCost method completed successfully for applicationId : "+applicationKey + " Response String : " + listAppPlanDetCostBean.toString());
		return listAppPlanDetCostBean;
	}
	
	public BundleApplicationDetail getBundleApplicationDetailsFromDmvas(String applicationKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start - getBundleApplicationDetailsFromDmvas for applicationId : "+applicationKey);
		BundleApplicationDetail bundleApplicationDetail = null;
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		try {
			params.put(ApplicationConstants.APPLICATIONKEY, applicationKey);
			ResponseEntity<Object> getApplicationCostResp = creditApplicationServiceUtility
					.excuteRestCall(getApplicationDetailsUrl, HttpMethod.GET, String.class, params, null, headers);
			if (getApplicationCostResp.getStatusCode().equals(HttpStatus.OK)) {
				bundleApplicationDetail = mapper.readValue(getApplicationCostResp.getBody().toString(), BundleApplicationDetail.class);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in getBundleApplicationDetailsFromDmvas service call while getting details of FPP Application."
								+ getApplicationCostResp.getBody().toString());
				throw new CreditApplicationServiceException(getApplicationCostResp.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1033,
								env.getProperty(ApplicationConstants.CAS_1033)));
			}
		} catch (CreditApplicationServiceException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while getting details of FPP for applicationId : "+applicationKey ,e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while getting details of FPP for applicationId : " + applicationKey, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End getBundleApplicationDetailsFromDmvas method completed successfully for applicationId : " +applicationKey
				+ " Response String : " + bundleApplicationDetail.toString());
		return bundleApplicationDetail;
	}
	
	public EmandateRegistrationBean getEmandateRegistrationDetails(String applicationKey)
	{
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start getEmandateRegistrationDetails method for applicationId "+applicationKey);
		EmandateRegistrationBean emandateRegistration = null;
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			params.put(ApplicationConstants.APPLICATIONKEY, applicationKey);
			ResponseEntity<Object> emandateRegistrationResp = creditApplicationServiceUtility
					.excuteRestCall(getEmandatePaymentUrl, HttpMethod.GET, String.class, params, null, headers);
			if (emandateRegistrationResp.getStatusCode().equals(HttpStatus.OK)) {
				emandateRegistration = mapper.readValue(emandateRegistrationResp.getBody().toString(),
						new TypeReference<EmandateRegistrationBean>(){});
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in getEmandateRegistrationDetails service call"
								+ emandateRegistrationResp.getBody().toString());
				throw new CreditApplicationServiceException(emandateRegistrationResp.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1032,
								env.getProperty(ApplicationConstants.CAS_1032)));
			}
		
		}catch (CreditApplicationServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while fetching details of emandateRegistration for applicationId: " + applicationKey, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End getEmandateRegistrationDetails method for applicationId : "+applicationKey + " Response String : " + emandateRegistration.toString());
		
		return emandateRegistration;
		
	}
	
	public List<BranchDetails> getIfscCode(Integer branchkey)
	{
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start - Inside getIfscCode for branchKey : "+branchkey);
		Gson gson = new Gson();
		List<BranchDetails> branchDetailsList = new ArrayList<>();
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		ObjectMapper mapper = new ObjectMapper();
		try {
			params.put("branchKey", branchkey.toString());
			ResponseEntity<Object> executRestCall = creditApplicationServiceUtility
					.excuteRestCall(getImpsIfscCodeUrl, HttpMethod.GET, String.class, params, null, headers); 
			if (null != executRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				BranchDetails[] bankDetails = gson.fromJson(executRestCall.getBody().toString(), BranchDetails[].class);
				branchDetailsList = Arrays.asList(bankDetails);
			}
			else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in getIfscCode service call"
								+ executRestCall.getBody().toString());
				throw new CreditApplicationServiceException(executRestCall.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1032,
								env.getProperty(ApplicationConstants.CAS_1032)));
			}
		} catch (CreditApplicationServiceException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while getting details Ifsc Code for branchKey : "+branchkey , e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while getting details Ifsc Code for branchKey : "+branchkey , e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End - Inside getIfscCode for branchKey : " +branchkey + " Response String : " + branchDetailsList.toString());
		return branchDetailsList;
	}
	
	public CityResponseBean getCityCode(String citykey)
	{
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Start - Inside getEmandateRegistrationDetails for cityKey : "+citykey);
		CityResponseBean cityResponseBean = null;
		HashMap<String, String> params = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			params.put("citykey", citykey);
			ResponseEntity<Object> cityResponseBeanResp = creditApplicationServiceUtility
					.excuteRestCall(getCityCodeUrl, HttpMethod.GET, String.class, params, null, headers);
			if (cityResponseBeanResp.getStatusCode().equals(HttpStatus.OK)) {
				cityResponseBean = mapper.readValue(cityResponseBeanResp.getBody().toString(),
						new TypeReference<CityResponseBean>(){});
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in getEmandateRegistrationDetails service call"
								+ cityResponseBeanResp.getBody().toString());
				throw new CreditApplicationServiceException(cityResponseBeanResp.getStatusCode(),
						new ErrorBean(ApplicationConstants.CAS_1032,
								env.getProperty(ApplicationConstants.CAS_1032)));
			}
		
		}catch (CreditApplicationServiceException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while getting details of citycode for citykey : " +citykey, e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while getting details of citycode for citykey : " +citykey, e);
			throw new CreditApplicationServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(ApplicationConstants.CAS_1014, env.getProperty(ApplicationConstants.CAS_1014)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End - Inside getEmandateRegistrationDetails for cityKey : "+citykey + " Response String : " + cityResponseBean.toString());
		
		return cityResponseBean;
		}
}