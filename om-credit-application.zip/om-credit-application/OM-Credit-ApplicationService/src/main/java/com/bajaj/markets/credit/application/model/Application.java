package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

/**
 * The persistent class for the application database table.
 * 
 */
@DynamicUpdate 
@DynamicInsert 
@Entity
@Table(name = "application", schema = "dmcredit")
public class Application implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "application_applicationkey_generator", sequenceName = "dmcredit.seq_pk_application", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_applicationkey_generator")
	private Long applicationkey;

	private Timestamp appdate;

	private Integer appstatus;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long prodcdl2;

	private Long parentapplicationkey;

	private Long prodcdl3;

	private Long prodtypekey;

	private BigDecimal inprocessflg;

	private String riskoffertype;

	private BigDecimal cardlimit;
	
	private Integer isbundleselected;
	
	private String productrefno;
	
	private Long pincodekey;

	@OneToMany(mappedBy = "application", cascade = CascadeType.ALL)
	private Set<ApplicationAttribute> applicationAttributes;
	
	//bi-directional many-to-one association to LoanPurpose
	@ManyToOne
	@JoinColumn(name="loanpurposekey")
	private LoanPurpose loanPurpose;

	@OneToMany(mappedBy = "application", cascade = CascadeType.ALL)
	private Set<AppFinEligibilityRevision> appFinEligibilityRevision;


	private String hlproductintent;
	
	private Integer statusapi; 
	
	private String createdBy; 
	
	private Long citykey;
	
	private Integer bflbranchkey;
	
	private String appprocessidentifier;
	
	private Integer requestedcreditamount;
	
	private Integer requestedtenuremonths;
	
	private Boolean fppselectedbyuser;
	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getStatusapi() { 
		return statusapi;
	}

	public void setStatusapi(Integer statusapi) { 
		this.statusapi = statusapi;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	public BigDecimal getInprocessflg() {
		return inprocessflg;
	}

	public void setInprocessflg(BigDecimal inprocessflg) {
		this.inprocessflg = inprocessflg;
	}

	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	public Application() {
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Timestamp getAppdate() {
		return this.appdate;
	}

	public void setAppdate(Timestamp appdate) {
		this.appdate = appdate;
	}

	public Integer getAppstatus() {
		return this.appstatus;
	}

	public void setAppstatus(Integer appstatus) {
		this.appstatus = appstatus;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdcdl2() {
		return this.prodcdl2;
	}

	public void setProdcdl2(Long prodcdl2) {
		this.prodcdl2 = prodcdl2;
	}

	public Set<ApplicationAttribute> getApplicationAttributes() {
		return this.applicationAttributes;
	}

	public void setApplicationAttributes(Set<ApplicationAttribute> applicationAttributes) {
		this.applicationAttributes = applicationAttributes;
	}

	public Long getParentapplicationkey() {
		return parentapplicationkey;
	}

	public void setParentapplicationkey(Long parentapplicationkey) {
		this.parentapplicationkey = parentapplicationkey;
	}

	public Long getProdcdl3() {
		return prodcdl3;
	}

	public void setProdcdl3(Long prodcdl3) {
		this.prodcdl3 = prodcdl3;
	}

	public BigDecimal getCardlimit() {
		return cardlimit;
	}

	public void setCardlimit(BigDecimal cardlimit) {
		this.cardlimit = cardlimit;
	}
	
	public LoanPurpose getLoanPurpose() {
		return loanPurpose;
	}

	public void setLoanPurpose(LoanPurpose loanPurpose) {
		this.loanPurpose = loanPurpose;
	}
	
	public String getHlproductintent() {
		return hlproductintent;
	}

	public void setHlproductintent(String hlproductintent) {
		this.hlproductintent = hlproductintent;
	}

	public Integer getIsbundleselected() {
		return isbundleselected;
	}

	public void setIsbundleselected(Integer isbundleselected) {
		this.isbundleselected = isbundleselected;
	}
	
	public String getProductrefno() {
		return productrefno;
	}

	public void setProductrefno(String productrefno) {
		this.productrefno = productrefno;
	}

	public Long getCitykey() {
		return citykey;
	}

	public void setCitykey(Long citykey) {
		this.citykey = citykey;
	}

	public Set<AppFinEligibilityRevision> getAppFinEligibilityRevision() {
		return appFinEligibilityRevision;
	}

	public void setAppFinEligibilityRevision(Set<AppFinEligibilityRevision> appFinEligibilityRevision) {
		this.appFinEligibilityRevision = appFinEligibilityRevision;
	}

	public Integer getBflbranchkey() {
		return bflbranchkey;
	}

	public void setBflbranchkey(Integer bflbranchkey) {
		this.bflbranchkey = bflbranchkey;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public String getAppprocessidentifier() {
		return appprocessidentifier;
	}

	public void setAppprocessidentifier(String appprocessidentifier) {
		this.appprocessidentifier = appprocessidentifier;
	}

	public Integer getRequestedcreditamount() {
		return requestedcreditamount;
	}

	public void setRequestedcreditamount(Integer requestedcreditamount) {
		this.requestedcreditamount = requestedcreditamount;
	}

	public Integer getRequestedtenuremonths() {
		return requestedtenuremonths;
	}

	public void setRequestedtenuremonths(Integer requestedtenuremonths) {
		this.requestedtenuremonths = requestedtenuremonths;
	}

	public Boolean getFppselectedbyuser() {
		return fppselectedbyuser;
	}

	public void setFppselectedbyuser(Boolean fppselectedbyuser) {
		this.fppselectedbyuser = fppselectedbyuser;
	}
	
	
}