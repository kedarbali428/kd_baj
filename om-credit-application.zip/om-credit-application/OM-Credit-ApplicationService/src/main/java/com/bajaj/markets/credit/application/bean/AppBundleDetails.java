package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.BundleNotSelected;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.BundleSelected;

public class AppBundleDetails {

	@NotNull(groups = { BundleSelected.class, BundleNotSelected.class }, message = "bundleSelected flag can not be null")
	private Boolean bundleSelected;

	private Long appBundleKey;

	@NotNull(groups = { BundleSelected.class, BundleNotSelected.class }, message = "Only digit is allowed in applicationKey.")
	private Long applicationKey;

	@NotNull(groups = BundleSelected.class, message = "Only digit is allowed in bundleApplicationKey.")
	private Long bundleApplicationKey;

	private Integer bundlePlanKey;

	private String source;
	
	private Long apploanpricingkey;
	
	private Integer isActive;
	
	private Integer bundlerevision;
	
	private String status;
	

	public Long getApploanpricingkey() {
		return apploanpricingkey;
	}

	public void setApploanpricingkey(Long apploanpricingkey) {
		this.apploanpricingkey = apploanpricingkey;
	}

	public Integer getBundlerevision() {
		return bundlerevision;
	}

	public void setBundlerevision(Integer bundlerevision) {
		this.bundlerevision = bundlerevision;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public Long getAppBundleKey() {
		return appBundleKey;
	}

	public void setAppBundleKey(Long appBundleKey) {
		this.appBundleKey = appBundleKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getBundleApplicationKey() {
		return bundleApplicationKey;
	}

	public void setBundleApplicationKey(Long bundleApplicationKey) {
		this.bundleApplicationKey = bundleApplicationKey;
	}

	public Integer getBundlePlanKey() {
		return bundlePlanKey;
	}

	public void setBundlePlanKey(Integer bundlePlanKey) {
		this.bundlePlanKey = bundlePlanKey;
	}

	public Boolean getBundleSelected() {
		return bundleSelected;
	}

	public void setBundleSelected(Boolean bundleSelected) {
		this.bundleSelected = bundleSelected;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "AppBundleDetails [bundleSelected=" + bundleSelected + ", appBundleKey=" + appBundleKey
				+ ", applicationKey=" + applicationKey + ", bundleApplicationKey=" + bundleApplicationKey
				+ ", bundlePlanKey=" + bundlePlanKey + ", source=" + source + ", apploanpricingkey=" + apploanpricingkey
				+ ", isActive=" + isActive + ", bundlerevision=" + bundlerevision + ", status=" + status + "]";
	}
	
}