package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="app_detail_verification",schema = "dmcredit")
public class AppDetailsVerification {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long appdetverificationkey;
	
    private Integer permaddressreq;
    
    private Integer offaddressreq;
    
    private Integer stpprocess;
    
    private Integer docpickatoffice;
    
    private Integer docpickatresidence;

	private Integer qualifiedforstp;

	private Integer isactive;

	private long lstupdateby;

	private Timestamp lstupdatedt;
	
	private long applicationkey;
	
	private Integer videopdrequired;

	public Integer getVideopdrequired() {
		return videopdrequired;
	}

	public void setVideopdrequired(Integer videopdrequired) {
		this.videopdrequired = videopdrequired;
	}

	public long getAppdetverificationkey() {
		return appdetverificationkey;
	}

	public void setAppdetverificationkey(long appdetverificationkey) {
		this.appdetverificationkey = appdetverificationkey;
	}

	public Integer getPermaddressreq() {
		return permaddressreq;
	}

	public void setPermaddressreq(Integer permaddressreq) {
		this.permaddressreq = permaddressreq;
	}

	public Integer getOffaddressreq() {
		return offaddressreq;
	}

	public void setOffaddressreq(Integer offaddressreq) {
		this.offaddressreq = offaddressreq;
	}

	public Integer getStpprocess() {
		return stpprocess;
	}

	public void setStpprocess(Integer stpprocess) {
		this.stpprocess = stpprocess;
	}

	public Integer getDocpickatoffice() {
		return docpickatoffice;
	}

	public void setDocpickatoffice(Integer docpickatoffice) {
		this.docpickatoffice = docpickatoffice;
	}

	
	public Integer getDocpickatresidence() {
		return docpickatresidence;
	}

	public void setDocpickatresidence(Integer docpickatresidence) {
		this.docpickatresidence = docpickatresidence;
	}

	public Integer getQualifiedforstp() {
		return qualifiedforstp;
	}

	public void setQualifiedforstp(Integer qualifiedforstp) {
		this.qualifiedforstp = qualifiedforstp;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(long applicationkey) {
		this.applicationkey = applicationkey;
	}
	
}
