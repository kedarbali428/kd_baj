package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.AppRejectionDetail;
import com.bajaj.markets.credit.application.model.RejectionSystemMaster;

public interface ApplicationsRejectionDetailRoInterface extends ReadInterface<AppRejectionDetail, Long> {

	List<AppRejectionDetail> findByApplicationkeyAndIsactive(Long applicationkey, Integer isActive);

	List<AppRejectionDetail> findByApplicationkeyAndProdkeyAndRejectionSystemMasterAndIsactive(Long applicationkey,
			Long prodKey, RejectionSystemMaster rejectionSystemMaster, Integer isActive);

	List<AppRejectionDetail> findByApplicationkeyAndProdkeyAndProdtypekeyAndRiskoffertypeAndRejectionSystemMasterAndIsactive(
			Long applicationkey, Long prodKey, Long prodTypeKey, String riskOfferType,
			RejectionSystemMaster rejectionSystemMaster, Integer isActive);

	List<AppRejectionDetail> findByApplicationkeyAndRejectiontypeAndIsactive(Long applicationkey, Integer rejectiontype,
			Integer isActive);

	List<AppRejectionDetail> findByApplicationkeyAndProdkeyAndProdtypekeyAndRiskoffertypeAndIsactive(
			Long applicationkey, Long prodKey, Long prodTypeKey, String riskOfferType, Integer isActive);

	public List<AppRejectionDetail> findByApplicationkeyAndProdkeyAndIsactive(Long applicationkey, Long prodKey,
			Integer isActive);

}
