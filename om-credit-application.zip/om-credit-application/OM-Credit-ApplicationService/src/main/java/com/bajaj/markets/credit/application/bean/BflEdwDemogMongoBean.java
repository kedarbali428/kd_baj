package com.bajaj.markets.credit.application.bean;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class BflEdwDemogMongoBean {

	private List<BflEdwDemogData> demogDataForCustomerIds;
	
	@Id
	private String applicationId;
	
	private Date createdDate;

	public List<BflEdwDemogData> getDemogDataForCustomerIds() {
		return demogDataForCustomerIds;
	}

	public void setDemogDataForCustomerIds(List<BflEdwDemogData> demogDataForCustomerIds) {
		this.demogDataForCustomerIds = demogDataForCustomerIds;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
}
