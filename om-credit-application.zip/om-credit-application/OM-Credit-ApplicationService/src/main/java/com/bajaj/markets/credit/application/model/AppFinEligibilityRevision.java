package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the APP_FIN_ELIGIBILITY_REVISIONS database table.
 * 
 */
@Entity
@Table(name = "app_fin_eligibility_revision", schema = "dmcredit")
public class AppFinEligibilityRevision implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_fin_eligibility_revision_appfineligibilityrevkey_generator", sequenceName = "dmcredit.seq_pk_app_fin_eligibility_revision", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_fin_eligibility_revision_appfineligibilityrevkey_generator")
	private long appfineligibilityrevkey;
	private Long prodkey;
	private Long prodtypekey;
	private String riskoffertype;
	private Long revisedeligibilityammount;
	private Long revisedeligibilitytenure;
	private Long revisedloanrequirement;
	private Long revisedloantenure;
	private Long systemeligibilityammount;
	private Long systemeligibilitytenure;
	private Long raisedby;
	private Long approvedby;
	private String source;
	private String status;
	private Timestamp raiseddt;
	private Timestamp approveddt;
	@Column(precision = 1)
	private Integer isactive;
	private String revisedriskoffertype;
	@Column(length = 20)
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	@ManyToOne
	@JoinColumn(name = "applicationkey")
	private Application application;

	// bi-directional many-to-one association to AppFinEligRevProdDet
//	@OneToMany(mappedBy = "appFinEligibilityRevision", cascade = CascadeType.ALL)
//	private List<AppProductListing> appFinEligRevProdDets;

	public AppFinEligibilityRevision() {
	}

	public long getAppfineligibilityrevkey() {
		return appfineligibilityrevkey;
	}

	public void setAppfineligibilityrevkey(long appfineligibilityrevkey) {
		this.appfineligibilityrevkey = appfineligibilityrevkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	public Long getRevisedeligibilityammount() {
		return revisedeligibilityammount;
	}

	public void setRevisedeligibilityammount(Long revisedeligibilityammount) {
		this.revisedeligibilityammount = revisedeligibilityammount;
	}

	public Long getRevisedeligibilitytenure() {
		return revisedeligibilitytenure;
	}

	public void setRevisedeligibilitytenure(Long revisedeligibilitytenure) {
		this.revisedeligibilitytenure = revisedeligibilitytenure;
	}

	public Long getRevisedloanrequirement() {
		return revisedloanrequirement;
	}

	public void setRevisedloanrequirement(Long revisedloanrequirement) {
		this.revisedloanrequirement = revisedloanrequirement;
	}

	public Long getRevisedloantenure() {
		return revisedloantenure;
	}

	public void setRevisedloantenure(Long revisedloantenure) {
		this.revisedloantenure = revisedloantenure;
	}

	public Long getSystemeligibilityammount() {
		return systemeligibilityammount;
	}

	public void setSystemeligibilityammount(Long systemeligibilityammount) {
		this.systemeligibilityammount = systemeligibilityammount;
	}

	public Long getSystemeligibilitytenure() {
		return systemeligibilitytenure;
	}

	public void setSystemeligibilitytenure(Long systemeligibilitytenure) {
		this.systemeligibilitytenure = systemeligibilitytenure;
	}

	public Long getRaisedby() {
		return raisedby;
	}

	public void setRaisedby(Long raisedby) {
		this.raisedby = raisedby;
	}

	public Long getApprovedby() {
		return approvedby;
	}

	public void setApprovedby(Long approvedby) {
		this.approvedby = approvedby;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getRaiseddt() {
		return raiseddt;
	}

	public void setRaiseddt(Timestamp raiseddt) {
		this.raiseddt = raiseddt;
	}

	public Timestamp getApproveddt() {
		return approveddt;
	}

	public void setApproveddt(Timestamp approveddt) {
		this.approveddt = approveddt;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getRevisedriskoffertype() {
		return revisedriskoffertype;
	}

	public void setRevisedriskoffertype(String revisedriskoffertype) {
		this.revisedriskoffertype = revisedriskoffertype;
	}

	@Override
	public String toString() {
		return "AppFinEligibilityRevision [appfineligibilityrevkey=" + appfineligibilityrevkey + ", prodkey=" + prodkey
				+ ", prodtypekey=" + prodtypekey + ", riskoffertype=" + riskoffertype + ", revisedeligibilityammount="
				+ revisedeligibilityammount + ", revisedeligibilitytenure=" + revisedeligibilitytenure
				+ ", revisedloanrequirement=" + revisedloanrequirement + ", revisedloantenure=" + revisedloantenure
				+ ", systemeligibilityammount=" + systemeligibilityammount + ", systemeligibilitytenure="
				+ systemeligibilitytenure + ", raisedby=" + raisedby + ", approvedby=" + approvedby + ", source="
				+ source + ", status=" + status + ", raiseddt=" + raiseddt + ", approveddt=" + approveddt
				+ ", isactive=" + isactive + ", revisedriskoffertype=" + revisedriskoffertype + ", lstupdateby="
				+ lstupdateby + ", lstupdatedt=" + lstupdatedt + ", application=" + application + "]";
	}
}
