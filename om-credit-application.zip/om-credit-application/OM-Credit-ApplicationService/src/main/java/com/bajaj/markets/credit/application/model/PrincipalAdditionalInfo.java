package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "principal_additional_info", schema = "dmcredit")
public class PrincipalAdditionalInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long principaladdinfokey;
	private Long principalkey;
	private Long applicationkey;
	private Integer hassalaryaccount;
	private Timestamp appointmentdatetimefrom;
	private Timestamp appointmentdatetimeto;
	private String appointmentaddresstypecode;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	public Long getPrincipaladdinfokey() {
		return principaladdinfokey;
	}

	public void setPrincipaladdinfokey(Long principaladdinfokey) {
		this.principaladdinfokey = principaladdinfokey;
	}

	public Long getPrincipalkey() {
		return principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getHassalaryaccount() {
		return hassalaryaccount;
	}

	public void setHassalaryaccount(Integer hassalaryaccount) {
		this.hassalaryaccount = hassalaryaccount;
	}

	public Timestamp getAppointmentdatetimefrom() {
		return appointmentdatetimefrom;
	}

	public void setAppointmentdatetimefrom(Timestamp appointmentdatetimefrom) {
		this.appointmentdatetimefrom = appointmentdatetimefrom;
	}

	public Timestamp getAppointmentdatetimeto() {
		return appointmentdatetimeto;
	}

	public void setAppointmentdatetimeto(Timestamp appointmentdatetimeto) {
		this.appointmentdatetimeto = appointmentdatetimeto;
	}

	public String getAppointmentaddresstypecode() {
		return appointmentaddresstypecode;
	}

	public void setAppointmentaddresstypecode(String appointmentaddresstypecode) {
		this.appointmentaddresstypecode = appointmentaddresstypecode;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}
