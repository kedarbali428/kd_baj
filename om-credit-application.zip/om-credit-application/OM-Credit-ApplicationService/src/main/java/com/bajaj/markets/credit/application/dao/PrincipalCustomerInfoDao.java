package com.bajaj.markets.credit.application.dao;

import com.bajaj.markets.credit.application.bean.PrincipalCustomer;

public interface PrincipalCustomerInfoDao {

	/**
	 * 
	 * This method fetches existing record present with application, principal and application attribute,
	 * if record exist will update the same else create a new record.
	 * 
	 * @param applicationId
	 * @param principalkey
	 * @param customer
	 * 
	 */
	public void fetchExistingCustomerInfoAndSave(String applicationId, String principalkey, PrincipalCustomer customer);
	
}
