package com.bajaj.markets.credit.application.helper;

/**
 * Enum containing all application status'
 * 
 * @author 764504
 *
 */
public enum ApplicationStatusEnum {

	INPROGRESS(1), 
	AIP(2), 
	REJECTED(3), 
	APPROVAL(4), 
	SENTTOBANK(5), 
	CARDCREATION_INITIATED(6), 
	CARDCREATED(7), 
	DISBURSED(8), 
	CLOSED(9),
	SUSPENDED(10);

	private final Integer key;

	private ApplicationStatusEnum(Integer key) {
		this.key = key;
	}

	public Integer getKey() {
		return key;
	}

}
