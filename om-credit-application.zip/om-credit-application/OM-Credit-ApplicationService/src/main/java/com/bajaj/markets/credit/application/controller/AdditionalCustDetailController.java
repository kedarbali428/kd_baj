package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.AdditionalCustomerDetails;
import com.bajaj.markets.credit.application.bean.ApplicationPhoneNumberDetails;
import com.bajaj.markets.credit.application.bean.ApplicationPrincipalAdditionalDetails;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.AdditionalCustomerDetailService;
import com.bajaj.markets.credit.application.service.ApplicationEmailService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class AdditionalCustDetailController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;
	
	@Autowired
	private AdditionalCustomerDetailService addCustDetService; 

	private static final String CLASSNAME = ApplicationEmailService.class.getName();
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})@ApiOperation(value = "Update Alternate Mobile number", notes = "Update Alternate Mobile number for given applicationId", httpMethod = "PUT")
	@ApiImplicitParams(value = {@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
		 	@ApiResponse(code = 200, message = "Alternate Mobile number updated successfully.", response = AdditionalCustomerDetails.class),
		 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		 	@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
	        @ApiResponse(code = 404, message = "ApplicationId not found",response = ErrorBean.class),
		 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	// end point to be reviewed
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/addcustdetail", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateAdditionalCustDetails(
			@PathVariable(name = "applicationid", required = true) @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@Valid @RequestBody AdditionalCustomerDetails addCustDet, BindingResult result, @RequestHeader HttpHeaders headers) {
	
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateAdditionalCustDetails method controller - applicationId : " +applicationId);
		if(result.hasFieldErrors()){
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateAdditionalCustDetails method controller - resource validation failed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCA_001", result.getFieldErrors().get(0).getDefaultMessage()));
		}else {
			return new ResponseEntity<>(addCustDetService.updateAdditionalCustDetails(applicationId, addCustDet), HttpStatus.CREATED);
		}
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL,Role.SYSTEM ,Role.INTERNAL})
	@ApiOperation(value = "Fetch Alternate Mobile Number", notes = "Fetch Alternate Mobile Number Details On The Basis Of ApplicationId", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Alternate mobile number detail found for the given applicationId", response = ApplicationPhoneNumberDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Alternate Mobile Number Detail not found for the given applicationId",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "${api.omcreditapplicationservice.getalternatemobileno.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getAlternateMobileNumber(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getAlternateMobileNumber method controller - applicationId: "+ applicationId);
		ApplicationPhoneNumberDetails response = addCustDetService.getAlternateMobileNumber(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Completed AdditionalCustDetailController :: getAlternateMobileNumber method for applicationId : "+applicationId);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL, Role.SYSTEM, Role.INTERNAL })
	@ApiOperation(value = "Update Principal Addtional Details", notes = "Update Principal Addtional Details", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Update Principal Addtional Details for the given applicationId", response = ApplicationPrincipalAdditionalDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Principal Addtional Details not found for the given applicationId", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/principals/{principalkey}/additionaldetail", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationPrincipalAdditionalDetails> updatePrincipalAddDetails(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable("principalkey") @NotBlank(message = "Principal Key can not be null or empty") @Digits(fraction = 0, integer = 2, message = "Principalkey must be numeric.") String principalKey,
			@Valid @RequestBody ApplicationPrincipalAdditionalDetails applicationPrincipalAdditionalDetails,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updatePrincipalAddDetails method controller - applicationId: " + applicationId);
		ApplicationPrincipalAdditionalDetails updatePrincipalAddDetails = addCustDetService
				.updatePrincipalAddDetails(applicationId, principalKey, applicationPrincipalAdditionalDetails);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Completed AdditionalCustDetailController :: updatePrincipalAddDetails method for applicationId : "
						+ applicationId);
		return new ResponseEntity<>(updatePrincipalAddDetails, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL, Role.SYSTEM, Role.INTERNAL })
	@ApiOperation(value = "Fetch Principal Addtional Details", notes = "Fetch Principal Addtional Details On The Basis Of ApplicationId", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Principal Addtional Details found for the given applicationId", response = ApplicationPrincipalAdditionalDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Principal Addtional Details not found for the given applicationId", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/principals/{principalkey}/additionaldetail", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationPrincipalAdditionalDetails> getPrincipalAddDetails(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable("principalkey") @NotBlank(message = "Principal Key can not be null or empty") @Digits(fraction = 0, integer = 2, message = "Principalkey must be numeric.") String principalKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getPrincipalAddDetails method controller - applicationId: " + applicationId);
		ApplicationPrincipalAdditionalDetails principalAddDetails = addCustDetService.getPrincipalAddDetails(applicationId, principalKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Completed AdditionalCustDetailController :: getPrincipalAddDetails method for applicationId : "
						+ applicationId);
		return new ResponseEntity<>(principalAddDetails, HttpStatus.OK);
	}
}
