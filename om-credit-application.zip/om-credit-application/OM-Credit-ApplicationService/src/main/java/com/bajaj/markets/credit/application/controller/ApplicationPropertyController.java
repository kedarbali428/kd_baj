package com.bajaj.markets.credit.application.controller;

import javax.validation.constraints.Digits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.PropertyDetails;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationPropertyService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationPropertyController {

	private static final String CLASSNAME = ApplicationPropertyController.class.getName();

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private ApplicationPropertyService applicationPropertyService;

	/**
	 * Controller method to save and update property details on application in
	 * app_property_detail table. Checks for existing record of same application and
	 * updates or inserts the record accordingly
	 * 
	 * @param propertyDetailsRequest
	 * @param applicationKey
	 * @return PropertyDetails
	 */
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Application property details endpoint to create and update property details ", notes = "This resource will be used to create and update property details of application", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Property details created successfully.", response = PropertyDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.savepropertydetails.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<PropertyDetails> savePropertyDetails(@RequestBody PropertyDetails propertyDetailsRequest,
			@PathVariable(name = "applicationKey", required = true) @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") String applicationKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"START - Inside savePropertyDetails controller method for applicationKey :" + applicationKey
						+ " , propertyDetails:" + propertyDetailsRequest);
		PropertyDetails propertyDetails = applicationPropertyService.savePropertyDetails(applicationKey,
				propertyDetailsRequest);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"END - Inside savePropertyDetails controller method completed successfully for applicationKey :"
						+ applicationKey + " , propertyDetails:" + propertyDetails);
		return propertyDetails.isCreated() ? new ResponseEntity<>(propertyDetails, HttpStatus.CREATED)
				: new ResponseEntity<>(propertyDetails,HttpStatus.OK);
	}

	/**
	 * Controller method to fetch property details of application from
	 * app_property_detail table.
	 * 
	 * @param applicationKey
	 * @return PropertyDetails
	 */
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,
			Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Application property details endpoint to fetch property details ", notes = "This resource will be used to fetch property details of application", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Property details found for application successfully.", response = PropertyDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "${api.omcreditapplicationservice.getpropertydetails.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<PropertyDetails> getPropertyDetails(
			@PathVariable(name = "applicationKey", required = true) @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") String applicationKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"START - Inside getPropertyDetails controller method for applicationKey :" + applicationKey);
		PropertyDetails propertyDetails = applicationPropertyService.getPropertyDetails(applicationKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"END - Inside getPropertyDetails controller method , property details fetch completed successfully for applicationKey :"
						+ applicationKey);
		return new ResponseEntity<PropertyDetails>(propertyDetails, HttpStatus.OK);
	}

}
