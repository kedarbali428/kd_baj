package com.bajaj.markets.credit.application.dao.impl;

import java.sql.Timestamp;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.application.dao.ApplicationAnalyticsDataDao;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.AppAppsScore;
import com.bajaj.markets.credit.application.model.AppFinObligation;
import com.bajaj.markets.credit.application.model.AppSegmentation;
import com.bajaj.markets.credit.application.repository.tx.AppAppsScoreRepository;
import com.bajaj.markets.credit.application.repository.tx.AppFinObligationRepository;
import com.bajaj.markets.credit.application.repository.tx.AppSegmentationRepository;

@Component
public class ApplicationAnalyticsDataDaoImpl implements ApplicationAnalyticsDataDao {

	private static final String ERRORCODE_OMCA_201 = "OMCA_201";
	private static final String CLASS_NAME = ApplicationAnalyticsDataDaoImpl.class.getCanonicalName();
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private AppSegmentationRepository appSegmentationRepository;
	
	@Autowired
	private AppAppsScoreRepository appAppsScoreRepository;
	
	@Autowired
	private AppFinObligationRepository appFinObligationRepository;
	
	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;
	
	@Autowired
	private Environment env;

	@Transactional(value = TxType.REQUIRES_NEW)
	@Override
	public AppSegmentation updateAppSegmentation(AppSegmentation appSegmentation) {
		if(null != appSegmentation.getApplicationkey()) {
			AppSegmentation existingAppSegmentation = appSegmentationRepository
					.findByApplicationkeyAndIsactive(appSegmentation.getApplicationkey(), 1);
			if (null != existingAppSegmentation) {
				appSegmentation.setAppsegmentkey(existingAppSegmentation.getAppsegmentkey());
				if(StringUtils.isEmpty(appSegmentation.getProfileincomesegment())){
	                appSegmentation.setProfileincomesegment(existingAppSegmentation.getProfileincomesegment());
	            }
				if(StringUtils.isEmpty(appSegmentation.getProfilemicrosegment())){
                    appSegmentation.setProfilemicrosegment(existingAppSegmentation.getProfilemicrosegment());
                }
				if(StringUtils.isEmpty(appSegmentation.getProfilesegment())){
                    appSegmentation.setProfilesegment(existingAppSegmentation.getProfilesegment());
                }
				
			}
			
		
			appSegmentation.setIsactive(1);
			appSegmentation.setLstupdateby(customDefaultHeaders.getUserKey());
			appSegmentation.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "before appsegment save.");
			return appSegmentationRepository.save(appSegmentation);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Invalid data for updating app segmentation,"
					+ " applicationKey is mandatory: " + appSegmentation);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(ERRORCODE_OMCA_201, env.getProperty(ERRORCODE_OMCA_201)));
		}
	}

	@Transactional
	@Override
	public AppAppsScore updateAppAppsScore(AppAppsScore appAppsScore) {
		if(null != appAppsScore.getApplicationkey()) {
			AppAppsScore existingAppAppsScore = appAppsScoreRepository.findByApplicationkeyAndIsactive(appAppsScore.getApplicationkey(), 1);
			if(null != existingAppAppsScore) {
				appAppsScore.setAppsscorekey(existingAppAppsScore.getAppsscorekey());
			}
			appAppsScore.setIsactive(1);
			appAppsScore.setLstupdateby(customDefaultHeaders.getUserKey());
			appAppsScore.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
			return appAppsScoreRepository.save(appAppsScore);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Invalid data for updating AppAppsScore,"
					+ " applicationKey is mandatory: " + appAppsScore);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(ERRORCODE_OMCA_201, env.getProperty(ERRORCODE_OMCA_201)));
		}
	}

	@Transactional
	@Override
	public AppFinObligation updateAppFinObligation(AppFinObligation appFinObligation) {
		if(null != appFinObligation.getApplicationkey() && null != appFinObligation.getObligationsrc()) {
			AppFinObligation existingFinObligation = appFinObligationRepository.findByApplicationkeyAndIsactiveAndObligationsrc(appFinObligation.getApplicationkey(), 1, appFinObligation.getObligationsrc());
			if(null != existingFinObligation) {
				appFinObligation.setAppobligationkey(existingFinObligation.getAppobligationkey());
			}
			appFinObligation.setIsactive(1);
			appFinObligation.setLstupdateby(customDefaultHeaders.getUserKey());
			appFinObligation.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
			return appFinObligationRepository.save(appFinObligation);	
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Invalid data for updating AppFinObligation,"
					+ " applicationKey and obligation source are mandatory: " + appFinObligation);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(ERRORCODE_OMCA_201, env.getProperty(ERRORCODE_OMCA_201)));
		}
	}
}
