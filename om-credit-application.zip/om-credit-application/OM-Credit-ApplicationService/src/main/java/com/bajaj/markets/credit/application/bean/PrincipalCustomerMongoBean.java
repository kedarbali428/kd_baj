package com.bajaj.markets.credit.application.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class PrincipalCustomerMongoBean {

	@Id
	private Long id;
	
	@Indexed
	private Long applicationKey;
	
	private Long appattrbkey;
	
	private Long principalKey;
	
	private String principleCustRefId;
	
	private Object additionalDetails;

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public String getPrincipleCustRefId() {
		return principleCustRefId;
	}

	public void setPrincipleCustRefId(String principleCustRefId) {
		this.principleCustRefId = principleCustRefId;
	}

	public Object getAdditionalDetails() {
		return additionalDetails;
	}

	public void setAdditionalDetails(Object additionalDetails) {
		this.additionalDetails = additionalDetails;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}
	
}
