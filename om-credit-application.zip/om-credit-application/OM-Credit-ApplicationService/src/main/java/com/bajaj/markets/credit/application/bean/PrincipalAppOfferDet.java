package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class PrincipalAppOfferDet {

	private Long applicationkey;

	private Long prodkey;

	private String isofferavailable;

	private String offerid;

	private String partnerofferid;

	private Integer offertype;

	private String offercustomerid;

	private BigDecimal offeramt;

	private Integer offertenure;

	private BigDecimal offerroi;

	private BigDecimal offerprocessingfees;

	private Timestamp offerstartdt;

	private Timestamp offerexpirydt;

	private Timestamp offerapplieddt;

	private String lineavailedflg;

	private Integer offeracceptsts;

	private Timestamp offeracceptdt;

	private String offertypecode;

	private String risksegment;

	private Long offersrckey;

	private String prospectid;

	private String riskoffertype;

	private String generationrule;

	private String offergenerationsource;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String riskclassification;

	private BigDecimal tlbaserate;

	private BigDecimal isbaserate;

	private String offerprogramcode;

	private String iscardholder;

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getIsofferavailable() {
		return isofferavailable;
	}

	public void setIsofferavailable(String isofferavailable) {
		this.isofferavailable = isofferavailable;
	}

	public String getOfferid() {
		return offerid;
	}

	public void setOfferid(String offerid) {
		this.offerid = offerid;
	}

	public String getPartnerofferid() {
		return partnerofferid;
	}

	public void setPartnerofferid(String partnerofferid) {
		this.partnerofferid = partnerofferid;
	}

	public Integer getOffertype() {
		return offertype;
	}

	public void setOffertype(Integer offertype) {
		this.offertype = offertype;
	}

	public String getOffercustomerid() {
		return offercustomerid;
	}

	public void setOffercustomerid(String offercustomerid) {
		this.offercustomerid = offercustomerid;
	}

	public BigDecimal getOfferamt() {
		return offeramt;
	}

	public void setOfferamt(BigDecimal offeramt) {
		this.offeramt = offeramt;
	}

	public Integer getOffertenure() {
		return offertenure;
	}

	public void setOffertenure(Integer offertenure) {
		this.offertenure = offertenure;
	}

	public BigDecimal getOfferroi() {
		return offerroi;
	}

	public void setOfferroi(BigDecimal offerroi) {
		this.offerroi = offerroi;
	}

	public BigDecimal getOfferprocessingfees() {
		return offerprocessingfees;
	}

	public void setOfferprocessingfees(BigDecimal offerprocessingfees) {
		this.offerprocessingfees = offerprocessingfees;
	}

	public Timestamp getOfferstartdt() {
		return offerstartdt;
	}

	public void setOfferstartdt(Timestamp offerstartdt) {
		this.offerstartdt = offerstartdt;
	}

	public Timestamp getOfferexpirydt() {
		return offerexpirydt;
	}

	public void setOfferexpirydt(Timestamp offerexpirydt) {
		this.offerexpirydt = offerexpirydt;
	}

	public Timestamp getOfferapplieddt() {
		return offerapplieddt;
	}

	public void setOfferapplieddt(Timestamp offerapplieddt) {
		this.offerapplieddt = offerapplieddt;
	}

	public String getLineavailedflg() {
		return lineavailedflg;
	}

	public void setLineavailedflg(String lineavailedflg) {
		this.lineavailedflg = lineavailedflg;
	}

	public Integer getOfferacceptsts() {
		return offeracceptsts;
	}

	public void setOfferacceptsts(Integer offeracceptsts) {
		this.offeracceptsts = offeracceptsts;
	}

	public Timestamp getOfferacceptdt() {
		return offeracceptdt;
	}

	public void setOfferacceptdt(Timestamp offeracceptdt) {
		this.offeracceptdt = offeracceptdt;
	}

	public String getOffertypecode() {
		return offertypecode;
	}

	public void setOffertypecode(String offertypecode) {
		this.offertypecode = offertypecode;
	}

	public String getRisksegment() {
		return risksegment;
	}

	public void setRisksegment(String risksegment) {
		this.risksegment = risksegment;
	}

	public Long getOffersrckey() {
		return offersrckey;
	}

	public void setOffersrckey(Long offersrckey) {
		this.offersrckey = offersrckey;
	}

	public String getProspectid() {
		return prospectid;
	}

	public void setProspectid(String prospectid) {
		this.prospectid = prospectid;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	public String getGenerationrule() {
		return generationrule;
	}

	public void setGenerationrule(String generationrule) {
		this.generationrule = generationrule;
	}

	public String getOffergenerationsource() {
		return offergenerationsource;
	}

	public void setOffergenerationsource(String offergenerationsource) {
		this.offergenerationsource = offergenerationsource;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getRiskclassification() {
		return riskclassification;
	}

	public void setRiskclassification(String riskclassification) {
		this.riskclassification = riskclassification;
	}

	public BigDecimal getTlbaserate() {
		return tlbaserate;
	}

	public void setTlbaserate(BigDecimal tlbaserate) {
		this.tlbaserate = tlbaserate;
	}

	public BigDecimal getIsbaserate() {
		return isbaserate;
	}

	public void setIsbaserate(BigDecimal isbaserate) {
		this.isbaserate = isbaserate;
	}

	public String getOfferprogramcode() {
		return offerprogramcode;
	}

	public void setOfferprogramcode(String offerprogramcode) {
		this.offerprogramcode = offerprogramcode;
	}

	public String getIscardholder() {
		return iscardholder;
	}

	public void setIscardholder(String iscardholder) {
		this.iscardholder = iscardholder;
	}

	@Override
	public String toString() {
		return "PrincipalAppOfferDet [applicationkey=" + applicationkey + ", prodkey=" + prodkey + ", isofferavailable="
				+ isofferavailable + ", offerid=" + offerid + ", partnerofferid=" + partnerofferid + ", offertype="
				+ offertype + ", offercustomerid=" + offercustomerid + ", offeramt=" + offeramt + ", offertenure="
				+ offertenure + ", offerroi=" + offerroi + ", offerprocessingfees=" + offerprocessingfees
				+ ", offerstartdt=" + offerstartdt + ", offerexpirydt=" + offerexpirydt + ", offerapplieddt="
				+ offerapplieddt + ", lineavailedflg=" + lineavailedflg + ", offeracceptsts=" + offeracceptsts
				+ ", offeracceptdt=" + offeracceptdt + ", offertypecode=" + offertypecode + ", risksegment="
				+ risksegment + ", offersrckey=" + offersrckey + ", prospectid=" + prospectid + ", riskoffertype="
				+ riskoffertype + ", generationrule=" + generationrule + ", offergenerationsource="
				+ offergenerationsource + ", isactive=" + isactive + ", lstupdateby=" + lstupdateby + ", lstupdatedt="
				+ lstupdatedt + ", riskclassification=" + riskclassification + ", tlbaserate=" + tlbaserate
				+ ", isbaserate=" + isbaserate + ", offerprogramcode=" + offerprogramcode + ", iscardholder="
				+ iscardholder + "]";
	}

}
