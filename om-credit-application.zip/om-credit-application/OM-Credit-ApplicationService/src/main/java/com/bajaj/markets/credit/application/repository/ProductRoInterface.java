package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.Product;

public interface ProductRoInterface extends ReadInterface<Product, Long> {

	Product findByProdcode(String prodCode);

	Product findByProdcodeAndIsactive(String prodCode, Integer isActive);

	Product findByProdkeyAndIsactive(Long prodkey, Integer isActive);

	List<Product> findByPrincipalkeyAndIsactive(Long principalkey, Integer isActive);

	List<Product> findByProdcatkeyAndIsactive(Long prodcatkey, Integer isActive);

	List<Product> findByIsactive(Integer isactive);

}
