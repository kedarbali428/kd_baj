package com.bajaj.markets.credit.application.bean;

public class DueDateDetails {
	
	private String firstDueDate;
	private Integer dueDate;
	
	public String getFirstDueDate() {
		return firstDueDate;
	}
	public void setFirstDueDate(String firstDueDate) {
		this.firstDueDate = firstDueDate;
	}
	public Integer getDueDate() {
		return dueDate;
	}
	public void setDueDate(Integer dueDate) {
		this.dueDate = dueDate;
	}
	
	

}
