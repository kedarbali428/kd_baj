package com.bajaj.markets.credit.application.helper;

public enum VerificationAtrribute {
	OFFICIAL_EMAIL,
	PERSONAL_EMAIL,
	PAN,
	EMPLOYER;
}
