package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.DocumentDetails;
import com.bajaj.markets.credit.application.bean.PrincipalDocumenDetails;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceUtility;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationDocumentsService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller for operations of application documents resource
 * 
 * @author 764504
 *
 */
@RestController
@Validated
public class ApplicationDocumentsController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private ApplicationDocumentsService applicationDocumentsService;
	
	@Autowired
	private CreditApplicationServiceUtility creditApplicationServiceUtility;

	private static final String CLASSNAME = ApplicationDocumentsController.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "Applications user proflie endpoint", notes = "This resource will be used to add user documentDetails for an application", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Documents updated successfully.", response = DocumentDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/documentdetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> saveDocumentDetails(@Valid @RequestBody DocumentDetails bean, BindingResult result,
			@PathVariable(name = "applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@PathVariable(name = "userattributekey") @NotNull(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10,message = "userattributekey should be numeric & should not exceeds size") Long userattributeKey,
			@RequestHeader HttpHeaders headers) {

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside ApplicationDocumentsController :: saveDocumentDetails method controller - applicationId: "+ applicationId + " and userattributekey : " +userattributeKey );
		if (result.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveDocumentDetails method - invalid parameters passed");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_011", result.getFieldErrors().get(0).getDefaultMessage()));
		} else {
			creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId.toString(), userattributeKey.toString());
			DocumentDetails response = applicationDocumentsService.saveDocumentDetails(bean, applicationId,userattributeKey);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Completed ApplicationDocumentsController :: saveDocumentDetails method applicationId : "+ applicationId);
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.SYSTEM,Role.INTERNAL})
	@ApiOperation(value = "Fetch Document Detail", notes = "Fetch Document details on the basis of user attribute id and document name key", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Document Detail found for the user attribute id", response = DocumentDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Document Detail not found for the user attribute id",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/documentdetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getDocument(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@PathVariable("userattributekey") @NotBlank(message = "userattributekey can not be null or empty") @Digits(fraction = 0, integer = 10,message = "userattributekey should be numeric & should not exceeds size")String userattributeKey,
			@RequestParam (name = "documentnamekey", required = false) Long documentNameKey,
			@RequestHeader HttpHeaders headers){

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getDocument method controller - applicationId: "+ applicationId + " userattributeKey: "+ userattributeKey + " documentnameKey: "+documentNameKey);
		if (StringUtils.isNumeric(applicationId)) {
			creditApplicationServiceUtility.validateApplicationAndApplicationAttribute(applicationId, userattributeKey);
			return new ResponseEntity<>(applicationDocumentsService.getDocumentDetails(userattributeKey, documentNameKey),HttpStatus.OK);	
		}else {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
			new ErrorBean("OMCA_033", "ApplicationId should be number."));
		}
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.SYSTEM,
			Role.INTERNAL })
	@ApiOperation(value = "Fetch Principal Document Detail", notes = "Fetch Principal Document details on the basis of application Id", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Document Detail found for the application Id", response = PrincipalDocumenDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Document Detail not found for the application id", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/applications/{applicationid}/document", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> getDocument(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getDocument method controller Start- applicationId: " + applicationId);
		PrincipalDocumenDetails principalDocumenDetails = applicationDocumentsService
				.getPrincipalDocumentDetails(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getDocument method controller End- applicationId: " + applicationId + " with "
						+ principalDocumenDetails.toString());
		return new ResponseEntity<>(principalDocumenDetails, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.SYSTEM,
			Role.INTERNAL })
	@ApiOperation(value = "Save Principal Document Detail", notes = "Save Principal Document details on the basis of application Id", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Principal Document Detail updated for the application Id", response = PrincipalDocumenDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Document Detail not found for the application id", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/document", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> saveDocument(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestBody PrincipalDocumenDetails principalDocumenDetails, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside saveDocument method controller Start- applicationId: " + applicationId + " with "
						+ principalDocumenDetails.toString());
		PrincipalDocumenDetails documentDetails = applicationDocumentsService
				.savePrincipalDocumentDetails(applicationId, principalDocumenDetails);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside saveDocument method controller End- applicationId: " + applicationId);
		return new ResponseEntity<>(documentDetails, HttpStatus.OK);
	}

}
