package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class PrincipalOccupationDetail {

	private Long appoccupationkey;

	private Long appattrbkey;

	private String businessname;

	private Long businesskey;

	private Integer businessvintage;

	private Integer declaredexperience;

	private Long declaredincome;

	private String designforoth;

	private Long emplrdesigkey;

	private String empnameforoth;

	private Long emprmastid;

	private Integer finalexperience;

	private String medicalregistrationnumber;

	private BigDecimal netmonthlysalary;

	private Long nobkey;

	private Long occupationtype;

	private Long perfiosincome;

	private String practicetype;

	private Long smsincome;

	private Long subindumastkey;

	private String emplrtype;

	private String emplrcategory;

	private String annualturnover;

	private String businesspan;

	private String gstnumber;

	private BigDecimal netmthincome;

	private BigDecimal profitaftertax;

	private BigDecimal avgbankbalance;
	
	private Integer currentexperience;
	
	private Integer presentbusinessvintage;
	
	private Long custIndMastKey;
	
	private BigDecimal coApplicantIncome;

	private String empsectorservice;

	private String businessnature;

	public Long getAppoccupationkey() {
		return appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public Long getBusinesskey() {
		return businesskey;
	}

	public void setBusinesskey(Long businesskey) {
		this.businesskey = businesskey;
	}

	public Integer getBusinessvintage() {
		return businessvintage;
	}

	public void setBusinessvintage(Integer businessvintage) {
		this.businessvintage = businessvintage;
	}

	public Integer getDeclaredexperience() {
		return declaredexperience;
	}

	public void setDeclaredexperience(Integer declaredexperience) {
		this.declaredexperience = declaredexperience;
	}

	public Long getDeclaredincome() {
		return declaredincome;
	}

	public void setDeclaredincome(Long declaredincome) {
		this.declaredincome = declaredincome;
	}

	public String getDesignforoth() {
		return designforoth;
	}

	public void setDesignforoth(String designforoth) {
		this.designforoth = designforoth;
	}

	public Long getEmplrdesigkey() {
		return emplrdesigkey;
	}

	public void setEmplrdesigkey(Long emplrdesigkey) {
		this.emplrdesigkey = emplrdesigkey;
	}

	public String getEmpnameforoth() {
		return empnameforoth;
	}

	public void setEmpnameforoth(String empnameforoth) {
		this.empnameforoth = empnameforoth;
	}

	public Long getEmprmastid() {
		return emprmastid;
	}

	public void setEmprmastid(Long emprmastid) {
		this.emprmastid = emprmastid;
	}

	public Integer getFinalexperience() {
		return finalexperience;
	}

	public void setFinalexperience(Integer finalexperience) {
		this.finalexperience = finalexperience;
	}

	public String getMedicalregistrationnumber() {
		return medicalregistrationnumber;
	}

	public void setMedicalregistrationnumber(String medicalregistrationnumber) {
		this.medicalregistrationnumber = medicalregistrationnumber;
	}

	public BigDecimal getNetmonthlysalary() {
		return netmonthlysalary;
	}

	public void setNetmonthlysalary(BigDecimal netmonthlysalary) {
		this.netmonthlysalary = netmonthlysalary;
	}

	public Long getNobkey() {
		return nobkey;
	}

	public void setNobkey(Long nobkey) {
		this.nobkey = nobkey;
	}

	public Long getOccupationtype() {
		return occupationtype;
	}

	public void setOccupationtype(Long occupationtype) {
		this.occupationtype = occupationtype;
	}

	public Long getPerfiosincome() {
		return perfiosincome;
	}

	public void setPerfiosincome(Long perfiosincome) {
		this.perfiosincome = perfiosincome;
	}

	public String getPracticetype() {
		return practicetype;
	}

	public void setPracticetype(String practicetype) {
		this.practicetype = practicetype;
	}

	public Long getSmsincome() {
		return smsincome;
	}

	public void setSmsincome(Long smsincome) {
		this.smsincome = smsincome;
	}

	public Long getSubindumastkey() {
		return subindumastkey;
	}

	public void setSubindumastkey(Long subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

	public String getEmplrtype() {
		return emplrtype;
	}

	public void setEmplrtype(String emplrtype) {
		this.emplrtype = emplrtype;
	}

	public String getEmplrcategory() {
		return emplrcategory;
	}

	public void setEmplrcategory(String emplrcategory) {
		this.emplrcategory = emplrcategory;
	}

	public String getAnnualturnover() {
		return annualturnover;
	}

	public void setAnnualturnover(String annualturnover) {
		this.annualturnover = annualturnover;
	}

	public String getBusinesspan() {
		return businesspan;
	}

	public void setBusinesspan(String businesspan) {
		this.businesspan = businesspan;
	}

	public String getGstnumber() {
		return gstnumber;
	}

	public void setGstnumber(String gstnumber) {
		this.gstnumber = gstnumber;
	}

	public BigDecimal getNetmthincome() {
		return netmthincome;
	}

	public void setNetmthincome(BigDecimal netmthincome) {
		this.netmthincome = netmthincome;
	}

	public BigDecimal getProfitaftertax() {
		return profitaftertax;
	}

	public void setProfitaftertax(BigDecimal profitaftertax) {
		this.profitaftertax = profitaftertax;
	}

	public BigDecimal getAvgbankbalance() {
		return avgbankbalance;
	}

	public void setAvgbankbalance(BigDecimal avgbankbalance) {
		this.avgbankbalance = avgbankbalance;
	}

	public Integer getCurrentexperience() {
		return currentexperience;
	}

	public void setCurrentexperience(Integer currentexperience) {
		this.currentexperience = currentexperience;
	}

	public Integer getPresentbusinessvintage() {
		return presentbusinessvintage;
	}

	public void setPresentbusinessvintage(Integer presentbusinessvintage) {
		this.presentbusinessvintage = presentbusinessvintage;
	}
	
	public Long getCustIndMastKey() {
		return custIndMastKey;
	}

	public void setCustIndMastKey(Long custIndMastKey) {
		this.custIndMastKey = custIndMastKey;
	}

	public BigDecimal getCoApplicantIncome() {
		return coApplicantIncome;
	}

	public void setCoApplicantIncome(BigDecimal coApplicantIncome) {
		this.coApplicantIncome = coApplicantIncome;
	}

	public String getEmpsectorservice() {
		return empsectorservice;
	}

	public void setEmpsectorservice(String empsectorservice) {
		this.empsectorservice = empsectorservice;
	}

	public String getBusinessnature() {
		return businessnature;
	}

	public void setBusinessnature(String businessnature) {
		this.businessnature = businessnature;
	}

	@Override
	public String toString() {
		return "PrincipalOccupationDetail [appoccupationkey=" + appoccupationkey + ", appattrbkey=" + appattrbkey + ", businessname=" + businessname
				+ ", businesskey=" + businesskey + ", businessvintage=" + businessvintage + ", declaredexperience=" + declaredexperience + ", declaredincome="
				+ declaredincome + ", designforoth=" + designforoth + ", emplrdesigkey=" + emplrdesigkey + ", empnameforoth=" + empnameforoth + ", emprmastid="
				+ emprmastid + ", finalexperience=" + finalexperience + ", medicalregistrationnumber=" + medicalregistrationnumber + ", netmonthlysalary="
				+ netmonthlysalary + ", nobkey=" + nobkey + ", occupationtype=" + occupationtype + ", perfiosincome=" + perfiosincome + ", practicetype="
				+ practicetype + ", smsincome=" + smsincome + ", subindumastkey=" + subindumastkey + ", emplrtype=" + emplrtype + ", emplrcategory="
				+ emplrcategory + ", annualturnover=" + annualturnover + ", businesspan=" + businesspan + ", gstnumber=" + gstnumber + ", netmthincome="
				+ netmthincome + ", profitaftertax=" + profitaftertax + ", avgbankbalance=" + avgbankbalance + ", currentexperience=" + currentexperience
				+ ", presentbusinessvintage=" + presentbusinessvintage + ", custIndMastKey=" + custIndMastKey + ", coApplicantIncome=" + coApplicantIncome
				+ "]";
	}

}
