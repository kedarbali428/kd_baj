package com.bajaj.markets.credit.application.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.ApplyCardConsentOtpResponse;
import com.bajaj.markets.credit.application.bean.CheckCaseStatusRes;
import com.bajaj.markets.credit.application.bean.CustDemogConsentOtpResponse;
import com.bajaj.markets.credit.application.bean.CustDemogReqBean;
import com.bajaj.markets.credit.application.bean.CustomerDemogResponse;
import com.bajaj.markets.credit.application.bean.PrincipalCardResponse;
import com.bajaj.markets.credit.application.bean.PrincipalFeature;
import com.bajaj.markets.credit.application.bean.PrincipalFeatureRequest;
import com.bajaj.markets.credit.application.bean.ProcessCardRequest;
import com.bajaj.markets.credit.application.bean.ProcessCardResponse;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationPrincipleService;
import com.bajaj.markets.credit.offer.bfl.bean.PosidexResponse;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationPrincipleController {
	
	@Autowired
	private ApplicationPrincipleService applicationPrincipleService;

	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private BFLLoggerUtil loggerWithoutCorrelId;
	
	private static final String CLASS_NAME = ApplicationPrincipleController.class.getCanonicalName();

	/**
	 * Trigger the OTP for any L3 Product. It will internally call the principal
	 * API.
	 * 
	 * @param applicationKey     : child application key
	 * @param processCardRequest
	 * @param headers
	 * @return applyCardConsentOtpResponse
	 */
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Trigger Apply Card Consent OTP.", notes = "Trigger Apply Card Consent OTP.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully trigger otp for principal", response = ApplyCardConsentOtpResponse.class),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@GetMapping("/v1/creditapplication/applications/{applicationKey}/consent")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> applyCardConsent(
			@PathVariable("applicationKey") @NotBlank(message = "Applicationkey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationkey should be numeric & should not exceeds size") String applicationKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside applyCardConsent controller for Parent ApplicationKey : "
				+ applicationKey);
		ApplyCardConsentOtpResponse applyCardConsentOtpResponse = applicationPrincipleService
				.applyCardConsent(applicationKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Exiting applyCardConsent controller for applicationKey : " +applicationKey);
		return new ResponseEntity<>(applyCardConsentOtpResponse, HttpStatus.OK);

	}

	/**
	 * @param applicationKey     : child application key
	 * @param processCardRequest
	 * @param headers
	 * @return
	 */
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Process new card request.", notes = "Process new card request.", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully processed new card request.", response = ProcessCardResponse.class),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@PutMapping("/v1/creditapplication/applications/{applicationKey}/consent")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> processCard(
			@PathVariable("applicationKey") @NotBlank(message = "Applicationkey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationkey should be numeric & should not exceeds size") String applicationKey,
			@Valid @RequestBody Optional<ProcessCardRequest> processCardRequest, BindingResult bindingResult,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside processCard controller for applicationKey : "+ applicationKey );
		ProcessCardResponse processCardResponse = applicationPrincipleService.processCard(processCardRequest,
				applicationKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exiting processCard controller for applicationKey : "+applicationKey);
		return new ResponseEntity<>(processCardResponse, HttpStatus.OK);

	}

	/**
	 * @param applicationKey: child application key
	 * @param headers
	 * @return
	 */
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "Check the status of card.", notes = "Check the status of card.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetch status of new card request.", response = CheckCaseStatusRes.class),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@GetMapping("/v1/creditapplication/applications/{applicationKey}/card/status")
	@Produces(value = { "text/event-stream;charset=UTF-8" })
	@CrossOrigin
	@EnableFineGrainCheck
	public SseEmitter checkStatus(
			@PathVariable("applicationKey") @NotBlank(message = "Applicationkey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationkey should be numeric & should not exceeds size") String applicationKey,
			@RequestParam @NotBlank(message = "l3ProdCode is mandatory.") String l3ProdCode,
			@RequestParam(required = true) @NotBlank(message = "authtoken is mandatory") String authtoken,
			HttpServletResponse httpServletResponse) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside checkStatus controller for child application Key : " + applicationKey);
		SseEmitter checkCaseStatusRes = applicationPrincipleService.checkStatus(applicationKey, l3ProdCode,authtoken);
		httpServletResponse.addHeader("Content-Type", "text/event-stream");
		httpServletResponse.addHeader("Cache-Control", "no-cache");
		httpServletResponse.addHeader("X-Accel-Buffering", "no");
		loggerWithoutCorrelId.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exiting checkStatus for applicationKey : " + applicationKey);
		return checkCaseStatusRes;
	}
	/**
	 * @param applicationKey          : child application key
	 * @param principalFetaureRequest
	 * @param headers
	 * @return
	 */
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Save or update the feature of principal.", notes = "Save or update the feature of principal like contactless,internal and shopping.", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Successfully save or update the feature of principal."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource Not Found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Bad Request", response = ErrorBean.class) })
	@PutMapping("/v1/creditapplication/applications/{applicationid}/principal/feature")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> saveorUpdatePrincipalFeature(
			@PathVariable("applicationid") @NotBlank(message = "Applicationid cannot be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationid should be numeric & should not exceeds size") String applicationid,
			@RequestParam(required = true) @NotBlank(message = "l3ProductCode cannot be null or empty") String l3ProductCode,
			@Valid @RequestBody PrincipalFeatureRequest principalFetaureRequest, @RequestHeader HttpHeaders headers,
			BindingResult bindingResult) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"saveorUpdatePrincipalFeature Start : " + applicationid);
		applicationPrincipleService.saveOrUpdatePrincipalFeature(applicationid, l3ProductCode, principalFetaureRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "saveorUpdatePrincipalFeature End");
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);

	}

	/**
	 * @param applicationKey          : parent application key
	 * @param principalFetaureRequest
	 * @param headers
	 * @return
	 */
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get the feature of principal.", notes = "Get principal feature", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully get feature of principal.", response = PrincipalFeature.class, responseContainer = "List"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource Not Found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@GetMapping("/v1/creditapplication/applications/{applicationid}/principal/feature")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> getPrincipalFeature(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationid should be numeric & should not exceeds size") String applicationid,
			@RequestParam(required = true) @NotBlank(message = "l3ProdCode can not be null or empty") String l3ProductCode,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside getPrincipalFeature for applicationId : " + applicationid + "  ProdKey : " + l3ProductCode);
		List<PrincipalFeature> principalFetaureRes = applicationPrincipleService.getprincipalFeature(applicationid,
				l3ProductCode);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Exiting getPrincipalFeature for applicationId : " + applicationid);
		return new ResponseEntity<>(principalFetaureRes, HttpStatus.OK);

	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch Posidex Details From Mongodb.", notes = "Fetch Posidex Details From Mongodb.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched Credit Vidya details from mongodb", response = PosidexResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource Not Found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@CrossOrigin
	@GetMapping(value = "${api.omcreditapplicationservice.posidex.mongodetails.GET.uri}")	
	public ResponseEntity<PosidexResponse> fetchPosidexDetailsfromMongo(@PathVariable("applicationkey") @NotBlank(message = "applicationkey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationkey should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside fetchPosidexDetailsfromMongo for applicationId : "+applicationId);	
		PosidexResponse response = applicationPrincipleService.fetchPosidexDetails(applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exiting fetchPosidexDetailsfromMongo completed successfully for applicationId : "+applicationId);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * @param applicationKey     : child application key
	 * @param headers
	 * @return
	 */
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE,Role.B2BPARTNER})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "get Process card data.", notes = "get Process card data.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully processed new card request.", response = PrincipalCardResponse.class),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@GetMapping("${api.omcreditapplicationservice.application.details.GET.uri}")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> processCardData(
			@PathVariable("applicationKey") @NotBlank(message = "Applicationkey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationkey should be numeric & should not exceeds size") String applicationKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside processCardData controller for applicationKey : " + applicationKey);
		PrincipalCardResponse principalCardResponse = applicationPrincipleService.getProcessCardData(applicationKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exiting processCardData controller for applicationId : " + applicationKey );
		return new ResponseEntity<>(principalCardResponse, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Trigger Cust Demog Consent OTP.", notes = "Trigger Cust Demog Consent OTP.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully trigger otp for principal", response = CustDemogConsentOtpResponse.class),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@GetMapping("${api.omcreditapplicationservice.demogconsent.GET.uri}")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> custDemogConsent(
			@PathVariable("applicationid") @NotBlank(message = "Applicationkey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationkey should be numeric & should not exceeds size") String applicationid,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside custDemogConsent controller for Parent ApplicationKey : " + applicationid);
		CustDemogConsentOtpResponse custDemogConsentOtpResponse = applicationPrincipleService
				.custDemogConsent(applicationid);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Exiting custDemogConsent controller for applicationId : " + applicationid);
		return new ResponseEntity<>(custDemogConsentOtpResponse, HttpStatus.OK);

	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.SYSTEM })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch Cust Demog Details from Ext API", notes = "Fetch Cust Demog Details from Ext API", httpMethod = "PUT", response = CustomerDemogResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully Fetched Cust Demog Details from External Axis API"),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@PutMapping("${api.omcreditapplicationservice.demog.PUT.uri}")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> custDemogDetails(
			@PathVariable("applicationid") @NotBlank(message = "ApplicationId can not be null or empty") @Digits(fraction = 0, integer = 20, message = "Applicationkey should be numeric & should not exceeds size") String applicationid,
			@RequestHeader HttpHeaders headers, @Valid @RequestBody CustDemogReqBean custDemogReqBean) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside custDemogDetails for Parent ApplicationId : " + applicationid);
		CustomerDemogResponse customerDemogResponse = applicationPrincipleService.custDemog(applicationid,
				custDemogReqBean.getOtp());
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exiting custDemogDetails controller for applicationId : "+applicationid);
		return new ResponseEntity<>(customerDemogResponse, HttpStatus.OK);

	}

}