package com.bajaj.markets.credit.application.bean;

public class HMLScoreDetails {

	private String modelName;
	private String modelScore;
	private String modelSegment;
	private String modelVersion;
	private String scoreDate;
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getModelScore() {
		return modelScore;
	}
	public void setModelScore(String modelScore) {
		this.modelScore = modelScore;
	}
	public String getModelSegment() {
		return modelSegment;
	}
	public void setModelSegment(String modelSegment) {
		this.modelSegment = modelSegment;
	}
	public String getModelVersion() {
		return modelVersion;
	}
	public void setModelVersion(String modelVersion) {
		this.modelVersion = modelVersion;
	}
	public String getScoreDate() {
		return scoreDate;
	}
	public void setScoreDate(String scoreDate) {
		this.scoreDate = scoreDate;
	}
}
