package com.bajaj.markets.credit.application.bean;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CreditDispositionIntegrationBean {

	private String activityid;
	
	private String identity;
	
	@JsonProperty("activity_params")
	private List<Map<String,Object>> activityParams;

	public String getActivityid() {
		return activityid;
	}

	public void setActivityid(String activityid) {
		this.activityid = activityid;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public List<Map<String, Object>> getActivityParams() {
		return activityParams;
	}

	public void setActivityParams(List<Map<String, Object>> activityParams) {
		this.activityParams = activityParams;
	}

	@Override
	public String toString() {
		return "DispositionNotificationeEventBean [activityid=" + activityid + ", identity=" + identity
				+ ", activityParams=" + activityParams + "]";
	}

}
