package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the subdisposition_code database table.
 * 
 */
@Entity
@Table(name="subdisposition_code",schema = "dmcredit")
public class SubDispositionCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "subdisposition_code_subdispostionkey_generator", sequenceName = "dmcredit.seq_pk_subdisposition_code", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "subdisposition_code_subdispostionkey_generator")
	
	private Long subdispostionkey;
	
	private String subdispositioncode;
	
	private String subdispositiondesc;

	private Integer isactive;
	
	private Long dispostionkey;
	
	/**
	 * @return the subdispostionkey
	 */
	public Long getSubdispostionkey() {
		return subdispostionkey;
	}


	/**
	 * @param subdispostionkey the subdispostionkey to set
	 */
	public void setSubdispostionkey(Long subdispostionkey) {
		this.subdispostionkey = subdispostionkey;
	}


	/**
	 * @return the subdispositioncode
	 */
	public String getSubdispositioncode() {
		return subdispositioncode;
	}


	/**
	 * @param subdispositioncode the subdispositioncode to set
	 */
	public void setSubdispositioncode(String subdispositioncode) {
		this.subdispositioncode = subdispositioncode;
	}


	/**
	 * @return the subdispositiondesc
	 */
	public String getSubdispositiondesc() {
		return subdispositiondesc;
	}


	/**
	 * @param subdispositiondesc the subdispositiondesc to set
	 */
	public void setSubdispositiondesc(String subdispositiondesc) {
		this.subdispositiondesc = subdispositiondesc;
	}


	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}


	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}


	public Long getDispostionkey() {
		return dispostionkey;
	}


	public void setDispostionkey(Long dispostionkey) {
		this.dispostionkey = dispostionkey;
	}
}