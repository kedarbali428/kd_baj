package com.bajaj.markets.credit.application.bean;

public class PinCode {
	private Boolean oglFlag;
	private Boolean negativeAreaFlag;
	private String city;
	private String tier;
	private Long pincode;
	private String programType;

	public Long getPincode() {
		return pincode;
	}

	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}

	public Boolean getOglFlag() {
		return oglFlag;
	}

	public void setOglFlag(Boolean oglFlag) {
		this.oglFlag = oglFlag;
	}

	public Boolean getNegativeAreaFlag() {
		return negativeAreaFlag;
	}

	public void setNegativeAreaFlag(Boolean negativeAreaFlag) {
		this.negativeAreaFlag = negativeAreaFlag;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}	

	public String getProgramType() {
		return programType;
	}

	public void setProgramType(String programType) {
		this.programType = programType;
	}

	@Override
	public String toString() {
		return "PinCode [oglFlag=" + oglFlag + ", negativeAreaFlag=" + negativeAreaFlag + ", city=" + city + ", tier="
				+ tier + ", pincode=" + pincode + ", programType=" + programType + "]";
	}

}
