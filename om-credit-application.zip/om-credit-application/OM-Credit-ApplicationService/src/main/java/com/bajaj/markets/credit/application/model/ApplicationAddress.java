package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Persistence class for application_address table
 * @author bflrdpuser1
 *
 */
@Entity
@Table(name = "application_address", schema = "dmcredit")
public class ApplicationAddress implements Cloneable {

	@Id
	@SequenceGenerator(name = "application_address_addrkey_generator", sequenceName = "dmcredit.seq_pk_application_address", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_address_addrkey_generator")
	private Long addrkey;

	private Long addrtypkey;

	private Long statekey;

	private Long citykey;

	private Long pincodekey;

	private Long countryKey;

	private Timestamp effstartdt;

	private Timestamp effenddt;

	private String addrsrc;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long appattrbkey;

	private String addressline1;

	private String addressline2;
	
	private Long localitykey;

	private Integer currentaddressduration;
	
	private String housenum; 
	
	private String flatnum;
	
	private String street;
	
	private Long prefferedflg;
	
    private Long ovddockey;
	
	private String ovddocvalue;
	
	public Long getAddrkey() {
		return addrkey;
	}

	public void setAddrkey(Long addrkey) {
		this.addrkey = addrkey;
	}

	public Long getAddrtypkey() {
		return addrtypkey;
	}

	public void setAddrtypkey(Long addrtypkey) {
		this.addrtypkey = addrtypkey;
	}

	public Long getStatekey() {
		return statekey;
	}

	public void setStatekey(Long statekey) {
		this.statekey = statekey;
	}

	public Long getCitykey() {
		return citykey;
	}

	public void setCitykey(Long citykey) {
		this.citykey = citykey;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public Timestamp getEffstartdt() {
		return effstartdt;
	}

	public void setEffstartdt(Timestamp effstartdt) {
		this.effstartdt = effstartdt;
	}

	public Timestamp getEffenddt() {
		return effenddt;
	}

	public void setEffenddt(Timestamp effenddt) {
		this.effenddt = effenddt;
	}

	public String getAddrsrc() {
		return addrsrc;
	}

	public void setAddrsrc(String addrsrc) {
		this.addrsrc = addrsrc;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getCountryKey() {
		return countryKey;
	}

	public void setCountryKey(Long countryKey) {
		this.countryKey = countryKey;
	}

	public String getAddressline1() {
		return addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	public String getAddressline2() {
		return addressline2;
	}

	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}
	
	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}
	
	public Long getLocalitykey() {
		return localitykey;
	}

	public void setLocalitykey(Long localitykey) {
		this.localitykey = localitykey;
	}

	public Integer getCurrentaddressduration() {
		return currentaddressduration;
	}

	public void setCurrentaddressduration(Integer currentaddressduration) {
		this.currentaddressduration = currentaddressduration;
	}

	public String getHousenum() {
		return housenum;
	}

	public void setHousenum(String housenum) {
		this.housenum = housenum;
	}

	public String getFlatnum() {
		return flatnum;
	}

	public void setFlatnum(String flatnum) {
		this.flatnum = flatnum;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}
	
	public Long getPrefferedflg() {
		return prefferedflg;
	}

	public void setPrefferedflg(Long prefferedflg) {
		this.prefferedflg = prefferedflg;
	}
	public Long getOvddockey() {
		return ovddockey;
	}

	public void setOvddockey(Long ovddockey) {
		this.ovddockey = ovddockey;
	}

	public String getOvddocvalue() {
		return ovddocvalue;
	}

	public void setOvddocvalue(String ovddocvalue) {
		this.ovddocvalue = ovddocvalue;
	}

	@Override
	public ApplicationAddress clone() throws CloneNotSupportedException {
		ApplicationAddress addr = new ApplicationAddress();
		addr.setAddrtypkey(this.addrtypkey);
		addr.setStatekey(this.statekey);
		addr.setCitykey(this.citykey);
		addr.setPincodekey(this.pincodekey);
		addr.setCountryKey(this.countryKey);
		addr.setEffstartdt(this.effstartdt);
		addr.setEffenddt(this.effenddt);
		addr.setAddrsrc(this.addrsrc);
		addr.setIsactive(this.isactive);
		addr.setLstupdateby(this.lstupdateby);
		addr.setLstupdatedt(this.lstupdatedt);
		addr.setAppattrbkey(this.appattrbkey);
		addr.setAddressline1(this.addressline1);
		addr.setAddressline2(this.addressline2);
		addr.setLocalitykey(this.localitykey);
		addr.setCurrentaddressduration(this.currentaddressduration);
		addr.setHousenum(this.housenum);
		addr.setFlatnum(this.flatnum);
		addr.setStreet(this.street);
		addr.setPrefferedflg(this.prefferedflg);
		addr.setOvddockey(this.ovddockey);
		addr.setOvddocvalue(this.ovddocvalue);
		return addr;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((addressline1 == null) ? 0 : addressline1.hashCode());
		result = prime * result + ((addressline2 == null) ? 0 : addressline2.hashCode());
		result = prime * result + ((citykey == null) ? 0 : citykey.hashCode());
		result = prime * result + ((countryKey == null) ? 0 : countryKey.hashCode());
		result = prime * result + ((flatnum == null) ? 0 : flatnum.hashCode());
		result = prime * result + ((housenum == null) ? 0 : housenum.hashCode());
		result = prime * result + ((localitykey == null) ? 0 : localitykey.hashCode());
		result = prime * result + ((pincodekey == null) ? 0 : pincodekey.hashCode());
		result = prime * result + ((statekey == null) ? 0 : statekey.hashCode());
		result = prime * result + ((ovddockey == null) ? 0 : ovddockey.hashCode());
		result = prime * result + ((ovddocvalue == null) ? 0 : ovddocvalue.hashCode());
		result = prime * result + ((street == null) ? 0 : street.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplicationAddress other = (ApplicationAddress) obj;
		if (addressline1 == null) {
			if (other.addressline1 != null)
				return false;
		} else if (!addressline1.equals(other.addressline1))
			return false;
		if (addressline2 == null) {
			if (other.addressline2 != null)
				return false;
		} else if (!addressline2.equals(other.addressline2))
			return false;
		if (citykey == null) {
			if (other.citykey != null)
				return false;
		} else if (!citykey.equals(other.citykey))
			return false;
		if (countryKey == null) {
			if (other.countryKey != null)
				return false;
		} else if (!countryKey.equals(other.countryKey))
			return false;
		if (ovddockey == null) {
			if (other.ovddockey != null)
				return false;
		} else if (!ovddockey.equals(other.ovddockey))
			return false;
		if (ovddocvalue == null) {
			if (other.ovddocvalue != null)
				return false;
		} else if (!ovddocvalue.equals(other.ovddocvalue))
			return false;
		if (flatnum == null) {
			if (other.flatnum != null)
				return false;
		} else if (!flatnum.equals(other.flatnum))
			return false;
		if (housenum == null) {
			if (other.housenum != null)
				return false;
		} else if (!housenum.equals(other.housenum))
			return false;
		if (localitykey == null) {
			if (other.localitykey != null)
				return false;
		} else if (!localitykey.equals(other.localitykey))
			return false;
		if (pincodekey == null) {
			if (other.pincodekey != null)
				return false;
		} else if (!pincodekey.equals(other.pincodekey))
			return false;
		if (statekey == null) {
			if (other.statekey != null)
				return false;
		} else if (!statekey.equals(other.statekey))
			return false;
		if (street == null) {
			if (other.street != null)
				return false;
		} else if (!street.equals(other.street))
			return false;
		return true;
	}
	
	
}
