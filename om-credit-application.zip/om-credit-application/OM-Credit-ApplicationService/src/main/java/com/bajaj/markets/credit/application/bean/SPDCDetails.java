package com.bajaj.markets.credit.application.bean;

public class SPDCDetails {

	private String pdcnumber1;
	private String pdcamount1;
	private String pdcnumber2;
	private String pdcamount2;
	private String pdcnumber3;
	private String pdcamount3;
	private String pdcnumber4;
	private String pdcamount4;
	
	public String getPdcnumber1() {
		return pdcnumber1;
	}
	public void setPdcnumber1(String pdcnumber1) {
		this.pdcnumber1 = pdcnumber1;
	}
	public String getPdcamount1() {
		return pdcamount1;
	}
	public void setPdcamount1(String pdcamount1) {
		this.pdcamount1 = pdcamount1;
	}
	public String getPdcnumber2() {
		return pdcnumber2;
	}
	public void setPdcnumber2(String pdcnumber2) {
		this.pdcnumber2 = pdcnumber2;
	}
	public String getPdcamount2() {
		return pdcamount2;
	}
	public void setPdcamount2(String pdcamount2) {
		this.pdcamount2 = pdcamount2;
	}
	public String getPdcnumber3() {
		return pdcnumber3;
	}
	public void setPdcnumber3(String pdcnumber3) {
		this.pdcnumber3 = pdcnumber3;
	}
	public String getPdcamount3() {
		return pdcamount3;
	}
	public void setPdcamount3(String pdcamount3) {
		this.pdcamount3 = pdcamount3;
	}
	public String getPdcnumber4() {
		return pdcnumber4;
	}
	public void setPdcnumber4(String pdcnumber4) {
		this.pdcnumber4 = pdcnumber4;
	}
	public String getPdcamount4() {
		return pdcamount4;
	}
	public void setPdcamount4(String pdcamount4) {
		this.pdcamount4 = pdcamount4;
	}
	
}
