package com.bajaj.markets.credit.application.controller;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.UpdateApplication;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationEligibilityService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationEligibilityController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	ApplicationEligibilityService applicationEligibilityService;

	private static final String CLASSNAME = ApplicationEligibilityController.class.getName();

	@Secured(value = { Role.B2BPARTNER, Role.VENDORPARTNER, Role.PRINCIPAL, Role.PSEUDO_CUSTOMER,
			Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update Eligibility Details", notes = "Update Eligibility Details", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application Updated successfully."),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.eligibility.details.PUT.uri}")
	@CrossOrigin
	public ResponseEntity<Object> updateEligibilityDetails(
			@PathVariable("applicationkey") @NotBlank(message = "applicationkey can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationkey should be numeric & should not exceeds size") String applicationId,
			@RequestBody UpdateApplication updateApplication, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateEligibilityDetails controller - applicationId " + applicationId );
		applicationEligibilityService.updateEligibilityDetails(applicationId, updateApplication);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "updateEligibilityDetails : Update loan application completed for applicationId : " + applicationId );
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
