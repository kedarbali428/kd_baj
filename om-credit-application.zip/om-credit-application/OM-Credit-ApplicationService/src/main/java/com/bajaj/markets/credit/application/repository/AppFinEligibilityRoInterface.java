package com.bajaj.markets.credit.application.repository;

import com.bajaj.markets.credit.application.model.AppFinEligibility;

public interface AppFinEligibilityRoInterface extends ReadInterface<AppFinEligibility, Long> {

	AppFinEligibility findByApplicationkeyAndIsactive(Long applicationkey, Integer isActive);

	AppFinEligibility findByApplicationkeyAndIsactiveAndAppprodlistkey(Long applicationkey, Integer isActive,
			Long appprodlistkey);

}
