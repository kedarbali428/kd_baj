package com.bajaj.markets.credit.application.controller;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.ApplicationVerificationBean;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.Verificationdetail;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationVerificationService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationVerificationController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	ApplicationVerificationService applicationVerificationService;
	
	@Autowired
    private Validator validator;

	private static final String CLASSNAME = ApplicationVerificationController.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER,Role.EMPLOYEE,Role.SYSTEM})
	@ApiOperation(value = "Application verification details", notes = "Verification details", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Verification details added successfully.", response = ApplicationVerificationBean.class),
			@ApiResponse(code = 200, message = "Verification details updated sucessfully", response = ApplicationVerificationBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "${api.omcreditapplicationservice.verification.PUT.uri}", produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationVerificationBean> applicationVerificationDetails(@Valid @RequestBody ApplicationVerificationBean bean,
			@RequestHeader HttpHeaders headers) {
		String applicationKey =bean.getApplicationKey();
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside ApplicationVerificationController :: applicationVerificationDetails method for application: "+applicationKey);
		Set<ConstraintViolation<ApplicationVerificationBean>> validationErrors = validator.validate(bean, Verificationdetail.class);
        if (!CollectionUtils.isEmpty(validationErrors)) {
            String message = "";
            if(validationErrors.stream().findFirst().isPresent()) {
                message = validationErrors.stream().findFirst().get().getMessage();
            }
            throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-11011", message));
        }
		ApplicationVerificationBean response = applicationVerificationService.applicationVerificationDetails(bean);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, 
				"Inside ApplicationVerificationController :: applicationVerificationDetails method completed successfully, applicationKey: "+applicationKey);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}
}