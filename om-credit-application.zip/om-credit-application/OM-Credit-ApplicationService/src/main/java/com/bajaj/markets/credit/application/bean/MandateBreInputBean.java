/**
 * 
 */
package com.bajaj.markets.credit.application.bean;

/**
 * @author pranoti.pandole
 *
 */
public class MandateBreInputBean {
	private MandateInput mandateInput;
	
	
	public MandateInput getMandateInput() {
		return mandateInput;
	}

	public void setMandateInput(MandateInput mandateInput) {
		this.mandateInput = mandateInput;
	}

	private AdditionalParameterDetail additionalParameterDetail;


	/**
	 * @return the additionalParameterDetail
	 */
	public AdditionalParameterDetail getAdditionalParameterDetail() {
		return additionalParameterDetail;
	}

	/**
	 * @param additionalParameterDetail the additionalParameterDetail to set
	 */
	public void setAdditionalParameterDetail(AdditionalParameterDetail additionalParameterDetail) {
		this.additionalParameterDetail = additionalParameterDetail;
	}


}
