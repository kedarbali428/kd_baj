package com.bajaj.markets.credit.application.bean;

import java.sql.Timestamp;

public class PinCodeServiceableMasterData{
	private Long pinServiceKey;

	private Long pincodeKey;

	private Long prodKey;

	private String cityName;

	private String tier;

	private String stdCode;

	private String stateName;
	
	private String cityCode;

	private boolean oglFlg;

	public Long getPinServiceKey() {
		return pinServiceKey;
	}

	public void setPinServiceKey(Long pinServiceKey) {
		this.pinServiceKey = pinServiceKey;
	}

	public Long getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(Long pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public Long getProdKey() {
		return prodKey;
	}

	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	
	public String getStdCode() {
		return stdCode;
	}

	public void setStdCode(String stdCode) {
		this.stdCode = stdCode;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	
	public boolean getOglFlg() {
		return oglFlg;
	}

	public void setOglFlg(boolean oglFlg) {
		this.oglFlg = oglFlg;
	}
	
	
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	

}