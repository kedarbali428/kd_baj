package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.FeeCalculationInputBean;
import com.bajaj.markets.credit.application.bean.FeeCalculationOutputBean;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.FeeCalculationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class FeeCalculationController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	FeeCalculationService feeCalculationService;

	private static final String CLASSNAME = ProductBundleController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Get Fee Calcualtion from BRE and save response to DB", notes = "Get Fee Calcualtion from BRE and save response to DB", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fee calculated Fetch Successfully", response = FeeCalculationOutputBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(path = "${api.omcreditapplicationservice.feesdetails.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<FeeCalculationOutputBean> fetchFeeCalculation(
			@PathVariable("applicationId") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@Valid @RequestBody FeeCalculationInputBean feeCalculationInputBean, BindingResult result,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside fetchFeeCalculation method for applicationId: " +applicationId);
		if (result.hasErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_030", result.getFieldErrors().get(0).getDefaultMessage()));
		}
		FeeCalculationOutputBean feeCalculationOutputBean = feeCalculationService.fetchCalcualtedFee(
				feeCalculationInputBean,
				applicationId, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside fetchFeeCalculation method End for applicationId: " +applicationId);
		return new ResponseEntity<FeeCalculationOutputBean>(feeCalculationOutputBean, HttpStatus.OK);
	}

}
