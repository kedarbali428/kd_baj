package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.ApplicantProfileRequest;
import com.bajaj.markets.credit.application.bean.CoapplicantRequest;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.ApplicationAttribute;
import com.bajaj.markets.credit.application.service.ApplicationApplicantService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationApplicantController {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	ApplicationApplicantService applicationApplicantService;

	private static final String CLASSNAME = ApplicationApplicantController.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "Applications co-applicant save details endpoint", notes = "Save co-applicant details", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "applicant details added successfully.", response = ApplicationAttribute.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/creditapplication/applications/{applicationid}/applicant", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> saveApplicant(@Valid @RequestBody ApplicantProfileRequest applicantRequest,
			@PathVariable(name = "applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationid,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside ApplicationApplicantController :: saveApplicant method started - applicationkey :" + applicationid);
		if (bindingResult.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Invalid request parameters passed on application : "+applicationid);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1022", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}else {
			ApplicationAttribute response  = applicationApplicantService.saveApplicantToAttribute(applicantRequest, applicationid);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Completed ApplicationApplicantController :: saveApplicant method for application :"+ applicationid);
			return new ResponseEntity<>(response.getAppattrbkey(), HttpStatus.CREATED);
		}
	}
	
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "delete co-applicant endpoint", notes = "Delete co-applicant details", httpMethod = "DELETE")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "applicant details deleted successfully.", response = ApplicationAttribute.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@RequestMapping(value = "/v1/creditapplication/applications/{applicationid}/applicant",method = RequestMethod.DELETE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> deleteApplicant(
			@PathVariable(name = "applicationid", required = true)@Digits(fraction = 0, integer = 20,message = "applicationkey should be numeric & should not exceeds size") Long applicationid,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"In Applicant Controller: Delete applicant invoked for application : "+applicationid);
		Long appAttrbKey = applicationApplicantService.deleteApplicant(applicationid);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"In Applicant Controller: Delete applicant completed for application : "+applicationid);
		return new ResponseEntity<>(appAttrbKey, HttpStatus.OK);
	}

	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "Applications co-applicant update details endpoint", notes = "update co-applicant details", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "applicant details added successfully.", response = ApplicationAttribute.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationid}/applicant", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateApplicant(@Valid @RequestBody CoapplicantRequest applicantRequest,
			@PathVariable(name = "applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationid,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside ApplicationApplicantController :: updateApplicant method started - applicationkey :" + applicationid);
		if (bindingResult.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Invalid parameters passed on application : "+applicationid);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1022", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}else {
			ApplicationAttribute response  = applicationApplicantService.updateApplicantToAttribute(applicantRequest, applicationid);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Completed ApplicationApplicantController :: updateApplicant method - applicationkey :" + applicationid);
			return new ResponseEntity<>(response.getAppattrbkey(), HttpStatus.OK);
		}
	}
}

