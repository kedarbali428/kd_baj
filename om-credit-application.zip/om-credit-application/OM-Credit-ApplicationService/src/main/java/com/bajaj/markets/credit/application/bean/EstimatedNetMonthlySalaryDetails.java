package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class EstimatedNetMonthlySalaryDetails {
	
	private String salarySource;
	private BigDecimal salaryAmount;
	
	public String getSalarySource() {
		return salarySource;
	}
	public void setSalarySource(String salarySource) {
		this.salarySource = salarySource;
	}
	public BigDecimal getSalaryAmount() {
		return salaryAmount;
	}
	public void setSalaryAmount(BigDecimal salaryAmount) {
		this.salaryAmount = salaryAmount;
	}
	
	

}
