package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the substage_master database table.
 * 
 */
@Entity
@Table(name="substage_master", schema = "dmcredit")
public class SubstageMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long substagekey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String substagecode;

	private Integer substagecompletionper;

	private String substagedesc;

	private Integer substagerank;

	//bi-directional many-to-one association to StageMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="stagekey")
	private StageMaster stageMaster;

	public SubstageMaster() {
	}

	public Long getSubstagekey() {
		return this.substagekey;
	}

	public void setSubstagekey(Long substagekey) {
		this.substagekey = substagekey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getSubstagecode() {
		return this.substagecode;
	}

	public void setSubstagecode(String substagecode) {
		this.substagecode = substagecode;
	}

	public Integer getSubstagecompletionper() {
		return this.substagecompletionper;
	}

	public void setSubstagecompletionper(Integer substagecompletionper) {
		this.substagecompletionper = substagecompletionper;
	}

	public String getSubstagedesc() {
		return this.substagedesc;
	}

	public void setSubstagedesc(String substagedesc) {
		this.substagedesc = substagedesc;
	}

	public Integer getSubstagerank() {
		return this.substagerank;
	}

	public void setSubstagerank(Integer substagerank) {
		this.substagerank = substagerank;
	}

	public StageMaster getStageMaster() {
		return this.stageMaster;
	}

	public void setStageMaster(StageMaster stageMaster) {
		this.stageMaster = stageMaster;
	}

}