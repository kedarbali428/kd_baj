package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class ServiceRequestDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long applicationKey;
	private Long productKey;
	private Long subProductKey;
	private String subProductCode;
	private String productRefNo;
	public Long getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}
	public Long getProductKey() {
		return productKey;
	}
	public void setProductKey(Long productKey) {
		this.productKey = productKey;
	}
	public Long getSubProductKey() {
		return subProductKey;
	}
	public void setSubProductKey(Long subProductKey) {
		this.subProductKey = subProductKey;
	}
	public String getSubProductCode() {
		return subProductCode;
	}
	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}
	public String getProductRefNo() {
		return productRefNo;
	}
	public void setProductRefNo(String productRefNo) {
		this.productRefNo = productRefNo;
	}
}
