package com.bajaj.markets.credit.application.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.application.bean.CardsAndLoansProductDetails;
import com.bajaj.markets.credit.application.dao.AppProductListingDao;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.AppEligibilityDetail;
import com.bajaj.markets.credit.application.model.AppFinEligibility;
import com.bajaj.markets.credit.application.model.AppLoanPricing;
import com.bajaj.markets.credit.application.model.AppLoanPricingFees;
import com.bajaj.markets.credit.application.model.AppProductListing;
import com.bajaj.markets.credit.application.repository.tx.AppEligibilityDetailRepository;
import com.bajaj.markets.credit.application.repository.tx.AppFinEligibilityRepository;
import com.bajaj.markets.credit.application.repository.tx.AppLoanPricingFeesRepository;
import com.bajaj.markets.credit.application.repository.tx.AppLoanPricingRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationProductListingRepository;

@Component
public class AppProductListingDaoImpl implements AppProductListingDao {
	
	private static final String ERRORCODE_OMCA_201 = "OMCA_201";
	private static final String CLASS_NAME = AppProductListingDaoImpl.class.getCanonicalName();
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private ApplicationProductListingRepository applicationProductListingRepository;
	
	@Autowired
	private AppLoanPricingRepository appLoanPricingRepository;
	
	@Autowired
	private AppLoanPricingFeesRepository appLoanPricingFeesRepository;
	
	@Autowired
	private AppFinEligibilityRepository appFinEligibilityRepository;
	
	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;
	
	@Autowired
	private AppEligibilityDetailRepository appEligibilityDetailRepository;
	
	@Autowired
	private Environment env;
	
	@Transactional
	@Override
	public void copyOverProductDataToDestinationApplication(Long applicationKey, AppProductListing appProductListing,
			AppLoanPricing appLoanPricing, List<AppLoanPricingFees> appLoanPricingFeesList,
			AppFinEligibility appFinEligibility) throws CloneNotSupportedException {
		List<AppProductListing> childAppProductListing = applicationProductListingRepository
				.findByApplicationkeyAndIsactive(applicationKey, 1);
		
		Timestamp applicationCreateDate = new Timestamp(Calendar.getInstance().getTime().getTime());
		long userKey = customDefaultHeaders.getUserKey();
		Long appLoanPricingKey = null;
		AppLoanPricing childAppLoanPricing = null;
		AppLoanPricing childAppEPLoanPricing = null;
		AppFinEligibility childAppFinEligibility = null;
		Boolean isEpPricingApproved = false;
		if(null != childAppProductListing && !childAppProductListing.isEmpty()) {
			childAppLoanPricing = appLoanPricingRepository.findByApplicationkeyAndAppprodlistkeyAndSourceAndIsactive(
					applicationKey, childAppProductListing.get(0).getAppprodlistkey(),ApplicationConstants.JOURNEY,1);
			
			childAppEPLoanPricing = appLoanPricingRepository.findByApplicationkeyAndAppprodlistkeyAndSourceAndIsactive(
					applicationKey, childAppProductListing.get(0).getAppprodlistkey(),ApplicationConstants.EP,1);
			if(null != childAppEPLoanPricing && ApplicationConstants.APPROVED.equalsIgnoreCase(childAppEPLoanPricing.getStatus())) {
				isEpPricingApproved = true;
			}
			if (null != childAppLoanPricing && !isEpPricingApproved) {
				List<AppLoanPricingFees> childAppLoanPricingFeesList = appLoanPricingFeesRepository
						.findByApploanpricingkeyAndIsactive(childAppLoanPricing.getApploanpricingkey(), 1) ;
				if(null != childAppLoanPricingFeesList) {
					for(AppLoanPricingFees fees : childAppLoanPricingFeesList) {
						fees.setApploanpricingkey(childAppLoanPricing.getApploanpricingkey());
						fees.setIsactive(0);
						fees.setLstupdateby(userKey);
						fees.setLstupdatedt(applicationCreateDate);
						appLoanPricingFeesRepository.save(fees);
					}
				}
			}
			childAppFinEligibility = appFinEligibilityRepository.findByApplicationkeyAndIsactiveAndAppprodlistkey(
					applicationKey, 1, childAppProductListing.get(0).getAppprodlistkey());
		}
		
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Inside copyPricingDataToChildApplication method - Cloning Existing record for AppProductListing");
			AppProductListing appProductListingCloned = appProductListing.clone();
			AppLoanPricing appLoanPricingCloned = appLoanPricing != null ? appLoanPricing.clone() : null;
			AppFinEligibility appFinEligibilityCloned = appFinEligibility != null ? appFinEligibility.clone() : null;

			if (null != childAppProductListing && !childAppProductListing.isEmpty())
				appProductListingCloned.setAppprodlistkey(childAppProductListing.get(0).getAppprodlistkey());
			else
				appProductListingCloned.setAppprodlistkey(null);

			appProductListingCloned.setApplicationkey(applicationKey);
			appProductListingCloned.setLstupdateby(userKey);
			appProductListingCloned.setLstupdatedt(applicationCreateDate);
			appProductListingCloned = applicationProductListingRepository.save(appProductListingCloned);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Successfully updated applicationProductListing");

			if (appFinEligibilityCloned != null) {
				appFinEligibilityCloned.setAppfineligibilitykey(
						null != childAppFinEligibility ? childAppFinEligibility.getAppfineligibilitykey() : null);
				appFinEligibilityCloned.setApplicationkey(applicationKey);
				appFinEligibilityCloned.setAppprodlistkey(appProductListingCloned.getAppprodlistkey());
				appFinEligibilityCloned.setLstupdateby(userKey);
				appFinEligibilityCloned.setLstupdatedt(applicationCreateDate);
				appFinEligibilityRepository.save(appFinEligibilityCloned);
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Successfully updated appFinEligibility");
			}
			
			if (!isEpPricingApproved) {
				if (appLoanPricingCloned != null) {
					appLoanPricingCloned.setApploanpricingkey(
							null != childAppLoanPricing ? childAppLoanPricing.getApploanpricingkey() : null);
					appLoanPricingCloned.setApplicationkey(applicationKey);
					appLoanPricingCloned.setAppprodlistkey(appProductListingCloned.getAppprodlistkey());
					appLoanPricingCloned.setLstupdateby(userKey);
					appLoanPricingCloned.setLstupdatedt(applicationCreateDate);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Before updating appLoanPricingcloned");
					appLoanPricingCloned = appLoanPricingRepository.save(appLoanPricingCloned);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Successfully updated appLoanPricing");
					appLoanPricingKey = appLoanPricingCloned.getApploanpricingkey();
				}
				copyLoanPricingFeesToChildApplication(applicationCreateDate, userKey, appLoanPricingFeesList,
						appLoanPricingKey);
			}

	}
	
	private void copyLoanPricingFeesToChildApplication(Timestamp applicationCreateDate, long userKey,
			List<AppLoanPricingFees> appLoanPricingFeesList, Long childAppLoanPricingKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "appLoanPricingFeesList " + appLoanPricingFeesList);
		if (appLoanPricingFeesList != null) {
			appLoanPricingFeesList.forEach(appLoanPricingFees -> {

				AppLoanPricingFees appLoanPricingFeesCloned = null;
				try {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Inside copyOverChildApplication method - Cloning Existing record for AppLoanPricingFees");
					appLoanPricingFeesCloned = appLoanPricingFees.clone();
				} catch (CloneNotSupportedException exception) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Technical exception occurred while creating clone for AppLoanPricingFees: ",
							exception);
					throw new CreditApplicationServiceException(HttpStatus.CONFLICT, exception);
				}
				appLoanPricingFeesCloned.setApploanpricingfeeskey(null);
				appLoanPricingFeesCloned.setApploanpricingkey(childAppLoanPricingKey);
				appLoanPricingFeesCloned.setLstupdateby(userKey);
				appLoanPricingFeesCloned.setLstupdatedt(applicationCreateDate);
				appLoanPricingFeesRepository.save(appLoanPricingFeesCloned);
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Successfully updated appLoanPricingFees");
			});
		}
	}
	
	@Transactional
	@Override
	public AppProductListing updateAppProductListing(AppProductListing appProductListing) {
		if(null != appProductListing.getApplicationkey() && null != appProductListing.getProdkey()) {
			AppProductListing existingAppProductListing = applicationProductListingRepository
						.findByApplicationkeyAndIsactiveAndProdkeyAndProdtypekeyAndRiskoffertype(appProductListing.getApplicationkey(),
								1, appProductListing.getProdkey(), appProductListing.getProdtypekey(), appProductListing.getRiskoffertype());
			if (null != existingAppProductListing) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Existing record found for applicationKey: " + appProductListing.getApplicationkey() + " , productkey: " + appProductListing.getProdkey() + " , prodtypekey: " + appProductListing.getProdtypekey() + " and riskOfferType: " + appProductListing.getRiskoffertype() + " with listingkey: " + existingAppProductListing.getAppprodlistkey());
				appProductListing.copyExistingProductListing(existingAppProductListing);
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Creating new record for: " + appProductListing);
			}
			appProductListing.setIsactive(1);
			appProductListing.setLstupdateby(customDefaultHeaders.getUserKey());
			appProductListing.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
			return applicationProductListingRepository.save(appProductListing);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Invalid parameters for creating or updating appProductListing: " + appProductListing);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(ERRORCODE_OMCA_201, env.getProperty(ERRORCODE_OMCA_201)));
		} 
	}

	@Transactional
	@Override
	public AppFinEligibility updateAppFinEligibility(AppFinEligibility appFinEligibility) {
		if(null != appFinEligibility.getApplicationkey() && null != appFinEligibility.getAppprodlistkey()) {
			AppFinEligibility existingAppFinEligibility = appFinEligibilityRepository
					.findByApplicationkeyAndIsactiveAndAppprodlistkey(appFinEligibility.getApplicationkey(), 1,
							appFinEligibility.getAppprodlistkey());
			if (null != existingAppFinEligibility) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Existing record found for applicationKey: " + appFinEligibility.getApplicationkey() + " and listing key " + appFinEligibility.getAppprodlistkey() + " with appfineligibilitykey: " + existingAppFinEligibility.getAppfineligibilitykey());
				appFinEligibility.setAppfineligibilitykey(existingAppFinEligibility.getAppfineligibilitykey());
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Creating new record for: " + appFinEligibility);
			}
			appFinEligibility.setLstupdateby(customDefaultHeaders.getUserKey());
			appFinEligibility.setIsactive(1);
			appFinEligibility.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
			return appFinEligibilityRepository.save(appFinEligibility);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Invalid parameters for creating or updating appFinEligibility: " + appFinEligibility);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(ERRORCODE_OMCA_201, env.getProperty(ERRORCODE_OMCA_201)));
		}
	}
	
	@Transactional
	@Override
	public void updateAppEligibilityDetail(String applicationKey, Long appattrbkey,
			CardsAndLoansProductDetails productDetails) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.DAO,
				"Start updateAppEligibilityDetail for applicationKey: " + applicationKey);

		if (null != appattrbkey) {
			AppEligibilityDetail existingAppEligibilityDetail = appEligibilityDetailRepository
					.findByAppattrbkeyAndIsactive(appattrbkey, 1);
			if (null == existingAppEligibilityDetail) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.DAO,
						"appEligibilityDetailRepository Existing Record Found for applicationKey"+applicationKey);
				
				existingAppEligibilityDetail = new AppEligibilityDetail();
				existingAppEligibilityDetail.setAppattrbkey(appattrbkey);
				existingAppEligibilityDetail.setIsactive(1);
			}

			existingAppEligibilityDetail.setLstupdateby(customDefaultHeaders.getUserKey());
			existingAppEligibilityDetail.setLstupdatedt(Calendar.getInstance().getTime());
			Long maxeligibility = productDetails.getOpenArcCardListingOutput().getOpenMarketsLoanListing()
					.getMaxEligibility();
			existingAppEligibilityDetail
					.setMaxeligibility(maxeligibility == null ? null : new BigDecimal(maxeligibility));
			Integer maxTenor = productDetails.getOpenArcCardListingOutput().getOpenMarketsLoanListing().getMaxTenor();
			existingAppEligibilityDetail.setMaxtenor(maxTenor == null ? null : new BigDecimal(maxTenor));

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Before Save or update appEligibilityDetailRepository");
			appEligibilityDetailRepository.save(existingAppEligibilityDetail);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "After Save or update appEligibilityDetailRepository");

		} else {

			logger.error(CLASS_NAME, BFLLoggerComponent.DAO,
					"Invalid data for updating AppEligibilityDetail," + " appattrbkey is mandatory: " + appattrbkey);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean(ERRORCODE_OMCA_201, env.getProperty(ERRORCODE_OMCA_201)));

		}
	}
	

}
