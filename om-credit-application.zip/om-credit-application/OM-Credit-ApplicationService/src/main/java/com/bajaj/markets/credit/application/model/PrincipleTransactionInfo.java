package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "principle_transaction_info", schema = "dmcredit")
public class PrincipleTransactionInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long principletransinfokey;

	private Long applicationkey;
	private Long prodkey;
	private String principlerefid1;
	private String principlerefid2;
	private String principlerefid3;
	private String principlerefid4;
	private String principlerefid5;
	private String validationtoken;
	private Timestamp validationtokengentime;

	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Integer iscasecreated;
	private String failurereason;
	private Integer iscaseprocessed;
	private Integer iscardapproved;
	private String statusmessage;
	private String statuscode;
	private String processtransactionid;
	private String url1;
	private String url2;
	private Long principalkey;
	private String custdemogtoken;
	private String workflowstatus;
	private Integer offerapi;
	private Timestamp offerapidt;
	private Integer leadpush;
	private Timestamp leadpushdt;
	private Integer statusapi;
	private Timestamp statusapidt;
	private String principalstage;
	private String substatusmessage;
	private String substatuscode;
	private String rejectionreason;
	private String instantloan;
	private String rejectioncode;
	public long getPrincipletransinfokey() {
		return principletransinfokey;
	}
	public void setPrincipletransinfokey(long principletransinfokey) {
		this.principletransinfokey = principletransinfokey;
	}
	public Long getApplicationkey() {
		return applicationkey;
	}
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}
	public Long getProdkey() {
		return prodkey;
	}
	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}
	public String getPrinciplerefid1() {
		return principlerefid1;
	}
	public void setPrinciplerefid1(String principlerefid1) {
		this.principlerefid1 = principlerefid1;
	}
	public String getPrinciplerefid2() {
		return principlerefid2;
	}
	public void setPrinciplerefid2(String principlerefid2) {
		this.principlerefid2 = principlerefid2;
	}
	public String getPrinciplerefid3() {
		return principlerefid3;
	}
	public void setPrinciplerefid3(String principlerefid3) {
		this.principlerefid3 = principlerefid3;
	}
	public String getPrinciplerefid4() {
		return principlerefid4;
	}
	public void setPrinciplerefid4(String principlerefid4) {
		this.principlerefid4 = principlerefid4;
	}
	public String getPrinciplerefid5() {
		return principlerefid5;
	}
	public void setPrinciplerefid5(String principlerefid5) {
		this.principlerefid5 = principlerefid5;
	}
	public String getValidationtoken() {
		return validationtoken;
	}
	public void setValidationtoken(String validationtoken) {
		this.validationtoken = validationtoken;
	}
	public Timestamp getValidationtokengentime() {
		return validationtokengentime;
	}
	public void setValidationtokengentime(Timestamp validationtokengentime) {
		this.validationtokengentime = validationtokengentime;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	public Long getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	public Integer getIscasecreated() {
		return iscasecreated;
	}
	public void setIscasecreated(Integer iscasecreated) {
		this.iscasecreated = iscasecreated;
	}
	public String getFailurereason() {
		return failurereason;
	}
	public void setFailurereason(String failurereason) {
		this.failurereason = failurereason;
	}
	public Integer getIscaseprocessed() {
		return iscaseprocessed;
	}
	public void setIscaseprocessed(Integer iscaseprocessed) {
		this.iscaseprocessed = iscaseprocessed;
	}
	public Integer getIscardapproved() {
		return iscardapproved;
	}
	public void setIscardapproved(Integer iscardapproved) {
		this.iscardapproved = iscardapproved;
	}
	public String getStatusmessage() {
		return statusmessage;
	}
	public void setStatusmessage(String statusmessage) {
		this.statusmessage = statusmessage;
	}
	public String getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}
	public String getProcesstransactionid() {
		return processtransactionid;
	}
	public void setProcesstransactionid(String processtransactionid) {
		this.processtransactionid = processtransactionid;
	}
	public String getUrl1() {
		return url1;
	}
	public void setUrl1(String url1) {
		this.url1 = url1;
	}
	public String getUrl2() {
		return url2;
	}
	public void setUrl2(String url2) {
		this.url2 = url2;
	}
	public Long getPrincipalkey() {
		return principalkey;
	}
	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}
	public String getCustdemogtoken() {
		return custdemogtoken;
	}
	public void setCustdemogtoken(String custdemogtoken) {
		this.custdemogtoken = custdemogtoken;
	}
	public String getWorkflowstatus() {
		return workflowstatus;
	}
	public void setWorkflowstatus(String workflowstatus) {
		this.workflowstatus = workflowstatus;
	}
	public Integer getOfferapi() {
		return offerapi;
	}
	public void setOfferapi(Integer offerapi) {
		this.offerapi = offerapi;
	}
	public Timestamp getOfferapidt() {
		return offerapidt;
	}
	public void setOfferapidt(Timestamp offerapidt) {
		this.offerapidt = offerapidt;
	}
	public Integer getLeadpush() {
		return leadpush;
	}
	public void setLeadpush(Integer leadpush) {
		this.leadpush = leadpush;
	}
	public Timestamp getLeadpushdt() {
		return leadpushdt;
	}
	public void setLeadpushdt(Timestamp leadpushdt) {
		this.leadpushdt = leadpushdt;
	}
	public Integer getStatusapi() {
		return statusapi;
	}
	public void setStatusapi(Integer statusapi) {
		this.statusapi = statusapi;
	}
	public Timestamp getStatusapidt() {
		return statusapidt;
	}
	public void setStatusapidt(Timestamp statusapidt) {
		this.statusapidt = statusapidt;
	}
	public String getPrincipalstage() {
		return principalstage;
	}
	public void setPrincipalstage(String principalstage) {
		this.principalstage = principalstage;
	}
	public String getSubstatusmessage() {
		return substatusmessage;
	}
	public void setSubstatusmessage(String substatusmessage) {
		this.substatusmessage = substatusmessage;
	}
	public String getSubstatuscode() {
		return substatuscode;
	}
	public void setSubstatuscode(String substatuscode) {
		this.substatuscode = substatuscode;
	}
	public String getRejectionreason() {
		return rejectionreason;
	}
	public void setRejectionreason(String rejectionreason) {
		this.rejectionreason = rejectionreason;
	}
	public String getInstantloan() {
		return instantloan;
	}
	public void setInstantloan(String instantloan) {
		this.instantloan = instantloan;
	}
	public String getRejectioncode() {
		return rejectioncode;
	}
	public void setRejectioncode(String rejectioncode) {
		this.rejectioncode = rejectioncode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
