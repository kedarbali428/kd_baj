package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the app_product_listing database table.
 * 
 */
@Entity
@Table(name = "app_product_listing", schema = "dmcredit")
@NamedQuery(name = "AppProductListing.getEligibleProductsOnly", query = "SELECT apl FROM AppProductListing apl JOIN Product prod ON apl.prodkey = prod.prodkey WHERE apl.applicationkey =:applicationkey AND apl.isactive = 1 AND apl.isdisplayflg = 1 AND prod.isactive = 1 order by apl.priorityorder")
public class AppProductListing implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_product_listingkey_generator", sequenceName = "dmcredit.seq_pk_app_product_listing", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_product_listingkey_generator")
	private Long appprodlistkey;

	private BigDecimal annualfee;

	private Long applicationkey;

	private String feature;

	private Integer isactive;

	private Long lstupdateby;

	private BigDecimal iseligible;

	private Timestamp lstupdatedt;

	private Long prodkey;

	private String promotionaloffer;

	private String rewardpoint;

	private Integer priorityorder;

	private String cardtag;

	private String approvalchance;

	private String productsize;

	private BigDecimal bscore;

	private String ctaname;

	private String leadQualifiesBflFlag;

	private String pefiosRequiredFlag;

	private String eligibilitytype;

	private BigDecimal requiredloanamount;

	private Integer tenure;

	private String loantyperecommendation;

	private Integer preapproved;

	private String fppapplicable;

	private String deviationcode;

	private String bflapplicablelocationflag;

	private Long prodtypekey;

	private String pennantloantyperecommendation;

	private Integer isdisplayflg;

	private String riskoffertype;
	
	private Integer stmttobecollected;
	
	private Boolean segmentrerun;

	public Boolean getSegmentrerun() {
		return segmentrerun;
	}

	public void setSegmentrerun(Boolean segmentrerun) {
		this.segmentrerun = segmentrerun;
	}

	public Long getAppprodlistkey() {
		return appprodlistkey;
	}

	public void setAppprodlistkey(Long appprodlistkey) {
		this.appprodlistkey = appprodlistkey;
	}

	public BigDecimal getAnnualfee() {
		return annualfee;
	}

	public void setAnnualfee(BigDecimal annualfee) {
		this.annualfee = annualfee;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public String getFeature() {
		return feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public BigDecimal getIseligible() {
		return iseligible;
	}

	public void setIseligible(BigDecimal iseligible) {
		this.iseligible = iseligible;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getPromotionaloffer() {
		return promotionaloffer;
	}

	public void setPromotionaloffer(String promotionaloffer) {
		this.promotionaloffer = promotionaloffer;
	}

	public String getRewardpoint() {
		return rewardpoint;
	}

	public void setRewardpoint(String rewardpoint) {
		this.rewardpoint = rewardpoint;
	}

	public Integer getPriorityorder() {
		return priorityorder;
	}

	public void setPriorityorder(Integer priorityorder) {
		this.priorityorder = priorityorder;
	}

	public String getCardtag() {
		return cardtag;
	}

	public void setCardtag(String cardtag) {
		this.cardtag = cardtag;
	}

	public String getApprovalchance() {
		return approvalchance;
	}

	public void setApprovalchance(String approvalchance) {
		this.approvalchance = approvalchance;
	}

	public String getProductsize() {
		return productsize;
	}

	public void setProductsize(String productsize) {
		this.productsize = productsize;
	}

	public BigDecimal getBscore() {
		return bscore;
	}

	public void setBscore(BigDecimal bscore) {
		this.bscore = bscore;
	}

	public String getCtaname() {
		return ctaname;
	}

	public void setCtaname(String ctaname) {
		this.ctaname = ctaname;
	}

	public String getLeadQualifiesBflFlag() {
		return leadQualifiesBflFlag;
	}

	public void setLeadQualifiesBflFlag(String leadQualifiesBflFlag) {
		this.leadQualifiesBflFlag = leadQualifiesBflFlag;
	}

	public String getPefiosRequiredFlag() {
		return pefiosRequiredFlag;
	}

	public void setPefiosRequiredFlag(String pefiosRequiredFlag) {
		this.pefiosRequiredFlag = pefiosRequiredFlag;
	}

	public String getEligibilitytype() {
		return eligibilitytype;
	}

	public void setEligibilitytype(String eligibilitytype) {
		this.eligibilitytype = eligibilitytype;
	}

	public BigDecimal getRequiredloanamount() {
		return requiredloanamount;
	}

	public void setRequiredloanamount(BigDecimal requiredloanamount) {
		this.requiredloanamount = requiredloanamount;
	}

	public Integer getTenure() {
		return tenure;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	public String getLoantyperecommendation() {
		return loantyperecommendation;
	}

	public void setLoantyperecommendation(String loantyperecommendation) {
		this.loantyperecommendation = loantyperecommendation;
	}

	public Integer getPreapproved() {
		return preapproved;
	}

	public void setPreapproved(Integer preapproved) {
		this.preapproved = preapproved;
	}

	public String getFppapplicable() {
		return fppapplicable;
	}

	public void setFppapplicable(String fppapplicable) {
		this.fppapplicable = fppapplicable;
	}

	public String getDeviationcode() {
		return deviationcode;
	}

	public void setDeviationcode(String deviationcode) {
		this.deviationcode = deviationcode;
	}

	public String getBflapplicablelocationflag() {
		return bflapplicablelocationflag;
	}

	public void setBflapplicablelocationflag(String bflapplicablelocationflag) {
		this.bflapplicablelocationflag = bflapplicablelocationflag;
	}

	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	public String getPennantloantyperecommendation() {
		return pennantloantyperecommendation;
	}

	public void setPennantloantyperecommendation(String pennantloantyperecommendation) {
		this.pennantloantyperecommendation = pennantloantyperecommendation;
	}

	public Integer getIsdisplayflg() {
		return isdisplayflg;
	}

	public void setIsdisplayflg(Integer isdisplayflg) {
		this.isdisplayflg = isdisplayflg;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}


	
	public Integer getStmttobecollected() {
		return stmttobecollected;
	}

	public void setStmttobecollected(Integer stmttobecollected) {
		this.stmttobecollected = stmttobecollected;
	}

	public AppProductListing clone() throws CloneNotSupportedException {
		AppProductListing appProductListing = new AppProductListing();
		appProductListing.setAppprodlistkey(this.appprodlistkey);
		appProductListing.setApplicationkey(this.applicationkey);
		appProductListing.setAnnualfee(this.annualfee);
		appProductListing.setApprovalchance(this.approvalchance);
		appProductListing.setBflapplicablelocationflag(this.bflapplicablelocationflag);
		appProductListing.setCardtag(this.cardtag);
		appProductListing.setDeviationcode(this.deviationcode);
		appProductListing.setEligibilitytype(this.eligibilitytype);
		appProductListing.setFeature(this.feature);
		appProductListing.setFppapplicable(this.fppapplicable);
		appProductListing.setIsactive(this.isactive);
		appProductListing.setIseligible(this.iseligible);
		appProductListing.setLeadQualifiesBflFlag(this.leadQualifiesBflFlag);
		appProductListing.setLoantyperecommendation(this.loantyperecommendation);
		appProductListing.setLstupdateby(this.lstupdateby);
		appProductListing.setLstupdatedt(this.lstupdatedt);
		appProductListing.setPefiosRequiredFlag(this.pefiosRequiredFlag);
		appProductListing.setPennantloantyperecommendation(this.pennantloantyperecommendation);
		appProductListing.setPreapproved(this.preapproved);
		appProductListing.setPriorityorder(this.priorityorder);
		appProductListing.setProdkey(this.prodkey);
		appProductListing.setProdtypekey(this.prodtypekey);
		appProductListing.setProductsize(this.productsize);
		appProductListing.setPromotionaloffer(this.promotionaloffer);
		appProductListing.setRequiredloanamount(this.requiredloanamount);
		appProductListing.setRewardpoint(this.rewardpoint);
		appProductListing.setTenure(this.tenure);
		appProductListing.setBscore(this.bscore);
		appProductListing.setCtaname(this.ctaname);
		appProductListing.setRiskoffertype(this.riskoffertype);
		appProductListing.setIsdisplayflg(this.isdisplayflg);
		appProductListing.setStmttobecollected(this.stmttobecollected);
		return appProductListing;
	}

	public AppProductListing copyExistingProductListing(AppProductListing existingAppProductListing) {
		this.setAppprodlistkey(existingAppProductListing.getAppprodlistkey());
		this.setSegmentrerun(
				null != this.segmentrerun ? this.segmentrerun : existingAppProductListing.getSegmentrerun());
		return this;
	}
	@Override
	public String toString() {
		return "AppProductListing [appprodlistkey=" + appprodlistkey + ", annualfee=" + annualfee + ", applicationkey="
				+ applicationkey + ", feature=" + feature + ", isactive=" + isactive + ", lstupdateby=" + lstupdateby
				+ ", iseligible=" + iseligible + ", lstupdatedt=" + lstupdatedt + ", prodkey=" + prodkey
				+ ", promotionaloffer=" + promotionaloffer + ", rewardpoint=" + rewardpoint + ", priorityorder="
				+ priorityorder + ", cardtag=" + cardtag + ", approvalchance=" + approvalchance + ", productsize="
				+ productsize + ", bscore=" + bscore + ", ctaname=" + ctaname + ", leadQualifiesBflFlag="
				+ leadQualifiesBflFlag + ", pefiosRequiredFlag=" + pefiosRequiredFlag + ", eligibilitytype="
				+ eligibilitytype + ", requiredloanamount=" + requiredloanamount + ", tenure=" + tenure
				+ ", loantyperecommendation=" + loantyperecommendation + ", preapproved=" + preapproved
				+ ", fppapplicable=" + fppapplicable + ", deviationcode=" + deviationcode
				+ ", bflapplicablelocationflag=" + bflapplicablelocationflag + ", prodtypekey=" + prodtypekey
				+ ", pennantloantyperecommendation=" + pennantloantyperecommendation + ", riskoffertype="
				+ riskoffertype + ", isdisplayflg=" + isdisplayflg + ", stmttobecollected=" + stmttobecollected + "]";
	}

}