package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.Business;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.CA;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.Doctor;
import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.Salaried;

public class IncomeDetail {

	@Digits(fraction = 0, integer = 10,groups = {Salaried.class,Business.class,Doctor.class,CA.class}, message = "declaredIncome cannot be in fraction & should not exceed size")
    @NotNull(groups = {Salaried.class,Business.class,Doctor.class,CA.class},message = "declaredIncome cannot be null or empty")
	private Long declaredIncome;
    
	private Long perfiosIncome;
	private Long smsIncome;
	private Verification verification;
	
	public IncomeDetail(){
		super();	
	}
	
	public IncomeDetail(@Digits(fraction = 0, integer = 10, groups = { Salaried.class, Business.class, Doctor.class,
			CA.class }, message = "declaredIncome cannot be in fraction & should not exceed size") @NotNull(groups = {
					Salaried.class, Business.class, Doctor.class,
					CA.class }, message = "declaredIncome cannot be null or empty") Long declaredIncome,
			Long perfiosIncome, Long smsIncome, Verification verification) {
		super();
		this.declaredIncome = declaredIncome;
		this.perfiosIncome = perfiosIncome;
		this.smsIncome = smsIncome;
		this.verification = verification;
	}
	public Long getDeclaredIncome() {
		return declaredIncome;
	}
	public void setDeclaredIncome(Long declaredIncome) {
		this.declaredIncome = declaredIncome;
	}
	public Long getPerfiosIncome() {
		return perfiosIncome;
	}
	public void setPerfiosIncome(Long perfiosIncome) {
		this.perfiosIncome = perfiosIncome;
	}
	public Long getSmsIncome() {
		return smsIncome;
	}
	public void setSmsIncome(Long smsIncome) {
		this.smsIncome = smsIncome;
	}
	public Verification getVerification() {
		return verification;
	}
	public void setVerification(Verification verification) {
		this.verification = verification;
	}
	@Override
	public String toString() {
		return "IncomeDetail [declaredIncome=" + declaredIncome + ", perfiosIncome=" + perfiosIncome + ", smsIncome="
				+ smsIncome + ", verification=" + verification + "]";
	}
}
