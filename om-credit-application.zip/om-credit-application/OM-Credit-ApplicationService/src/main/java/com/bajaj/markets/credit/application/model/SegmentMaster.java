package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the segment_master database table.
 * 
 */
@Entity
@Table(name="segment_master", schema="dmcredit")
public class SegmentMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long segkey;

	private Integer isactive;

	private BigDecimal lstupdateby;

	private Timestamp lstupdatedt;

	private String segcode;

	private String segdescription;

	public SegmentMaster() {
	}

	public Long getSegkey() {
		return this.segkey;
	}

	public void setSegkey(Long segkey) {
		this.segkey = segkey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public BigDecimal getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(BigDecimal lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getSegcode() {
		return this.segcode;
	}

	public void setSegcode(String segcode) {
		this.segcode = segcode;
	}

	public String getSegdescription() {
		return this.segdescription;
	}

	public void setSegdescription(String segdescription) {
		this.segdescription = segdescription;
	}

}