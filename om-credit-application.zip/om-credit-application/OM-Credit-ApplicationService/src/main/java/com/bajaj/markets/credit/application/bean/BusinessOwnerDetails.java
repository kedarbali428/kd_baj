package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

import javax.validation.constraints.Pattern;

public class BusinessOwnerDetails {

	private String businessName;

	private Reference businessType;

	private Reference natureOfBusiness;

	private Reference industryType;

	private Reference anualTurnover;

	private String netMonthlyIncome;

	@Pattern(regexp = "^(0|[1-9][0-9]*)$", message = "BusinessVintage is not valid.It should only be numeric")
	private String businessVintage;

	private String proprieterName;

	private String businessPan;

	private String gstNumber;

	private Reference subindumastkey;

	private BigDecimal profitAfterTax;

	private BigDecimal averageBankBalance;

	private Reference companyType;

	private Integer presentBusinessVintage;
	
	private String cif;
	
    private Reference shopStatus;
	
	private Reference corporateLinkageType;

	private Reference businessNature;

	public Reference getShopStatus() {
		return shopStatus;
	}

	public void setShopStatus(Reference shopStatus) {
		this.shopStatus = shopStatus;
	}

	public Reference getCorporateLinkageType() {
		return corporateLinkageType;
	}

	public void setCorporateLinkageType(Reference corporateLinkageType) {
		this.corporateLinkageType = corporateLinkageType;
	}

	@Pattern(regexp = "OWN|RENTED", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Please enter a valid value - OWN|RENTAL")
	private String officetype;
	
	private Reference qualification;
	
	private Reference specialization;
	
	private String otherSpecialization;
	
	private Integer yearOfGraduation;
	
	private Integer yearOfPostGraduation;
	
	private Reference regCouncil;
	
	private String doctorRegistrationNumber;
	
	private Reference hospital;
	
	private String hospitalNameOther;
	
	private String practiceType;

	private String caRegistrationNumber;
	
	private Integer certificateOfPracticeYear;
	
	public Reference getCompanyType() {
		return companyType;
	}

	public void setCompanyType(Reference companyType) {
		this.companyType = companyType;
	}

	public BigDecimal getProfitAfterTax() {
		return profitAfterTax;
	}

	public void setProfitAfterTax(BigDecimal profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}

	public BigDecimal getAverageBankBalance() {
		return averageBankBalance;
	}

	public void setAverageBankBalance(BigDecimal averageBankBalance) {
		this.averageBankBalance = averageBankBalance;
	}

	public Reference getSubindumastkey() {
		return subindumastkey;
	}

	public void setSubindumastkey(Reference subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public Reference getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Reference businessType) {
		this.businessType = businessType;
	}

	public Reference getNatureOfBusiness() {
		return natureOfBusiness;
	}

	public void setNatureOfBusiness(Reference natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}

	public Reference getIndustryType() {
		return industryType;
	}

	public void setIndustryType(Reference industryType) {
		this.industryType = industryType;
	}

	public Reference getAnualTurnover() {
		return anualTurnover;
	}

	public void setAnualTurnover(Reference anualTurnover) {
		this.anualTurnover = anualTurnover;
	}

	public String getNetMonthlyIncome() {
		return netMonthlyIncome;
	}

	public void setNetMonthlyIncome(String netMonthlyIncome) {
		this.netMonthlyIncome = netMonthlyIncome;
	}

	public String getBusinessVintage() {
		return businessVintage;
	}

	public void setBusinessVintage(String businessVintage) {
		this.businessVintage = businessVintage;
	}

	public String getProprieterName() {
		return proprieterName;
	}

	public void setProprieterName(String proprieterName) {
		this.proprieterName = proprieterName;
	}

	public String getBusinessPan() {
		return businessPan;
	}

	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public Integer getPresentBusinessVintage() {
		return presentBusinessVintage;
	}

	public void setPresentBusinessVintage(Integer presentBusinessVintage) {
		this.presentBusinessVintage = presentBusinessVintage;
	}

	public String getOfficetype() {
		return officetype;
	}

	public void setOfficetype(String officetype) {
		this.officetype = officetype;
	}
	
	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}
	
	public Reference getQualification() {
		return qualification;
	}

	public void setQualification(Reference qualification) {
		this.qualification = qualification;
	}

	public Reference getSpecialization() {
		return specialization;
	}

	public void setSpecialization(Reference specialization) {
		this.specialization = specialization;
	}

	public String getOtherSpecialization() {
		return otherSpecialization;
	}

	public void setOtherSpecialization(String otherSpecialization) {
		this.otherSpecialization = otherSpecialization;
	}

	public Integer getYearOfGraduation() {
		return yearOfGraduation;
	}

	public void setYearOfGraduation(Integer yearOfGraduation) {
		this.yearOfGraduation = yearOfGraduation;
	}

	public Integer getYearOfPostGraduation() {
		return yearOfPostGraduation;
	}

	public void setYearOfPostGraduation(Integer yearOfPostGraduation) {
		this.yearOfPostGraduation = yearOfPostGraduation;
	}

	public Reference getRegCouncil() {
		return regCouncil;
	}

	public void setRegCouncil(Reference regCouncil) {
		this.regCouncil = regCouncil;
	}

	public String getDoctorRegistrationNumber() {
		return doctorRegistrationNumber;
	}

	public void setDoctorRegistrationNumber(String doctorRegistrationNumber) {
		this.doctorRegistrationNumber = doctorRegistrationNumber;
	}

	public Reference getHospital() {
		return hospital;
	}

	public void setHospital(Reference hospital) {
		this.hospital = hospital;
	}

	public String getHospitalNameOther() {
		return hospitalNameOther;
	}

	public void setHospitalNameOther(String hospitalNameOther) {
		this.hospitalNameOther = hospitalNameOther;
	}

	public String getPracticeType() {
		return practiceType;
	}

	public void setPracticeType(String practiceType) {
		this.practiceType = practiceType;
	}

	public String getCaRegistrationNumber() {
		return caRegistrationNumber;
	}

	public void setCaRegistrationNumber(String caRegistrationNumber) {
		this.caRegistrationNumber = caRegistrationNumber;
	}

	public Integer getCertificateOfPracticeYear() {
		return certificateOfPracticeYear;
	}

	public void setCertificateOfPracticeYear(Integer certificateOfPracticeYear) {
		this.certificateOfPracticeYear = certificateOfPracticeYear;
	}

	public Reference getBusinessNature() {
		return businessNature;
	}

	public void setBusinessNature(Reference businessNature) {
		this.businessNature = businessNature;
	}

	@Override
	public String toString() {
		return "BusinessOwnerDetails [businessName=" + businessName + ", businessType=" + businessType
				+ ", natureOfBusiness=" + natureOfBusiness + ", industryType=" + industryType + ", anualTurnover="
				+ anualTurnover + ", netMonthlyIncome=" + netMonthlyIncome + ", businessVintage=" + businessVintage
				+ ", proprieterName=" + proprieterName + ", businessPan=" + businessPan + ", gstNumber=" + gstNumber
				+ ", subindumastkey=" + subindumastkey + ", profitAfterTax=" + profitAfterTax + ", averageBankBalance="
				+ averageBankBalance + ", companyType=" + companyType + ", presentBusinessVintage="
				+ presentBusinessVintage + ", cif=" + cif + ", shopStatus=" + shopStatus + ", corporateLinkageType="
				+ corporateLinkageType + ", businessNature=" + businessNature + ", officetype=" + officetype
				+ ", qualification=" + qualification + ", specialization=" + specialization + ", otherSpecialization="
				+ otherSpecialization + ", yearOfGraduation=" + yearOfGraduation + ", yearOfPostGraduation="
				+ yearOfPostGraduation + ", regCouncil=" + regCouncil + ", doctorRegistrationNumber="
				+ doctorRegistrationNumber + ", hospital=" + hospital + ", hospitalNameOther=" + hospitalNameOther
				+ ", practiceType=" + practiceType + ", caRegistrationNumber=" + caRegistrationNumber
				+ ", certificateOfPracticeYear=" + certificateOfPracticeYear + "]";
	}

}
