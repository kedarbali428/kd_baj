package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.AppDeviationDtl;

public interface AppDeviationDtlRoInterface extends ReadInterface<AppDeviationDtl, Long> {

	List<AppDeviationDtl> findByApplicationkeyAndProdkeyAndIsactive(Long applicationkey, Long prodkey,
			Integer isactive);

}
