package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class LoanPurposeBean {

	private Long key;

	@Pattern(regexp = "AGRICULTURE|ASSET_PURCHASE|BALANCE_TRANSFER|EDUCATION|PURCHASE_HOME_OR_RENOVATION|INVESTMENTS|MEDICAL_EXPENCE|OTHERS|PURCHASE_MACHINERY|PURCHASE_PROPERTY", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Please enter a valid Loan purpose code - AGRICULTURE|ASSET_PURCHASE|BALANCE_TRANSFER|EDUCATION|PURCHASE_HOME_OR_RENOVATION|INVESTMENTS|MEDICAL_EXPENCE|OTHERS|PURCHASE_MACHINERY|PURCHASE_PROPERTY")
	@NotBlank(message = "Loan purpose code can not be null/empty")
	private String code;

	private String purposeValue;

	public Long getKey() {
		return key;
	}

	public void setKey(Long key) {
		this.key = key;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getPurposeValue() {
		return purposeValue;
	}

	public void setPurposeValue(String purposeValue) {
		this.purposeValue = purposeValue;
	}

	@Override
	public String toString() {
		return "purposeofLoan[purposeValue = " + purposeValue + "key = " + key + "code =" + code + "]";
	}
}
