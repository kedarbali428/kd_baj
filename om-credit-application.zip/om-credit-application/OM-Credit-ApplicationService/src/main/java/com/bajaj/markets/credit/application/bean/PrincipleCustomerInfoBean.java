package com.bajaj.markets.credit.application.bean;

import java.sql.Timestamp;

public class PrincipleCustomerInfoBean {

	private Long applicationkey;

	private Long principalkey;

	private String principlecustrefid;

	private String principlecustrefsrc;

	private String isetb;

	private Integer isactive;

	private String principlecustsegment;

	private String principlecusttype;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String btssegment;

	private String etbsrc;

	private Long appattrbkey;

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getPrincipalkey() {
		return principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

	public String getPrinciplecustrefid() {
		return principlecustrefid;
	}

	public void setPrinciplecustrefid(String principlecustrefid) {
		this.principlecustrefid = principlecustrefid;
	}

	public String getPrinciplecustrefsrc() {
		return principlecustrefsrc;
	}

	public void setPrinciplecustrefsrc(String principlecustrefsrc) {
		this.principlecustrefsrc = principlecustrefsrc;
	}

	public String getIsetb() {
		return isetb;
	}

	public void setIsetb(String isetb) {
		this.isetb = isetb;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public String getPrinciplecustsegment() {
		return principlecustsegment;
	}

	public void setPrinciplecustsegment(String principlecustsegment) {
		this.principlecustsegment = principlecustsegment;
	}

	public String getPrinciplecusttype() {
		return principlecusttype;
	}

	public void setPrinciplecusttype(String principlecusttype) {
		this.principlecusttype = principlecusttype;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getBtssegment() {
		return btssegment;
	}

	public void setBtssegment(String btssegment) {
		this.btssegment = btssegment;
	}

	public String getEtbsrc() {
		return etbsrc;
	}

	public void setEtbsrc(String etbsrc) {
		this.etbsrc = etbsrc;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	@Override
	public String toString() {
		return "PrincipleCustomerInfoBean [applicationkey=" + applicationkey + ", principalkey=" + principalkey
				+ ", principlecustrefid=" + principlecustrefid + ", principlecustrefsrc=" + principlecustrefsrc
				+ ", isetb=" + isetb + ", isactive=" + isactive + ", principlecustsegment=" + principlecustsegment
				+ ", principlecusttype=" + principlecusttype + ", lstupdateby=" + lstupdateby + ", lstupdatedt="
				+ lstupdatedt + ", btssegment=" + btssegment + ", etbsrc=" + etbsrc + ", appattrbkey=" + appattrbkey
				+ "]";
	}

}
