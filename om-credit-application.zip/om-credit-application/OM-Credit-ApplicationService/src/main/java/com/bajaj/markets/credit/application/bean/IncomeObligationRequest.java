package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class IncomeObligationRequest {
	@NotNull(message = "obligationAmount can not be null/empty")
	private BigDecimal obligationAmount;

	@Pattern(regexp="^[a-zA-Z0-9\\s_-]+$", message = "source is invalid") 
	@NotBlank(message = "source can not be null/empty")
	private String source;
	
	@NotNull(message = "incomeValue can not be null/empty")
	private BigDecimal incomeValue;

	public BigDecimal getObligationAmount() {
		return obligationAmount;
	}

	public void setObligationAmount(BigDecimal obligationAmount) {
		this.obligationAmount = obligationAmount;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public BigDecimal getIncomeValue() {
		return incomeValue;
	}

	public void setIncomeValue(BigDecimal incomeValue) {
		this.incomeValue = incomeValue;
	}

	@Override
	public String toString() {
		return "IncomeObligationRequest [obligationAmount=" + obligationAmount + ", source=" + source + ", incomeValue="
				+ incomeValue + "]";
	}
	
	
}

