package com.bajaj.markets.credit.application.controller;

import javax.validation.Validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.BusinessDetailCtaBean;
import com.bajaj.markets.credit.application.bean.Occupation;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.BusinessDetailCtaService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class BusinessDetailCtaController {

	@Autowired
	BFLLoggerUtil logger;
	
	@Autowired
	BusinessDetailCtaService businessDetailCtaService;

	private static final String CLASSNAME = BusinessDetailCtaController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Create & update Occupation Detail", notes = "update Business Detail at application level", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Business details updated Successfully.", response = Occupation.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application Business detail not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/creditapplication/applications/{applicationId}/businessdetail", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateBusinessDetails(@PathVariable("applicationId") String applicationId,
			@RequestBody BusinessDetailCtaBean businessDetails, @RequestHeader HttpHeaders headers) {
		if (StringUtils.isNumeric(applicationId)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Inside updateBusinessDetails method controller - applicationId: " + applicationId);
			BusinessDetailCtaBean businessBean = businessDetailCtaService.updateIndustryDetails(applicationId,
					businessDetails);
			return new ResponseEntity<>(businessBean, HttpStatus.OK);
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
			throw new CreditApplicationServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean("OMCA_033", "ApplicationId should be number."));
		}
	}
}
