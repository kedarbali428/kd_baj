package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

public class AppAnalyticsScoreBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8259453316839639393L;
	private Integer cibilScore;
	private Integer monthlyObligation;
	private Integer currentBalance;

	public Integer getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(Integer cibilScore) {
		this.cibilScore = cibilScore;
	}

	public Integer getMonthlyObligation() {
		return monthlyObligation;
	}

	public void setMonthlyObligation(Integer monthlyObligation) {
		this.monthlyObligation = monthlyObligation;
	}

	public Integer getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(Integer currentBalance) {
		this.currentBalance = currentBalance;
	}

	@Override
	public String toString() {
		return "AppAnalyticsScoreBean [cibilScore=" + cibilScore + ", monthlyObligation=" + monthlyObligation
				+ ", currentBalance=" + currentBalance + "]";
	}

}
