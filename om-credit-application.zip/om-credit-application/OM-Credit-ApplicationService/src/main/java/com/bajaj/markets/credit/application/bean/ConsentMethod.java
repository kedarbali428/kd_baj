package com.bajaj.markets.credit.application.bean;

public class ConsentMethod {
	
	private String consentMechanism;

	public String getConsentMechanism() {
		return consentMechanism;
	}

	public void setConsentMechanism(String consentMechanism) {
		this.consentMechanism = consentMechanism;
	}

	@Override
	public String toString() {
		return "ConsentMethod [consentMechanism=" + consentMechanism + "]";
	}
	
	
	
	

}
