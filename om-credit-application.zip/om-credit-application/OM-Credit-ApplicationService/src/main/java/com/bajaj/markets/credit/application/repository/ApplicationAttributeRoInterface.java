package com.bajaj.markets.credit.application.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bajaj.markets.credit.application.model.Application;
import com.bajaj.markets.credit.application.model.ApplicationAttribute;

public interface ApplicationAttributeRoInterface extends ReadInterface<ApplicationAttribute, Long> {

	@Query("select a.application.applicationkey from ApplicationAttribute a where a.mobile=:mobile AND a.dob=:dob AND a.isactive=1 AND a.applicanttype=1")
	public Long findApplicationkeyByMobileAndDob(@Param("mobile") Long mobile, @Param("dob") Date dob);

	@Query("select a.application from ApplicationAttribute a where a.mobile=:mobile AND a.dob=:dob AND a.isactive=1 AND a.applicanttype=1")
	public List<Application> findApplicationByMobileAndDob(@Param("mobile") Long mobile, @Param("dob") Date dob);

	@Query("select a.appattrbkey from ApplicationAttribute a where a.mobile=:mobile AND a.dob=:dob AND a.isactive=1 AND a.applicanttype=1")
	public Long findAppattrbkeyByMobileAndDob(@Param("mobile") Long mobile, @Param("dob") Date dob);

	public List<ApplicationAttribute> findByApplication_ApplicationkeyAndIsactiveAndApplicanttype(Long applicationKey,
			Integer isactive, Long applicanttype);

	public List<ApplicationAttribute> findByApplication_ApplicationkeyAndIsactive(Long applicationKey,
			Integer isactive);

	public ApplicationAttribute findByApplication_ApplicationkeyAndApplicanttypeAndIsactive(Long applicationKey,
			Long applicanttype, Integer isactive);

	@Query("select a.appattrbkey from ApplicationAttribute a where a.application.applicationkey =:applicationId AND a.isactive=1 AND a.applicanttype=1")
	public Long findApplicationAttrkeyByApplId(@Param("applicationId") Long applicationId);

	@Query("select a.application.applicationkey from ApplicationAttribute a where a.appattrbkey=:userAttributeKey AND a.isactive=1")
	public Long findApplicationkeyByAppattrbkey(@Param("userAttributeKey") Long userAttributeKey);

	public List<ApplicationAttribute> findByMobileAndDobAndIsactiveAndApplicanttype(Long mobile, Date date,
			Integer isActive, Long applicanttype);

	public ApplicationAttribute findByAppattrbkeyAndIsactiveAndApplicanttype(Long appattrbKey, Integer isactive,
			Long applicanttype);

	@Query("select a from ApplicationAttribute a where a.application.applicationkey =:applicationId AND a.isactive=1 AND a.applicanttype=1")
	public ApplicationAttribute findByApplicationkeyAndIsactive(@Param("applicationId") Long applicationId);

	public Optional<ApplicationAttribute> findByAppattrbkeyAndApplication_ApplicationkeyAndIsactiveAndApplicanttype(
			Long applicationAttributeKey, Long applicationId, Integer isactive, Long applicanttype);

	public ApplicationAttribute findByApplication_ApplicationkeyAndApplicantkeyAndIsactiveAndApplicanttype(
			Long applicationKey, Long applicantkey, Integer isactive, Long applicanttype);

	public ApplicationAttribute findByApplication_ApplicationkeyAndMobileAndDobAndIsactiveAndApplicanttype(
			Long applicationKey, Long mobile, Date date, Integer isActive, Long applicanttype);

	@Query("select e from ApplicationAttribute e where e.application.applicationkey IN (select distinct(apl.parentapplicationkey) from Application apl JOIN ApplicationStage apstg "
			+ "ON apl.applicationkey = apstg.applicationkey where apstg.appstagecompletionper >=:percentage AND apl.prodcdl3 IN (select p.prodkey from Product p where "
			+ "p.principalkey =:principleKey AND p.isactive=1) AND apl.isactive=1 AND apstg.isactive=1 AND apl.appstatus NOT IN (:status) AND (apl.appdate BETWEEN :filterDate AND :currentDate) ) AND e.isactive=1 AND e.applicanttype=1")
	public List<ApplicationAttribute> findMobileforSchedulerforCards(@Param("percentage") Integer completionPercentage,
			@Param("principleKey") Long principleKey, @Param("currentDate") Date currentDate,
			@Param("filterDate") Date filterDate, @Param("status") List<Integer> intStatus);

	@Query("select e from ApplicationAttribute e where e.application.applicationkey IN (select distinct(apl.parentapplicationkey) from Application apl JOIN ApplicationStage apstg "
			+ "ON apl.applicationkey = apstg.applicationkey where apstg.appstagecompletionper >=:percentage AND apl.prodcdl3 IN (select p.prodkey from Product p where "
			+ "p.principalkey =:principleKey AND p.isactive=1) AND apl.isactive=1 AND apstg.isactive=1 AND apl.appstatus NOT IN (:status) AND (apl.appdate BETWEEN :filterDate AND :currentDate) ) AND e.isactive=1 AND e.applicanttype=1")
	public List<ApplicationAttribute> findApplicationsForLoansStatusApi(
			@Param("percentage") Integer completionPercentage, @Param("principleKey") Long principleKey,
			@Param("currentDate") Date currentDate, @Param("filterDate") Date filterDate,
			@Param("status") List<Integer> intStatus);

	public ApplicationAttribute findByAppattrbkeyAndIsactive(Long appattrbKey, Integer isactive);

	public Optional<ApplicationAttribute> findByAppattrbkeyAndApplicationApplicationkeyAndIsactive(Long appattrbKey,
			Long applicationKey, Integer isactive);

	public List<ApplicationAttribute> findByApplicantkeyAndMobileAndDob(Long applicantKey, Long mobile, Date dob);

	public List<ApplicationAttribute> findByApplicantkeyAndIsactiveAndApplicanttype(Long applicantKey, Integer isActive,
			long applicanttype);

}
