package com.bajaj.markets.credit.application.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.BidiMap;
import org.apache.commons.collections4.bidimap.DualHashBidiMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.application.model.InterfaceSystem;
import com.bajaj.markets.credit.application.model.RefSysCode;
import com.bajaj.markets.credit.application.repository.tx.InterfaceSystemRepo;
import com.bajaj.markets.credit.application.repository.tx.RefSysCodeRepo;
import com.bajaj.markets.interfacetransformation.lib.Direction;
import com.bajaj.markets.interfacetransformation.lib.FieldMetadata;
import com.bajaj.markets.interfacetransformation.lib.InterfaceDefinition;
import com.bajaj.markets.interfacetransformation.lib.InterfaceDefinitionImpl;
import com.bajaj.markets.interfacetransformation.lib.TransformData;
import com.bajaj.markets.interfacetransformation.lib.TranslationUnit;
import com.bajaj.markets.interfacetransformation.lib.TranslationUnitImpl;
import com.bajaj.markets.interfacetransformation.lib.errors.TransformationException;

@Component
public class InterfaceTransformationHelper {
	@Autowired
	private BFLLoggerUtil loggerWithoutCorrelId;
	
	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private InterfaceSystemRepo interfaceSystemRepo;
	@Autowired
	private RefSysCodeRepo refSysCodeRepo;

	private Map<Long, TranslationUnit> principalTranslationMap;
	
	public static final String CLASS_NAME = InterfaceTransformationHelper.class.getCanonicalName();

	@PostConstruct
	public void inIt() {
		principalTranslationMap = new HashMap<>();
		List<InterfaceSystem> interfaceList = interfaceSystemRepo.findAll();
		for (InterfaceSystem interfaceSystem : interfaceList) {
			TranslationUnit translationUnit = new TranslationUnitImpl();
			com.bajaj.markets.interfacetransformation.lib.InterfaceSystem interfaceSys = new com.bajaj.markets.interfacetransformation.lib.InterfaceSystem();
			interfaceSys.setPrincipalkey(interfaceSystem.getPrincipalkey());
			interfaceSys.setPrincipalName(interfaceSystem.getSystemcode());
			interfaceSys.setSystemkey(interfaceSystem.getSystemkey());
			InterfaceDefinition defination = new InterfaceDefinitionImpl(interfaceSys);
			Long principalKey = interfaceSystem.getPrincipalkey();
			try {
				defination.setTranslationFieldMetadataList(prepFieldMetaData(principalKey));
				translationUnit.setInterfaceDefination(defination);
			} catch (Exception e) {
				loggerWithoutCorrelId.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exception while field metadata prep. : " + e);
			}
			principalTranslationMap.put(principalKey, translationUnit);
		}

	}
	public Map<String, Object> transformInterfaceData(String systemCode, String fieldName, String fieldValue,
			Direction direction) {
		Map<String, Object> outMap = null;
		try {
			TransformData transformData = new TransformData();
			Map<String, FieldMetadata> transformationMetaData = popTransformationMetaData(systemCode, direction);
			outMap = transformData.transformInterfaceData(fieldName, fieldValue, transformationMetaData, direction);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, e.toString());
		}
		return outMap;
	}

	public Map<String, FieldMetadata> popTransformationMetaData(String systemCode, Direction direction)
			throws TransformationException {
		Map<String,FieldMetadata> transformationMap=new HashMap<>();
		InterfaceSystem interfaceSystem = fetchInterfaceSystemDetails(systemCode);
		List<RefSysCode> refSysCodeList = refSysCodeRepo.findBySystemkeyAndIsactive(interfaceSystem.getSystemkey(), 1);
		for (RefSysCode refSysCode : refSysCodeList) {
			FieldMetadata transFormData = null;
			if (Direction.OUT_BOUND.equals(direction)) {
				transFormData = transformationMap.get(refSysCode.getOmlable());
			} else if (Direction.IN_BOUND.equals(direction)) {
				transFormData = transformationMap.get(refSysCode.getPrinciplelable());
			}
			if (null != transFormData) {
				transFormData.getTransformationMap().put(refSysCode.getOmcode(), refSysCode.getPrinciplevalue());
			} else {
				FieldMetadata transformationMetaData = new FieldMetadata();
				if (null != refSysCode.getConversionfactor() && !refSysCode.getConversionfactor().equalsIgnoreCase("null")) {
				transformationMetaData.setConversionfactor(Double.valueOf(refSysCode.getConversionfactor()));
				}
				transformationMetaData.setOmLable(refSysCode.getOmlable());
				transformationMetaData.setOmDataType(refSysCode.getOmdatatype());
				transformationMetaData.addRule(refSysCode.getTranslationruletype());
				transformationMetaData.setPrincipalLabel(refSysCode.getPrinciplelable());
				transformationMetaData.setPrincipalDataType(refSysCode.getPrincipledatatype());
				BidiMap<String, String> transformMap = new DualHashBidiMap<>();
				transformMap.put(refSysCode.getOmcode(), refSysCode.getPrinciplevalue());
				transformationMetaData.setTransformationMap(transformMap);
				if(Direction.OUT_BOUND.equals(direction)) {
				transformationMap.put(refSysCode.getOmlable(), transformationMetaData);
				}else if(Direction.IN_BOUND.equals(direction)) {
					transformationMap.put(refSysCode.getPrinciplelable(), transformationMetaData);
				}
			}
		}
		return transformationMap;
	}
	public InterfaceSystem fetchInterfaceSystemDetails(String systemCode) {
		InterfaceSystem interfaceSystem = interfaceSystemRepo.findBySystemcodeAndIsactive(systemCode, 1);
		return interfaceSystem;
	}
	
	private List<FieldMetadata> prepFieldMetaData(Long principalkey) throws TransformationException {
		Map<String, FieldMetadata> transformationMap = new HashMap<>();
		InterfaceSystem interfaceSystem = interfaceSystemRepo.findByPrincipalkeyAndIsactive(principalkey,1);
		List<RefSysCode> refSysCodeList = refSysCodeRepo.findBySystemkeyAndIsactive(interfaceSystem.getSystemkey(), 1);
		for (RefSysCode refSysCode : refSysCodeList) {
			FieldMetadata transFormData = transformationMap.get(String.valueOf(refSysCode.getMappingid()));
			if (null != transFormData) {
				transFormData.getTransformationMap().put(refSysCode.getOmcode(), refSysCode.getPrinciplevalue());
			} else {
				FieldMetadata transformationMetaData = new FieldMetadata();
				if (null != refSysCode.getConversionfactor()) {
					transformationMetaData.setConversionfactor(Double.valueOf(refSysCode.getConversionfactor()));
				}
				transformationMetaData.setOmLable(refSysCode.getOmlable());
				transformationMetaData.setOmDataType(refSysCode.getOmdatatype());
				transformationMetaData.addRule(refSysCode.getTranslationruletype());
				transformationMetaData.setPrincipalLabel(refSysCode.getPrinciplelable());
				transformationMetaData.setPrincipalDataType(refSysCode.getPrincipledatatype());
				transformationMetaData.setOmFormat(refSysCode.getOmformat());
				transformationMetaData.setPrincipalFormat(refSysCode.getPrincipalformat());
				transformationMetaData.setOmSelectorType(refSysCode.getOmselectortype());
				transformationMetaData.setOmSelectorValue(refSysCode.getOmselectorvalue());
				BidiMap<String, String> transformMap = new DualHashBidiMap<>();
				transformMap.put(refSysCode.getOmcode(), refSysCode.getPrinciplevalue());
				transformationMetaData.setTransformationMap(transformMap);
				transformationMap.put(String.valueOf(refSysCode.getMappingid()), transformationMetaData);
			}
		}
		return transformationMap.values().stream().collect(Collectors.toList());
	}
}
