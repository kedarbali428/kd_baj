package com.bajaj.markets.credit.application.bean;

public class PricingConsentCaptureRequest {

	private String consentToken;
	private Boolean employeeCaptured;
	private String employeeUserKey;
	private String consentSource;
	private String consentModeValue;

	public String getConsentToken() {
		return consentToken;
	}

	public void setConsentToken(String consentToken) {
		this.consentToken = consentToken;
	}

	public Boolean getEmployeeCaptured() {
		return employeeCaptured;
	}

	public void setEmployeeCaptured(Boolean employeeCaptured) {
		this.employeeCaptured = employeeCaptured;
	}

	public String getEmployeeUserKey() {
		return employeeUserKey;
	}

	public void setEmployeeUserKey(String employeeUserKey) {
		this.employeeUserKey = employeeUserKey;
	}

	public String getConsentSource() {
		return consentSource;
	}

	public void setConsentSource(String consentSource) {
		this.consentSource = consentSource;
	}

	public String getConsentModeValue() {
		return consentModeValue;
	}

	public void setConsentModeValue(String consentModeValue) {
		this.consentModeValue = consentModeValue;
	}

	@Override
	public String toString() {
		return "PricingConsentCaptureRequest [consentToken=" + consentToken + ", employeeCaptured=" + employeeCaptured
				+ ", employeeUserKey=" + employeeUserKey + ", consentSource=" + consentSource + ", consentModeValue="
				+ consentModeValue + "]";
	}

}
