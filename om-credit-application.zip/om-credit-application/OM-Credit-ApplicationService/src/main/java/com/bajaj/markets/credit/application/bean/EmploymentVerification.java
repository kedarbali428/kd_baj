package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

public class EmploymentVerification implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@NotEmpty(message = "occupationType cannot be null or empty")
	private String occupationType;
	private String branch;
	private Long emplrScore;
	private Double nameConfidence;
	private Boolean settledFlag;
	private Boolean recentFlag;
	private Boolean uniqueFlag;
	private String officialEmailDomain;
	private String creditVidyaStatus;
	private Boolean nameExactFlag;
	private String karzaApproach;
	private String karzaId;
	private Long status;
	private String companyCatogery;
	private String companyType;
	private String karzaType;
	private KarzaExternalResponse karzaBreResponse;

	public String getOccupationType() {
		return occupationType;
	}

	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public Long getEmplrScore() {
		return emplrScore;
	}

	public void setEmplrScore(Long emplrScore) {
		this.emplrScore = emplrScore;
	}

	public Double getNameConfidence() {
		return nameConfidence;
	}

	public void setNameConfidence(Double nameConfidence) {
		this.nameConfidence = nameConfidence;
	}

	public Boolean getSettledFlag() {
		return settledFlag;
	}

	public void setSettledFlag(Boolean settledFlag) {
		this.settledFlag = settledFlag;
	}

	public Boolean getRecentFlag() {
		return recentFlag;
	}

	public void setRecentFlag(Boolean recentFlag) {
		this.recentFlag = recentFlag;
	}

	public Boolean getUniqueFlag() {
		return uniqueFlag;
	}

	public void setUniqueFlag(Boolean uniqueFlag) {
		this.uniqueFlag = uniqueFlag;
	}

	public String getOfficialEmailDomain() {
		return officialEmailDomain;
	}

	public void setOfficialEmailDomain(String officialEmailDomain) {
		this.officialEmailDomain = officialEmailDomain;
	}

	public String getCreditVidyaStatus() {
		return creditVidyaStatus;
	}

	public void setCreditVidyaStatus(String creditVidyaStatus) {
		this.creditVidyaStatus = creditVidyaStatus;
	}

	public Boolean getNameExactFlag() {
		return nameExactFlag;
	}

	public void setNameExactFlag(Boolean nameExactFlag) {
		this.nameExactFlag = nameExactFlag;
	}

	public String getKarzaApproach() {
		return karzaApproach;
	}

	public void setKarzaApproach(String karzaApproach) {
		this.karzaApproach = karzaApproach;
	}

	public String getKarzaId() {
		return karzaId;
	}

	public void setKarzaId(String karzaId) {
		this.karzaId = karzaId;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public String getCompanyCatogery() {
		return companyCatogery;
	}

	public void setCompanyCatogery(String companyCatogery) {
		this.companyCatogery = companyCatogery;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public KarzaExternalResponse getKarzaBreResponse() {
		return karzaBreResponse;
	}

	public void setKarzaBreResponse(KarzaExternalResponse karzaBreResponse) {
		this.karzaBreResponse = karzaBreResponse;
	}

	public String getKarzaType() {
		return karzaType;
	}

	public void setKarzaType(String karzaType) {
		this.karzaType = karzaType;
	}
	
	@Override
	public String toString() {
		return "EmploymentVerification [occupationType=" + occupationType + ", branch=" + branch + ", emplrScore=" + emplrScore + ", nameConfidence="
				+ nameConfidence + ", settledFlag=" + settledFlag + ", recentFlag=" + recentFlag + ", uniqueFlag=" + uniqueFlag + ", officialEmailDomain="
				+ officialEmailDomain + ", creditVidyaStatus=" + creditVidyaStatus + ", nameExactFlag=" + nameExactFlag + ", karzaApproach=" + karzaApproach
				+ ", karzaId=" + karzaId + ", status=" + status + ", companyCatogery=" + companyCatogery + ", companyType=" + companyType + ", karzaType="
				+ karzaType + ", karzaBreResponse=" + karzaBreResponse + "]";
	}
}
