package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

public class BtBankRequest {

	@NotBlank(message = "bankMasterKey Key cannot be null or empty")
	@Digits(fraction = 0, integer = 20)
	private String bankMasterKey;

	@NotBlank(message = "bankAccountCatagory Key cannot be null or empty")
	private String bankAccountCatCode;

	private String sourceName;

	public String getBankMasterKey() {
		return bankMasterKey;
	}

	public void setBankMasterKey(String bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}

	public String getBankAccountCatCode() {
		return bankAccountCatCode;
	}

	public void setBankAccountCatCode(String bankAccountCatCode) {
		this.bankAccountCatCode = bankAccountCatCode;
	}

	public String getSourceName() {
		return sourceName;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	@Override
	public String toString() {
		return "BtBankRequest [bankMasterKey=" + bankMasterKey + ", bankAccountCatCode=" + bankAccountCatCode + ", sourceName=" + sourceName + "]";
	}

}
