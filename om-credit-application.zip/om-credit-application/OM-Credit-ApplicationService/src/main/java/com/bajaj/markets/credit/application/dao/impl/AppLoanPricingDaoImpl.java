package com.bajaj.markets.credit.application.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.application.dao.AppLoanPricingDao;
import com.bajaj.markets.credit.application.helper.ApplicationConstants;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.AppLoanPricing;
import com.bajaj.markets.credit.application.model.AppLoanPricingFees;
import com.bajaj.markets.credit.application.model.AppProductListing;
import com.bajaj.markets.credit.application.model.Application;
import com.bajaj.markets.credit.application.model.ApplicationAttribute;
import com.bajaj.markets.credit.application.repository.tx.AppLoanPricingFeesRepository;
import com.bajaj.markets.credit.application.repository.tx.AppLoanPricingRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationAttributeRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationProductListingRepository;
import com.bajaj.markets.credit.application.repository.tx.ApplicationRepository;

@Component
public class AppLoanPricingDaoImpl implements AppLoanPricingDao {
	
	private static final String ERRORCODE_OMCA_201 = "OMCA_201";
	private static final String CLASS_NAME = AppLoanPricingDaoImpl.class.getCanonicalName();
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private AppLoanPricingRepository appLoanPricingRepository;
	
	@Autowired
	private AppLoanPricingFeesRepository appLoanPricingFeesRepository;
	
	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private ApplicationRepository applicationRepository;
	
	@Autowired
	private ApplicationProductListingRepository applicationProductListingRepository;
	
	@Autowired
	private ApplicationAttributeRepository applicationAttributeRepository;
	
	@Transactional
	@Override
	public AppLoanPricing updateAppLoanPricing(AppLoanPricing appLoanPricing) {
		if(null != appLoanPricing && null != appLoanPricing.getApplicationkey() && null != appLoanPricing.getAppprodlistkey()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Start - updateAppLoanPricing with: " + appLoanPricing.getApplicationkey());
			AppLoanPricing existingAppLoanPricing = appLoanPricingRepository.findByApplicationkeyAndIsactiveAndAppprodlistkey(
					appLoanPricing.getApplicationkey(), 1, appLoanPricing.getAppprodlistkey());
			if (null != existingAppLoanPricing) {
				appLoanPricing.setApploanpricingkey(existingAppLoanPricing.getApploanpricingkey());
			}
			appLoanPricing.setIsactive(1);
			appLoanPricing.setLstupdateby(customDefaultHeaders.getUserKey());
			appLoanPricing.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
			logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "End - updateAppLoanPricing successful ");
			return appLoanPricingRepository.save(appLoanPricing);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Invalid data for updating loan pricing,"
					+ " applicationkey and product listing key are mandatory: " + appLoanPricing);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(ERRORCODE_OMCA_201, env.getProperty(ERRORCODE_OMCA_201)));
		} 
	}
	
	@Transactional
	@Override
	public AppLoanPricing suspendChildAppEPLoanPricing(String parentapplicationKey, AppProductListing appProductListing) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Start - suspendChildAppEPLoanPricing with: " + parentapplicationKey);
		AppLoanPricing appLoanPricing = null;
		List<Application> childAppList = applicationRepository.findByParentapplicationkeyAndIsactiveAndInprocessflg(
				Long.valueOf(parentapplicationKey), 1, BigDecimal.ONE);
		Long childAppId = CollectionUtils.isEmpty(childAppList) ? null : childAppList.get(0).getApplicationkey();

		if (null != childAppId) {
			AppProductListing childAppProductListing = applicationProductListingRepository
					.findByApplicationkeyAndIsactiveAndProdkeyAndProdtypekey(childAppId, 1,
							appProductListing.getProdkey(), appProductListing.getProdtypekey());
			Long childAppProductListingKey = null != childAppProductListing ? childAppProductListing.getAppprodlistkey(): null;

			if (null != childAppProductListingKey) {
				AppLoanPricing epPricing = appLoanPricingRepository
						.findByApplicationkeyAndAppprodlistkeyAndSourceAndIsactive(childAppId,
								childAppProductListingKey, ApplicationConstants.EP, 1);
				if (null != epPricing) {
					ApplicationAttribute applicationAttribute = applicationAttributeRepository
							.findByApplicationkeyAndIsactive(childAppId);
					//Setting mobile number to identify, EP pricing is Rejected from BRE  
					epPricing.setLstupdateby(null != applicationAttribute ? applicationAttribute.getMobile() : null);
					epPricing.setStatus(ApplicationConstants.REJECTED);
					appLoanPricing = appLoanPricingRepository.save(epPricing);
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "END - suspendChildAppEPLoanPricing with: " + parentapplicationKey);
		return appLoanPricing;
	}

	@Transactional
	@Override
	public List<AppLoanPricingFees> updateAppLoanPricingFees(Long appLoanPricingKey, List<AppLoanPricingFees> appLoanPricingFees) {
		if(null != appLoanPricingKey && !appLoanPricingFees.isEmpty()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Start - updateAppLoanPricingFees with: " + appLoanPricingKey);
			List<AppLoanPricingFees> existingAppLoanPrincingFees = appLoanPricingFeesRepository
					.findByApploanpricingkeyAndIsactive(appLoanPricingKey, 1);
			if(null != existingAppLoanPrincingFees && !existingAppLoanPrincingFees.isEmpty()) {
				for (AppLoanPricingFees appLoanPricingFee : existingAppLoanPrincingFees) {
					appLoanPricingFee.setIsactive(0);
					appLoanPricingFee.setLstupdateby(customDefaultHeaders.getUserKey());
					appLoanPricingFee.setLstupdatedt(new Timestamp(Calendar.getInstance().getTime().getTime()));
				}
			} else {
				existingAppLoanPrincingFees = new ArrayList<>();
			}
			existingAppLoanPrincingFees.addAll(appLoanPricingFees);
			logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "End - updateAppLoanPricingFees successful ");
			return appLoanPricingFeesRepository.saveAll(existingAppLoanPrincingFees);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Invalid data for updating loan pricing fees,"
					+ " appLoanPricingKey is mandatory: " + appLoanPricingKey);
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(ERRORCODE_OMCA_201, env.getProperty(ERRORCODE_OMCA_201)));
		}
	}
}
