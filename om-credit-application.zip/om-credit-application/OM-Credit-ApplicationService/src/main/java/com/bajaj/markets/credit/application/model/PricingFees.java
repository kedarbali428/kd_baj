package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_loan_pricing_fees", schema = "dmcredit")
public class PricingFees implements Serializable,Cloneable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="app_loan_pricing_fees_generator", sequenceName="dmcredit.seq_pk_app_loan_pricing_fees",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_loan_pricing_fees_generator")
	
	@Column(name="apploanpricingfeeskey")
	private Long feesKey;
	
    private Long appLoanPricingKey;
    
    private BigDecimal feesInPercent;
    
    private BigDecimal feesInAmount;
    
    private String feeCode;
    
    private Integer isactive;

	public Long getFeesKey() {
		return feesKey;
	}

	public void setFeesKey(Long feesKey) {
		this.feesKey = feesKey;
	}

	public Long getAppLoanPricingKey() {
		return appLoanPricingKey;
	}

	public void setAppLoanPricingKey(Long appLoanPricingKey) {
		this.appLoanPricingKey = appLoanPricingKey;
	}

	public BigDecimal getFeesInPercent() {
		return feesInPercent;
	}

	public void setFeesInPercent(BigDecimal feesInPercent) {
		this.feesInPercent = feesInPercent;
	}

	public BigDecimal getFeesInAmount() {
		return feesInAmount;
	}

	public void setFeesInAmount(BigDecimal feesInAmount) {
		this.feesInAmount = feesInAmount;
	}

	public String getFeeCode() {
		return feeCode;
	}

	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
    
}