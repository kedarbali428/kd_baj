package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the disposition_code database table.
 * 
 */
@Entity
@Table(name="disposition_code",schema = "dmcredit")
public class DispositionCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long dispostionkey;

	private Integer dispositioncategory;
	
	private String dispositioncode;
	
	private String dispositiondesc;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;


	public DispositionCode() {
	}


	/**
	 * @return the dispostionkey
	 */
	public Long getDispostionkey() {
		return dispostionkey;
	}


	/**
	 * @param dispostionkey the dispostionkey to set
	 */
	public void setDispostionkey(Long dispostionkey) {
		this.dispostionkey = dispostionkey;
	}


	/**
	 * @return the dispositioncategory
	 */
	public Integer getDispositioncategory() {
		return dispositioncategory;
	}


	/**
	 * @param dispositioncategory the dispositioncategory to set
	 */
	public void setDispositioncategory(Integer dispositioncategory) {
		this.dispositioncategory = dispositioncategory;
	}


	/**
	 * @return the dispositioncode
	 */
	public String getDispositioncode() {
		return dispositioncode;
	}


	/**
	 * @param dispositioncode the dispositioncode to set
	 */
	public void setDispositioncode(String dispositioncode) {
		this.dispositioncode = dispositioncode;
	}


	/**
	 * @return the dispositiondesc
	 */
	public String getDispositiondesc() {
		return dispositiondesc;
	}


	/**
	 * @param dispositiondesc the dispositiondesc to set
	 */
	public void setDispositiondesc(String dispositiondesc) {
		this.dispositiondesc = dispositiondesc;
	}


	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}


	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}


	/**
	 * @return the lstupdateby
	 */
	public Long getLstupdateby() {
		return lstupdateby;
	}


	/**
	 * @param lstupdateby the lstupdateby to set
	 */
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}


	/**
	 * @return the lstupdatedt
	 */
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}


	/**
	 * @param lstupdatedt the lstupdatedt to set
	 */
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	}