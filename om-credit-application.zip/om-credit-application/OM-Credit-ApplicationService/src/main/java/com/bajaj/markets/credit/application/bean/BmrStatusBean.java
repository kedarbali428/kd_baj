package com.bajaj.markets.credit.application.bean;

public class BmrStatusBean {

	private boolean bmrStatus;

	public boolean isBmrStatus() {
		return bmrStatus;
	}

	public void setBmrStatus(boolean bmrStatus) {
		this.bmrStatus = bmrStatus;
	}
	
}
