package com.bajaj.markets.credit.application.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.BeneficiaryBean;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.DisbursementPrecheckService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class DisbursementPrecheckController
{
	@Autowired
	private DisbursementPrecheckService disbursementPrecheckService;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = DisbursementPrecheckController.class.getName();
	
	@Secured(value = {Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER,Role.INTERNAL})
	@ApiOperation(value = "Get Disbursement prechecks", notes = "Get Disbursement prechecks", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching DisbursementPrecheck Successfully."),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/creditapplication/applications/{applicationId}/disbursement/preChecks", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getDisbursementPrecheck(@PathVariable("applicationId") String applicationId){
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "START: getDisbursementPrecheck method");
		disbursementPrecheckService.prcheckValidation(applicationId);
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "END: getDisbursementPrecheck method ");
		return new ResponseEntity<>(true, HttpStatus.OK);
		
	}
	@Secured(value = {Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER,Role.INTERNAL})
	@ApiOperation(value = "Get Disbursement prechecks", notes = "Get Disbursement prechecks", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching DisbursementPrecheck Successfully."),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@GetMapping(value = "/v1/creditapplication/applications/{applicationId}/beneficiarydetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getCreateBeneficiaryDetails(@PathVariable("applicationId") String applicationId){
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "START: getDisbursementPrecheck method");
		BeneficiaryBean result = disbursementPrecheckService.getBeneficiaryDetails(applicationId);
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "END: getDisbursementPrecheck method ");
		return new ResponseEntity<>(result, HttpStatus.OK);
		
	}
	
}