package com.bajaj.markets.credit.application.bean;

public class CheckCaseStatusRes {
	private String c1id;
	private String caseReferenceId;
	private Boolean isCaseProcessed;
	private Boolean isCardApproved;
	private String statusCode;
	private String message;
	private String status;
	private String cardLimit;
	private String custName;

	public String getC1id() {
		return c1id;
	}

	public void setC1id(String c1id) {
		this.c1id = c1id;
	}

	public String getCaseReferenceId() {
		return caseReferenceId;
	}

	public void setCaseReferenceId(String caseReferenceId) {
		this.caseReferenceId = caseReferenceId;
	}

	public Boolean getIsCaseProcessed() {
		return isCaseProcessed;
	}

	public void setIsCaseProcessed(Boolean isCaseProcessed) {
		this.isCaseProcessed = isCaseProcessed;
	}

	public Boolean getIsCardApproved() {
		return isCardApproved;
	}

	public void setIsCardApproved(Boolean isCardApproved) {
		this.isCardApproved = isCardApproved;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCardLimit() {
		return cardLimit;
	}

	public void setCardLimit(String cardLimit) {
		this.cardLimit = cardLimit;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	@Override
	public String toString() {
		return "CheckCaseStatusRes [c1id=" + c1id + ", caseReferenceId=" + caseReferenceId + ", isCaseProcessed="
				+ isCaseProcessed + ", isCardApproved=" + isCardApproved + ", statusCode=" + statusCode + ", message="
				+ message + ", status=" + status + ", cardLimit=" + cardLimit + ", custName=" + custName + "]";
	}


}
