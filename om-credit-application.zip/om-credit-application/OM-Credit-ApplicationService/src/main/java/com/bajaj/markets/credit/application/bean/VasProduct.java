package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class VasProduct {
	private String productCode;
	private String productName;
	private String productUserFriendlyName;
	private String productType;
	private List<VasProductRider> riders;

	public String getProductCode() {
		return productCode;
	}

	public String getProductName() {
		return productName;
	}

	public String getProductUserFriendlyName() {
		return productUserFriendlyName;
	}

	public String getProductType() {
		return productType;
	}

	public List<VasProductRider> getRiders() {
		return riders;
	}
}
