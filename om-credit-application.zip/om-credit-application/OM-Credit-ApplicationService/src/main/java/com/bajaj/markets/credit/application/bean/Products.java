package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class Products {

	private List<Product> productList;

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

	@Override
	public String toString() {
		return "Products [productList=" + productList + "]";
	}


}