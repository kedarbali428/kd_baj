package com.bajaj.markets.credit.application.bean;

import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MasterDataBean {
	private String id; //Changed to String for Product offering, applicable across all product - Upwan
	private String displayName;
	@JsonInclude(Include.NON_NULL)
	private String code;
	@Transient
	private Integer dispositioncategory;
	@JsonIgnore
	@JsonProperty(value = "dispositioncategory")	
	public Integer getDispositioncategory() {
		return dispositioncategory;
	}
	public void setDispositioncategory(Integer dispositioncategory) {
		this.dispositioncategory = dispositioncategory;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	

}
