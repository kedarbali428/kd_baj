package com.bajaj.markets.credit.application.bean;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 
 * 
 *
 */
public class Email{

	@NotNull(message = "typeKey can not be null")
	private Long typeKey;
	
	@NotBlank(message = "email can not be null")
	private String email;
	
	private Verification verification;

	private List<Verification> verifications;

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	

	/**
	 * @return the verification
	 */
	public Verification getVerification() {
		return verification;
	}

	/**
	 * @param verification the verification to set
	 */
	public void setVerification(Verification verification) {
		this.verification = verification;
	}

	/**
	 * @return the typeKey
	 */
	public Long getTypeKey() {
		return typeKey;
	}

	/**
	 * @param typeKey the typeKey to set
	 */
	public void setTypeKey(Long typeKey) {
		this.typeKey = typeKey;
	}
	
	public List<Verification> getVerifications() {
		return verifications;
	}

	public void setVerifications(List<Verification> verifications) {
		this.verifications = verifications;
	}

}
