package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "app_relationship_detail", schema = "dmcredit")
public class AppRelationshipDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long apprelationshipdetkey;
	private Long appattrbkey;
	private Long relationcodemasterkey;
	private Long salutationkey;
	private String name;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	public Long getApprelationshipdetkey() {
		return apprelationshipdetkey;
	}

	public void setApprelationshipdetkey(Long apprelationshipdetkey) {
		this.apprelationshipdetkey = apprelationshipdetkey;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Long getRelationcodemasterkey() {
		return relationcodemasterkey;
	}

	public void setRelationcodemasterkey(Long relationcodemasterkey) {
		this.relationcodemasterkey = relationcodemasterkey;
	}

	public Long getSalutationkey() {
		return salutationkey;
	}

	public void setSalutationkey(Long salutationkey) {
		this.salutationkey = salutationkey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}
