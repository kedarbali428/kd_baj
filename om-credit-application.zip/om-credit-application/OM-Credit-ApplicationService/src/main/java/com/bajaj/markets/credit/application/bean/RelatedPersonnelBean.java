package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class RelatedPersonnelBean {

	@NotBlank
	private String fullName;
	@NotBlank
	@Size(min = 10, max = 10, message 
		      = "Mobile number  can not be less than 10 or greater than 10")
	@Digits(fraction = 0, integer = 10, message = "Mobile number can not be other than digits")
	private String mobileNumber;
	private Reference relationship;
	private String addressLine1;
	private String addressLine2;
	private Long pincodeKey;
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Reference getRelationship() {
		return relationship;
	}
	public void setRelationship(Reference relationship) {
		this.relationship = relationship;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public Long getPincodeKey() {
		return pincodeKey;
	}
	public void setPincodeKey(Long pincodeKey) {
		this.pincodeKey = pincodeKey;
	}
	@Override
	public String toString() {
		return "RelatedPersonnelBean [fullName=" + fullName + ", mobileNumber=" + mobileNumber + ", relationship="
				+ relationship + ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + ", pincodeKey="
				+ pincodeKey + "]";
	}
	
}