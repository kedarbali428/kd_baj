package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class Product {

	private String description;
	private BigDecimal annualFee;
	private String feature;
	private String rewardPoint;
	private String promotionalOffer;
	private String approvalChances;
	private String cardTag;
	private BigDecimal isEligible;
	private Integer priorityOrder;
	private String productCode;
	// added for Len-632 changes
	private String isSmallTicket;
	private Long productListingKey;
	private String l3productCode;
	private String roi;
	private String emi;
	private List<FeesList> feesList;
	private String preApproved;
	private String productSize;
	private Float bScore;
	private Long l4ProductKey;
	private String l4ProductCode;
	private String principalSelectedByCustomer;
	private String loanTypeName;
	// private String promotionalOffer;
	private String perfiosRequiredFlag;
	private Integer statementToBeCollected;
	private String ctaName;
	private Boolean fppApplicable;

	private Boolean cvRequired;

	private String riskoffertype;

	private String isSelected;

	private Integer emailverificationrequiredflag;

	private Integer requiredLoanAmount;
	private Integer tenor;
	private Boolean toBeDisplayedOnListingPage;
	private Long eligibilityAmount;
	private Long principalKey;
	private String honouredPricingSource;
	private Boolean segmentReRunFlag;
	
	public Boolean getSegmentReRunFlag() {
		return segmentReRunFlag;
	}

	public void setSegmentReRunFlag(Boolean segmentReRunFlag) {
		this.segmentReRunFlag = segmentReRunFlag;
	}

	public String getHonouredPricingSource() {
		return honouredPricingSource;
	}

	public void setHonouredPricingSource(String honouredPricingSource) {
		this.honouredPricingSource = honouredPricingSource;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getAnnualFee() {
		return annualFee;
	}

	public void setAnnualFee(BigDecimal annualFee) {
		this.annualFee = annualFee;
	}

	public String getFeature() {
		return feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	public String getRewardPoint() {
		return rewardPoint;
	}

	public void setRewardPoint(String rewardPoint) {
		this.rewardPoint = rewardPoint;
	}

	public String getPromotionalOffer() {
		return promotionalOffer;
	}

	public void setPromotionalOffer(String promotionalOffer) {
		this.promotionalOffer = promotionalOffer;
	}

	public String getApprovalChances() {
		return approvalChances;
	}

	public void setApprovalChances(String approvalChances) {
		this.approvalChances = approvalChances;
	}

	public String getCardTag() {
		return cardTag;
	}

	public void setCardTag(String cardTag) {
		this.cardTag = cardTag;
	}

	public BigDecimal getIsEligible() {
		return isEligible;
	}

	public void setIsEligible(BigDecimal isEligible) {
		this.isEligible = isEligible;
	}

	public Integer getPriorityOrder() {
		return priorityOrder;
	}

	public void setPriorityOrder(Integer priorityOrder) {
		this.priorityOrder = priorityOrder;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getIsSmallTicket() {
		return isSmallTicket;
	}

	public void setIsSmallTicket(String isSmallTicket) {
		this.isSmallTicket = isSmallTicket;
	}

	public Long getProductListingKey() {
		return productListingKey;
	}

	public void setProductListingKey(Long productListingKey) {
		this.productListingKey = productListingKey;
	}

	public String getL3productCode() {
		return l3productCode;
	}

	public void setL3productCode(String l3productCode) {
		this.l3productCode = l3productCode;
	}

	public String getRoi() {
		return roi;
	}

	public void setRoi(String roi) {
		this.roi = roi;
	}

	public String getEmi() {
		return emi;
	}

	public void setEmi(String emi) {
		this.emi = emi;
	}

	public List<FeesList> getFeesList() {
		return feesList;
	}

	public void setFeesList(List<FeesList> feesList) {
		this.feesList = feesList;
	}

	public String getPreApproved() {
		return preApproved;
	}

	public void setPreApproved(String preApproved) {
		this.preApproved = preApproved;
	}

	public String getProductSize() {
		return productSize;
	}

	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}

	public Float getbScore() {
		return bScore;
	}

	public void setbScore(Float bScore) {
		this.bScore = bScore;
	}

	public Long getL4ProductKey() {
		return l4ProductKey;
	}

	public void setL4ProductKey(Long l4ProductKey) {
		this.l4ProductKey = l4ProductKey;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public String getPrincipalSelectedByCustomer() {
		return principalSelectedByCustomer;
	}

	public void setPrincipalSelectedByCustomer(String principalSelectedByCustomer) {
		this.principalSelectedByCustomer = principalSelectedByCustomer;
	}

	public String getLoanTypeName() {
		return loanTypeName;
	}

	public void setLoanTypeName(String loanTypeName) {
		this.loanTypeName = loanTypeName;
	}

	public String getPerfiosRequiredFlag() {
		return perfiosRequiredFlag;
	}

	public void setPerfiosRequiredFlag(String perfiosRequiredFlag) {
		this.perfiosRequiredFlag = perfiosRequiredFlag;
	}

	public Integer getStatementToBeCollected() {
		return statementToBeCollected;
	}

	public void setStatementToBeCollected(Integer statementToBeCollected) {
		this.statementToBeCollected = statementToBeCollected;
	}

	public String getCtaName() {
		return ctaName;
	}

	public void setCtaName(String ctaName) {
		this.ctaName = ctaName;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	public Boolean getCvRequired() {
		return cvRequired;
	}

	public void setCvRequired(Boolean cvRequired) {
		this.cvRequired = cvRequired;
	}

	public Boolean getFppApplicable() {
		return fppApplicable;
	}

	public void setFppApplicable(Boolean fppApplicable) {
		this.fppApplicable = fppApplicable;
	}

	public String getIsSelected() {
		return isSelected;
	}

	public void setIsSelected(String isSelected) {
		this.isSelected = isSelected;
	}

	public Integer getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(Integer requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public Integer getTenor() {
		return tenor;
	}

	public void setTenor(Integer tenor) {
		this.tenor = tenor;
	}

	public Boolean getToBeDisplayedOnListingPage() {
		return toBeDisplayedOnListingPage;
	}

	public void setToBeDisplayedOnListingPage(Boolean toBeDisplayedOnListingPage) {
		this.toBeDisplayedOnListingPage = toBeDisplayedOnListingPage;
	}

	public Integer getEmailverificationrequiredflag() {
		return emailverificationrequiredflag;
	}

	public void setEmailverificationrequiredflag(Integer emailverificationrequiredflag) {
		this.emailverificationrequiredflag = emailverificationrequiredflag;
	}

	public Long getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(Long eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	@Override
	public String toString() {
		return "Product [description=" + description + ", annualFee=" + annualFee + ", feature=" + feature
				+ ", rewardPoint=" + rewardPoint + ", promotionalOffer=" + promotionalOffer + ", approvalChances="
				+ approvalChances + ", cardTag=" + cardTag + ", isEligible=" + isEligible + ", priorityOrder="
				+ priorityOrder + ", productCode=" + productCode + ", isSmallTicket=" + isSmallTicket
				+ ", productListingKey=" + productListingKey + ", l3productCode=" + l3productCode + ", roi=" + roi
				+ ", emi=" + emi + ", feesList=" + feesList + ", preApproved=" + preApproved + ", productSize="
				+ productSize + ", bScore=" + bScore + ", l4ProductKey=" + l4ProductKey + ", l4ProductCode="
				+ l4ProductCode + ", principalSelectedByCustomer=" + principalSelectedByCustomer + ", loanTypeName="
				+ loanTypeName + ", perfiosRequiredFlag=" + perfiosRequiredFlag + ", statementToBeCollected="
				+ statementToBeCollected + ", ctaName=" + ctaName + ", fppApplicable=" + fppApplicable + ", cvRequired="
				+ cvRequired + ", riskoffertype=" + riskoffertype + ", isSelected=" + isSelected
				+ ", emailverificationrequiredflag=" + emailverificationrequiredflag + ", requiredLoanAmount="
				+ requiredLoanAmount + ", tenor=" + tenor + ", toBeDisplayedOnListingPage=" + toBeDisplayedOnListingPage
				+ ", eligibilityAmount=" + eligibilityAmount + ", principalKey=" + principalKey
				+ ", honouredPricingSource=" + honouredPricingSource + "]";
	}
}