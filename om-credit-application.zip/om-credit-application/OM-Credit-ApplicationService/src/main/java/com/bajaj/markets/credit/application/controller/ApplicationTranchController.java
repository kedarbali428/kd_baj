package com.bajaj.markets.credit.application.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.TranchBean;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.service.ApplicationTranchService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationTranchController {
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	ApplicationTranchService applicationTranchCtaService;
	
	private static final String CLASSNAME = ApplicationTranchController.class.getName();
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "Applications tranch details endpoint", notes = "Save user tranch details", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Tranch details added successfully.", response = TranchBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/creditapplication/applications/{applicationKey}/tranches", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> saveTrancheDetails(@Valid @RequestBody TranchBean inputBean,@PathVariable("applicationKey") String applicationId,
			 @RequestHeader HttpHeaders headers) {
		TranchBean result = applicationTranchCtaService.saveTrancheDetails(inputBean,applicationId,headers);
		return new ResponseEntity<>(result, HttpStatus.CREATED);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER,Role.EMPLOYEE,Role.INTERNAL})
	@ApiOperation(value = "Applications tranch details endpoint", notes = "Update user tranch details", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Tranch details updated successfully.", response = TranchBean.class),
			@ApiResponse(code = 200, message = "Tranch details updated sucessfully", response = TranchBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value ="/v1/creditapplication/applications/{applicationKey}/tranches/{tranchKey}", consumes = MediaType.APPLICATION_JSON_VALUE, 
									produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<?> updateTranchDetails(@Valid @RequestBody TranchBean tranchCta,
			@PathVariable(name = "applicationKey")  String applicationId, 
					    @PathVariable("tranchKey") String tranchKey, @RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside ApplicationBankDetailsController :: updateBankDetails method started - applicationKey :" + applicationId);
		TranchBean response = applicationTranchCtaService.updateTranchDetails(tranchCta, applicationId, tranchKey, headers);;
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Completed ApplicationTranchCtaController :: updateTranchDetails method");
		return new ResponseEntity<>(response, HttpStatus.OK);
		
	}
	
}
