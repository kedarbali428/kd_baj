package com.bajaj.markets.credit.application.bean;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.CreateUserProfileAttribute;

public class UserProfile {

	private String applicationKey;

	private String applicationUserAttributeKey;

	@Valid
	@NotNull(groups = CreateUserProfileAttribute.class, message = "applicationUserAttributeType cannot be null or empty")
	private String applicationUserAttributeType;

	private String mobile;

	private String dateOfBirth;

	private Name name;

	@Digits(fraction = 0, integer = 5, message = "maritalStatusKey cannot be in fraction & should not exceed size")
	private Long maritalStatusKey;

	@Digits(fraction = 0, integer = 5, message = "genderKey cannot be in fraction & should not exceed size")
	private Long genderKey;

	private Long residenceTypeKey;

	private String qualification;

	private String motherName;

	private String fatherName;

	//Adding Additional parameter as part of JIRAID Len-535
	private String panNumber;

	private Long coapplicantObligation;

	private Long applicantKey;

	private Boolean workEmailRequired;

	private String nameToBePrintedOnCard;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getApplicationUserAttributeKey() {
		return applicationUserAttributeKey;
	}

	public void setApplicationUserAttributeKey(String applicationUserAttributeKey) {
		this.applicationUserAttributeKey = applicationUserAttributeKey;
	}

	public String getApplicationUserAttributeType() {
		return applicationUserAttributeType;
	}

	public void setApplicationUserAttributeType(String applicationUserAttributeType) {
		this.applicationUserAttributeType = applicationUserAttributeType;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public Long getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(Long maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}

	public Long getGenderKey() {
		return genderKey;
	}

	public void setGenderKey(Long genderKey) {
		this.genderKey = genderKey;
	}

	public Long getResidenceTypeKey() {
		return residenceTypeKey;
	}

	public void setResidenceTypeKey(Long residenceTypeKey) {
		this.residenceTypeKey = residenceTypeKey;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public Long getCoapplicantObligation() {
		return coapplicantObligation;
	}

	public void setCoapplicantObligation(Long coapplicantObligation) {
		this.coapplicantObligation = coapplicantObligation;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public void setWorkEmailRequired(Boolean workEmailRequired) {
		this.workEmailRequired = workEmailRequired;
	}

	public Boolean getWorkEmailRequired() {
		return workEmailRequired;
	}

	public String getNameToBePrintedOnCard() {
		return nameToBePrintedOnCard;
	}

	public void setNameToBePrintedOnCard(String nameToBePrintedOnCard) {
		this.nameToBePrintedOnCard = nameToBePrintedOnCard;
	}

	@Override
	public String toString() {
		return "UserProfile [applicationKey=" + applicationKey + ", applicationUserAttributeKey="
				+ applicationUserAttributeKey + ", applicationUserAttributeType=" + applicationUserAttributeType
				+ ", mobile=" + mobile + ", dateOfBirth=" + dateOfBirth + ", name=" + name + ", maritalStatusKey="
				+ maritalStatusKey + ", genderKey=" + genderKey + ", residenceTypeKey=" + residenceTypeKey
				+ ", qualification=" + qualification + ", motherName=" + motherName + ", fatherName=" + fatherName
				+ ", panNumber=" + panNumber + ", coapplicantObligation=" + coapplicantObligation + ", applicantKey="
				+ applicantKey + ", workEmailRequired=" + workEmailRequired + ", nameToBePrintedOnCard="
				+ nameToBePrintedOnCard + "]";
	}

}
