package com.bajaj.markets.credit.application.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CityResponseBean {

	private String pincodeKey;
	private String citycategory;
	private String citycode;
	private String cityname;

	public String getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(String pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public String getCitycategory() {
		return citycategory;
	}

	public void setCitycategory(String citycategory) {
		this.citycategory = citycategory;
	}

	public String getCitycode() {
		return citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

}