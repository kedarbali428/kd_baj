package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class ProcessPrincipalCardRequest {
	private String otp;
	private PrincipalApplicationAttribute applicationAttribute;
	private PrincipalOccupationDetail appOccupationDetail;
	private List<PrincipalAppAddress> applicationAddress;
	private PrincipalLoanDetails apploanDetails;
	private String creditCardProductType;
	private String emailAddress;
	private String officialEmailAddress;
	private BigDecimal customerPreferredSalary;
	private Long prodKey;
	private String cardLimit;
	private String isCreditCardHolder;
	private PrincipalPropertyDetails principalPropertyDetails;
	private List<PrincipalBankLeadPushRequest> principalBankLeadPushRequest;
	private List<ApplicationUtmParam> appUtmList;
	private AppAnalyticsScoreBean analyiticScores;
	private PrinicipalEligibilityBean  prinicipalEligibilityBean;
	private List<AppGurantorDetailBean> appGurantorDetails;
	private String principleCustSegment;
	private String alternateMobileNumber;
	private List<ApplicationRelationShipDetails> applicationRelationShipDetails;

	public PrincipalApplicationAttribute getApplicationAttribute() {
		return applicationAttribute;
	}

	public void setApplicationAttribute(PrincipalApplicationAttribute applicationAttribute) {
		this.applicationAttribute = applicationAttribute;
	}

	public PrincipalOccupationDetail getAppOccupationDetail() {
		return appOccupationDetail;
	}

	public void setAppOccupationDetail(PrincipalOccupationDetail appOccupationDetail) {
		this.appOccupationDetail = appOccupationDetail;
	}

	public List<PrincipalAppAddress> getApplicationAddress() {
		return applicationAddress;
	}

	public void setApplicationAddress(List<PrincipalAppAddress> applicationAddress) {
		this.applicationAddress = applicationAddress;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getCreditCardProductType() {
		return creditCardProductType;
	}

	public void setCreditCardProductType(String creditCardProductType) {
		this.creditCardProductType = creditCardProductType;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Long getProdKey() {
		return prodKey;
	}

	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}

	public String getCardLimit() {
		return cardLimit;
	}

	public void setCardLimit(String cardLimit) {
		this.cardLimit = cardLimit;
	}

	public String getIsCreditCardHolder() {
		return isCreditCardHolder;
	}

	public void setIsCreditCardHolder(String isCreditCardHolder) {
		this.isCreditCardHolder = isCreditCardHolder;
	}

	public PrincipalLoanDetails getApploanDetails() {
		return apploanDetails;
	}

	public void setApploanDetails(PrincipalLoanDetails apploanDetails) {
		this.apploanDetails = apploanDetails;
	}

	public String getOfficialEmailAddress() {
		return officialEmailAddress;
	}

	public void setOfficialEmailAddress(String officialEmailAddress) {
		this.officialEmailAddress = officialEmailAddress;
	}

	public BigDecimal getCustomerPreferredSalary() {
		return customerPreferredSalary;
	}

	public void setCustomerPreferredSalary(BigDecimal customerPreferredSalary) {
		this.customerPreferredSalary = customerPreferredSalary;
	}

	public PrincipalPropertyDetails getPrincipalPropertyDetails() {
		return principalPropertyDetails;
	}

	public void setPrincipalPropertyDetails(PrincipalPropertyDetails principalPropertyDetails) {
		this.principalPropertyDetails = principalPropertyDetails;
	}

	public List<PrincipalBankLeadPushRequest> getPrincipalBankLeadPushRequest() {
		return principalBankLeadPushRequest;
	}

	public void setPrincipalBankLeadPushRequest(List<PrincipalBankLeadPushRequest> principalBankLeadPushRequest) {
		this.principalBankLeadPushRequest = principalBankLeadPushRequest;
	}

	public List<ApplicationUtmParam> getAppUtmList() {
		return appUtmList;
	}

	public void setAppUtmList(List<ApplicationUtmParam> appUtmList) {
		this.appUtmList = appUtmList;
	}

	public AppAnalyticsScoreBean getAnalyiticScores() {
		return analyiticScores;
	}

	public void setAnalyiticScores(AppAnalyticsScoreBean analyiticScores) {
		this.analyiticScores = analyiticScores;
	}
	

	public PrinicipalEligibilityBean getPrinicipalEligibilityBean() {
		return prinicipalEligibilityBean;
	}

	public void setPrinicipalEligibilityBean(PrinicipalEligibilityBean prinicipalEligibilityBean) {
		this.prinicipalEligibilityBean = prinicipalEligibilityBean;
	}

	public String getPrincipleCustSegment() {
		return principleCustSegment;
	}

	public void setPrincipleCustSegment(String principleCustSegment) {
		this.principleCustSegment = principleCustSegment;
	}

	public List<AppGurantorDetailBean> getAppGurantorDetails() {
		return appGurantorDetails;
	}

	public void setAppGurantorDetails(List<AppGurantorDetailBean> appGurantorDetails) {
		this.appGurantorDetails = appGurantorDetails;
	}
	
	public String getAlternateMobileNumber() {
		return alternateMobileNumber;
	}

	public void setAlternateMobileNumber(String alternateMobileNumber) {
		this.alternateMobileNumber = alternateMobileNumber;
	}

	public List<ApplicationRelationShipDetails> getApplicationRelationShipDetails() {
		return applicationRelationShipDetails;
	}

	public void setApplicationRelationShipDetails(List<ApplicationRelationShipDetails> applicationRelationShipDetails) {
		this.applicationRelationShipDetails = applicationRelationShipDetails;
	}

	@Override
	public String toString() {
		return "ProcessPrincipalCardRequest [otp=" + otp + ", applicationAttribute=" + applicationAttribute
				+ ", appOccupationDetail=" + appOccupationDetail + ", applicationAddress=" + applicationAddress
				+ ", apploanDetails=" + apploanDetails + ", creditCardProductType=" + creditCardProductType
				+ ", emailAddress=" + emailAddress + ", officialEmailAddress=" + officialEmailAddress
				+ ", customerPreferredSalary=" + customerPreferredSalary + ", prodKey=" + prodKey + ", cardLimit="
				+ cardLimit + ", isCreditCardHolder=" + isCreditCardHolder + ", principalPropertyDetails="
				+ principalPropertyDetails + ", principalBankLeadPushRequest=" + principalBankLeadPushRequest
				+ ", appUtmList=" + appUtmList + ", analyiticScores=" + analyiticScores + ", prinicipalEligibilityBean="
				+ prinicipalEligibilityBean + ", appGurantorDetails=" + appGurantorDetails + ", principleCustSegment="
				+ principleCustSegment + ", alternateMobileNumber=" + alternateMobileNumber
				+ ", applicationRelationShipDetails=" + applicationRelationShipDetails + "]";
	}
	
}
