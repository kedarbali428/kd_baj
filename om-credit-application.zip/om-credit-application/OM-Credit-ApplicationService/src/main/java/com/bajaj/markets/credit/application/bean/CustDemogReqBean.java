package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.NotBlank;

public class CustDemogReqBean {
	@NotBlank(message = "otp cannot be null or empty")
	private String otp;

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}
}
