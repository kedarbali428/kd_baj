package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.DispositionCode;

public interface DispositionCodeRoInterface extends ReadInterface<DispositionCode, Long> {

	List<DispositionCode> findByIsactive(Integer isactive);

	DispositionCode findByDispostionkeyAndIsactive(Long dispostionkey, Integer isactive);

	DispositionCode findByDispositioncodeAndDispositioncategory(String dispositioncode, Integer dispositioncategory);
	
	List<DispositionCode> findByDispositiondescAndDispositioncategoryAndIsactive(String dispositionDesc, Integer dispositioncategory, Integer isactive);
	
	DispositionCode findByDispositioncodeAndDispositioncategoryAndIsactive(String dispositioncode, Integer dispositioncategory, Integer isactive);

}
