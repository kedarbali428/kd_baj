package com.bajaj.markets.credit.application.helper;

public enum SmartechProductCodeEnum {

	Health_Insurance("Health Insurance", "HGI"), Two_Wheeler_Insurance("Two Wheeler Insurance", "TWGI"),
	Four_Wheeler_Insurance("Four Wheeler Insurance", "FWGI"), Business_Loan("BFLBOL", "BOL"),
	Salaried_Personal_Loan("BFLSOL","SOL"), Credit_Card("CC","CC"),
	Home_Loan("HL","HL") , Home_Loan_Balance_Transfer("HLBT","HLBT"),
	Loan_Against_Property("LAP","LAP"), 
	Loan_Against_Property_Balance_Transfer("LAPBT","LAPBT");

	private String productCategoryCode;
	private String productCodeValue;

	private SmartechProductCodeEnum(String productCategoryCode, String productCodeValue) {
		this.productCategoryCode = productCategoryCode;
		this.productCodeValue = productCodeValue;
	}

	public String getProductCategoryCode() {
		return productCategoryCode;
	}

	public String getProductCodeValue() {
		return productCodeValue;
	}

	public static String getValueOfProductCode(String productCategoryCode) {
		for (SmartechProductCodeEnum map : SmartechProductCodeEnum.values()) {
			if (map.productCategoryCode.equals(productCategoryCode)) {
				return map.productCodeValue;
			}
		}
		return null;
	}

}
