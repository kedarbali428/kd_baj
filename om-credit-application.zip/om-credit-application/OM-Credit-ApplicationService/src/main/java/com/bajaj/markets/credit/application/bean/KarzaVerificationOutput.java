package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;
import java.util.List;

public class KarzaVerificationOutput implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String employmentVerified;
	private String creditReviewCode;
	private String emailVerificationskipFlag;
	private List<KarzaRejectionCodes> rejectCode;
	private Boolean officialEmailIdReqFlag;

	public String getEmploymentVerified() {
		return employmentVerified;
	}

	public void setEmploymentVerified(String employmentVerified) {
		this.employmentVerified = employmentVerified;
	}

	public String getCreditReviewCode() {
		return creditReviewCode;
	}

	public void setCreditReviewCode(String creditReviewCode) {
		this.creditReviewCode = creditReviewCode;
	}

	public String getEmailVerificationskipFlag() {
		return emailVerificationskipFlag;
	}

	public void setEmailVerificationskipFlag(String emailVerificationskipFlag) {
		this.emailVerificationskipFlag = emailVerificationskipFlag;
	}

	public List<KarzaRejectionCodes> getRejectCode() {
		return rejectCode;
	}

	public void setRejectCode(List<KarzaRejectionCodes> rejectCode) {
		this.rejectCode = rejectCode;
	}

	public Boolean getOfficialEmailIdReqFlag() {
		return officialEmailIdReqFlag;
	}

	public void setOfficialEmailIdReqFlag(Boolean officialEmailIdReqFlag) {
		this.officialEmailIdReqFlag = officialEmailIdReqFlag;
	}

	@Override
	public String toString() {
		return "KarzaVerificationOutput [employmentVerified=" + employmentVerified + ", creditReviewCode=" + creditReviewCode + ", emailVerificationskipFlag="
				+ emailVerificationskipFlag + ", rejectCode=" + rejectCode + ", officialEmailIdReqFlag=" + officialEmailIdReqFlag + "]";
	}

}
