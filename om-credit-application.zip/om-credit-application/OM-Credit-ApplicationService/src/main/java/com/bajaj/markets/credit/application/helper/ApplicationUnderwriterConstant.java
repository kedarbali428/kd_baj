package com.bajaj.markets.credit.application.helper;

public class ApplicationUnderwriterConstant {
public static final  String DOB="DOB";
public static final  String NAME="NAME";
public static final  String MOBILENUMBER="MOBILENUMBER";
public static final  String PAN ="PAN";
public static final  String OFFICIAL_EMAIL="Official Email";
public static final  String WORK_ADDRESS="Work Address";
public static final  String PERSONAL_EMAIL="Personal Email";
public static final  String RESIDENCE_ADDRES="Residence Address";
public static final  String BANK_ACCOUNT="Bank Account";
public static final  String JOURNEY_SOURCENAME="JOURNEY";
public static final  String SUCCESS="SUCCESS";
public static final  String FAILURE="FAILURE";
public static final  String BFL_SOURCENAME="BFL";
public static final  String FINNONE_BANK_ACCOUNT_SOURCE="FINNONEMANDATE";
}
