package com.bajaj.markets.credit.application.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bajaj.markets.credit.application.model.ApplicationBankDetail;

public interface ApplicationBankRoInterface extends ReadInterface<ApplicationBankDetail, Long> {

	Optional<ApplicationBankDetail> findByAppattrbkeyAndBankacctcatkeyAndIsactive(Long appattrbkey, Integer categoryKey,
			Integer isActive);

	// OMSECURED-21 Start
	@Query("select a.bankmastkey from ApplicationBankDetail a where a.appattrbkey=:appAttrbKey AND a.isactive=:isActive AND a.bankacctcatkey=:bankAcctcatKey")

	public Integer findBankmastkeyByAppattrbkeyAndIsactiveAndBankacctcatkey(@Param("appAttrbKey") Long appAttrbKey,
			@Param("isActive") Integer isActive, @Param("bankAcctcatKey") Integer bankAcctcatKey);
	// OMSECURED-21 End

}
