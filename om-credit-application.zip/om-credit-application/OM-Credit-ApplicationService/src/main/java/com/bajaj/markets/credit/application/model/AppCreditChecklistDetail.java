package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_credit_checklist_detail", schema = "dmcredit")
public class AppCreditChecklistDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_credit_checklist_detail_appcredchecklistdetkey_generator", sequenceName = "dmcredit.seq_pk_app_credit_checklist_detail", allocationSize = 1)
	@GeneratedValue(generator = "app_credit_checklist_detail_appcredchecklistdetkey_generator", strategy = GenerationType.SEQUENCE)
	private Long appcredchecklistdetkey;

	private Integer addressmatchwithep;

	private Long applicationkey;

	private Integer businessvintageproof;

	private Integer casedeviationapproved;

	private Integer covertdone;

	private String dedupecheckfinal;

	private String dedupechecksoft;

	private Integer degreeexpcheckfinal;

	private Integer degreeexpchecksoft;

	private Integer deviationcapturedfinal;

	private Integer deviationcapturedsoft;

	private Integer dobpanmobilenamecheck;

	private String emibankingchecked;

	private Integer fvdone;

	private Integer geotagpicschecked;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Integer negativeareachecked;

	private Integer ownhouseproof;

	private Integer recentloancreditcheck;

	private Integer repaymentfromsameaccount;

	private Integer salaryaccountbankingchecked;

	private Integer salesvisitreportchecked;

	private Integer schemechange;

	public Long getAppcredchecklistdetkey() {
		return appcredchecklistdetkey;
	}

	public void setAppcredchecklistdetkey(Long appcredchecklistdetkey) {
		this.appcredchecklistdetkey = appcredchecklistdetkey;
	}

	public Integer getAddressmatchwithep() {
		return addressmatchwithep;
	}

	public void setAddressmatchwithep(Integer addressmatchwithep) {
		this.addressmatchwithep = addressmatchwithep;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getBusinessvintageproof() {
		return businessvintageproof;
	}

	public void setBusinessvintageproof(Integer businessvintageproof) {
		this.businessvintageproof = businessvintageproof;
	}

	public Integer getCasedeviationapproved() {
		return casedeviationapproved;
	}

	public void setCasedeviationapproved(Integer casedeviationapproved) {
		this.casedeviationapproved = casedeviationapproved;
	}

	public Integer getCovertdone() {
		return covertdone;
	}

	public void setCovertdone(Integer covertdone) {
		this.covertdone = covertdone;
	}

	public String getDedupecheckfinal() {
		return dedupecheckfinal;
	}

	public void setDedupecheckfinal(String dedupecheckfinal) {
		this.dedupecheckfinal = dedupecheckfinal;
	}

	public String getDedupechecksoft() {
		return dedupechecksoft;
	}

	public void setDedupechecksoft(String dedupechecksoft) {
		this.dedupechecksoft = dedupechecksoft;
	}

	public Integer getDegreeexpcheckfinal() {
		return degreeexpcheckfinal;
	}

	public void setDegreeexpcheckfinal(Integer degreeexpcheckfinal) {
		this.degreeexpcheckfinal = degreeexpcheckfinal;
	}

	public Integer getDegreeexpchecksoft() {
		return degreeexpchecksoft;
	}

	public void setDegreeexpchecksoft(Integer degreeexpchecksoft) {
		this.degreeexpchecksoft = degreeexpchecksoft;
	}

	public Integer getDeviationcapturedfinal() {
		return deviationcapturedfinal;
	}

	public void setDeviationcapturedfinal(Integer deviationcapturedfinal) {
		this.deviationcapturedfinal = deviationcapturedfinal;
	}

	public Integer getDeviationcapturedsoft() {
		return deviationcapturedsoft;
	}

	public void setDeviationcapturedsoft(Integer deviationcapturedsoft) {
		this.deviationcapturedsoft = deviationcapturedsoft;
	}

	public Integer getDobpanmobilenamecheck() {
		return dobpanmobilenamecheck;
	}

	public void setDobpanmobilenamecheck(Integer dobpanmobilenamecheck) {
		this.dobpanmobilenamecheck = dobpanmobilenamecheck;
	}

	public String getEmibankingchecked() {
		return emibankingchecked;
	}

	public void setEmibankingchecked(String emibankingchecked) {
		this.emibankingchecked = emibankingchecked;
	}

	public Integer getFvdone() {
		return fvdone;
	}

	public void setFvdone(Integer fvdone) {
		this.fvdone = fvdone;
	}

	public Integer getGeotagpicschecked() {
		return geotagpicschecked;
	}

	public void setGeotagpicschecked(Integer geotagpicschecked) {
		this.geotagpicschecked = geotagpicschecked;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Integer getNegativeareachecked() {
		return negativeareachecked;
	}

	public void setNegativeareachecked(Integer negativeareachecked) {
		this.negativeareachecked = negativeareachecked;
	}

	public Integer getOwnhouseproof() {
		return ownhouseproof;
	}

	public void setOwnhouseproof(Integer ownhouseproof) {
		this.ownhouseproof = ownhouseproof;
	}

	public Integer getRecentloancreditcheck() {
		return recentloancreditcheck;
	}

	public void setRecentloancreditcheck(Integer recentloancreditcheck) {
		this.recentloancreditcheck = recentloancreditcheck;
	}

	public Integer getRepaymentfromsameaccount() {
		return repaymentfromsameaccount;
	}

	public void setRepaymentfromsameaccount(Integer repaymentfromsameaccount) {
		this.repaymentfromsameaccount = repaymentfromsameaccount;
	}

	public Integer getSalaryaccountbankingchecked() {
		return salaryaccountbankingchecked;
	}

	public void setSalaryaccountbankingchecked(Integer salaryaccountbankingchecked) {
		this.salaryaccountbankingchecked = salaryaccountbankingchecked;
	}

	public Integer getSalesvisitreportchecked() {
		return salesvisitreportchecked;
	}

	public void setSalesvisitreportchecked(Integer salesvisitreportchecked) {
		this.salesvisitreportchecked = salesvisitreportchecked;
	}

	public Integer getSchemechange() {
		return schemechange;
	}

	public void setSchemechange(Integer schemechange) {
		this.schemechange = schemechange;
	}

}
