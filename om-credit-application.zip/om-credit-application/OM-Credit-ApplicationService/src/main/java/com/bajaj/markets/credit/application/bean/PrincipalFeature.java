package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class PrincipalFeature implements Serializable {

	private static final long serialVersionUID = 2703536940790624814L;
	@NotBlank(message = "Feature name is mandatory.")
	private String featureName;
	@NotNull(message = "Feature value is mandatory.")
	@Digits(fraction = 0, integer = 20, message = "Only digit is allowed in feature value.")
	private Integer featureValue;

	public String getFeatureName() {
		return featureName;
	}

	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}

	public Integer getFeatureValue() {
		return featureValue;
	}

	public void setFeatureValue(Integer featureValue) {
		this.featureValue = featureValue;
	}

	@Override
	public String toString() {
		return "PrincipalFeature [featureName=" + featureName + ", featureValue=" + featureValue + "]";
	}


}
