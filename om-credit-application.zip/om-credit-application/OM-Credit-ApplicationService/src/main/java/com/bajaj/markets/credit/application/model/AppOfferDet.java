package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the app_offer_det database table.
 * 
 */
@Entity
@Table(name = "app_offer_det", schema = "dmcredit")
public class AppOfferDet implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name = "app_offer_detkey_generator", sequenceName = "dmcredit.seq_pk_app_offer_det", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_offer_detkey_generator")
	private Long appofferdetkey;
	
    private Long applicationkey; 
    
    private Long prodkey;
    
    private String isofferavailable;
    
    private String offerid;
    
    private String partnerofferid;
    
    private Integer offertype;
    
    private String offercustomerid;
    
    private BigDecimal offeramt;
    
    private Integer offertenure;
    
    private BigDecimal offerroi;
    
    private BigDecimal offerprocessingfees;
    
    private Timestamp offerstartdt;
    
    private Timestamp offerexpirydt;
    
    private Timestamp offerapplieddt;
    
    private String lineavailedflg;
    
    private Integer offeracceptsts;
    
    private Timestamp offeracceptdt;
    
    private String offertypecode;
    
    private String risksegment;
    
    private Long offersrckey;
    
    private String prospectid;
    
    private String riskoffertype;
    
    private String generationrule;
    
    private String offergenerationsource;
    
    private Integer isactive;
    
    private Long lstupdateby;
    
    private Timestamp lstupdatedt;
    
    private String riskclassification;
    
    private BigDecimal tlbaserate;
    
    private BigDecimal isbaserate;
    
    private String offerprogramcode;
    
	private String iscardholder;

	private String prospectsource;

	private String offersubsource;

	private BigDecimal offerappscore;

	private BigDecimal offercibilscore;

	private Integer segkey;

	private BigDecimal offerobligation;
	
	private String offerstatusreason;

	private BigDecimal isemiamount;

	private Integer offerpriority;

	public String getRiskclassification() {
		return riskclassification;
	}

	public void setRiskclassification(String riskclassification) {
		this.riskclassification = riskclassification;
	}

	public BigDecimal getTlbaserate() {
		return tlbaserate;
	}

	public void setTlbaserate(BigDecimal tlbaserate) {
		this.tlbaserate = tlbaserate;
	}

	public BigDecimal getIsbaserate() {
		return isbaserate;
	}

	public void setIsbaserate(BigDecimal isbaserate) {
		this.isbaserate = isbaserate;
	}

	public String getOfferprogramcode() {
		return offerprogramcode;
	}

	public void setOfferprogramcode(String offerprogramcode) {
		this.offerprogramcode = offerprogramcode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getAppofferdetkey() {
		return appofferdetkey;
	}

	public void setAppofferdetkey(Long appofferdetkey) {
		this.appofferdetkey = appofferdetkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getIsofferavailable() {
		return isofferavailable;
	}

	public void setIsofferavailable(String isofferavailable) {
		this.isofferavailable = isofferavailable;
	}

	public String getOfferid() {
		return offerid;
	}

	public void setOfferid(String offerid) {
		this.offerid = offerid;
	}

	public String getPartnerofferid() {
		return partnerofferid;
	}

	public void setPartnerofferid(String partnerofferid) {
		this.partnerofferid = partnerofferid;
	}

	public Integer getOffertype() {
		return offertype;
	}

	public void setOffertype(Integer offertype) {
		this.offertype = offertype;
	}

	public String getOffercustomerid() {
		return offercustomerid;
	}

	public void setOffercustomerid(String offercustomerid) {
		this.offercustomerid = offercustomerid;
	}

	public BigDecimal getOfferamt() {
		return offeramt;
	}

	public void setOfferamt(BigDecimal offeramt) {
		this.offeramt = offeramt;
	}

	public Integer getOffertenure() {
		return offertenure;
	}

	public void setOffertenure(Integer offertenure) {
		this.offertenure = offertenure;
	}

	public BigDecimal getOfferroi() {
		return offerroi;
	}

	public void setOfferroi(BigDecimal offerroi) {
		this.offerroi = offerroi;
	}

	public BigDecimal getOfferprocessingfees() {
		return offerprocessingfees;
	}

	public void setOfferprocessingfees(BigDecimal offerprocessingfees) {
		this.offerprocessingfees = offerprocessingfees;
	}

	public Timestamp getOfferstartdt() {
		return offerstartdt;
	}

	public void setOfferstartdt(Timestamp offerstartdt) {
		this.offerstartdt = offerstartdt;
	}

	public Timestamp getOfferexpirydt() {
		return offerexpirydt;
	}

	public void setOfferexpirydt(Timestamp offerexpirydt) {
		this.offerexpirydt = offerexpirydt;
	}

	public Timestamp getOfferapplieddt() {
		return offerapplieddt;
	}

	public void setOfferapplieddt(Timestamp offerapplieddt) {
		this.offerapplieddt = offerapplieddt;
	}

	public String getLineavailedflg() {
		return lineavailedflg;
	}

	public void setLineavailedflg(String lineavailedflg) {
		this.lineavailedflg = lineavailedflg;
	}

	public Integer getOfferacceptsts() {
		return offeracceptsts;
	}

	public void setOfferacceptsts(Integer offeracceptsts) {
		this.offeracceptsts = offeracceptsts;
	}

	public Timestamp getOfferacceptdt() {
		return offeracceptdt;
	}

	public void setOfferacceptdt(Timestamp offeracceptdt) {
		this.offeracceptdt = offeracceptdt;
	}

	public String getOffertypecode() {
		return offertypecode;
	}

	public void setOffertypecode(String offertypecode) {
		this.offertypecode = offertypecode;
	}

	public String getRisksegment() {
		return risksegment;
	}

	public void setRisksegment(String risksegment) {
		this.risksegment = risksegment;
	}

	public String getProspectid() {
		return prospectid;
	}

	public void setProspectid(String prospectid) {
		this.prospectid = prospectid;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	public String getGenerationrule() {
		return generationrule;
	}

	public void setGenerationrule(String generationrule) {
		this.generationrule = generationrule;
	}

	public String getOffergenerationsource() {
		return offergenerationsource;
	}

	public void setOffergenerationsource(String offergenerationsource) {
		this.offergenerationsource = offergenerationsource;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getOffersrckey() {
		return offersrckey;
	}

	public void setOffersrckey(Long offersrckey) {
		this.offersrckey = offersrckey;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public String getIscardholder() {
		return iscardholder;
	}

	public void setIscardholder(String iscardholder) {
		this.iscardholder = iscardholder;
	}

	public String getProspectsource() {
		return prospectsource;
	}

	public void setProspectsource(String prospectsource) {
		this.prospectsource = prospectsource;
	}

	public Integer getOfferpriority() {
		return offerpriority;
	}

	public void setOfferpriority(Integer offerpriority) {
		this.offerpriority = offerpriority;
	}
    
	public BigDecimal getOffercibilscore() {
		return offercibilscore;
	}

	public void setOffercibilscore(BigDecimal offercibilscore) {
		this.offercibilscore = offercibilscore;
	}

	public String getOffersubsource() {
		return offersubsource;
	}

	public void setOffersubsource(String offersubsource) {
		this.offersubsource = offersubsource;
	}

	public BigDecimal getOfferappscore() {
		return offerappscore;
	}

	public void setOfferappscore(BigDecimal offerappscore) {
		this.offerappscore = offerappscore;
	}

	public Integer getSegkey() {
		return segkey;
	}

	public void setSegkey(Integer segkey) {
		this.segkey = segkey;
	}

	public BigDecimal getOfferobligation() {
		return offerobligation;
	}

	public void setOfferobligation(BigDecimal offerobligation) {
		this.offerobligation = offerobligation;
	}

	public String getOfferstatusreason() {
		return offerstatusreason;
	}

	public void setOfferstatusreason(String offerstatusreason) {
		this.offerstatusreason = offerstatusreason;
	}

	public BigDecimal getIsemiamount() {
		return isemiamount;
	}

	public void setIsemiamount(BigDecimal isemiamount) {
		this.isemiamount = isemiamount;
	}
}
