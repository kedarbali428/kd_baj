package com.bajaj.markets.credit.application.helper;

import java.text.Format;
import java.text.NumberFormat;

import org.springframework.stereotype.Component;

@Component
public class CurrencyConversionHelper {

	public static String numberToCurrencyConversion(Object amount) {
		if(null != amount) {
			Format format = NumberFormat.getInstance();
			return format.format(amount);
		}
		return "00.00";
	}
}
