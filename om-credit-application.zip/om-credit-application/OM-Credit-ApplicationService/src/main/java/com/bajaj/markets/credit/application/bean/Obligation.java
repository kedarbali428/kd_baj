package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bajaj.markets.credit.application.helper.CreditApplicationConstant.ObligationAmount;


public class Obligation {
	
	@NotNull(groups = ObligationAmount.class,message = "obligationAmount can not be null/empty")
	private BigDecimal obligationAmount;
	
	@Digits(groups = ObligationAmount.class,fraction = 0, integer = 20, message = "applicationKey can not be other than digits")
	@NotBlank(groups = ObligationAmount.class,message = "applicationKey can not be null/empty")
	private String applicationKey;
	
	@Pattern(groups = ObligationAmount.class,regexp="^[a-zA-Z0-9\\s_-]+$", message = "obligationSource is invalid") 
	@NotBlank(groups = ObligationAmount.class,message = "obligationSource can not be null/empty")
	private String obligationSource;
	
	private BigDecimal currentBalance;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public BigDecimal getObligationAmount() {
		return obligationAmount;
	}

	public void setObligationAmount(BigDecimal obligationAmount) {
		this.obligationAmount = obligationAmount;
	}

	public String getObligationSource() {
		return obligationSource;
	}

	public void setObligationSource(String obligationSource) {
		this.obligationSource = obligationSource;
	}

	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}

	@Override
	public String toString() {
		return "Obligation [obligationAmount=" + obligationAmount + ", applicationKey=" + applicationKey
				+ ", obligationSource=" + obligationSource + ", currentBalance=" + currentBalance + "]";
	}

}
