package com.bajaj.markets.credit.application.helper;

public enum CreditCardParentChildStatusEnum {
	
	INPROGRESS(1,2),
	SENTTOBANK(5,2),
	FINALAPPROVAL(4,4),
	CARDCREATIONINITIATED(6,4),
	CARDCREATED(7,7),
	REJECTED(3,3);

	private final Integer childStatus;
	private final Integer parentStatus;
	
	private CreditCardParentChildStatusEnum(Integer childStatus, Integer parentStatus) {
		this.childStatus = childStatus;
		this.parentStatus = parentStatus;
	}

	public Integer getChildStatus() {
		return childStatus;
	}
	
	public Integer getParentStatus() {
		return parentStatus;
	}
}
