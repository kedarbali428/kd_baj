package com.bajaj.markets.credit.application.bean;
import java.math.BigDecimal;

public class ObligationDetail {

	private BigDecimal obligationAmount;
	
	private String applicationKey;
	
	private String obligationSource;
	
	private String appObligationKey;

	public BigDecimal getObligationAmount() {
		return obligationAmount;
	}

	public void setObligationAmount(BigDecimal obligationAmount) {
		this.obligationAmount = obligationAmount;
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getObligationSource() {
		return obligationSource;
	}

	public void setObligationSource(String obligationSource) {
		this.obligationSource = obligationSource;
	}

	public String getAppObligationKey() {
		return appObligationKey;
	}

	public void setAppObligationKey(String appObligationKey) {
		this.appObligationKey = appObligationKey;
	}

	@Override
	public String toString() {
		return "ObligationDetail [obligationAmount=" + obligationAmount + ", applicationKey=" + applicationKey
				+ ", obligationSource=" + obligationSource + ", appObligationKey=" + appObligationKey + "]";
	}
	
}
