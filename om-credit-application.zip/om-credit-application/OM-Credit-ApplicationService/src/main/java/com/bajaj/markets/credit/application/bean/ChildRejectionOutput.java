package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class ChildRejectionOutput {

	private String parentStatus;
	private Boolean directToListing;
	private List<PrincipalProductRejectionOutput> principleProductDetails;
	private String childApplicationStagePercentage;
	private String parentApplicationStagePercentage;
	
	public String getParentStatus() {
		return parentStatus;
	}
	public void setParentStatus(String parentStatus) {
		this.parentStatus = parentStatus;
	}
	public Boolean getDirectToListing() {
		return directToListing;
	}
	public void setDirectToListing(Boolean directToListing) {
		this.directToListing = directToListing;
	}
	public List<PrincipalProductRejectionOutput> getPrincipleProductDetails() {
		return principleProductDetails;
	}
	public void setPrincipleProductDetails(List<PrincipalProductRejectionOutput> principleProductDetails) {
		this.principleProductDetails = principleProductDetails;
	}
	public String getChildApplicationStagePercentage() {
		return childApplicationStagePercentage;
	}
	public void setChildApplicationStagePercentage(String childApplicationStagePercentage) {
		this.childApplicationStagePercentage = childApplicationStagePercentage;
	}
	public String getParentApplicationStagePercentage() {
		return parentApplicationStagePercentage;
	}
	public void setParentApplicationStagePercentage(String parentApplicationStagePercentage) {
		this.parentApplicationStagePercentage = parentApplicationStagePercentage;
	}
	@Override
	public String toString() {
		return "ChildRejectionOutput [parentStatus=" + parentStatus + ", directToListing=" + directToListing
				+ ", principleProductDetails=" + principleProductDetails + ", childApplicationStagePercentage="
				+ childApplicationStagePercentage + ", parentApplicationStagePercentage="
				+ parentApplicationStagePercentage + "]";
	}
}
