package com.bajaj.markets.credit.application.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "credit_review_code", schema = "dmcredit")
public class CreditReviewCode {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer creditreviewkey;

	private String creditreviewcd;

	private String creditreviewdesc;

	private String creditreviewscenario;

	private Integer nonstpflag;

	private Integer creditreviewflag;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	public Integer getCreditreviewkey() {
		return creditreviewkey;
	}

	public void setCreditreviewkey(Integer creditreviewkey) {
		this.creditreviewkey = creditreviewkey;
	}

	public String getCreditreviewcd() {
		return creditreviewcd;
	}

	public void setCreditreviewcd(String creditreviewcd) {
		this.creditreviewcd = creditreviewcd;
	}

	public String getCreditreviewdesc() {
		return creditreviewdesc;
	}

	public void setCreditreviewdesc(String creditreviewdesc) {
		this.creditreviewdesc = creditreviewdesc;
	}

	public String getCreditreviewscenario() {
		return creditreviewscenario;
	}

	public void setCreditreviewscenario(String creditreviewscenario) {
		this.creditreviewscenario = creditreviewscenario;
	}

	public Integer getNonstpflag() {
		return nonstpflag;
	}

	public void setNonstpflag(Integer nonstpflag) {
		this.nonstpflag = nonstpflag;
	}

	public Integer getCreditreviewflag() {
		return creditreviewflag;
	}

	public void setCreditreviewflag(Integer creditreviewflag) {
		this.creditreviewflag = creditreviewflag;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}
