package com.bajaj.markets.credit.application.bean;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class BundleApplicationDetail {
	
	private Long applicationKey;

	private Long applicantKey;
	
	@NotBlank(message = "gender cannot be null or empty")
	private String gender;
	
	@Pattern(regexp="(0/91)?[6-9][0-9]{9}",message="mobile is not valid") 
	@NotBlank(message = "mobile cannot be null or empty")
    private String mobileNumber;

    private String sourceApplicationKey;

	@NotBlank(message = "Fpp plan code cannot be null or empty")
    private String fppPlanCode;
	private String planName;
	private Integer planKey;

    @NotBlank(message = "dateOfBirth cannot be null or empty")
    @Pattern(regexp = "\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])*", message = "Invalid date format. Please pass date in yyyy-MM-dd")
    private String dateOfBirth;
    
    private Integer sourceProductCategoryKey;
    
    private Integer sourceProductMasterKey;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getSourceApplicationKey() {
		return sourceApplicationKey;
	}

	public void setSourceApplicationKey(String sourceApplicationKey) {
		this.sourceApplicationKey = sourceApplicationKey;
	}

	public String getFppPlanCode() {
		return fppPlanCode;
	}

	public void setFppPlanCode(String fppPlanCode) {
		this.fppPlanCode = fppPlanCode;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Integer getSourceProductCategoryKey() {
		return sourceProductCategoryKey;
	}

	public void setSourceProductCategoryKey(Integer sourceProductCategoryKey) {
		this.sourceProductCategoryKey = sourceProductCategoryKey;
	}

	public Integer getSourceProductMasterKey() {
		return sourceProductMasterKey;
	}

	public void setSourceProductMasterKey(Integer sourceProductMasterKey) {
		this.sourceProductMasterKey = sourceProductMasterKey;
	}
	
	public Integer getPlanKey() {
		return planKey;
	}

	public void setPlanKey(Integer planKey) {
		this.planKey = planKey;
	}

	@Override
	public String toString() {
		return "BundleApplicationDetail [applicationKey=" + applicationKey + ", applicantKey=" + applicantKey
				+ ", gender=" + gender + ", mobileNumber=" + mobileNumber + ", sourceApplicationKey="
				+ sourceApplicationKey + ", fppPlanCode=" + fppPlanCode + ", planName=" + planName + ", planKey="
				+ planKey + ", dateOfBirth=" + dateOfBirth + ", sourceProductCategoryKey=" + sourceProductCategoryKey
				+ ", sourceProductMasterKey=" + sourceProductMasterKey + "]";
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}
}
