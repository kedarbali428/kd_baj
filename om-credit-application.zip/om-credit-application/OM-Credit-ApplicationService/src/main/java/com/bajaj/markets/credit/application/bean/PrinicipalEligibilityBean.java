package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class PrinicipalEligibilityBean {

	@Override
	public String toString() {
		return "PrinicipalEligibilityBean [eligibilityAmount=" + eligibilityAmount + "]";
	}

	private BigDecimal eligibilityAmount;

	public BigDecimal getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(BigDecimal eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}
}
