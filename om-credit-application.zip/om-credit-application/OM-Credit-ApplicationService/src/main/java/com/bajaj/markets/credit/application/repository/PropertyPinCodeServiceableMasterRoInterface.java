package com.bajaj.markets.credit.application.repository;

import com.bajaj.markets.credit.application.model.PropertyPincodeServiceable;

public interface PropertyPinCodeServiceableMasterRoInterface
		extends ReadInterface<PropertyPincodeServiceable, Integer> {

	PropertyPincodeServiceable findByPincodekeyAndProdkeyAndIsactive(Long pincodekey, Long prodkey, Integer isActive);
}
