package com.bajaj.markets.credit.application.bean;

public class ChildRejectionParentOutput {

	private ChildRejectionOutput childRejectionOutput;
	private Boolean Action;
	
	public ChildRejectionOutput getChildRejectionOutput() {
		return childRejectionOutput;
	}
	public void setChildRejectionOutput(ChildRejectionOutput childRejectionOutput) {
		this.childRejectionOutput = childRejectionOutput;
	}
	public Boolean getAction() {
		return Action;
	}
	public void setAction(Boolean action) {
		Action = action;
	}
	@Override
	public String toString() {
		return "ChildRejectionParentOutput [childRejectionOutput=" + childRejectionOutput + ", Action=" + Action + "]";
	}
}
