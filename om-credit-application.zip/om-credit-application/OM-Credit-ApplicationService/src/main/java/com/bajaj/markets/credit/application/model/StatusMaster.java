package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the status_master database table.
 * 
 */
@Entity
@Table(name = "status_master", schema = "dmcredit")
public class StatusMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long statuskey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String statusdesc;

	private Integer statusrank;

	public StatusMaster() {
	}

	public Long getStatuskey() {
		return this.statuskey;
	}

	public void setStatuskey(Long statuskey) {
		this.statuskey = statuskey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getStatusdesc() {
		return this.statusdesc;
	}

	public void setStatusdesc(String statusdesc) {
		this.statusdesc = statusdesc;
	}

	public Integer getStatusrank() {
		return this.statusrank;
	}

	public void setStatusrank(Integer statusrank) {
		this.statusrank = statusrank;
	}

}