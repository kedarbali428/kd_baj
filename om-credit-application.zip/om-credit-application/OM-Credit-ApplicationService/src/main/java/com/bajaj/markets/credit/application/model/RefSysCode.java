package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ref_sys_code", schema = "dmcredit")
public class RefSysCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long refsyscodekey;

	private String conversionfactor;

	private String omcode;

	private String omdatatype;

	private String omlable;

	private BigDecimal principledataprecision;

	private String principledatatype;

	private String principlelable;

	private String principlevalue;

	private String translationruletype;

	private Integer isactive;

	private Long systemkey;

	private String principalformat;
	private String omformat;
	private String omselectortype;
	private String omselectorvalue;
	private Integer mappingid;

	public RefSysCode() {
		// Not required
	}

	public Long getRefsyscodekey() {
		return this.refsyscodekey;
	}

	public void setRefsyscodekey(Long refsyscodekey) {
		this.refsyscodekey = refsyscodekey;
	}

	public void setConversionfactor(String conversionfactor) {
		this.conversionfactor = conversionfactor;
	}

	public String getConversionfactor() {
		return this.conversionfactor;
	}

	public String getOmcode() {
		return this.omcode;
	}

	public void setOmcode(String omcode) {
		this.omcode = omcode;
	}

	public String getOmdatatype() {
		return this.omdatatype;
	}

	public void setOmdatatype(String omdatatype) {
		this.omdatatype = omdatatype;
	}

	public String getOmlable() {
		return this.omlable;
	}

	public void setOmlable(String omlable) {
		this.omlable = omlable;
	}

	public BigDecimal getPrincipledataprecision() {
		return this.principledataprecision;
	}

	public void setPrincipledataprecision(BigDecimal principledataprecision) {
		this.principledataprecision = principledataprecision;
	}

	public String getPrincipledatatype() {
		return this.principledatatype;
	}

	public void setPrincipledatatype(String principledatatype) {
		this.principledatatype = principledatatype;
	}

	public String getPrinciplelable() {
		return this.principlelable;
	}

	public void setPrinciplelable(String principlelable) {
		this.principlelable = principlelable;
	}

	public String getPrinciplevalue() {
		return this.principlevalue;
	}

	public void setPrinciplevalue(String principlevalue) {
		this.principlevalue = principlevalue;
	}

	public String getTranslationruletype() {
		return this.translationruletype;
	}

	public void setTranslationruletype(String translationruletype) {
		this.translationruletype = translationruletype;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getSystemkey() {
		return systemkey;
	}

	public void setSystemkey(Long systemkey) {
		this.systemkey = systemkey;
	}

	public String getPrincipalformat() {
		return principalformat;
	}

	public void setPrincipalformat(String principalformat) {
		this.principalformat = principalformat;
	}

	public String getOmformat() {
		return omformat;
	}

	public void setOmformat(String omformat) {
		this.omformat = omformat;
	}

	public String getOmselectortype() {
		return omselectortype;
	}

	public void setOmselectortype(String omselectortype) {
		this.omselectortype = omselectortype;
	}

	public String getOmselectorvalue() {
		return omselectorvalue;
	}

	public void setOmselectorvalue(String omselectorvalue) {
		this.omselectorvalue = omselectorvalue;
	}

	public Integer getMappingid() {
		return mappingid;
	}

	public void setMappingid(Integer mappingid) {
		this.mappingid = mappingid;
	}

}
