package com.bajaj.markets.credit.application.bean;

public class FeeCalculationOutputBean {

	private FeeCalculationOutput feeCalculationOutput;

	public FeeCalculationOutput getFeeCalculationOutput() {
		return feeCalculationOutput;
	}

	public void setFeeCalculationOutput(FeeCalculationOutput feeCalculationOutput) {
		this.feeCalculationOutput = feeCalculationOutput;
	}

}
