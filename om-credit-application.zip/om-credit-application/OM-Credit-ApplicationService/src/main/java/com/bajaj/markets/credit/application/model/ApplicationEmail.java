package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.bajaj.markets.credit.application.helper.UpperCaseConverter;

/**
 * The persistent class for the application_email database table.
 * 
 */
@Entity
@Table(name = "application_email", schema = "dmcredit")
public class ApplicationEmail implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "application_email_appemaiidkey_generator", sequenceName = "dmcredit.seq_pk_application_email", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_email_appemaiidkey_generator")
	private Long appemaiidkey;

	private Long emailtypekey;

	//@Convert(converter = UpperCaseConverter.class)
	private String emailaddress;

	private Integer isverified;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String verificationsrc;

	private Long appattrbkey;

	private BigDecimal emailpriority;

	private Integer emailverificationrequiredflag;

	private Integer cvrequiredflag;

	public ApplicationEmail() {
	}

	/**
	 * @return the appemaiidkey
	 */
	public Long getAppemaiidkey() {
		return appemaiidkey;
	}

	/**
	 * @param appemaiidkey the appemaiidkey to set
	 */
	public void setAppemaiidkey(Long appemaiidkey) {
		this.appemaiidkey = appemaiidkey;
	}

	/**
	 * @return the emailtypekey
	 */
	public Long getEmailtypekey() {
		return emailtypekey;
	}

	/**
	 * @param emailtypekey the emailtypekey to set
	 */
	public void setEmailtypekey(Long emailtypekey) {
		this.emailtypekey = emailtypekey;
	}

	/**
	 * @return the emailaddress
	 */
	public String getEmailaddress() {
		return emailaddress;
	}

	/**
	 * @param emailaddress the emailaddress to set
	 */
	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}

	/**
	 * @return the isverified
	 */
	public Integer getIsverified() {
		return isverified;
	}

	/**
	 * @param isverified the isverified to set
	 */
	public void setIsverified(Integer isverified) {
		this.isverified = isverified;
	}

	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}

	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	/**
	 * @return the lstupdateby
	 */
	public Long getLstupdateby() {
		return lstupdateby;
	}

	/**
	 * @param lstupdateby the lstupdateby to set
	 */
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	/**
	 * @return the lstupdatedt
	 */
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	/**
	 * @param lstupdatedt the lstupdatedt to set
	 */
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	/**
	 * @return the verificationsrc
	 */
	public String getVerificationsrc() {
		return verificationsrc;
	}

	/**
	 * @param verificationsrc the verificationsrc to set
	 */
	public void setVerificationsrc(String verificationsrc) {
		this.verificationsrc = verificationsrc;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public BigDecimal getEmailpriority() {
		return emailpriority;
	}

	public void setEmailpriority(BigDecimal emailpriority) {
		this.emailpriority = emailpriority;
	}

	public Integer getEmailverificationrequiredflag() {
		return emailverificationrequiredflag;
	}

	public void setEmailverificationrequiredflag(Integer emailverificationrequiredflag) {
		this.emailverificationrequiredflag = emailverificationrequiredflag;
	}

	public Integer getCvrequiredflag() {
		return cvrequiredflag;
	}

	public void setCvrequiredflag(Integer cvrequiredflag) {
		this.cvrequiredflag = cvrequiredflag;
	}

	@Override
	public ApplicationEmail clone() throws CloneNotSupportedException {
		ApplicationEmail email = new ApplicationEmail();
		email.setAppattrbkey(this.appattrbkey);
		email.setEmailtypekey(this.emailtypekey);
		email.setEmailaddress(this.emailaddress);
		email.setIsverified(this.isverified);
		email.setIsactive(this.isactive);
		email.setLstupdateby(this.lstupdateby);
		email.setLstupdatedt(this.lstupdatedt);
		email.setVerificationsrc(this.verificationsrc);
		email.setEmailverificationrequiredflag(this.emailverificationrequiredflag);
		email.setCvrequiredflag(this.cvrequiredflag);
		return email;
	}

}