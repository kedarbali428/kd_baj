package com.bajaj.markets.credit.application.helper;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class ApplicationConstants {

	public static final Integer IS_ACTIVE = 1;
	public static final BigDecimal ACTIVE = BigDecimal.valueOf(1);
	public static final BigDecimal DEACTIVE = BigDecimal.valueOf(0);
	public static final String PRINCIPALKEY = "principalkey";
	public static final String APPLICATIONID = "applicationid";
	public static final String APPLICATIONKEY = "applicationKey";
	public static final String APP_ATTRIBUTE_KEY = "appAttributeKey";
	public static final String MOBILE = "mobilenumber";
	public static final String CUST_TYPE = "custtype";
	public static final String MOBILE_NUMBER = "mobileNumber";
	public static final String PHONE_NUMBER = "phoneNumber";
	public static final String PROD_KEY = "prodKey";
	public static final String MISS_APPLICATION_ATTRIBUTE = "Missing application attribute.";
	public static final String MISS_APPLICATION = "Resource not found for given application Id.";
	public static final String APPROVED_STATUS = "Approved";
	public static final String REJECTED = "REJECTED";
	public static final String REJECTED_STATUS = "Rejected";
	public static final String CREDIT_REJECTED_STATUS = "Credit Rejected";
	public static final String INPROGRESS_STATUS = "InProgress";
	public static final String CARDCREATED_STATUS = "CardCreated";
	public static final String ECOM = "ECOM";
	public static final String CONTACTLESS = "CONTACTLESS";
	public static final String INTERNATIONAL = "INTERNATIONAL";
	public static final String LIMIT_KEY_WORD = "Limit:";
	public static final String PARENT_CREATED = "PARENT CREATED";
	public static final String RESUME = "RESUME";
	public static final String UTM_TERM = "utm_term";
	public static final String UTM_SOURCE = "utm_source";
	public static final String UTM_REFERRAL = "utm_referral:";
	public static final String UTM_MEDIUM = "utm_medium";
	public static final String UTM_CONTENT = "utm_content";
	public static final String UTM_CAMPAIGN = "utm_campaign";
	public static final String SOURCING_CHANNEL = "sourcing_channel";
	public static final String GCLID = "gclid";
	public static final String NOTIFICATION_TYPE_CODE = "notificationTypeCode";
	public static final String CUSTOMER_NAME = "name";
	public static final String PRODUCT = "product";
	public static final String PRODUCT_LIST = "productList";
	public static final String PERSONAL_EMAIL = "recipientEmailId";
	public static final String TEMPLATE_DATA_MAP = "templateDataMap";
	public static final String LINK = "link";
	public static final String PRODUCT_COUNT = "productCount";
	public static final String LOAN = "Loan";
	public static final String CARD = "Card";
	public static final String TRUE = "TRUE";
	public static final String FALSE = "FALSE";

	public static final String CAS_1011 = "CAS-1011";
	public static final String CAS_1012 = "CAS-1012";
	public static final String CAS_1013 = "CAS-1013";
	public static final String CAS_1014 = "CAS-1014";
	public static final String CAS_1015 = "CAS-1015";
	public static final String CAS_1016 = "CAS-1016";
	public static final String CAS_1017 = "CAS-1017";
	public static final String CAS_1018 = "CAS-1018";
	public static final String CAS_1019 = "CAS-1019";
	public static final String CAS_1020 = "CAS-1020";
	public static final String CAS_1021 = "CAS-1021";
	public static final String CAS_1022 = "CAS-1022";
	public static final String CAS_1023 = "CAS-1023";
	public static final String CAS_1024 = "CAS-1024";
	public static final String CAS_1025 = "CAS-1025";
	public static final String CAS_1026 = "CAS-1026";
	public static final String CAS_1027 = "CAS-1027";
	public static final String CAS_1028 = "CAS-1028";
	public static final String CAS_1029 = "CAS-1029";
	public static final String CAS_1030 = "CAS_1030";
	public static final String CAS_1031 = "CAS_1031";
	public static final String CAS_1032 = "CAS_1032";
	public static final String CAS_1033 = "CAS_1033";
	public static final String CAS_1034 = "CAS_1034";
	public static final String CAS_1035 = "CAS_1035";
	public static final String CAS_1036 = "CAS_1036";
	public static final String CAS_1037 = "CAS_1037";
	public static final String CAS_1040 = "CAS_1040";
	public static final String CAS_1041 = "CAS_1041";
	public static final String CAS_1042 = "CAS_1042";
	public static final String CAS_1043= "CAS_1043";
	public static final String CAS_1044 = "CAS_1044";
	public static final String CAS_1045 = "CAS_1045";
	public static final String CAS_1046 = "CAS_1046";
	public static final String CAS_1047 = "CAS_1047";
	public static final String CAS_1048 = "CAS_1048";
	public static final String CAS_1049 = "CAS_1049";
	public static final String CAS_1050 = "CAS_1050";
	public static final String CAS_1051 = "CAS_1051";
	public static final String CAS_1052 = "CAS_1052";
	public static final String CAS_1053 = "CAS_1053";
	public static final String CAS_1054 = "CAS_1054";
	public static final String CAS_1055 = "CAS_1055";
	public static final String CAS_1056 = "CAS-1056";
	
	public static final String CAS_2011 = "CAS-2011";
	public static final String CAS_2012 = "CAS-2012";
	public static final String CAS_2013 = "CAS-2013";
	public static final String CAS_2014 = "CAS-2014";
	public static final String CAS_2015 = "CAS-2015";

	public static final String CAS_31011 = "CAS_31011";
	public static final String CAS_31012 = "CAS_31012";
	public static final String CAS_31013 = "CAS_31013";
	public static final String CAS_31014 = "CAS_31014";
	public static final String CAS_4100 = "CAS-4100";
	public static final String CAS_1091 = "CAS-1091";
	public static final String CAS_1092 = "CAS-1092";

	public static final String CREDIT_VIDYA = "CREDIT_VIDYA";

	public static final String OM_CARDS_AXIS_WAIT = "OMCARDSAXISWAIT";
	public static final String OM_CARDS_AXIS_APPROVE = "OMCARDSAXISAPPROVE";
	public static final String OM_CARDS_AXIS_REJECT = "OMCARDSAXISREJECT";
	public static final String OM_CARDS_LISTING_REJECT = "OMCARDSLISTINGREJECT";
	public static final String OM_COMMON_LIST_CARDS = "OMCOMMONLISTCARDS";
	public static final String APPROVED = "APPROVED";
	public static final String JOURNEY = "JOURNEY";
	public static final String VAS_EP = "EMPLOYEE_PORTAL";
	public static final String EP = "EP";
	public static final String UTM_PARAM_EVENT = "PARENT CREATED";
	public static final Long EMAIL_TYPE_KEY = 67L;
	public static final Long OTHER_EMAIL_TYPE_KEY = 68L;

	protected static final List<String> APPLICATION_KEY_FIELD_NAME = Arrays.asList("applicationKey", "applicationId", "applicationid", "applicationkey");
	public static final String FINEGRAIN_VALIDATION_FAILED = "FineGrain validation Failed.";
	public static final String FORBIDDEN = "FineGrain Validation Failed.";
	public static final String REJECTION_SYSTEM_KARZA = "KARZABRE";
	public static final String BANK_ACC_CATEGORY_DISB = "Disbursement";
	public static final String BANK_ACC_CATEGORY_REPAY = "Repayment";
	public static final String BANK_ACC_CATEGORY_NULL = "Null";
	public static final String BANK_DET_SOURCE_EP = "EP";
	public static final String BANK_DET_SOURCE_JOURNEY = "journey";
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	
	public static final String NEGATIVE_AREA_REJECT_CODE = "CCRNA";
	public static final String ADDITIONAL_DETAILS_REJECT = "RADDDET";

	public static final Long OCCUPATION_TYPEKEY_SEMP = 2L;
	public static final Long OCCUPATION_TYPEKEY_DOCSEMP = 9L;
	public static final Long OCCUPATION_TYPEKEY_CAICWA = 7L;
	
	public static final String OFFER_PROSPECT = "offer_prospect";
	public static final String ETB_Y = "1";
	public static final String ETB_N = "0";

	public static final String OCCUPATION_SRC_JOURNEY = "Journey";
	public static final String OCCUPATION_SRC_PERFIOS = "perfios";
	
	public static final String AUTH_TOKEN = "authtoken";
	public static final String CMPT_CORR_ID = "cmptcorrid";
	public static final String PRINCIPAL_STATUS_CHECK = "PRINCIPAL_STATUS_CHECK";
	public static final String PRINCIPAL_LEAD_PUSH = "PRINCIPAL_LEAD_PUSH";
	public static final String PRINCIPAL_KEY = "principalKey";
	protected static final List<String> STATUS_LIST = Arrays.asList("Rejected", "Approval", "Approved", "Card Created");
	public static final String STATUS = "status";
	public static final String MESSAGE = "message";

	public static final String SOURCE = "source";
	public static final String SOURCE_EP="EP";
	public static final String SOURCE_JOURNEY="Journey";
	public static final String SOURCE_PERFIOS="PERFIOS";
	public static final String SOURCE_BMR="BMR";

	public static final Long ALTERNATE_PHONE_TYPE_KEY = 49L;
	public static final String COUNTRY_CODE = "91";
	public static final String CUSTOMER = "CUSTOMER";
	public static final String EPCREDIT = "EPCREDIT";
	public static final String OMSL = "OMSL";
	
	public static List<String> getStatusList() {
		return STATUS_LIST;
	}

	public static List<String> getApplicationKeyFieldName() {
		return APPLICATION_KEY_FIELD_NAME;
	}
	
	public static final String MCP1 = "REJBRE1";

	private ApplicationConstants() {
		// Not Required.
	}

	public static final Long PROPERTYTYPE = 95l;
	
	public static final String NOTF_CODE_OM_LOANS_LISTING = "OMLOANSLISTING";
	public static final String NOTF_CODE_OM_LOANS_REJECT_PARENTAPP = "OMLNREJECTPARENTAPP";
	public static final String NOTF_CODE_OM_LOANS_PRICING_FLEXI_SMS = "OMLNPRICINGFLEXISMS";
	public static final String NOTF_CODE_OM_LOANS_PRICING_FLEXI_EMAIL = "OMLNPRICEFLEXIEMAIL";
	public static final String NOTF_CODE_OM_LOANS_PRICING_TERM_SMS = "OMLNPRICINGTERMSMS";
	public static final String NOTF_CODE_OM_LOANS_PRICING_TERM_EMAIL = "OMLNPRICINGTERMEMAIL";
	public static final String TOKEN_DELIMETER = "~";
	public static final String B2BPARTNER_ROLE = "b2bpartner";
	
	public static final String NOTF_CODE_OM_SL_LOANS_LISTING = "OMSLLISTING";
	public static final String NOTF_CODE_OM_SL_LOANS_REJECT_PARENTAPP = "OMSLREJECTPARENTAPP";

	public static final String HL_PRODUCT_CODE_INTENT_FRESHHOMELOAN = "HLF";
	public static final String HL_PRODUCT_CODE_INTENT_BALANCETRANSFER = "HLBT";
	public static final String HL_PRODUCT_CODE_INTENT_LOANAGAINSTPROPERTY = "LAP";
	public static final String HL_PRODUCT_CODE_INTENT_LOANAGAINSTPROPBALANCETRANSFER = "LAPBT";
	
	public static final String HLF_PRODUCT_DESC = "Fresh Home Loan";
	public static final String HLBT_PRODUCT_DESC = "Home Loan Balance Transfer";
	public static final String LAP_PRODUCT_DESC = "Loan Against Property";
	public static final String LAPBT_PRODUCT_DESC = "Loan Against Property Balance Transfer";
	public static final String PRODUCT_NAME = "productname";
	public static final String PRODUCT_MAX_ELIGIBILITY = "maxeligibility";
	public static final String CC = "CC";
	public static final String APPLINK = "applink";
	public static final String OMPL = "OMPL";


	public static final String EPCREDIT_SOURCE = "EPCREDIT";
	public static final String NULL = "Null";
	public static final String MOBILE_NO = "mobile";
	public static final Long BFL_BRANCH_NO_BRANCH = 2852l;
	public static final String APPLICANT_TYPE= "1";
	public static final Long COAPPLICANT_TYPE= 2l;
	public static final Integer INACTIVE= 0;
	public static final String OFFER_API = "OFFER_API";
	public static final String LISTING_BRE = "LISTING_BRE";

	public static final String VERIFICATION_ATTRB_EMAIL = "OFFICIAL_EMAIL";
	public static final String VERIFICATION_SRC_KARZABRE = "KARZABRE";
	public static final String OTHEREMPNAME = "Other";
	public static final String EMPLOYER_MASTER = "employer_master";
	public static final String EMPLOYER_MASTER_KEY = "emprmastid";
	public static final String AIP = "AIP";
	public static final String ELIGIBILITY_TYPE_IV = "IV";
	
	public static final Long PERSONAL_EMAIL_TYPE_KEY = 70L;
	public static final String CREDIT_CARD = "CC";

	public static final String POSIDEX_COLLECTION_NAME = "posidex";
	
	public static final Long SALARIED_OCCUPATIONTYPE = 1l;
	public static final String BFLSOL_PRODUCT_KEY  = "10";
	public static final String BFLBOL_PRODUCT_KEY  = "11";
	public static final String CCRCITY = "CCRCITY";
	public static final String CUSTOMER_INFOLOCK = "CUSTOMER_INFOLOCK";
	public static final String APPELIGIBILITYDETAIL_INFOLOCK = "APPELIGIBILITYDETAIL_INFOLOCK";
	public static final String OTP = "otp";
	public static final String OFFER_AVAIABLE = "1";
	public static final String APPPRODUCTLISTINGDETAIL_INFOLOCK = "APPPRODUCTLISTINGDETAIL_INFOLOCK";
	public static final String APPSEGMENTATIONDETAIL_INFOLOCK = "APPSEGMENTATIONDETAIL_INFOLOCK";

	public static final String OMCAS_7001 = "OMCAS_7001";
	public static final String OMCAS_7002 = "OMCAS_7002";
	public static final String OMCAS_7003 = "OMCAS_7003";
	public static final String OMCAS_7004 = "OMCAS_7004";
	public static final String OMCAS_7005 = "OMCAS_7005";
	
	public static final String BANK_DET_SOURCE_EPCREDIT = "EPCREDIT";
	public static final String BANK_ACC_CATEGORY_CREDIT_DISB = "CRDISBACCT";
	public static final String BANK_ACC_CATEGORY_CREDIT_REPAY = "CRREPAYACCT";
	public static final String MCP3 = "REJBRE3";
	
	public static final String ADDRESSTYPE_CURRENT = "50";
	public static final String ADDRESSTYPE_PROPERTY = "95";
	public static final String ADDRESSTYPE_OFFICE = "46";
	public static final String BMR_APPLICATIONID = "applicationId";
	public static final String BMR2 = "BMR2";
	public static final Integer BMR_APPROVEDFLAG_TRUE = 1;
	public static final String APPAPPSSCORE_LOCK = "APPAPPSSCORELOCK";
	public static final String APPFINOBLIGATION_LOCK = "APPFINOBLIGATION_LOCK";
	public static final Integer BMR_APPROVEDFLAG_UNDEFINED = 2;
	public static final String DATE_OF_BIRTH = "dateOfBirth";
	public static final String PRICING_CONSENT = "PRICING_CONSENT";
	public static final String OFFICIAL_EMAIL = "OFFICIAL_EMAIL";
	public static final String CHANNEL_OFFICE_EMAIL = "OFFICE_EMAIL";
	
	public static final String DISBURSEMENT_RECORDS="disbursement_records";
	public static final String TARGET = "target";
	public static final String NEO_PRINCIPAL_KEY = "23"; 
	public static final String APP_OCCUPATION_SALARY_LOCK="APPOCCUPATIONSALARY_LOCK";
	public static final long REBOOKED_LAN_UDFFLAGKEY = 584L;
	
	public static final String SOURCE_CREDIT="CREDIT";
	public static final String UNDERWRITER_BRE_TARGET ="UNDERWRITERCHECKSBRE";
	public static final String BFL_EDW_DEMOG = "bfl_edw_demog";
	public static final String YES = "YES";

	public static final Long OMPL_PRODUCT_CODE_KEY = 10002L;
	public static final String FLDGCREDITJOURNEY = "fldgCreditJourney";
	public static final String BFLSOLFLDG = "BFLSOLFLDG";
	public static final String BFLSOL = "BFLSOL";

	public static final String SOURCE_CREDIT_FEE="CREDIT";
	public static final String TARGET_FEEBRE= "FEEBRE";
	public static final String SUCCESS = "SUCCESS";
	public static final String OMCA_422="OMCA_422";
	public static final String OMCA_423="OMCA_423";
	public static final String OMCA_404="OMCA_404";

}
