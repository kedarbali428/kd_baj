package com.bajaj.markets.credit.application.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="app_eligibility_detail",schema = "dmcredit")
public class AppEligibilityDetail {

	@Id
	@SequenceGenerator(name="app_eligibility_detail_appeligibilitykey_generator", sequenceName="dmcredit.seq_pk_app_eligibility_detail",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_eligibility_detail_appeligibilitykey_generator")
	private Long appeligibilitykey;
	
    private Long appattrbkey;
    
    private BigDecimal maxeligibility;
    
    private BigDecimal maxtenor;
    
    private Integer isactive;
    
    private Long lstupdateby;
    
    private Date lstupdatedt;
    
	public Long getAppeligibilitykey() {
		return appeligibilitykey;
	}
	public void setAppeligibilitykey(Long appeligibilitykey) {
		this.appeligibilitykey = appeligibilitykey;
	}
	public Long getAppattrbkey() {
		return appattrbkey;
	}
	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}
	public BigDecimal getMaxeligibility() {
		return maxeligibility;
	}
	public void setMaxeligibility(BigDecimal maxeligibility) {
		this.maxeligibility = maxeligibility;
	}
	public BigDecimal getMaxtenor() {
		return maxtenor;
	}
	public void setMaxtenor(BigDecimal maxtenor) {
		this.maxtenor = maxtenor;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	public Long getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Date getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Date lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
        
}
