package com.bajaj.markets.credit.application.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="APP_UDF_VERIFICATION",schema="dmcredit")
public class AppUdfVerification {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long appudfverificationkey; 
	
	private long applicationkey;
	
	private long udfflgkey;
	
	private BigDecimal status;
	
	private Timestamp createdt; 
	
	private String remarks; 
	
	private int addedbyuserrolekey; 
	
	private int isactive;
	
	private int lstupdateby;
	
	private Timestamp lstupdatedt;

	public long getAppudfverificationkey() {
		return appudfverificationkey;
	}

	public void setAppudfverificationkey(long appudfverificationkey) {
		this.appudfverificationkey = appudfverificationkey;
	}

	public long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public long getUdfflgkey() {
		return udfflgkey;
	}

	public void setUdfflgkey(long udfflgkey) {
		this.udfflgkey = udfflgkey;
	}

	public BigDecimal getStatus() {
		return status;
	}

	public void setStatus(BigDecimal status) {
		this.status = status;
	}

	public Timestamp getCreatdt() {
		return createdt;
	}

	public void setCreatdt(Timestamp creatdt) {
		this.createdt = creatdt;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getAddedbyuserrolekey() {
		return addedbyuserrolekey;
	}

	public void setAddedbyuserrolekey(int addedbyuserrolekey) {
		this.addedbyuserrolekey = addedbyuserrolekey;
	}

	public int getIsactive() {
		return isactive;
	}

	public void setIsactive(int isactive) {
		this.isactive = isactive;
	}

	public int getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(int lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	
}
