package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class MCPAddressDetails {
	private String pinCodeKey;
	private String addressTypeKey;
	private List<PrincipalProductDet> principleProductDetails;

	public String getPinCodeKey() {
		return pinCodeKey;
	}

	public void setPinCodeKey(String pinCodeKey) {
		this.pinCodeKey = pinCodeKey;
	}

	public String getAddressTypeKey() {
		return addressTypeKey;
	}

	public void setAddressTypeKey(String addressTypeKey) {
		this.addressTypeKey = addressTypeKey;
	}

	public List<PrincipalProductDet> getPrincipleProductDetails() {
		return principleProductDetails;
	}

	public void setPrincipleProductDetails(List<PrincipalProductDet> principleProductDetails) {
		this.principleProductDetails = principleProductDetails;
	}

	@Override
	public String toString() {
		return "MCPAddressDetails [pinCodeKey=" + pinCodeKey + ", addressTypeKey=" + addressTypeKey
				+ ", principleProductDetails=" + principleProductDetails + "]";
	}

}
