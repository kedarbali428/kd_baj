package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class ApplicationSourceDetail {
private String parameterSourceName;
private List<ApplicationParametersDetail>parametersDetails;
public String getParameterSourceName() {
	return parameterSourceName;
}
public void setParameterSourceName(String parameterSourceName) {
	this.parameterSourceName = parameterSourceName;
}
public List<ApplicationParametersDetail> getParametersDetails() {
	return parametersDetails;
}
public void setParametersDetails(List<ApplicationParametersDetail> parametersDetails) {
	this.parametersDetails = parametersDetails;
}
@Override
public String toString() {
	return "ApplicationSourceDetail [parameterSourceName=" + parameterSourceName + ", parametersDetails="
			+ parametersDetails + "]";
}

}
