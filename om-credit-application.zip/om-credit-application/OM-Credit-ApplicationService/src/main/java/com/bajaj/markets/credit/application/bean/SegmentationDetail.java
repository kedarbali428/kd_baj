package com.bajaj.markets.credit.application.bean;

public class SegmentationDetail {
private SegmentationResponse segmentationResponse;
private Boolean action;
private String rejectionSystem;

public String getRejectionSystem() {
	return rejectionSystem;
}
public void setRejectionSystem(String rejectionSystem) {
	this.rejectionSystem = rejectionSystem;
}
public SegmentationResponse getSegmentationResponse() {
    return segmentationResponse;
}
public void setSegmentationResponse(SegmentationResponse segmentationResponse) {
    this.segmentationResponse = segmentationResponse;
}
public Boolean getAction() {
    return action;
}
public void setAction(Boolean action) {
    this.action = action;
}
@Override
public String toString() {
	return "SegmentationDetail [segmentationResponse=" + segmentationResponse + ", action=" + action
			+ ", rejectionSystem=" + rejectionSystem + "]";
}
}
