package com.bajaj.markets.credit.application.bean;
import java.util.List;
public class SegmentationResponse {
    private String customerSegment;
    private String customerProfileSegment;
    private String microSegment;
    private String employerClassification;
    private String profileIncomeSegment;
    private List<PrincipalProductDetails>principalProductDetails;
    public String getCustomerSegment() {
        return customerSegment;
    }
    public void setCustomerSegment(String customerSegment) {
        this.customerSegment = customerSegment;
    }
    public String getCustomerProfileSegment() {
        return customerProfileSegment;
    }
    public void setCustomerProfileSegment(String customerProfileSegment) {
        this.customerProfileSegment = customerProfileSegment;
    }
    public String getMicroSegment() {
        return microSegment;
    }
    public void setMicroSegment(String microSegment) {
        this.microSegment = microSegment;
    }
    public List<PrincipalProductDetails> getPrincipalProductDetails() {
        return principalProductDetails;
    }
    public void setPrincipalProductDetails(List<PrincipalProductDetails> principalProductDetails) {
        this.principalProductDetails = principalProductDetails;
    }
    public String getEmployerClassification() {
        return employerClassification;
    }
    public void setEmployerClassification(String employerClassification) {
        this.employerClassification = employerClassification;
    }
    public String getProfileIncomeSegment() {
        return profileIncomeSegment;
    }
    public void setProfileIncomeSegment(String profileIncomeSegment) {
        this.profileIncomeSegment = profileIncomeSegment;
    }
	
	@Override
	public String toString() {
		return "SegmentationResponse [customerSegment=" + customerSegment + ", customerProfileSegment="
				+ customerProfileSegment + ", microSegment=" + microSegment + ", employerClassification="
				+ employerClassification + ", profileIncomeSegment=" + profileIncomeSegment
				+ ", principalProductDetails=" + principalProductDetails + "]";
	}
    
    
}
