package com.bajaj.markets.credit.application.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PropertyDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	private boolean isPropertyIdentified;

	private BigDecimal propertySizeBHK;

	private BigDecimal propertySizeInSqrFeet;

	@JsonProperty("propertyRefference")
	private Long appPropertyDetKey;

	@JsonIgnore
	private boolean created;

	private String builderName;

	private String projectName;

	private BigDecimal propertyCost;

	private String propertyStatus;

	private String propertyType;

	private String propertyUsage;

	private Integer searchAssistRequired;

	private BigDecimal userBudget;
	
	private BigDecimal propertyMarketValue;

	public boolean getIsPropertyIdentified() {
		return isPropertyIdentified;
	}

	public void setIsPropertyIdentified(boolean isPropertyIdentified) {
		this.isPropertyIdentified = isPropertyIdentified;
	}

	public BigDecimal getPropertySizeBHK() {
		return propertySizeBHK;
	}

	public void setPropertySizeBHK(BigDecimal propertySizeBHK) {
		this.propertySizeBHK = propertySizeBHK;
	}

	public BigDecimal getPropertySizeInSqrFeet() {
		return propertySizeInSqrFeet;
	}

	public void setPropertySizeInSqrFeet(BigDecimal propertySizeInSqrFeet) {
		this.propertySizeInSqrFeet = propertySizeInSqrFeet;
	}

	public Long getAppPropertyDetKey() {
		return appPropertyDetKey;
	}

	public void setAppPropertyDetKey(Long appPropertyDetKey) {
		this.appPropertyDetKey = appPropertyDetKey;
	}

	public boolean isCreated() {
		return created;
	}

	public void setCreated(boolean created) {
		this.created = created;
	}

	public String getBuilderName() {
		return builderName;
	}

	public void setBuilderName(String builderName) {
		this.builderName = builderName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public BigDecimal getPropertyCost() {
		return propertyCost;
	}

	public void setPropertyCost(BigDecimal propertyCost) {
		this.propertyCost = propertyCost;
	}

	public String getPropertyStatus() {
		return propertyStatus;
	}

	public void setPropertyStatus(String propertyStatus) {
		this.propertyStatus = propertyStatus;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public String getPropertyUsage() {
		return propertyUsage;
	}

	public void setPropertyUsage(String propertyUsage) {
		this.propertyUsage = propertyUsage;
	}

	public Integer getSearchAssistRequired() {
		return searchAssistRequired;
	}

	public void setSearchAssistRequired(Integer searchAssistRequired) {
		this.searchAssistRequired = searchAssistRequired;
	}

	public BigDecimal getUserBudget() {
		return userBudget;
	}

	public void setUserBudget(BigDecimal userBudget) {
		this.userBudget = userBudget;
	}

	public BigDecimal getPropertyMarketValue() {
		return propertyMarketValue;
	}

	public void setPropertyMarketValue(BigDecimal propertyMarketValue) {
		this.propertyMarketValue = propertyMarketValue;
	}

	@Override
	public String toString() {
		return "PropertyDetails [isPropertyIdentified=" + isPropertyIdentified + ", propertySizeBHK=" + propertySizeBHK + ", propertySizeInSqrFeet=" + propertySizeInSqrFeet + ", appPropertyDetKey=" + appPropertyDetKey + ", created=" + created
				+ ", builderName=" + builderName + ", projectName=" + projectName + ", propertyCost=" + propertyCost + ", propertyStatus=" + propertyStatus + ", propertyType=" + propertyType + ", propertyUsage=" + propertyUsage
				+ ", searchAssistRequired=" + searchAssistRequired + ", userBudget=" + userBudget + ", propertyMarketValue=" + propertyMarketValue + "]";
	}
}
