package com.bajaj.markets.credit.application.repository;

import java.util.List;
import java.util.Optional;

public interface ReadInterface<T, ID> {
	default boolean isReadOnly() {
		return false;
	}

	Optional<T> findById(ID id);

	List<T> findAll();

	List<T> findAllById(Iterable<ID> ids);

	T getOne(ID id);

	boolean existsById(ID id);

	long count();
}