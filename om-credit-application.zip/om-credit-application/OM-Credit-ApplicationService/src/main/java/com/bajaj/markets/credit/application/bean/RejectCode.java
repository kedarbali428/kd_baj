package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class RejectCode {

	private List<String> rejectCodeList;

	public List<String> getRejectCodeList() {
		return rejectCodeList;
	}

	public void setRejectCodeList(List<String> rejectCodeList) {
		this.rejectCodeList = rejectCodeList;
	}

	@Override
	public String toString() {
		return "RejectCode [rejectCodeList=" + rejectCodeList + "]";
	}

}
