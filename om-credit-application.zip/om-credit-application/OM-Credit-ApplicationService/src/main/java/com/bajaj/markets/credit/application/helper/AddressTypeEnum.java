package com.bajaj.markets.credit.application.helper;

public enum AddressTypeEnum {

	CURRENT(50l), OFFICE(46l), PERMANENT(48l), OTHERS(52l), DELIVERY(56l);

	private final Long value;

	private AddressTypeEnum(Long value) {
		this.value = value;
	}

	public Long getValue() {
		return this.value;
	}

}
