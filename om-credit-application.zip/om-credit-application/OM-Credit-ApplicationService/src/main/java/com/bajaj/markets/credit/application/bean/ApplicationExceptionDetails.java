package com.bajaj.markets.credit.application.bean;


public class ApplicationExceptionDetails {

	
	private Integer percentageCompletionFrom;
	
	private Integer percentageCompletionTo;

	private Integer subStageKey;

	public Integer getPercentageCompletionFrom() {
		return percentageCompletionFrom;
	}

	public void setPercentageCompletionFrom(Integer percentageCompletionFrom) {
		this.percentageCompletionFrom = percentageCompletionFrom;
	}

	public Integer getPercentageCompletionTo() {
		return percentageCompletionTo;
	}

	public void setPercentageCompletionTo(Integer percentageCompletionTo) {
		this.percentageCompletionTo = percentageCompletionTo;
	}
	
	public Integer getSubStageKey() {
		return subStageKey;
	}
	public void setSubStageKey(Integer subStageKey) {
		this.subStageKey = subStageKey;
	}
	



}
