package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class VasPlan {
	private String planCode;
	private String planName;
	private String planFriendlyName;
	private String planType;
	private List<VasProduct> bundle;

	public String getPlanCode() {
		return planCode;
	}

	public String getPlanName() {
		return planName;
	}

	public String getPlanFriendlyName() {
		return planFriendlyName;
	}

	public String getPlanType() {
		return planType;
	}

	public List<VasProduct> getBundle() {
		return bundle;
	}

}
