package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class PrincipalProductDetailsInput {

	private String loanTypeRecommendation;
	private String principleProductCode;
	private List<OfferDetailsBean> offerDetails;
	private Integer isTenor;
	private Integer dropLineTenor;
	private Integer emiAmount;
	private BigDecimal roi;
	private Integer totalLoanAmount;
	private String city;
	private Integer requiredLoanAmount;
	private Integer fppAmount;

	public String getLoanTypeRecommendation() {
		return loanTypeRecommendation;
	}

	public void setLoanTypeRecommendation(String loanTypeRecommendation) {
		this.loanTypeRecommendation = loanTypeRecommendation;
	}

	public String getPrincipleProductCode() {
		return principleProductCode;
	}

	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}

	public List<OfferDetailsBean> getOfferDetails() {
		return offerDetails;
	}

	public void setOfferDetails(List<OfferDetailsBean> offerDetails) {
		this.offerDetails = offerDetails;
	}

	public Integer getIsTenor() {
		return isTenor;
	}

	public void setIsTenor(Integer isTenor) {
		this.isTenor = isTenor;
	}

	public Integer getDroplineTenor() {
		return dropLineTenor;
	}

	public void setDroplineTenor(Integer droplineTenor) {
		this.dropLineTenor = droplineTenor;
	}

	public Integer getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(Integer emiAmount) {
		this.emiAmount = emiAmount;
	}

	public BigDecimal getRoi() {
		return roi;
	}

	public void setRoi(BigDecimal roi) {
		this.roi = roi;
	}

	public Integer getTotalLoanAmount() {
		return totalLoanAmount;
	}

	public void setTotalLoanAmount(Integer totalLoanAmount) {
		this.totalLoanAmount = totalLoanAmount;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(Integer requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public Integer getFppAmount() {
		return fppAmount;
	}

	public void setFppAmount(Integer fppAmount) {
		this.fppAmount = fppAmount;
	}

	@Override
	public String toString() {
		return "PrincipalProductDetailsInput [loanTypeRecommendation=" + loanTypeRecommendation
				+ ", principleProductCode=" + principleProductCode + ", offerDetails=" + offerDetails + ", isTenor="
				+ isTenor + ", dropLineTenor=" + dropLineTenor + ", emiAmount=" + emiAmount + ", roi=" + roi
				+ ", totalLoanAmount=" + totalLoanAmount + ", city=" + city + ", requiredLoanAmount="
				+ requiredLoanAmount + ", fppAmount=" + fppAmount + "]";
	}

	
}
