package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the card_product_detail database table.
 * 
 */
@Entity
@Table(name = "card_product_detail", schema = "dmcredit")
public class CardProductDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	private BigDecimal annualfee;

	private String feature;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;
	@Id
	private Long prodkey;

	private String promotionaloffer;

	private String rewardpoint;

	public CardProductDetail() {
	}

	public BigDecimal getAnnualfee() {
		return this.annualfee;
	}

	public void setAnnualfee(BigDecimal annualfee) {
		this.annualfee = annualfee;
	}

	public String getFeature() {
		return this.feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdkey() {
		return this.prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getPromotionaloffer() {
		return this.promotionaloffer;
	}

	public void setPromotionaloffer(String promotionaloffer) {
		this.promotionaloffer = promotionaloffer;
	}

	public String getRewardpoint() {
		return this.rewardpoint;
	}

	public void setRewardpoint(String rewardpoint) {
		this.rewardpoint = rewardpoint;
	}

}