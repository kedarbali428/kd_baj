package com.bajaj.markets.credit.application.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.MasterDataBean;
import com.bajaj.markets.credit.application.bean.PinCodeServiceableBean;
import com.bajaj.markets.credit.application.bean.ProductBean;
import com.bajaj.markets.credit.application.bean.Reference;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.Application;
import com.bajaj.markets.credit.application.service.ApplicationMasterDataService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationMasterDataController {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private ApplicationMasterDataService applicationMasterDataService;
	
	
	private static final String CLASS_NAME = ApplicationMasterDataController.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching Status master Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get statusmaster", notes = "Get status master", httpMethod = "GET")
	@GetMapping(value = "/v2/creditapplication/status", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getStatusMaster(
			@RequestHeader HttpHeaders headers){
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getStatusMaster ");
		
		List<MasterDataBean> statusMaster = applicationMasterDataService.getStatusMaster();
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getStatusMaster:" +statusMaster );
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getStatusMaster method ");
		
		return new ResponseEntity<>(statusMaster, HttpStatus.OK);
		
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching Stage master Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get stage master", notes = "Get stage master", httpMethod = "GET")
	@GetMapping(value = "/v2/creditapplication/stage", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getStageMaster(@RequestParam(name = "l2ProdCode", required = false) Long l2ProdCode,
			@RequestHeader HttpHeaders headers){
		
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getStageMaster ");
		
		List<MasterDataBean> stageMaster = applicationMasterDataService.getStageMaster(l2ProdCode);
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getStageMaster:" +stageMaster );
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getStageMaster method ");
		
		return new ResponseEntity<>(stageMaster, HttpStatus.OK);
		
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching Rejection code master Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get rejection Codes ", notes = "Get Rejection code master", httpMethod = "GET")
	@GetMapping(value = "/v2/creditapplication/rejectioncode", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getRejectionCodes(@RequestParam(name = "l2ProdCode", required = false) Long l2ProdCode,
			@RequestParam(name = "categorycd", required = false) Character categoryCd,
			@RequestHeader HttpHeaders headers){
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getRejectionCodes ");
		
		List<MasterDataBean> rejectionCodeMaster = applicationMasterDataService.getRejectionCodes(l2ProdCode,categoryCd);
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getRejectionCodes:" +rejectionCodeMaster );
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getRejectionCodes method ");
		
		return new ResponseEntity<>(rejectionCodeMaster, HttpStatus.OK);
		
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching Sub stage master Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get sub satge master  ", notes = "Get Sub stage  master", httpMethod = "GET")
	@GetMapping(value = "/v2/creditapplication/substages", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getSubStageMaster(@RequestParam(name = "l2ProdCode") Long l2ProdCode,
			@RequestHeader HttpHeaders headers){
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getSubStageMaster ");
		
		
		
		List<MasterDataBean> subStageMaster = applicationMasterDataService.getSubStageMaster(l2ProdCode);
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getSubStageMaster:" +subStageMaster );
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getSubStageMaster method ");
		
		return new ResponseEntity<>(subStageMaster, HttpStatus.OK);
		
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.SYSTEMPARTNER,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching product master Successful.", response = ProductBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get prodcut master  ", notes = "Get product master", httpMethod = "GET")
	@GetMapping(value = "/v2/creditapplication/products", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getProductMaster(@RequestParam(name = "l2ProdCode", required = false) Long l2ProdCode,
			@RequestHeader HttpHeaders headers){
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getProductMaster ");
		
		List<MasterDataBean> productBeans = applicationMasterDataService.getProductMaster(l2ProdCode);
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getProductMaster:" +productBeans );
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getProductMaster method ");
		return new ResponseEntity<>(productBeans, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching product master Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get prodcut master  ", notes = "Get disposition master", httpMethod = "GET")
	@GetMapping(value = "/v2/creditapplication/dispositions", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getDispositionCode(
			@RequestParam(name = "functionCode", required = false) Long functionCode,
			@RequestParam(name = "applicationKey", required = false) Long applicationKey,
			@RequestParam(name = "dispositioncategory", required = false) Integer dispositioncategory,
			@RequestParam(name = "l2ProdCode", required = false) Long l2ProdCode,
			@RequestHeader HttpHeaders headers) {
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getDispositionCode ");
		final List<MasterDataBean> disposition = applicationMasterDataService.getDispositionCode();
		List<MasterDataBean> dispositions = new ArrayList<>();	
		Long prodcatkey =null;
		Application application  = null;
		if(null != applicationKey && 0 != applicationKey) {
			 application = applicationMasterDataService.getApplicationDetails(applicationKey);
			 if(null != application) {
				 prodcatkey = application.getProdcdl2();	 
			 }
		} else {
			prodcatkey = l2ProdCode;
		}
		Long prodkey =null ;		
		if (null != functionCode && null != prodcatkey && null != dispositioncategory) {
			Long functionKey = applicationMasterDataService.getFunctionKeyByFunctionCode(functionCode,headers);
			if(dispositioncategory==3) {
				prodkey = application.getProdcdl3();
			}
			if (null != prodkey) {
				List<Long> dispositionCodeProdMaps = applicationMasterDataService
						.findByFunctionkeyAndProdcatkeyAndProdkey(functionKey, prodcatkey, prodkey);
				dispositions = disposition.stream().filter(item -> item.getDispositioncategory() == dispositioncategory)
						.filter(item -> dispositionCodeProdMaps.contains(Long.parseLong(item.getId())))
						.collect(Collectors.toList());
			} else {
				List<Long> dispositionCodeProdMaps = applicationMasterDataService.findByFunctionkeyAndProdcatkey(functionKey,
						prodcatkey);
				dispositions = disposition.stream().filter(item -> item.getDispositioncategory() == dispositioncategory)
						.filter(item -> dispositionCodeProdMaps.contains(Long.parseLong(item.getId())))
						.collect(Collectors.toList());
			}
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getDispositionCode:" + disposition);
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getDispositionCode method ");
			return new ResponseEntity<>(disposition, HttpStatus.OK);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getDispositionCode:" + dispositions);
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getDispositionCode method ");
		return new ResponseEntity<>(dispositions, HttpStatus.OK);
	}
	
	

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL,Role.INTERNAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {

			@ApiResponse(code = 200, message = "Pincode serviceable master Successfully.", response = ProductBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get pincode serviceable master ", notes = "Get pincode serviceable master", httpMethod = "GET")
	@GetMapping(value = "/v1/creditapplication/pincodes/{pincodekey}/products/{prodkey}/pincode", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getPincodeDetails(@PathVariable("pincodekey") String pincodekey,@PathVariable("prodkey") String prodkey,
			@RequestHeader HttpHeaders headers){
		Long pinCodeKey=Long.valueOf(pincodekey).longValue();
		Long l3ProdKey=Long.valueOf(prodkey).longValue();
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getPincodeDetails pincodekey:" +pinCodeKey +"prodkey: "+l3ProdKey );
		PinCodeServiceableBean pinCodeServiceableBean = applicationMasterDataService.getPincodeDetails(pinCodeKey,l3ProdKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END getPincodeDetails pincodekey:" +pinCodeKey +"prodkey: "+l3ProdKey );
		return new ResponseEntity<>(pinCodeServiceableBean, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching product master Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get verfication flag  master  ", notes = "Get disposition master", httpMethod = "GET")
	@GetMapping(value = "/v2/creditapplication/verficationflag", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin	
	public ResponseEntity<?> getverficationFlag(	@RequestHeader HttpHeaders headers) {
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getverficationFlag ");
		List<MasterDataBean> verficationFlagMaster = applicationMasterDataService.getVerficationFlag();
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getverficationFlag:" +verficationFlagMaster );
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getverficationFlag method ");
		
		return new ResponseEntity<>(verficationFlagMaster, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching sub dispositions Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get sub disposition", notes = "Get sub disposition", httpMethod = "GET")
	@GetMapping(value = "/v1/creditapplication/subdispositions", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin	
	public ResponseEntity<?> getSubDispositionCode(
			@RequestParam(name = "functionCode", required = false) Long functionCode,
			@RequestParam(name = "dispositioncategory", required = false) Integer dispositioncategory,
			@RequestParam(name = "l2ProdCode", required = false) Long l2ProdCode,
			@RequestHeader HttpHeaders headers) {
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getDispositionCode ");
		
		final List<MasterDataBean> subDispositions = applicationMasterDataService.getSubDispositionCode(functionCode,dispositioncategory,l2ProdCode);
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getSubDispositionCode:" + subDispositions);
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getSubDispositionCode method ");
		return new ResponseEntity<>(subDispositions, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetching Segment master Successful.", response = MasterDataBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@ApiOperation(value = "Get segmentMaster", notes = "Get segment Master", httpMethod = "GET")
	@GetMapping(value = "/v1/creditapplication/segment", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getSegmentMaster(
			@RequestHeader HttpHeaders headers){
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "START: getSegmentMaster ");
		
		List<MasterDataBean> segmentMaster = applicationMasterDataService.getSegmentMaster();
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getSegmentMaster:" +segmentMaster );
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "END: getSegmentMaster method ");
		
		return new ResponseEntity<>(segmentMaster, HttpStatus.OK);
		
	}

	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch servicable master data.", notes = "Fetch servicable master data.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched data for given principal", response = Reference.class, responseContainer = "list"),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@GetMapping("/v1/credit/principals/{principalKey}/reference-attributes/{referenceAttributeCode}/serviceable-codes")
	@CrossOrigin
	public ResponseEntity<List<Reference>> getServiceableMasterData(
			@PathVariable("principalKey") @NotBlank(message = "Principalkey can not be null or empty") String principalKey,
			@PathVariable("referenceAttributeCode") @NotBlank(message = "ReferenceAttributeCode can not be null or empty") String serviceableCode,
			@ApiParam(name = "status", value = "Status of isactive flag of entry. accepted value: all , active", example = "all,active") @RequestParam("status") String status) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"ApplicationMaster data controller: getServiceableMasterData Start");
		List<Reference> serviceableMasterData = applicationMasterDataService
				.getServiceableMasterData(Long.valueOf(principalKey), serviceableCode, status);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"ApplicationMaster data controller: getServiceableMasterData End");
		return new ResponseEntity<>(serviceableMasterData, HttpStatus.OK);

	}

}
