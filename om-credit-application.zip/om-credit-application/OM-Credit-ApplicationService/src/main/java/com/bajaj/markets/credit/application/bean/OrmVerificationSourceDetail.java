package com.bajaj.markets.credit.application.bean;



public class OrmVerificationSourceDetail {
	private OrmSourceName sourceName;
	private String sourceValue;
	public OrmSourceName getSourceName() {
		return sourceName;
	}
	public void setSourceName(OrmSourceName sourceName) {
		this.sourceName = sourceName;
	}
	public String getSourceValue() {
		return sourceValue;
	}
	public void setSourceValue(String sourceValue) {
		this.sourceValue = sourceValue;
	}
	@Override
	public String toString() {
		return "OrmVerificationSourceDetail [sourceName=" + sourceName + ", sourceValue=" + sourceValue + "]";
	}
	
}
