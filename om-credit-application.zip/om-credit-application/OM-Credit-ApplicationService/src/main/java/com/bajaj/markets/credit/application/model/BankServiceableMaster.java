package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the bank_serviceable_master database table.
 * 
 */
@Entity
@Table(name="bank_serviceable_master", schema = "dmcredit")
public class BankServiceableMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long bankservicekey;

	private Integer bankmastkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String partnerbankcode;

	private Long partnerbankid;

	private String partnerbankname;

	private Long principalkey;

	public BankServiceableMaster() {
		//No implementation
	}

	public Long getBankservicekey() {
		return this.bankservicekey;
	}

	public void setBankservicekey(Long bankservicekey) {
		this.bankservicekey = bankservicekey;
	}

	public Integer getBankmastkey() {
		return this.bankmastkey;
	}

	public void setBankmastkey(Integer bankmastkey) {
		this.bankmastkey = bankmastkey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getPartnerbankcode() {
		return this.partnerbankcode;
	}

	public void setPartnerbankcode(String partnerbankcode) {
		this.partnerbankcode = partnerbankcode;
	}

	public Long getPartnerbankid() {
		return this.partnerbankid;
	}

	public void setPartnerbankid(Long partnerbankid) {
		this.partnerbankid = partnerbankid;
	}

	public String getPartnerbankname() {
		return this.partnerbankname;
	}

	public void setPartnerbankname(String partnerbankname) {
		this.partnerbankname = partnerbankname;
	}

	public Long getPrincipalkey() {
		return this.principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

}