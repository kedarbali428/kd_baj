package com.bajaj.markets.credit.application.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "negative_area_master", schema="dmcredit")
public class NegativeAreaMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer negativeareakey;
	
	private Long pincodekey;
	
	private Long principalkey;
	
	private Long prodkey;
	
	private String areadesc;
	
	private Integer isactive;

	public Integer getNegativeareakey() {
		return negativeareakey;
	}

	public void setNegativeareakey(Integer negativeareakey) {
		this.negativeareakey = negativeareakey;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public Long getPrincipalkey() {
		return principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getAreadesc() {
		return areadesc;
	}

	public void setAreadesc(String areadesc) {
		this.areadesc = areadesc;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

}
