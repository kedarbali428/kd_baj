package com.bajaj.markets.credit.application.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.application.bean.CardsAndLoansProductDetails;
import com.bajaj.markets.credit.application.bean.ProductDetails;
import com.bajaj.markets.credit.application.bean.Products;
import com.bajaj.markets.credit.application.bean.SegmentationDetail;
import com.bajaj.markets.credit.application.finegrain.EnableFineGrainCheck;
import com.bajaj.markets.credit.application.helper.CreditApplicationServiceException;
import com.bajaj.markets.credit.application.helper.ErrorBean;
import com.bajaj.markets.credit.application.model.Product;
import com.bajaj.markets.credit.application.service.ApplicationsProductListService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class ApplicationsProductListController {
	@Autowired
	private ApplicationsProductListService applicationsProductListService;
	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASSNAME = ApplicationsProductListController.class.getName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update or create the appliation for card listing", notes = "Update or create the application for card listing.", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Product details updated successfully.", response = ProductDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(path = "/v1/applications/{applicationid}/productlist")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> updateProduct(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@Valid @RequestBody ProductDetails productDetails, BindingResult result, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateProduct method controller for applicationId: "+applicationId);
		if (result.hasErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception: ApplicationId should be number");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_030", result.getFieldErrors().get(0).getDefaultMessage()));
		}
		ProductDetails updateProduct = applicationsProductListService.updateProduct(applicationId, productDetails);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateProduct method controller End for applicationId: "+applicationId);
		return new ResponseEntity<>(updateProduct, HttpStatus.OK);
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE, Role.INTERNAL, Role.B2BPARTNER})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch list of card.", notes = "Fetch list of card to be displayed on cardlist page.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Product details fetched successfully.", response = Products.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/applications/{applicationid}/productlist")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> productList(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestParam(name = "showonlyeligible", required = false, defaultValue = "false") Boolean showOnlyEligible,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside productList for applicationId: " + applicationId);
		Products products = null;
		if (StringUtils.isNumeric(applicationId)) {
			products = applicationsProductListService.products(applicationId,showOnlyEligible);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside productList End for applicationId: " + applicationId);
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception: ApplicationId should be number");
			throw new CreditApplicationServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_033", "ApplicationId should be number."));
		}
		return new ResponseEntity<>(products, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Updating Listing BRE response for Loan and Card.", notes = "Updating Listing BRE response for Loan and Card.", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Product details updated successfully.", response = Product.class, responseContainer ="List"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(path = "/v1/applications/{applicationid}/creditlisting")
	@CrossOrigin
	@EnableFineGrainCheck
	public ResponseEntity<Object> updateProductCredits(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@Valid @RequestBody CardsAndLoansProductDetails productDetails, BindingResult result, 
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateProductCredits method controller for applicationId: "+applicationId );
		List<com.bajaj.markets.credit.application.bean.Product> productList = null;
		
		productList = applicationsProductListService.updateCLProduct(applicationId, productDetails);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateProductCredits method controller End for applicationId: "+applicationId);
		return new ResponseEntity<>(productList, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
    @ApiOperation(value = "Updating segmentation BRE response", notes = "Updating segmentation BRE response", httpMethod = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "App Segmentation details updated successfully.", response = SegmentationDetail.class),
            @ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
            @ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
            @ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
            @ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
            @ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
    @PostMapping(path = "/v1/creditapplication/applications/{applicationid}/segmentation")
    @CrossOrigin
    @EnableFineGrainCheck
    public ResponseEntity<Object> saveSegmentationDeatil(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
            @Valid @RequestBody SegmentationDetail segmentationDetail, BindingResult result, 
            @RequestHeader HttpHeaders headers) {
        logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
                "Inside saveSegmentationDeatil method controller for applicationId: "+applicationId );
         SegmentationDetail segmentationDetailData = applicationsProductListService.saveSegmentationDetails(applicationId, segmentationDetail);
        logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
                "Inside updateProductCredits method controller End for applicationId: "+applicationId);
        return new ResponseEntity<>(segmentationDetailData, HttpStatus.OK);
    }
	
}
