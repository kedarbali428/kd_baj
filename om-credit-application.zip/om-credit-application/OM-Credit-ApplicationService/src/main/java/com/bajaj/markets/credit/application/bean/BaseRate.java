package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class BaseRate {
	
	private String baseRateCode;
	private BigDecimal baseRateValue;
	public String getBaseRateCode() {
		return baseRateCode;
	}
	public void setBaseRateCode(String baseRateCode) {
		this.baseRateCode = baseRateCode;
	}
	public BigDecimal getBaseRateValue() {
		return baseRateValue;
	}
	public void setBaseRateValue(BigDecimal baseRateValue) {
		this.baseRateValue = baseRateValue;
	}
	
}
