package com.bajaj.markets.credit.application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.bajaj.markets.credit.application.model.ApplicationEmail;

public interface ApplicationEmailRoInterface extends ReadInterface<ApplicationEmail, Long> {

	public ApplicationEmail findByAppattrbkeyAndEmailtypekeyAndIsactive(Long appattrbkey, Long emailtypekey,
			Integer isactive);

	public List<ApplicationEmail> findByAppattrbkeyAndIsactive(Long appattrbkey, Integer isactive);

	@Query("from ApplicationEmail where appattrbkey=:appattrbkey and isactive=:isactive and emailtypekey IN (:emailtypekeysList)")
	public List<ApplicationEmail> findByAppattrbkeyAndIsactiveAndEmailtypekey(Long appattrbkey, Integer isactive,
			List<Long> emailtypekeysList);

}
