package com.bajaj.markets.credit.application.bean;

public class PropertyPincode {
	private Boolean oglFlag;
	private String negativeAreaFlag;

	public Boolean getOglFlag() {
		return oglFlag;
	}

	public void setOglFlag(Boolean oglFlag) {
		this.oglFlag = oglFlag;
	}

	public String getNegativeAreaFlag() {
		return negativeAreaFlag;
	}

	public void setNegativeAreaFlag(String negativeAreaFlag) {
		this.negativeAreaFlag = negativeAreaFlag;
	}

	@Override
	public String toString() {
		return "PropertyPincode [oglFlag=" + oglFlag + ", negativeAreaFlag=" + negativeAreaFlag + "]";
	}
}
