package com.bajaj.markets.credit.application.bean;

public class ProdCategory {

	private Long prodcatkey;
	private String prodCatCode;

	private String prodCatDesc;

	public Long getProdcatkey() {
		return prodcatkey;
	}

	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public String getProdCatCode() {
		return prodCatCode;
	}

	public void setProdCatCode(String prodCatCode) {
		this.prodCatCode = prodCatCode;
	}

	public String getProdCatDesc() {
		return prodCatDesc;
	}

	public void setProdCatDesc(String prodCatDesc) {
		this.prodCatDesc = prodCatDesc;
	}

	@Override
	public String toString() {
		return "ProdCategory [prodcatkey=" + prodcatkey + ", prodCatCode=" + prodCatCode + ", prodCatDesc="
				+ prodCatDesc + "]";
	}

}
