package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class PrincipalDocumenDetails {

	private List<Long> principleDocTypeKeys;

	public List<Long> getPrincipleDocTypeKeys() {
		return principleDocTypeKeys;
	}

	public void setPrincipleDocTypeKeys(List<Long> principleDocTypeKeys) {
		this.principleDocTypeKeys = principleDocTypeKeys;
	}

	@Override
	public String toString() {
		return "PrincipalDocumenDetails [principleDocTypeKeys=" + principleDocTypeKeys + "]";
	}

}
