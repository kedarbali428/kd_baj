package com.bajaj.markets.credit.application.bean;

import java.util.List;

public class PrincipalProductDetails {
    String principleProductCode;
    private List<String> rejectDetails;
    private Boolean isEligible;
    public String getPrincipleProductCode() {
        return principleProductCode;
    }
    public void setPrincipleProductCode(String principleProductCode) {
        this.principleProductCode = principleProductCode;
    }
    public List<String> getRejectDetails() {
        return rejectDetails;
    }
    public void setRejectDetails(List<String> rejectDetails) {
        this.rejectDetails = rejectDetails;
    }
    public Boolean getIsEligible() {
        return isEligible;
    }
    public void setIsEligible(Boolean isEligible) {
        this.isEligible = isEligible;
    }
	@Override
	public String toString() {
		return "PrincipalProductDetails [principleProductCode=" + principleProductCode + ", rejectDetails="
				+ rejectDetails + ", isEligible=" + isEligible + "]";
	}
    
}
