package com.bajaj.markets.credit.application.helper;

/**
 * Enum to map string representation of document type with its numeric value
 * 
 * @author 764504
 *
 */
public enum ApplicationDocumentsEnum {

	PAN(1L), CIBILREFERENCEKEY(2L);

	private final Long value;

	private ApplicationDocumentsEnum(Long value) {
		this.value = value;
	}

	public Long getValue() {
		return value;
	}

}
