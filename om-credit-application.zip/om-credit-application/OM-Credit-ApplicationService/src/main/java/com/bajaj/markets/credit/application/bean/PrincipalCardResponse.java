package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;
import java.util.List;

public class PrincipalCardResponse {
	
	private PrincipalApplicationAttribute applicationAttribute;
	private PrincipalOccupationDetail principalOccupationDetail;
	private List<PrincipalAppAddress> applicationAddress;
	private PrincipalLoanDetails apploanDetails;
	private String creditCardProductType;
	private String emailAddress;
	private String officialEmailAddress;
	private BigDecimal customerPreferredSalary;
	private Long prodKey;
	private PrincipalPropertyDetails principalPropertyDetails;
	private List<PrincipalBankLeadPushRequest> principalBankLeadPushRequest;
	private PrincipleCustomerInfoBean principleCustomerInfoBean;
	private PrincipalAppOfferDet principalAppOfferDet;
	

	private String alternateMobileNumber;
	private AppProductListingBean principalAppProductListing;
	
	public AppProductListingBean getPrincipalAppProductListing() {
		return principalAppProductListing;
	}
	public void setPrincipalAppProductListing(AppProductListingBean principalAppProductListing) {
		this.principalAppProductListing = principalAppProductListing;
	}
	public PrincipalApplicationAttribute getApplicationAttribute() {
		return applicationAttribute;
	}
	public void setApplicationAttribute(PrincipalApplicationAttribute applicationAttribute) {
		this.applicationAttribute = applicationAttribute;
	}
	public PrincipalOccupationDetail getPrincipalOccupationDetail() {
		return principalOccupationDetail;
	}
	public void setPrincipalOccupationDetail(PrincipalOccupationDetail principalOccupationDetail) {
		this.principalOccupationDetail = principalOccupationDetail;
	}
	public List<PrincipalAppAddress> getApplicationAddress() {
		return applicationAddress;
	}
	public void setApplicationAddress(List<PrincipalAppAddress> applicationAddress) {
		this.applicationAddress = applicationAddress;
	}
	public PrincipalLoanDetails getApploanDetails() {
		return apploanDetails;
	}
	public void setApploanDetails(PrincipalLoanDetails apploanDetails) {
		this.apploanDetails = apploanDetails;
	}
	public String getCreditCardProductType() {
		return creditCardProductType;
	}
	public void setCreditCardProductType(String creditCardProductType) {
		this.creditCardProductType = creditCardProductType;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getOfficialEmailAddress() {
		return officialEmailAddress;
	}
	public void setOfficialEmailAddress(String officialEmailAddress) {
		this.officialEmailAddress = officialEmailAddress;
	}
	public BigDecimal getCustomerPreferredSalary() {
		return customerPreferredSalary;
	}
	public void setCustomerPreferredSalary(BigDecimal customerPreferredSalary) {
		this.customerPreferredSalary = customerPreferredSalary;
	}
	public Long getProdKey() {
		return prodKey;
	}
	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}
	public PrincipalPropertyDetails getPrincipalPropertyDetails() {
		return principalPropertyDetails;
	}
	public void setPrincipalPropertyDetails(PrincipalPropertyDetails principalPropertyDetails) {
		this.principalPropertyDetails = principalPropertyDetails;
	}
	public List<PrincipalBankLeadPushRequest> getPrincipalBankLeadPushRequest() {
		return principalBankLeadPushRequest;
	}
	public void setPrincipalBankLeadPushRequest(List<PrincipalBankLeadPushRequest> principalBankLeadPushRequest) {
		this.principalBankLeadPushRequest = principalBankLeadPushRequest;
	}


	public PrincipleCustomerInfoBean getPrincipleCustomerInfoBean() {
		return principleCustomerInfoBean;
	}

	public void setPrincipleCustomerInfoBean(PrincipleCustomerInfoBean principleCustomerInfoBean) {
		this.principleCustomerInfoBean = principleCustomerInfoBean;
	}

	public PrincipalAppOfferDet getPrincipalAppOfferDet() {
		return principalAppOfferDet;
	}

	public void setPrincipalAppOfferDet(PrincipalAppOfferDet principalAppOfferDet) {
		this.principalAppOfferDet = principalAppOfferDet;
	}
	
	public String getAlternateMobileNumber() {
		return alternateMobileNumber;
	}
	public void setAlternateMobileNumber(String alternateMobileNumber) {
		this.alternateMobileNumber = alternateMobileNumber;
	}
	@Override
	public String toString() {
		return "PrincipalCardResponse [applicationAttribute=" + applicationAttribute + ", principalOccupationDetail="
				+ principalOccupationDetail + ", applicationAddress=" + applicationAddress + ", apploanDetails="
				+ apploanDetails + ", creditCardProductType=" + creditCardProductType + ", emailAddress=" + emailAddress
				+ ", officialEmailAddress=" + officialEmailAddress + ", customerPreferredSalary="
				+ customerPreferredSalary + ", prodKey=" + prodKey + ", principalPropertyDetails="
				+ principalPropertyDetails + ", principalBankLeadPushRequest=" + principalBankLeadPushRequest
				+ ", principleCustomerInfoBean=" + principleCustomerInfoBean + ", principalAppOfferDet="
				+ principalAppOfferDet + ", alternateMobileNumber=" + alternateMobileNumber
				+ ", principalAppProductListing=" + principalAppProductListing + "]";
	}
	
}
