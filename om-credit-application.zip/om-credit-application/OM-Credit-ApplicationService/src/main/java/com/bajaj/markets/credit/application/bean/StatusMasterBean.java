package com.bajaj.markets.credit.application.bean;

public class StatusMasterBean {
	private Long statuskey;
	private String statusdesc;
	public Long getStatuskey() {
		return statuskey;
	}
	public void setStatuskey(Long statuskey) {
		this.statuskey = statuskey;
	}
	public String getStatusdesc() {
		return statusdesc;
	}
	public void setStatusdesc(String statusdesc) {
		this.statusdesc = statusdesc;
	}
	
}
