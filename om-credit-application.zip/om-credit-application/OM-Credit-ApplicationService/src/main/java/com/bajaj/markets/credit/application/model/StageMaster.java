package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the stage_master database table.
 * 
 */
@Entity
@Table(name="stage_master", schema = "dmcredit")
public class StageMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long stagekey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long prodcatkey;

	private Long prodkey;

	private String stagecode;

	private String stagedesc;

	private Integer stagerank;

	private String stagproducttype;

	//bi-directional many-to-one association to SubstageMaster
	@OneToMany(mappedBy="stageMaster")
	private Set<SubstageMaster> substageMasters;

	public StageMaster() {
	}

	public Long getStagekey() {
		return this.stagekey;
	}

	public void setStagekey(Long stagekey) {
		this.stagekey = stagekey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdcatkey() {
		return this.prodcatkey;
	}

	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public Long getProdkey() {
		return this.prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getStagecode() {
		return this.stagecode;
	}

	public void setStagecode(String stagecode) {
		this.stagecode = stagecode;
	}

	public String getStagedesc() {
		return this.stagedesc;
	}

	public void setStagedesc(String stagedesc) {
		this.stagedesc = stagedesc;
	}

	public Integer getStagerank() {
		return this.stagerank;
	}

	public void setStagerank(Integer stagerank) {
		this.stagerank = stagerank;
	}

	public String getStagproducttype() {
		return this.stagproducttype;
	}

	public void setStagproducttype(String stagproducttype) {
		this.stagproducttype = stagproducttype;
	}

	public Set<SubstageMaster> getSubstageMasters() {
		return this.substageMasters;
	}

	public void setSubstageMasters(Set<SubstageMaster> substageMasters) {
		this.substageMasters = substageMasters;
	}

	public SubstageMaster addSubstageMaster(SubstageMaster substageMaster) {
		getSubstageMasters().add(substageMaster);
		substageMaster.setStageMaster(this);

		return substageMaster;
	}

	public SubstageMaster removeSubstageMaster(SubstageMaster substageMaster) {
		getSubstageMasters().remove(substageMaster);
		substageMaster.setStageMaster(null);

		return substageMaster;
	}

}