package com.bajaj.markets.credit.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
	

/**
 * The persistent class for the principle_customer_info database table.
 * 
 */
@Entity
@Table(name = "principle_customer_info", schema = "dmcredit")
public class PrincipleCustomerInfo implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "principle_customer_infokey_generator", sequenceName = "dmcredit.seq_pk_principle_customer_info", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "principle_customer_infokey_generator")
	private Long principlecustkey;

	private Long applicationkey;
	
	private Long principalkey;
	
	private String principlecustrefid;
	
	private String principlecustrefsrc;
	
	private String isetb;
	
	private BigDecimal livepos;
	
	private Integer isactive;
	
	private String principlecustsegment;
	
	private String principlecusttype;
	
	private Long lstupdateby;
	
	private Timestamp lstupdatedt;
	
	private String btssegment;
	
	private String etbsrc;
	
	private Long appattrbkey;
	
	private Integer wipflag;

	private Integer approvedflag;

	private Integer fraudflag;

	private Integer rejectflag;
	
	private Integer bmr1approvedflag;
	
	private Integer bmr2approvedflag;
	
	private Integer bmr2badflag;
	
	private Integer bmr2disbflag;
	
	private Integer bmr2rejectflag;
	
	private String edwstatus;
	
	private Long finnoneid;

	public PrincipleCustomerInfo() {
		
	}
	
	public Long getPrinciplecustkey() {
		return principlecustkey;
	}

	public void setPrinciplecustkey(Long principlecustkey) {
		this.principlecustkey = principlecustkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getPrincipalkey() {
		return principalkey;
	}

	public void setPrincipalkey(Long principalkey) {
		this.principalkey = principalkey;
	}

	public String getPrinciplecustrefid() {
		return principlecustrefid;
	}

	public void setPrinciplecustrefid(String principlecustrefid) {
		this.principlecustrefid = principlecustrefid;
	}

	public String getPrinciplecustrefsrc() {
		return principlecustrefsrc;
	}

	public void setPrinciplecustrefsrc(String principlecustrefsrc) {
		this.principlecustrefsrc = principlecustrefsrc;
	}

	public String getIsetb() {
		return isetb;
	}

	public void setIsetb(String isetb) {
		this.isetb = isetb;
	}
	
	public BigDecimal getLivepos() {
		return livepos;
	}

	public void setLivepos(BigDecimal livepos) {
		this.livepos = livepos;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public String getPrinciplecustsegment() {
		return principlecustsegment;
	}

	public void setPrinciplecustsegment(String principlecustsegment) {
		this.principlecustsegment = principlecustsegment;
	}

	public String getPrinciplecusttype() {
		return principlecusttype;
	}

	public void setPrinciplecusttype(String principlecusttype) {
		this.principlecusttype = principlecusttype;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getBtssegment() {
		return btssegment;
	}

	public void setBtssegment(String btssegment) {
		this.btssegment = btssegment;
	}

	public String getEtbsrc() {
		return etbsrc;
	}

	public void setEtbsrc(String etbsrc) {
		this.etbsrc = etbsrc;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Integer getWipflag() {
		return wipflag;
	}

	public void setWipflag(Integer wipflag) {
		this.wipflag = wipflag;
	}

	public Integer getApprovedflag() {
		return approvedflag;
	}

	public void setApprovedflag(Integer approvedflag) {
		this.approvedflag = approvedflag;
	}

	public Integer getFraudflag() {
		return fraudflag;
	}

	public void setFraudflag(Integer fraudflag) {
		this.fraudflag = fraudflag;
	}

	public Integer getRejectflag() {
		return rejectflag;
	}

	public void setRejectflag(Integer rejectflag) {
		this.rejectflag = rejectflag;
	}

	public Integer getBmr1approvedflag() {
		return bmr1approvedflag;
	}

	public void setBmr1approvedflag(Integer bmr1approvedflag) {
		this.bmr1approvedflag = bmr1approvedflag;
	}

	public Integer getBmr2approvedflag() {
		return bmr2approvedflag;
	}

	public void setBmr2approvedflag(Integer bmr2approvedflag) {
		this.bmr2approvedflag = bmr2approvedflag;
	}

	public Integer getBmr2badflag() {
		return bmr2badflag;
	}

	public void setBmr2badflag(Integer bmr2badflag) {
		this.bmr2badflag = bmr2badflag;
	}

	public Integer getBmr2disbflag() {
		return bmr2disbflag;
	}

	public void setBmr2disbflag(Integer bmr2disbflag) {
		this.bmr2disbflag = bmr2disbflag;
	}

	public Integer getBmr2rejectflag() {
		return bmr2rejectflag;
	}

	public void setBmr2rejectflag(Integer bmr2rejectflag) {
		this.bmr2rejectflag = bmr2rejectflag;
	}

	public String getEdwstatus() {
		return edwstatus;
	}

	public void setEdwstatus(String edwstatus) {
		this.edwstatus = edwstatus;
	}

	public Long getFinnoneid() {
		return finnoneid;
	}

	public void setFinnoneid(Long finnoneid) {
		this.finnoneid = finnoneid;
	}
	
}
