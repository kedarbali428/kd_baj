package com.bajaj.markets.credit.application.bean;

import java.math.BigDecimal;

public class OfferDetailsBean {

	private String riskOfferType;
	private String offerType;
	private BigDecimal offerAmount;
	private String offerSource;
	private String offerExpiryDate;
	private Boolean offerAcceptedStatus;
	private String offerID;
	private String riskClassification;
	private String offerProgramCode;
	private BigDecimal offerROI;
	private String offerGenerationRule;
	private Boolean isOfferAvailable;

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public BigDecimal getOfferAmount() {
		return offerAmount;
	}

	public void setOfferAmount(BigDecimal offerAmount) {
		this.offerAmount = offerAmount;
	}

	public String getOfferSource() {
		return offerSource;
	}

	public void setOfferSource(String offerSource) {
		this.offerSource = offerSource;
	}

	public String getOfferExpiryDate() {
		return offerExpiryDate;
	}

	public void setOfferExpiryDate(String offerExpiryDate) {
		this.offerExpiryDate = offerExpiryDate;
	}

	public Boolean getOfferAcceptedStatus() {
		return offerAcceptedStatus;
	}

	public void setOfferAcceptedStatus(Boolean offerAcceptedStatus) {
		this.offerAcceptedStatus = offerAcceptedStatus;
	}

	public String getOfferID() {
		return offerID;
	}

	public void setOfferID(String offerID) {
		this.offerID = offerID;
	}

	public String getRiskClassification() {
		return riskClassification;
	}

	public void setRiskClassification(String riskClassification) {
		this.riskClassification = riskClassification;
	}

	public String getOfferProgramCode() {
		return offerProgramCode;
	}

	public void setOfferProgramCode(String offerProgramCode) {
		this.offerProgramCode = offerProgramCode;
	}

	public BigDecimal getOfferROI() {
		return offerROI;
	}

	public void setOfferROI(BigDecimal offerROI) {
		this.offerROI = offerROI;
	}

	public String getOfferGenerationRule() {
		return offerGenerationRule;
	}

	public void setOfferGenerationRule(String offerGenerationRule) {
		this.offerGenerationRule = offerGenerationRule;
	}

	public Boolean getIsOfferAvailable() {
		return isOfferAvailable;
	}

	public void setIsOfferAvailable(Boolean isOfferAvailable) {
		this.isOfferAvailable = isOfferAvailable;
	}

	@Override
	public String toString() {
		return "OfferDetailsBean [riskOfferType=" + riskOfferType + ", offerType=" + offerType + ", offerAmount="
				+ offerAmount + ", offerSource=" + offerSource + ", offerExpiryDate=" + offerExpiryDate
				+ ", offerAcceptedStatus=" + offerAcceptedStatus + ", offerID=" + offerID + ", riskClassification="
				+ riskClassification + ", offerProgramCode=" + offerProgramCode + ", offerROI=" + offerROI
				+ ", offerGenerationRule=" + offerGenerationRule + ", isOfferAvailable=" + isOfferAvailable + "]";
	}

}
