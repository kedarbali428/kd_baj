package com.bajaj.markets.credit.application.repository;

import java.util.List;

import com.bajaj.markets.credit.application.model.AppOccupationSalary;

public interface AppOccupationSalaryRoInterface extends ReadInterface<AppOccupationSalary, Long> {

	AppOccupationSalary findByAppoccupationkeyAndSalarysourceAndIsactive(Long appoccupationKey, String SalarySource,
			Integer isActive);

	public List<AppOccupationSalary> findByAppoccupationkeyAndIsactive(Long appoccupationKey, Integer isActive);

}
